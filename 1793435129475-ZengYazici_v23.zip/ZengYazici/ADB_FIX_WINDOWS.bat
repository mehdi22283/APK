@echo off
setlocal
set "ADB_TARGET=127.0.0.1:5555"
echo Lokal ADB cihazina qosulunur: %ADB_TARGET%
adb connect %ADB_TARGET%
if errorlevel 1 (
  echo Qoşulma alınmadı. Lokal cihazda/emulatorda TCP ADB 5555 portunun aktiv olduğunu yoxlayin.
  pause
  exit /b 1
)
adb -s %ADB_TARGET% get-state >nul 2>&1
if errorlevel 1 (
  echo %ADB_TARGET% ADB cihaz kimi hazir deyil. adb devices -l ile yoxlayin.
  pause
  exit /b 1
)
echo Zeng Yazici icazeleri verilir...
adb -s %ADB_TARGET% shell pm grant com.zengyazici android.permission.RECORD_AUDIO
adb -s %ADB_TARGET% shell pm grant com.zengyazici android.permission.READ_PHONE_STATE
adb -s %ADB_TARGET% shell pm grant com.zengyazici android.permission.READ_CALL_LOG
adb -s %ADB_TARGET% shell pm grant com.zengyazici android.permission.POST_NOTIFICATIONS 2>nul
adb -s %ADB_TARGET% shell appops set com.zengyazici RECORD_AUDIO allow
adb -s %ADB_TARGET% shell appops set com.zengyazici SYSTEM_ALERT_WINDOW allow
adb -s %ADB_TARGET% shell appops set com.zengyazici RUN_IN_BACKGROUND allow
adb -s %ADB_TARGET% shell appops set com.zengyazici RUN_ANY_IN_BACKGROUND allow
adb -s %ADB_TARGET% shell dumpsys deviceidle whitelist +com.zengyazici
adb -s %ADB_TARGET% shell cmd notification allow_listener com.zengyazici/com.zengyazici.WaListener
adb -s %ADB_TARGET% shell am force-stop com.zengyazici
adb -s %ADB_TARGET% shell monkey -p com.zengyazici 1
echo.
echo Bitdi. WhatsApp test zengi edin, sonra proqramin Menyu -^> Log bolmesine baxin.
pause
