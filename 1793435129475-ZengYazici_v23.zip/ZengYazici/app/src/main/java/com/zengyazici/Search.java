package com.zengyazici;

import java.util.Locale;

/** Ad və nömrə üzrə axtarış: böyük/kiçik hərf və Azərbaycan hərfləri (ə→e, ı→i, ö→o …) fərqləndirilmir. */
public class Search {
    public static String fold(String s) {
        if (s == null) return "";
        String t = s.toLowerCase(Locale.ROOT).replace("\u0307", "");
        StringBuilder b = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            switch (c) {
                case 'ə': c = 'e'; break;
                case 'ı': c = 'i'; break;
                case 'ö': c = 'o'; break;
                case 'ü': c = 'u'; break;
                case 'ç': c = 'c'; break;
                case 'ş': c = 's'; break;
                case 'ğ': c = 'g'; break;
                default: break;
            }
            b.append(c);
        }
        return b.toString();
    }

    private static String digits(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) if (Character.isDigit(s.charAt(i))) b.append(s.charAt(i));
        return b.toString();
    }

    /** Sorğu boşdursa hamısı uyğundur. Rəqəmlər üçün baştakı 0 nəzərə alınmır (050… ↔ +99450…). */
    public static boolean match(String hay, String query) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) return true;
        if (hay == null) hay = "";
        if (fold(hay).contains(fold(q))) return true;
        String qd = digits(q);
        if (qd.length() >= 2 && q.matches("[+0-9 ()\\-]+")) {
            int i = 0;
            while (i < qd.length() - 1 && qd.charAt(i) == '0') i++;
            return digits(hay).contains(qd.substring(i));
        }
        return false;
    }
}
