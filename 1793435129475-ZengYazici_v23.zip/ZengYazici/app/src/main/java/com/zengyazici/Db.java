package com.zengyazici;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Db {
    public static class Item {
        public String path, num, app, dir; // dir: "in" / "out"
        public long ts;
        public int dur;
        public String note = "";
    }

    /** Hər dəyişiklikdə artır: ekran bütün siyahını hər dəfə oxumasın deyə. */
    public static volatile int rev;

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("db", 0); }

    public static synchronized List<Item> all(Context c) {
        List<Item> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.path = o.getString("path");
                it.num = o.optString("num");
                it.app = o.optString("app");
                it.dir = o.optString("dir");
                it.ts = o.optLong("ts");
                it.dur = o.optInt("dur");
                it.note = o.optString("note");
                l.add(it);
            }
        } catch (Exception e) { }
        return l;
    }

    private static void save(Context c, List<Item> l) {
        JSONArray a = new JSONArray();
        for (Item it : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("path", it.path); o.put("num", it.num); o.put("app", it.app);
                o.put("dir", it.dir); o.put("ts", it.ts); o.put("dur", it.dur); o.put("note", it.note == null ? "" : it.note);
                a.put(o);
            } catch (Exception e) { }
        }
        sp(c).edit().putString("items", a.toString()).apply();
    }

    public static synchronized void add(Context c, Item it) {
        List<Item> l = all(c);
        l.add(0, it);
        save(c, l);
        rev++;
    }

    public static synchronized void remove(Context c, Item it) {
        List<Item> l = all(c);
        for (Iterator<Item> i = l.iterator(); i.hasNext(); ) {
            if (i.next().path.equals(it.path)) i.remove();
        }
        save(c, l);
        rev++;
    }
}
