package com.zengyazici;

import android.app.Notification;
import android.content.Intent;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * Arxa fonda heç nə işlətmir: sistem yalnız WhatsApp bildirişi gələndə oyadır.
 * Yalnız WhatsApp-ın ZƏNG bildirişinə baxır (mətn oxunmur, saxlanmır; yalnız ad), qalan bildirişləri atır.
 */
public class WaListener extends NotificationListenerService {
    static boolean isWa(StatusBarNotification s) {
        String p = s.getPackageName();
        return "com.whatsapp".equals(p) || "com.whatsapp.w4b".equals(p);
    }

    /** Sistem zəng tətbiqlərinin (dialer) zəng bildirişi. */
    static boolean isPhoneCall(StatusBarNotification s) {
        String p = s.getPackageName();
        boolean dialer = "com.android.incallui".equals(p) || "com.android.phone".equals(p)
                || "com.google.android.dialer".equals(p) || "com.samsung.android.incallui".equals(p)
                || "com.android.server.telecom".equals(p);
        return dialer && Notification.CATEGORY_CALL.equals(s.getNotification().category);
    }

    static boolean isCall(StatusBarNotification s) {
        if (!isWa(s)) return false;
        Notification n = s.getNotification();
        // Yeni WhatsApp versiyaları CallStyle istifadə edir; köhnələri CATEGORY_CALL
        return Notification.CATEGORY_CALL.equals(n.category) || n.extras.containsKey("android.callType");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification s) {
        // Adi telefon zəngi: tətbiq son tətbiqlərdən silinibsə, sistem bu xidməti yenidən bağlayır və zəng bildirişi onu oyadır.
        if (isPhoneCall(s)) { RecService.ensure(this); return; }
        if (!isCall(s)) return;
        Notification n = s.getNotification();
        if (!RecService.waActive) {
            RecService.waActive = true;
            RecService.waDir = n.actions != null && n.actions.length >= 2 ? "in" : "out";
            CharSequence t = n.extras.getCharSequence(Notification.EXTRA_TITLE);
            RecService.waName = t == null ? "" : t.toString();
        }
        if (!RecService.running) {
            RecService.ensure(this, new Intent(this, RecService.class).setAction("wa"));
        }
    }

    @Override
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        try { requestRebind(new android.content.ComponentName(this, WaListener.class)); } catch (Throwable e) { }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification s) {
        if (isCall(s)) RecService.waActive = false;
    }
}
