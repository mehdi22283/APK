package com.zengyazici;

import android.media.AudioFormat;
import android.media.AudioRecord;
import java.io.File;
import java.io.RandomAccessFile;

/**
 * Tətbiqin öz daxilində (ADB-siz) 16 kHz mono WAV yazır.
 * Mənbələr ardıcıl sınanır: 4 (VOICE_CALL, qarşı tərəf də — yalnız icazə verən telefonlarda),
 * 6 (VOICE_RECOGNITION), 1 (MIC), 7 (VOICE_COMMUNICATION).
 * Mənbə açılmırsa və ya ilk 1,5 san ərzində tam səssizlikdirsə (sistem mikrofonu susdurub), növbətisinə keçilir.
 */
public class Recorder {
    public interface Cb { void onSource(int src, boolean far); }

    static final int RATE = 16000;
    static final int[] ORDER = {4, 6, 1, 7};
    private static final long PROBE_MS = 1500;

    private final File out;
    private final Cb cb;
    private volatile boolean stop;
    private Thread t;

    public Recorder(File out, Cb cb) { this.out = out; this.cb = cb; }

    public void start() {
        t = new Thread(this::run, "recorder");
        t.setDaemon(true);
        t.start();
    }

    public void stopAndJoin() {
        stop = true;
        try { if (t != null) t.join(5000); } catch (Throwable e) { }
    }

    private void run() {
        long total = 0;
        try (RandomAccessFile r = new RandomAccessFile(out, "rw")) {
            r.write(new byte[44]);
            long[] tot = {0};
            boolean accepted = false;
            for (int i = 0; i < ORDER.length && !stop && !accepted; i++) {
                int res = session(r, tot, ORDER[i], false);
                if (res == 1) accepted = true;
            }
            if (!stop && !accepted) {
                RecService.log("Heç bir mənbədə səs gəlmədi — son mənbə ilə davam edilir");
                session(r, tot, ORDER[ORDER.length - 1], true);
            }
            total = tot[0];
            RecService.header(r, total);
        } catch (Throwable e) {
            RecService.log("Yazıcı: " + e);
        }
    }

    /** 1 = yazı bu mənbə ilə sona çatdı (qəbul edildi), 0 = mənbə uyğun deyil. */
    private int session(RandomAccessFile r, long[] tot, int src, boolean force) {
        AudioRecord ar = null;
        try {
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            ar = new AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, RATE) * 2);
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) { RecService.log("Mənbə " + src + ": açılmadı"); return 0; }
            ar.startRecording();
            if (ar.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) { RecService.log("Mənbə " + src + ": başlamadı"); return 0; }
            short[] buf = new short[1600];
            byte[] bytes = new byte[buf.length * 2];
            boolean accepted = force;
            long t0 = System.currentTimeMillis();
            int peak = 0;
            float env = 0f;
            if (force) announce(src);
            while (!stop) {
                int n = ar.read(buf, 0, buf.length);
                if (n <= 0) { RecService.log("Mənbə " + src + ": oxuma xətası " + n); return accepted ? 1 : 0; }
                int cp = 0;
                for (int k = 0; k < n; k++) cp = Math.max(cp, Math.abs((int) buf[k]));
                peak = Math.max(peak, cp);
                // Mikrofon mənbələrində qarşı tərəf dinamikdən zəif düşür: səviyyəyə uyğun avtomatik gücləndirmə (1x-10x)
                env = Math.max(cp, env * 0.99f);
                float gain = src == 4 ? 1f : (env > 120f ? Math.max(1f, Math.min(10f, 9000f / env)) : 3f);
                int bi = 0;
                for (int k = 0; k < n; k++) {
                    int v = buf[k];
                    v = (int) Math.max(-32768, Math.min(32767, v * gain));
                    bytes[bi++] = (byte) v;
                    bytes[bi++] = (byte) (v >> 8);
                }
                r.write(bytes, 0, bi);
                tot[0] += bi;
                if (!accepted && System.currentTimeMillis() - t0 >= PROBE_MS) {
                    if (peak > 0) { accepted = true; announce(src); }
                    else { RecService.log("Mənbə " + src + ": tam səssiz — keçilir"); return 0; }
                }
            }
            return accepted ? 1 : 0;
        } catch (Throwable e) {
            RecService.log("Mənbə " + src + ": " + e);
            return 0;
        } finally {
            try { if (ar != null) { ar.stop(); ar.release(); } } catch (Throwable e) { }
        }
    }

    private void announce(int src) {
        boolean far = src == 4;
        RecService.log("Audio mənbəyi: " + src + (far ? " (qarşı tərəf də)" : " (mikrofon)"));
        try { if (cb != null) cb.onSource(src, far); } catch (Throwable e) { }
    }
}
