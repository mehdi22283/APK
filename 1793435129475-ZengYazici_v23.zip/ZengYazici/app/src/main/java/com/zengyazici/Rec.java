package com.zengyazici;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.media.AudioFormat;
import android.media.AudioRecord;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * ADB shell (uid 2000) icazələri ilə app_process vasitəsilə işə salınır:
 * CLASSPATH=<apk> app_process /system/bin com.zengyazici.Rec <port> <planlar>
 * planlar: "4;3+2;3+1;7;1" — ";" ilə ayrılmış planlar, "+" ilə eyni anda yazılan mənbələr (qarışdırılır).
 * Qarşı tərəfi tuta bilən mənbələr: 3 (DOWNLINK), 4 (VOICE_CALL), 8 (REMOTE_SUBMIX).
 * 1-ci mərhələ: yalnız qarşı tərəf mənbəyi olan planlar; 2 saniyə ərzində həmin mənbədə səs gəlməlidir.
 * 2-ci mərhələ: mikrofon planları.
 * Nəticə stderr-ə yazılır: FAR=ok / FAR=none.
 */
public class Rec {
    static final int RATE = 16000, CH = AudioFormat.CHANNEL_IN_MONO, ENC = AudioFormat.ENCODING_PCM_16BIT;
    static final int CHUNK = 1600;

    static class Plan {
        String name;
        int[] src;
        List<AudioRecord> recs = new ArrayList<>();
    }

    static volatile boolean quiet = false;
    static void err(String s) { if (!quiet) System.err.println(s); }
    static void errAlways(String s) { System.err.println(s); }

    /** app_process-də paket adı "com.android.shell" kimi görünsün (scrcpy üsulu): köhnə Android/MIUI-də AppOps boş paketi rədd edir. */
    static class FakeCtx extends ContextWrapper {
        FakeCtx(Context base) { super(base); }
        @Override public String getPackageName() { return "com.android.shell"; }
        public String getOpPackageName() { return "com.android.shell"; }
        @Override public Context getApplicationContext() { return this; }
        public String getAttributionTag() { return null; }
        public android.content.AttributionSource getAttributionSource() {
            try {
                Class<?> b = Class.forName("android.content.AttributionSource$Builder");
                Object bo = b.getConstructor(int.class).newInstance(2000);
                b.getMethod("setPackageName", String.class).invoke(bo, "com.android.shell");
                return (android.content.AttributionSource) b.getMethod("build").invoke(bo);
            } catch (Throwable e) { return null; }
        }
    }

    static Context fakeCtx;

    static void fillApp() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Constructor<?> c = at.getDeclaredConstructor();
            c.setAccessible(true);
            try { android.os.Looper.prepareMainLooper(); } catch (Throwable e) { }
            Object thread = c.newInstance();
            Field sct = at.getDeclaredField("sCurrentActivityThread");
            sct.setAccessible(true);
            sct.set(null, thread);
            try {
                Field ms = at.getDeclaredField("mSystemThread");
                ms.setAccessible(true);
                ms.setBoolean(thread, true);
            } catch (Throwable e) { }
            Class<?> abd = Class.forName("android.app.ActivityThread$AppBindData");
            Constructor<?> bc = abd.getDeclaredConstructor();
            bc.setAccessible(true);
            Object data = bc.newInstance();
            ApplicationInfo ai = new ApplicationInfo();
            ai.packageName = "com.android.shell";
            Field fa = abd.getDeclaredField("appInfo");
            fa.setAccessible(true);
            fa.set(data, ai);
            Field bound = at.getDeclaredField("mBoundApplication");
            bound.setAccessible(true);
            bound.set(thread, data);
            try {   // Android 12+: ConfigurationController olmadan sistem konteksti yaranmır
                Class<?> cc = Class.forName("android.app.ConfigurationController");
                Class<?> ati = Class.forName("android.app.ActivityThreadInternal");
                Constructor<?> ccc = cc.getDeclaredConstructor(ati);
                ccc.setAccessible(true);
                Object o = ccc.newInstance(thread);
                Field fc = at.getDeclaredField("mConfigurationController");
                fc.setAccessible(true);
                fc.set(thread, o);
            } catch (Throwable e) { errAlways("ConfigurationController: " + e); }
            java.lang.reflect.Method gsc = at.getDeclaredMethod("getSystemContext");
            gsc.setAccessible(true);
            Context base = (Context) gsc.invoke(thread);
            fakeCtx = new FakeCtx(base);
            Application app = Instrumentation.newApplication(Application.class, fakeCtx);
            Field ia = at.getDeclaredField("mInitialApplication");
            ia.setAccessible(true);
            ia.set(thread, app);
            errAlways("Shell konteksti: ok");
        } catch (Throwable e) {
            Throwable ce = e instanceof java.lang.reflect.InvocationTargetException && e.getCause() != null ? e.getCause() : e;
            errAlways("Shell konteksti alinmadi: " + ce);
            StackTraceElement[] st = ce.getStackTrace();
            for (int i = 0; i < Math.min(4, st.length); i++) errAlways("  at " + st[i]);
        }
    }

    static boolean isFar(int s) { return s == 3 || s == 4 || s == 8; }

    /** Mikrofon mənbəyidirmi (qarşı tərəfin səsi ora yalnız dinamikdən/qulaqdan sızır). */
    static boolean isMic(int s) { return s == 1 || s == 5 || s == 6 || s == 7; }

    static int[] parse(String plan) {
        String[] xs = plan.split("\\+");
        int[] r = new int[xs.length];
        for (int i = 0; i < xs.length; i++) r[i] = Integer.parseInt(xs[i].trim());
        return r;
    }

    static boolean hasFar(String plan) {
        try { for (int s : parse(plan)) if (isFar(s)) return true; } catch (Throwable e) { }
        return false;
    }

    static AudioRecord open(int src) {
        try {
            int min = AudioRecord.getMinBufferSize(RATE, CH, ENC);
            int size = Math.max(min, RATE) * 4;
            AudioRecord r = null;
            if (fakeCtx != null && android.os.Build.VERSION.SDK_INT >= 31) {
                try {
                    AudioRecord.Builder bld = new AudioRecord.Builder();
                    try { AudioRecord.Builder.class.getMethod("setContext", Context.class).invoke(bld, fakeCtx); } catch (Throwable e) { }
                    r = bld.setAudioSource(src)
                            .setAudioFormat(new AudioFormat.Builder().setSampleRate(RATE).setChannelMask(CH).setEncoding(ENC).build())
                            .setBufferSizeInBytes(size).build();
                } catch (Throwable e) { r = null; }
            }
            if (r == null) r = new AudioRecord(src, RATE, CH, ENC, size);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                err("Menbe " + src + ": INITIALIZED deyil"); r.release(); return null;
            }
            r.startRecording();
            if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                err("Menbe " + src + ": baslamadi"); r.release(); return null;
            }
            return r;
        } catch (Throwable e) {
            err("Menbe " + src + ": " + e);
            return null;
        }
    }

    static Plan openPlan(String plan) {
        Plan p = new Plan();
        p.name = plan;
        try { p.src = parse(plan); } catch (Throwable e) { return null; }
        for (int s : p.src) {
            AudioRecord r = open(s);
            if (r == null) { release(p); return null; }
            p.recs.add(r);
        }
        return p;
    }

    static void release(Plan p) {
        for (AudioRecord r : p.recs) { try { r.stop(); } catch (Throwable e) { } try { r.release(); } catch (Throwable e) { } }
    }

    static boolean readFully(AudioRecord r, short[] b) {
        int off = 0;
        while (off < b.length) {
            int k = r.read(b, off, b.length - off);
            if (k < 0) return false;
            off += k;
        }
        return true;
    }

    static double rms(short[] b) {
        double e = 0;
        for (short v : b) e += (double) v * v;
        return Math.sqrt(e / b.length);
    }

    /**
     * Bir hissə oxuyub qarışdırır; peaks[j]-ə j-ci mənbənin maksimum amplitudunu yazır.
     * Exo qarşısı: qarşı tərəf mənbəyi (3/4/8) ilə mikrofon qarışdırılanda qarşı tərəfin səsi mikrofona
     * sızıb ikinci dəfə (gecikmiş) yazılır. Qarşı tərəf danışanda və mikrofon ondan zəif olanda
     * (yəni sızma olanda, sizin səsiniz yox) mikrofon susdurulur.
     */
    static boolean chunk(Plan p, short[] out, int[] peaks) {
        int n = p.recs.size();
        short[][] t = new short[n][out.length];
        for (int j = 0; j < n; j++) {
            if (!readFully(p.recs.get(j), t[j])) return false;
            for (int i = 0; i < out.length; i++) {
                int ab = Math.abs((int) t[j][i]);
                if (ab > peaks[j]) peaks[j] = ab;
            }
        }
        double farRms = 0;
        for (int j = 0; j < n; j++) if (isFar(p.src[j])) farRms = Math.max(farRms, rms(t[j]));
        int[] sum = new int[out.length];
        for (int j = 0; j < n; j++) {
            float g = 1f;
            if (farRms > 0 && isMic(p.src[j])) {
                double mr = rms(t[j]);
                if (farRms > 600 && mr < farRms * 0.9) g = 0.1f;
            }
            for (int i = 0; i < out.length; i++) sum[i] += Math.round(t[j][i] * g);
        }
        for (int i = 0; i < out.length; i++) out[i] = (short) Math.max(-32768, Math.min(32767, sum[i]));
        return true;
    }

    static int farPeak(Plan p, int[] peaks) {
        int m = 0;
        for (int j = 0; j < p.src.length; j++) if (isFar(p.src[j]) && peaks[j] > m) m = peaks[j];
        return m;
    }

    static int maxPeak(int[] peaks) {
        int m = 0;
        for (int v : peaks) if (v > m) m = v;
        return m;
    }

    static void write(OutputStream o, short[] s) throws Exception {
        byte[] b = new byte[s.length * 2];
        for (int i = 0; i < s.length; i++) { b[2 * i] = (byte) (s[i] & 0xff); b[2 * i + 1] = (byte) ((s[i] >> 8) & 0xff); }
        o.write(b);
    }

    /** Planı sınaqdan keçirir: probe baytlarını qaytarır, peaks-i doldurur; uğursuzsa null. */
    static ByteArrayOutputStream probe(Plan p, int chunks, int[] peaks) throws Exception {
        ByteArrayOutputStream pr = new ByteArrayOutputStream();
        short[] buf = new short[CHUNK];
        for (int k = 0; k < chunks; k++) {
            if (!chunk(p, buf, peaks)) return null;
            write(pr, buf);
        }
        return pr;
    }

    /** Bir cəhd: planları sınayır; {Plan, idx, pre, far} qaytarır və ya null. */
    static Object[] select(String[] plans, int farTh) throws Exception {
        Plan chosen = null;
        int chosenIdx = -1;
        ByteArrayOutputStream pre = new ByteArrayOutputStream();
        String far = "none";

            // 1-ci mərhələ: qarşı tərəfi tutan planlar
            for (int pi = 0; pi < plans.length && chosen == null; pi++) {
                if (!hasFar(plans[pi])) continue;
                Plan p = openPlan(plans[pi]);
                if (p == null) { err("Plan " + plans[pi] + ": acilmadi"); continue; }
                int[] peaks = new int[p.recs.size()];
                ByteArrayOutputStream pr = probe(p, 20, peaks);
                err("Plan " + plans[pi] + ": qarsi-teref peak=" + (pr == null ? -1 : farPeak(p, peaks)) + ", hamisi=" + maxPeak(peaks));
                if (pr != null && farPeak(p, peaks) > farTh) {
                    errAlways("Plan " + plans[pi] + ": SECILDI");
                    chosen = p; chosenIdx = pi; pre = pr; far = "ok";
                } else {
                    release(p);
                }
            }

            // 2-ci mərhələ: mikrofon planları
            if (chosen == null) {
                Plan firstOpen = null;
                int firstIdx = -1;
                for (int pi = 0; pi < plans.length && chosen == null; pi++) {
                    if (hasFar(plans[pi])) continue;
                    Plan p = openPlan(plans[pi]);
                    if (p == null) { err("Plan " + plans[pi] + ": acilmadi"); continue; }
                    int[] peaks = new int[p.recs.size()];
                    ByteArrayOutputStream pr = probe(p, 10, peaks);
                    err("Plan " + plans[pi] + ": peak=" + maxPeak(peaks));
                    if (pr != null && maxPeak(peaks) > 2) {
                        chosen = p; chosenIdx = pi; pre = pr;
                    } else if (firstOpen == null) {
                        firstOpen = p; firstIdx = pi;   // açıq saxlayırıq, ehtiyat olaraq
                    } else {
                        release(p);
                    }
                }
                if (chosen == null && firstOpen != null) {
                    err("Butun menbeler sessizdir; " + firstOpen.name + " ile davam edilir");
                    chosen = firstOpen; chosenIdx = firstIdx;
                } else if (firstOpen != null) {
                    release(firstOpen);
                }
            }

        return chosen == null ? null : new Object[]{chosen, chosenIdx, pre, far};
    }

    public static void main(String[] a) {
        try {
            int port = Integer.parseInt(a[0]);
            final int farTh = 2;
            String[] plans = a[1].split(";");
            errAlways("Rec v29 | Cihaz: " + android.os.Build.MODEL + " SDK " + android.os.Build.VERSION.SDK_INT);
            fillApp();
            Plan chosen = null;
            int chosenIdx = -1;
            ByteArrayOutputStream pre = new ByteArrayOutputStream();
            String far = "none";
            // Zəngin əvvəlində audio sistemi hələ məşğul ola bilər: 8 dəfəyə qədər təkrar cəhd
            for (int att = 0; att < 8 && chosen == null; att++) {
                quiet = att > 0 && att < 7;
                if (att > 0) Thread.sleep(400);
                Object[] res = select(plans, farTh);
                if (res != null) { chosen = (Plan) res[0]; chosenIdx = (Integer) res[1]; pre = (ByteArrayOutputStream) res[2]; far = (String) res[3]; }
            }
            quiet = false;

            if (chosen == null) {
                errAlways("Hec bir audio menbeyi acilmadi");
                System.exit(2);
            }
            err("FAR=" + far);
            err("Secilen plan: " + chosen.name);

            Socket sock = new Socket("127.0.0.1", port);
            OutputStream o = sock.getOutputStream();
            o.write(chosenIdx);
            o.write(pre.toByteArray());
            short[] buf = new short[CHUNK];
            int[] peaks = new int[chosen.recs.size()];
            int[] win = new int[peaks.length];
            int cnt = 0;
            while (true) {
                if (!chunk(chosen, buf, peaks)) break;
                write(o, buf);
                for (int j = 0; j < peaks.length; j++) { if (peaks[j] > win[j]) win[j] = peaks[j]; peaks[j] = 0; }
                if (++cnt >= 40) {   // 4 saniyədə bir: hansı mənbə nə qədər səs tutur
                    StringBuilder sb = new StringBuilder("menbe-peak:");
                    for (int j = 0; j < win.length; j++) { sb.append(' ').append(chosen.src[j]).append('=').append(win[j]); win[j] = 0; }
                    err(sb.toString());
                    cnt = 0;
                }
            }
        } catch (Throwable e) {
            err("Rec: " + e);
            System.exit(1);
        }
        System.exit(0);
    }
}
