package com.zengyazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

public class PairReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Bundle r = android.app.RemoteInput.getResultsFromIntent(i);
        if (r == null || r.getCharSequence("code") == null) return;
        final String code = r.getCharSequence("code").toString().trim();
        final Context app = c.getApplicationContext();
        final SharedPreferences p = app.getSharedPreferences("cfg", 0);
        final String host = p.getString("pair_host", "127.0.0.1");
        final int port = p.getInt("pair_port", 0);
        final PendingResult pr = goAsync();
        PairHelper.result(app, "Cütləşdirilir…");
        new Thread(() -> {
            boolean ok = false;
            String msg;
            try {
                if (port == 0) throw new Exception("Cütləşmə portu tapılmadı. «Pair with pairing code» pəncərəsi açıq olmalıdır.");
                AdbMgr m = AdbMgr.get(app);
                try {
                    m.pair(host, port, code);
                } catch (Throwable e) {
                    RecService.log("pair " + host + ": " + e);
                    if (host.equals("127.0.0.1")) throw e;
                    m.pair("127.0.0.1", port, code);
                }
                ok = true;
                msg = "Cütləşmə uğurlu. Qoşulur…";
            } catch (Throwable e) {
                RecService.log("pair: " + e);
                msg = "Cütləşmə alınmadı: " + e.getMessage() + " — yeni kodla yenidən «Cütləşdir» basın.";
            }
            PairHelper.result(app, msg);
            pr.finish();
            if (ok) {
                PairHelper.stop();
                try {
                    Conn.ensure(app);
                    PairHelper.result(app, "Cütləşmə və qoşulma uğurlu ✅");
                } catch (Throwable e) {
                    RecService.log("connect: " + e);
                    PairHelper.result(app, "Cütləşdi, amma qoşulmadı: " + e.getMessage());
                }
            }
        }).start();
    }
}
