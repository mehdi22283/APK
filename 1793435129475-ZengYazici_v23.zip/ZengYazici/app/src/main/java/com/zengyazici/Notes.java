package com.zengyazici;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Nömrə/kontakt üzrə qeydlər və «neçə gün sonra zəng et» xatırlatmaları. */
public class Notes {
    public static final String T_NOTE = "note", T_REM = "rem";
    /** Xatırlatma həmin günün bu saatında bildiriş göndərir. */
    public static final int REMIND_HOUR = 9;

    public static class Entry {
        public int id, days;
        public String key = "", type = T_NOTE, text = "";
        public long ts, due;
        public boolean done;
    }

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("notes", 0); }

    /** Eyni nömrə fərqli yazılsa da (boşluq, tire, mötərizə) eyni açar alınsın. */
    public static String norm(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.matches("[+0-9 ()\\-]+")) return s.replaceAll("[ ()\\-]", "");
        return s.replaceAll("\\s+", " ");
    }

    public static boolean isNumber(String key) { return key != null && key.matches("\\+?[0-9]{3,}"); }

    public static synchronized List<Entry> all(Context c) {
        List<Entry> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Entry e = new Entry();
                e.id = o.getInt("id");
                e.key = o.optString("key");
                e.type = o.optString("type", T_NOTE);
                e.text = o.optString("text");
                e.ts = o.optLong("ts");
                e.due = o.optLong("due");
                e.days = o.optInt("days");
                e.done = o.optBoolean("done");
                l.add(e);
            }
        } catch (Exception e) { }
        return l;
    }

    private static void save(Context c, List<Entry> l, int nextId) {
        JSONArray a = new JSONArray();
        for (Entry e : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("id", e.id); o.put("key", e.key); o.put("type", e.type); o.put("text", e.text);
                o.put("ts", e.ts); o.put("due", e.due); o.put("days", e.days); o.put("done", e.done);
                a.put(o);
            } catch (Exception x) { }
        }
        SharedPreferences.Editor ed = sp(c).edit().putString("items", a.toString());
        if (nextId > 0) ed.putInt("nid", nextId);
        ed.apply();
    }

    public static synchronized Entry get(Context c, int id) {
        for (Entry e : all(c)) if (e.id == id) return e;
        return null;
    }

    /** Açarlar: ən son dəyişən birinci. */
    public static synchronized List<String> keys(Context c) {
        List<Entry> l = all(c);
        Set<String> s = new LinkedHashSet<>();
        for (int i = l.size() - 1; i >= 0; i--) s.add(l.get(i).key);
        return new ArrayList<>(s);
    }

    public static synchronized Entry add(Context c, String key, String type, String text, int days) {
        List<Entry> l = all(c);
        int id = sp(c).getInt("nid", 1);
        Entry e = new Entry();
        e.id = id;
        e.key = norm(key);
        e.type = type;
        e.text = text == null ? "" : text;
        e.ts = System.currentTimeMillis();
        e.days = days;
        if (T_REM.equals(type)) e.due = dueFor(days);
        l.add(e);
        save(c, l, id + 1);
        if (T_REM.equals(type)) schedule(c, e);
        return e;
    }

    public static synchronized void setText(Context c, int id, String text) {
        List<Entry> l = all(c);
        for (Entry e : l) if (e.id == id) { e.text = text; e.ts = System.currentTimeMillis(); }
        save(c, l, 0);
    }

    public static synchronized void markDone(Context c, int id) {
        List<Entry> l = all(c);
        for (Entry e : l) if (e.id == id) e.done = true;
        save(c, l, 0);
    }

    public static synchronized void remove(Context c, int id) {
        List<Entry> l = all(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id == id) l.remove(i);
        save(c, l, 0);
        cancel(c, id);
    }

    public static synchronized void removeKey(Context c, String key) {
        List<Entry> l = all(c);
        for (int i = l.size() - 1; i >= 0; i--) {
            if (l.get(i).key.equals(key)) { cancel(c, l.get(i).id); l.remove(i); }
        }
        save(c, l, 0);
    }

    // ---------- alarmlar ----------
    /** Bu gündən {days} gün sonra, saat 09:00. Vaxt keçibsə (məs. 0 gün) 1 dəqiqə sonra. */
    static long dueFor(int days) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, days);
        cal.set(Calendar.HOUR_OF_DAY, REMIND_HOUR);
        cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        long t = cal.getTimeInMillis(), now = System.currentTimeMillis();
        return t <= now ? now + 60000 : t;
    }

    private static PendingIntent pi(Context c, int id) {
        return PendingIntent.getBroadcast(c, id, new Intent(c, ReminderReceiver.class).putExtra("id", id),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void schedule(Context c, Entry e) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            PendingIntent p = pi(c, e.id);
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.due, p);
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.due, p);
            } catch (Throwable x) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.due, p);
            }
        } catch (Throwable x) {
            RecService.log("Xatırlatma alarmı: " + x);
        }
    }

    static void cancel(Context c, int id) {
        try { ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi(c, id)); } catch (Throwable x) { }
    }

    /** Telefon yenidən başlayanda / tətbiq yenilənəndə alarmlar itir — yenidən qurulur. */
    public static void rescheduleAll(Context c) {
        long now = System.currentTimeMillis();
        for (Entry e : all(c)) {
            if (!T_REM.equals(e.type) || e.done) continue;
            if (e.due <= now) ReminderReceiver.fire(c, e.id);
            else schedule(c, e);
        }
    }
}
