package com.zengyazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

/**
 * Tətbiq arxa fonda heç nə işlətmir. Sistem zəng vəziyyəti dəyişəndə bu qəbuledicini oyadır;
 * zəng gələndə/başlayanda yazı xidməti qalxır, zəng bitəndə xidmət özü bağlanır.
 */
public class CallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(i.getAction())) return;
        String st = i.getStringExtra(TelephonyManager.EXTRA_STATE);
        if (TelephonyManager.EXTRA_STATE_RINGING.equals(st) || TelephonyManager.EXTRA_STATE_OFFHOOK.equals(st)) {
            RecService.ensure(c);
        }
    }
}
