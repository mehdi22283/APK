import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "az.mehdi.iptvplayer"
    compileSdk = 36

    defaultConfig {
        applicationId = "az.mehdi.iptvplayer"
        minSdk = 24
        targetSdk = 35
        versionCode = 52
        versionName = "1.52"

        // Universal APK: 32-bit (armv7) və 64-bit (armv8/arm64) ARM. Cihaz öz ABI-sini avtomatik seçir.
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
    }

    buildTypes {
        // Debug imza ilə qalır, amma debuggable söndürülür: TV box-da ART tam optimallaşdırma ilə işləyir.
        debug {
            isDebuggable = false
            // R8: kod kiçiltmə + istifadə olunmayan resursların silinməsi (APK ölçüsü və açılış sürəti). Qaydalar: proguard-rules.pro.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    packaging {
        // Media3/NextLib (FFmpeg) native kitabxanaları libc++_shared.so gətirə bilər: biri seçilir.
        jniLibs { pickFirsts += "**/libc++_shared.so" }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Android 7.1 (API 25) üçün java.time və yeni Java API-lərini uyğunlaşdırır.
        isCoreLibraryDesugaringEnabled = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // java.time API-ləri API 26-dan aşağı Android versiyalarında da işləsin.
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // OkHttp: playlist/EPG yükləmə üçün (pleyer deyil).
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Android TV ana ekranı: "Watch Next" (son izlənən kanallar).
    implementation("androidx.tvprovider:tvprovider:1.0.0")

    // Birinci pleyer: Media3 (ExoPlayer, yalnız http/https). MediaCodec dekoderləri, çatışmayanda və ya çık-çık səsdə FFmpeg dekoderləri.
    val media3 = "1.11.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-datasource-okhttp:$media3")

    // Media3 üçün FFmpeg (NextLib, GPL-3.0): səs (AAC, AC3, EAC3, DTS, TrueHD, MP3, Opus, Vorbis, FLAC, ALAC ...) və
    // video (H.264, HEVC, VP8, VP9, AV1) proqram dekoderləri. Versiya adı: <Media3 versiyası>-<NextLib versiyası>,
    // Media3 versiyası ilə eyni olmalıdır. Native kitabxanalar libavcodec.so/libavformat.so/libavutil.so/libswscale.so/
    // libswresample.so adları ilə gəlir (artıq toqquşma yoxdur: mpv silinib).
    implementation("io.github.anilbeesetti:nextlib-media3ext:$media3-0.16.0")
}
