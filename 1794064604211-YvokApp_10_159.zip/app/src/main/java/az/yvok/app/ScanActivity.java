package az.yvok.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.core.resolutionselector.AspectRatioStrategy;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.resolutionselector.ResolutionStrategy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Toplu yoxlama üçün canlı kamera skanı: düzbucağın içindəki 10011 ilə başlayan YVÖK kodu tanınır,
 * kod sabitləşəndən sonra borcu yoxlanılır və düzbucağın altında yazılır.
 * "Siyahıya əlavə et" tanınmış kodları Toplu yoxlama siyahısına qaytarır.
 */
public class ScanActivity extends ComponentActivity {
    public static final String EXTRA_CODES = "codes";
    private static final int REQ_CAM = 9101;
    // OCR səhvlərinə tolerant (MainActivity.OCR_CODE ilə eyni qayda): 10011 + 7 simvol
    private static final Pattern CODE = Pattern.compile("[1IL|!][0OQD][0OQD][1IL|!][1IL|!]([A-Z0-9|!]{7})");
    private static final Pattern VALID = Pattern.compile("^10011[A-Z0-9]{7}$");   // şərt: yalnız 10011 ilə başlayan 12 simvol
    private static final Pattern STD_TAIL = Pattern.compile("^[A-Z]{3}[0-9]{4}$");

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private FrameLayout root;
    private PreviewView pv;
    private Overlay ov;
    private Button doneBtn;
    private TextRecognizer rec;
    private Camera camera;
    private boolean torch = false;

    private volatile boolean busy = false;
    private long lastRun = 0;
    private String candidate = "";
    private int candCount = 0;
    private int noneCount = 0;
    private String current = "";

    private final LinkedHashSet<String> collected = new LinkedHashSet<>();
    private final LinkedHashMap<String, List<String>> lines = new LinkedHashMap<>();   // kod -> düzbucağın altında yazılan sətirlər
    private final LinkedHashMap<String, Integer> colors = new LinkedHashMap<>();

    private YeloChecker yelo;
    private PortmanatChecker port;

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        pv = new PreviewView(this);
        pv.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        pv.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(pv, new FrameLayout.LayoutParams(-1, -1));

        ov = new Overlay();
        root.addView(ov, new FrameLayout.LayoutParams(-1, -1));

        Button close = mkBtn("✕", Color.parseColor("#CC333333"));
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP | Gravity.END);
        cl.setMargins(0, dp(36), dp(16), 0);
        root.addView(close, cl);
        close.setOnClickListener(v -> { setResult(Activity.RESULT_CANCELED); finish(); });

        Button tb = mkBtn("🔦", Color.parseColor("#CC333333"));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP | Gravity.START);
        tl.setMargins(dp(16), dp(36), 0, 0);
        root.addView(tb, tl);
        tb.setOnClickListener(v -> {
            if (camera == null || !camera.getCameraInfo().hasFlashUnit()) return;
            torch = !torch;
            camera.getCameraControl().enableTorch(torch);
        });

        doneBtn = mkBtn("Siyahıya əlavə et (0)", Color.parseColor("#1FA85A"));
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM);
        dl.setMargins(dp(20), 0, dp(20), dp(28));
        root.addView(doneBtn, dl);
        doneBtn.setOnClickListener(v -> finishWithCodes());

        rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera();
        else requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
    }

    private Button mkBtn(String t, int bg) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(16f);
        bt.setAllCaps(false);
        bt.setBackgroundColor(bg);
        return bt;
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_CAM) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) startCamera();
            else { Toast.makeText(this, "Kamera icazəsi verilmədi", Toast.LENGTH_LONG).show(); finish(); }
        }
    }

    private void startCamera() {
        final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                bind(f.get());
            } catch (Exception e) {
                Toast.makeText(this, "Kamera açılmadı", Toast.LENGTH_LONG).show();
                finish();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bind(ProcessCameraProvider p) {
        Preview preview = new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build();
        preview.setSurfaceProvider(pv.getSurfaceProvider());
        ResolutionSelector rs = new ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(new ResolutionStrategy(new Size(1600, 1200),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                .build();
        ImageAnalysis ia = new ImageAnalysis.Builder()
                .setResolutionSelector(rs)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();
        ia.setAnalyzer(exec, this::analyze);
        p.unbindAll();
        camera = p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, ia);
    }

    // ---------------- Tanıma ----------------

    @ExperimentalGetImage
    private void analyze(final ImageProxy image) {
        long now = SystemClock.elapsedRealtime();
        if (busy || now - lastRun < 300 || ov.vw == 0 || image.getImage() == null) { image.close(); return; }
        busy = true; lastRun = now;
        final int rot = image.getImageInfo().getRotationDegrees();
        final int w = rot % 180 == 0 ? image.getWidth() : image.getHeight();
        final int h = rot % 180 == 0 ? image.getHeight() : image.getWidth();
        InputImage in = InputImage.fromMediaImage(image.getImage(), rot);
        rec.process(in)
                .addOnSuccessListener(exec, t -> onText(t, w, h))
                .addOnFailureListener(exec, e -> reportNone())
                .addOnCompleteListener(exec, t -> { busy = false; image.close(); });
    }

    private void onText(Text t, int w, int h) {
        // düzbucağın şəkil koordinatlarındakı yeri (PreviewView FILL_CENTER: şəkil ekrana tam sığır, kənarlar kəsilir)
        float scale = Math.max(ov.vw / (float) w, ov.vh / (float) h);
        float offX = (w * scale - ov.vw) / 2f, offY = (h * scale - ov.vh) / 2f;
        RectF r = ov.rect;
        float l = (r.left + offX) / scale, rr = (r.right + offX) / scale;
        float tp = (r.top + offY) / scale, bt = (r.bottom + offY) / scale;

        StringBuilder all = new StringBuilder();
        List<String> perLine = new ArrayList<>();
        for (Text.TextBlock blk : t.getTextBlocks()) {
            for (Text.Line ln : blk.getLines()) {
                StringBuilder sb = new StringBuilder();
                for (Text.Element el : ln.getElements()) {
                    Rect bb = el.getBoundingBox();
                    if (bb == null) continue;
                    float cx = bb.centerX(), cy = bb.centerY();
                    if (cx >= l && cx <= rr && cy >= tp && cy <= bt) sb.append(el.getText());
                }
                if (sb.length() > 0) { perLine.add(sb.toString()); all.append(sb); }
            }
        }
        perLine.add(0, all.toString());
        String found = null;
        for (String s : perLine) {
            Matcher m = CODE.matcher(s.toUpperCase().replace(" ", ""));
            if (m.find()) {
                String raw = m.group(1).replace('|', 'I').replace('!', 'I');
                String tail = raw;
                if (!STD_TAIL.matcher(raw).matches()) {
                    String fx = fixTail(m.group(1));
                    tail = STD_TAIL.matcher(fx).matches() ? fx : raw;   // adi format (3 hərf + 4 rəqəm) olmayan kodlar olduğu kimi qalır
                }
                if (VALID.matcher("10011" + tail).matches()) { found = "10011" + tail; break; }
            }
        }
        if (found == null) { reportNone(); return; }
        final String code = found;
        ui.post(() -> {
            noneCount = 0;
            if (code.equals(candidate)) candCount++; else { candidate = code; candCount = 1; }
            if (candCount >= 2 && !code.equals(current)) onStable(code);   // eyni kod ardıcıl 2 kadrda: oxuma səhvlərinə qarşı
        });
    }

    private void reportNone() {
        ui.post(() -> {
            candCount = 0;
            if (++noneCount >= 4 && !current.isEmpty()) { current = ""; ov.setInfo("", null, 0); }
        });
    }

    private static String fixTail(String t) {
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (i < 3) {
                if (c == '0') c = 'O';
                else if (c == '1' || c == '|' || c == '!') c = 'I';
                else if (c == '5') c = 'S';
                else if (c == '8') c = 'B';
            } else {
                if (c == 'O' || c == 'Q' || c == 'D') c = '0';
                else if (c == 'I' || c == 'L' || c == '|' || c == '!') c = '1';
                else if (c == 'S') c = '5';
                else if (c == 'B') c = '8';
            }
            sb.append(c);
        }
        return sb.toString();
    }

    // ---------------- Borcun yoxlanması ----------------

    private void onStable(String code) {
        current = code;
        if (collected.add(code)) doneBtn.setText("Siyahıya əlavə et (" + collected.size() + ")");
        if (!lines.containsKey(code)) {
            List<String> l = new ArrayList<>();
            l.add("Yoxlanılır…");
            lines.put(code, l); colors.put(code, Color.WHITE);
            lookup(code);
        }
        refresh();
    }

    private void refresh() {
        if (current.isEmpty()) return;
        List<String> l = lines.get(current);
        Integer c = colors.get(current);
        ov.setInfo(current, l, c == null ? Color.WHITE : c);
    }

    private void setLines(String code, List<String> l, int color) {
        lines.put(code, l); colors.put(code, color);
        if (code.equals(current)) refresh();
    }

    private YeloChecker yelo() {
        if (yelo == null) {
            yelo = new YeloChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            yelo.setMaxWait(20000);
        }
        return yelo;
    }

    private PortmanatChecker port() {
        if (port == null) {
            port = new PortmanatChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            port.setMaxWait(25000);
        }
        return port;
    }

    private void lookup(final String code) {
        yelo().check(code, new YeloChecker.Callback() {
            @Override public void onResult(String name, String debt) { onResult(name, debt, 0); }
            @Override public void onResult(String name, String debt, int azn) {
                if (azn != 1) {                     // iki məbləğ: vergi sətirləri portmanat.az-dan (əsas qayda ilə eyni)
                    fromPortmanat(code, name, debt, true);
                } else {
                    showDebt(code, name, debt, null);
                }
            }
            @Override public void onFail() { fromPortmanat(code, null, null, false); }
        });
    }

    private void fromPortmanat(final String code, final String yName, final String yDebt, final boolean haveYelo) {
        port().check(code, new PortmanatChecker.Callback() {
            @Override public void onResult(String name, String debt) { onResult(name, debt, new ArrayList<String>()); }
            @Override public void onResult(String name, String debt, List<String> items) {
                List<String> norm = PortmanatChecker.normalizeItems(items);
                if (norm.size() >= 2) showDebt(code, name != null && !name.isEmpty() ? name : yName, PortmanatChecker.sumItems(norm), norm);
                else if (haveYelo) showDebt(code, yName, yDebt, null);
                else showDebt(code, name, debt, null);
            }
            @Override public void onFail() {
                if (haveYelo) showDebt(code, yName, yDebt, null);
                else setLines(code, one("Məlumat tapılmadı"), Color.parseColor("#FF8A80"));
            }
        });
    }

    private static List<String> one(String s) { List<String> l = new ArrayList<>(); l.add(s); return l; }

    private void showDebt(String code, String name, String debt, List<String> items) {
        List<String> l = new ArrayList<>();
        if (name != null && !name.trim().isEmpty()) l.add(name.trim());
        if (items != null) l.addAll(items);
        String d = debt == null ? "" : debt.trim();
        l.add("Borc: " + (d.isEmpty() ? "?" : d) + " AZN");
        boolean has = false;
        try { has = Double.parseDouble(d.replace(',', '.')) > 0; } catch (Exception ignored) { }
        setLines(code, l, has ? Color.parseColor("#FFB74D") : Color.parseColor("#69F0AE"));
    }

    // ---------------- Çıxış ----------------

    private void finishWithCodes() {
        if (collected.isEmpty()) { setResult(Activity.RESULT_CANCELED); finish(); return; }
        Intent d = new Intent();
        d.putExtra(EXTRA_CODES, collected.toArray(new String[0]));
        setResult(Activity.RESULT_OK, d);
        finish();
    }

    @Override
    public void onBackPressed() { setResult(Activity.RESULT_CANCELED); finish(); }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (yelo != null) yelo.destroy(); } catch (Exception ignored) { }
        try { if (port != null) port.destroy(); } catch (Exception ignored) { }
        try { exec.shutdownNow(); } catch (Exception ignored) { }
        try { rec.close(); } catch (Exception ignored) { }
    }

    // ---------------- Düzbucaq və nəticə yazısı ----------------

    private class Overlay extends View {
        final RectF rect = new RectF();
        int vw = 0, vh = 0;
        private String code = "";
        private List<String> info = null;
        private int color = Color.WHITE;
        private final Paint dim = new Paint();
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint hint = new Paint(Paint.ANTI_ALIAS_FLAG);

        Overlay() {
            super(ScanActivity.this);
            dim.setColor(Color.parseColor("#88000000"));
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(3));
            bg.setColor(Color.parseColor("#CC000000"));
            tp.setTextAlign(Paint.Align.CENTER);
            hint.setColor(Color.WHITE);
            hint.setTextAlign(Paint.Align.CENTER);
            hint.setTextSize(dp(15));
        }

        void setInfo(String c, List<String> i, int col) { code = c; info = i; color = col; invalidate(); }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            vw = w; vh = h;
            float rw = w * 0.9f, rh = Math.max(dp(72), h * 0.11f);
            float top = h * 0.36f - rh / 2f;
            rect.set((w - rw) / 2f, top, (w + rw) / 2f, top + rh);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawRect(0, 0, vw, rect.top, dim);
            c.drawRect(0, rect.bottom, vw, vh, dim);
            c.drawRect(0, rect.top, rect.left, rect.bottom, dim);
            c.drawRect(rect.right, rect.top, vw, rect.bottom, dim);
            stroke.setColor(code.isEmpty() ? Color.WHITE : color);
            c.drawRoundRect(rect, dp(10), dp(10), stroke);
            float cx = vw / 2f;
            float y = rect.bottom + dp(14);
            if (code.isEmpty() || info == null) {
                c.drawText("YVÖK kodunu (10011…) düzbucağın içinə sal", cx, rect.top - dp(14), hint);
                return;
            }
            float lh = dp(26);
            float boxH = dp(14) + lh * (info.size() + 1);
            c.drawRoundRect(new RectF(dp(16), y, vw - dp(16), y + boxH), dp(12), dp(12), bg);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
            tp.setColor(Color.WHITE);
            tp.setTextSize(dp(20));
            c.drawText(code, cx, y + dp(10) + lh * 0.8f, tp);
            for (int i = 0; i < info.size(); i++) {
                String s = info.get(i);
                boolean last = i == info.size() - 1;
                tp.setTypeface(last ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
                tp.setColor(last ? color : Color.parseColor("#DDDDDD"));
                tp.setTextSize(last ? dp(22) : dp(15));
                while (tp.measureText(s) > vw - dp(44) && tp.getTextSize() > dp(10)) tp.setTextSize(tp.getTextSize() - 1);
                c.drawText(s, cx, y + dp(10) + lh * (i + 1.8f), tp);
            }
        }
    }
}
