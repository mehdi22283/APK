# Oynatma konfiqurasiyası (2 GB RAM TV box) — v1.15

## Pleyer ardıcıllığı
Hər addım 5 s. Əvvəl serverə sorğu göndərilir (5 s); xəta cavabı (404/403/5xx, qoşulmur) alınarsa pleyerlər yoxlanmır. Ehtiyat (yoda.az tokenli) linkdə sorğu göndərilmir.

| Vəziyyət | Ardıcıllıq |
|---|---|
| Yeni kanal (yaddaşda yoxdur) | Media3 → VLC → Media3 (15 s) |
| VLC ilə yadda qalıb | VLC → Media3 → VLC |
| Media3 ilə yadda qalıb | Media3 → VLC → Media3 |
| Media3 ilə bu seansda artıq işləyib | Media3 → Media3 → Media3 (VLC-yə keçid yoxdur) |
| rtmp, rtmps, mms, rtp, udp, srt, rist, ftp, smb, dvb, tcp və s. | VLC → VLC → VLC |

Hamısı açmasa "Kanal İşləmir" (və ya ehtiyat link prosesi). Əvvəl işləmiş kanalda hamısı açmasa xəta göstərilmir, hər 2 s-dən bir avtomatik təkrar yoxlanılır.

**Bərpa (işləyən kanal qırılıb/donub):** VLC ilə işləyirdisə VLC → Media3; Media3 ilə işləyirdisə pleyer dəyişmir, yalnız Media3 yenidən qoşulur. 60 s-də 4 dəfə yenidən qoşulma olarsa VLC-də olan kanal Media3-ə verilir.

Pleyer yaddaşı: kanal linki (SHA-1) → `exo` / `vlc`, `SharedPreferences("player_memory_v3")`. Hansı pleyer açsa, o yadda saxlanılır (VLC-only protokollar yadda saxlanılmır). Playlist yüklənəndə siyahıda olmayan linklərin yaddaşı silinir; yeni link yeni kanal sayılır.

## Media3 (ExoPlayer)
- **Bufer:** min 10 s, max 20 s, başlamaq 2.5 s, təkrar buferdən sonra 5 s; yaddaş limiti 20 MB (Java heap-dədir); geriyə bufer yox.
- **Keyfiyyət:** maksimum 1080p / 30 kadr (yalnız 4K varsa o açılır), ekran ölçüsündən böyük variant seçilmir, tunneling söndürülüb.
- **Dekoder:** cihazın MediaCodec-i (HW, açılmasa SW ehtiyatı); dəstəklənməyən audio/video codec-lər üçün FFmpeg (NextLib) renderer ehtiyat kimi (EXTENSION_RENDERER_MODE_ON).
- **Canlı yayım:** hədəf gecikmə yayımın öz siyahısından götürülür, oxutma sürəti həmişə 1.0x; pleyer canlı pəncərədən geri qalarsa kanal canlı nöqtəyə qayıdır.
- **OkHttp:** HTTP/1.1, hovuz 2 bağlantı, eyni anda ən çox 8 sorğu (host başına 4), connect timeout 6 s, read timeout 10 s; yönləndirmələr (http↔https), vaxtı keçmiş/özü imzalı sertifikat qəbul edilir.
- **User-Agent:** standart `VLC/3.0.20`; kanalın öz User-Agent və Referer-i varsa o işlədilir.
- Video həmişə stretch: `VIDEO_SCALING_MODE_SCALE_TO_FIT`.

## VLC (libVLC)
- network-caching / live-caching 4 s, file-caching 1 s, `--http-reconnect`, `--rtsp-tcp`.
- Adaptiv yayımda maksimum 1920x1080.
- Dekoder thread sayı: zəif RAM-lı cihazda ən çox 3, əks halda avtomatik; `--no-avcodec-fast`, `--avcodec-skiploopfilter=0`, `--no-skip-frames`, `--drop-late-frames`.
- `--deinterlace=-1`; rejim: nüvə sayı ≥ 6 və güclü cihazda `yadif`, əks halda `linear`.
- `--no-spu`, `--no-osd`, `--no-snapshot-preview`, `--no-stats`, `--audio-time-stretch`.
- Görüntü: `setAspectRatio("W:H")` + `setScale(0)` — hər açılışda və video ölçüsü dəyişəndə yenidən tətbiq olunur.
- Bütün native əməliyyatlar tək `vlc-ctl` thread-ində ardıcıl icra olunur.

## Avtomatik bərpa (davamlı izləmə)
- Yayım işləyərkən qırılsa (xəta, yayım bitdi) kanal gözləmədən (0 s) yenidən qoşulur.
- Bufer 5 s dolmursa və ya görüntü 5 s donursa yenidən qoşulur (VLC-də "səs var, görüntü donub" aşkarı 5 s; açılışda vaxt göstəricisi 10 s gəlmirsə də yenilənir).
- Watchdog hər 1 s yoxlayır; istifadəçi pauza edibsə bərpa işləmir.
- Təkrar cəhddə VLC buferi tam boşaldılır (stop + media ayrılır + video səthi yenidən qoşulur); donma səbəbilə ilk təkrar cəhddən proqram (SW) dekoderi işlədilir.
- Əvvəl işləmiş kanalın bərpasında yükləmə paneli dərhal çıxmır (son kadr ekranda qalır); yalnız 3.5 s-dən uzun çəkərsə görünür.

## Yaddaş (2 GB RAM)
- `largeHeap=true`, ABI yalnız `armeabi-v7a` (APK kiçilir; 32-bit dəstəkləyən arm64 cihazlarda da açılır).
- Eyni anda yalnız bir video səthi görünür.
- **libVLC ömrü:** kanal dəyişəndə `MediaPlayer` boşaldılır; `LibVLC` nüsxəsi təkrar istifadə olunur. Media3 işləyəndə VLC 45 s sonra tam boşaldılır. `onTrimMemory ≥ 15` (kritik) bildirəndə Media3 işləyirsə VLC dərhal boşaldılır, oynayan yayıma toxunulmur; `≥ 10`-da loqo keşi təmizlənir.
- **Loqo keşi:** bitmap keşi 3–8 MB, eyni anda 2 dekod / 2 endirmə.
- **EPG:** proqram təsviri 160 simvol, təkrarlanan başlıqlar bir nüsxədə.
- **Playlist yoxlaması:** köhnə keş ikinci dəfə String kimi yaddaşa oxunmur (bayt-bayt müqayisə).
- **Ehtiyat link WebView:** yalnız lazım olanda yaradılır, şəkil yükləmə söndürülüb, iş bitəndə silinir.

## Stabillik qeydləri
- **VLC donmuş yayımda:** əsas thread `detachViews()` gözləmir (video səthi worker-də ayrılır); worker 1 s-dən uzun ilişibsə boşaltma əmri növbəyə qoyulmur, köhnə pleyer ayrıca thread-ə verilir. İlişmə bərpasında paralel LibVLC yaradılmır, təkrar ilişmədə köhnə LibVLC sızdırılır (native çökmənin qarşısı).
- **yoda.az WebView:** `onRenderProcessGone` ilə render prosesi ölərsə tətbiq çökmür.
- **İlkin server sorğusu:** gözlənilməz xəta nəticəsiz sayılır, pleyerlər yoxlayır; kanal dəyişəndə köhnə sorğunun nəticəsi ignor edilir.
- **Alt zolaq:** saat/sürət/ad mətni yalnız dəyişəndə yenilənir.
- **Təhlükəsizlik toru (`App.kt`):** tutulmayan Java/Kotlin xətasında tətbiq yenidən açılır (15 s-də təkrar çökərsə açılmır). Native çökmələr və sistemin yaddaş azlığından prosesi öldürməsi bununla tutulmur.

## Bütün stream linkləri
- http/https (m3u8, ts, mp4, mpd, ism və genişlənməsiz linklər) və rtsp: yuxarıdakı ardıcıllıqla Media3/VLC.
- `.m3u8`/`.mpd` linkdə harada olsa (sorğu hissəsində də) HLS/DASH kimi tanınır.

## Playlist linki dəyişəndə
İzlənən kanalın linki yeni playlistdə dəyişibsə, kanal yeni linklə avtomatik yenidən açılır. Son kanal link, ad, qrup və tvg-id ilə saxlanılır və tətbiq yenidən açılanda ad/qrup və ya tvg-id ilə tapılır.

## Pleyer işarəsi
EPG-nin sağında üstdə Media3 üçün 💙, VLC üçün 🧡, yanında ölçü, altında bufer (🟢🟡🔴) • endirmə sürəti • bitrate yazılır.
