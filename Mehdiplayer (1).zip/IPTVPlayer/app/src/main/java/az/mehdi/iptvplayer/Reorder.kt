package az.mehdi.iptvplayer

import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Qrup daxilində kanalların istifadəçi sırası. Playlist hər açılışda yenidən yüklənsə də sıra qalır:
 * hər qrup üçün "ad␂link" siyahısı saxlanılır; tətbiq edəndə əvvəl ad+link, sonra yalnız ad üzrə uyğunlaşdırılır,
 * saxlanmış siyahıda olmayan (yeni) kanallar qrupun sonuna düşür.
 */
object ChannelOrder {
    private const val FILE = "order"
    private const val SEP = '\u0002'

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun applyTo(p: SharedPreferences, group: String, list: List<Channel>): List<Channel> {
        val raw = p.getString("g:$group", null) ?: return list
        if (list.size < 2) return list
        val saved = raw.split('\n')
        val exact = HashMap<String, Int>()
        val byName = HashMap<String, ArrayDeque<Int>>()
        saved.forEachIndexed { i, s ->
            exact.putIfAbsent(s, i)
            byName.getOrPut(s.substringBefore(SEP)) { ArrayDeque() }.add(i)
        }
        val used = HashSet<Int>()
        val pos = IntArray(list.size)
        list.forEachIndexed { k, c ->
            var q = exact["${c.name}$SEP${c.url}"]
            if (q != null && q in used) q = null
            if (q == null) {
                val dq = byName[c.name]
                while (dq != null && dq.isNotEmpty() && dq.first() in used) dq.removeFirst()
                q = dq?.firstOrNull()
            }
            if (q != null) used.add(q)
            pos[k] = q ?: Int.MAX_VALUE
        }
        return list.indices.sortedWith(compareBy({ pos[it] }, { it })).map { list[it] }
    }

    fun save(ctx: Context, group: String, ordered: List<Channel>) {
        prefs(ctx).edit().putString("g:$group", ordered.joinToString("\n") { "${it.name}$SEP${it.url}" }).apply()
    }

    fun clear(ctx: Context, group: String) {
        prefs(ctx).edit().remove("g:$group").apply()
    }
}

/** Ümumi kanal siyahısının ən sonundakı düymə ("⚙️ Kanalların Yerini Dəyiş"). */
class FooterAdapter(
    private val text: String,
    private val onClick: () -> Unit
) : RecyclerView.Adapter<FooterAdapter.VH>() {
    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val c = p.context
        val d = c.resources.displayMetrics.density
        val tv = TextView(c).apply {
            layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                setMargins((5 * d).toInt(), (14 * d).toInt(), (5 * d).toInt(), (10 * d).toInt())
            }
            setBackgroundResource(R.drawable.item_bg)
            isFocusable = true
            isClickable = true
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding((12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt())
            setOnFocusChangeListener { v, has -> v.pop(has, 1.03f) }
        }
        return VH(tv)
    }

    override fun getItemCount() = 1

    override fun onBindViewHolder(h: VH, pos: Int) {
        h.tv.text = text
        h.tv.setOnClickListener { onClick() }
    }
}

/**
 * Tam ekran yerdəyişmə pəncərəsi. Solda kanallar, sağda düymələr.
 * OK: kanalı seç / seçimi ləğv et. Düymələr seçilmiş kanallara (seçim yoxdursa, son fokuslanan kanala) tətbiq olunur.
 */
class ReorderDialog(
    private val act: Context,
    private val group: String,
    channels: List<Channel>,
    private val onSave: (List<Channel>) -> Unit,
    private val onReset: () -> Unit
) : Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen) {

    private class Row(val ch: Channel) { var sel = false }
    private class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    private var rows: MutableList<Row> = channels.map { Row(it) }.toMutableList()
    private var anchorRow: Row? = rows.firstOrNull()
    private var changed = false
    private lateinit var rv: RecyclerView
    private lateinit var title: TextView
    private val buttons = ArrayList<TextView>()
    private var lastButton = 0
    private val density = act.resources.displayMetrics.density

    private fun dp(v: Int) = (v * density).toInt()

    private fun label(row: Row, pos: Int) = "${if (row.sel) "✔" else "   "}  ${pos + 1}.  ${row.ch.name}"

    private inner class RowAdapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = rows.size

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val tv = TextView(act).apply {
                layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                    setMargins(dp(4), dp(3), dp(4), dp(3))
                }
                setBackgroundResource(R.drawable.item_bg)
                isFocusable = true
                isClickable = true
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(10), dp(8), dp(10))
            }
            return VH(tv)
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val row = rows[pos]
            h.tv.text = label(row, pos)
            h.tv.isActivated = row.sel
            h.tv.setOnClickListener {
                row.sel = !row.sel
                val p = h.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) { h.tv.text = label(row, p); h.tv.isActivated = row.sel }
                updateTitle()
            }
            h.tv.setOnFocusChangeListener { v, has -> if (has) anchorRow = row; v.pop(has, 1.03f) }
        }
    }

    private fun selCount() = rows.count { it.sel }

    private fun updateTitle() {
        val n = selCount()
        title.text = "⚙️ Kanalların Yerini Dəyiş  ·  $group  (${rows.size})" + if (n > 0) "  ·  seçilib: $n" else ""
    }

    private fun addButton(text: String, action: () -> Unit) {
        val idx = buttons.size
        val tv = TextView(act).apply {
            this.text = text
            setBackgroundResource(R.drawable.item_bg)
            isFocusable = true
            isClickable = true
            maxLines = 1
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(12), dp(10), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnClickListener { action() }
            setOnFocusChangeListener { v, has -> if (has) lastButton = idx; v.pop(has, 1.04f) }
        }
        buttons.add(tv)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.apply {
            setLayout(MATCH_PARENT, MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(0xFF0E1117.toInt()))
            addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        val left = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        title = TextView(act).apply {
            setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), dp(4), dp(8), dp(2))
        }
        val hint = TextView(act).apply {
            text = "OK: kanalı seç / seçimi ləğv et   •   Sağ ►: düymələr   •   Seçim yoxdursa, fokusdakı kanal köçürülür"
            setTextColor(0xB3FFFFFF.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        rv = RecyclerView(act).apply {
            layoutManager = LinearLayoutManager(act)
            adapter = RowAdapter()
            itemAnimator = null
            clipToPadding = false
            isFocusable = false
        }
        left.addView(title, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        left.addView(hint, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        left.addView(rv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        root.addView(left, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))

        addButton("▲  Yuxarı") { moveBy(-1) }
        addButton("▼  Aşağı") { moveBy(1) }
        addButton("⏫  Ən başa") { moveEdge(true) }
        addButton("⏬  Ən sona") { moveEdge(false) }
        addButton("🔢  Nömrəyə apar") { askNumber() }
        addButton("✔  Hamısını seç") { selectAll(true) }
        addButton("✖  Seçimi təmizlə") { selectAll(false) }
        addButton("↩  İlkin sıraya qaytar") { confirmReset() }
        addButton("💾  Saxla") { save() }
        addButton("Ləğv et") { tryClose() }
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        buttons.forEach { col.addView(it) }
        val scroll = ScrollView(act).apply { isFillViewport = false; isFocusable = false; addView(col) }
        root.addView(scroll, LinearLayout.LayoutParams(dp(300), MATCH_PARENT).apply { marginStart = dp(12) })

        setContentView(root)
        updateTitle()
        setCancelable(false)
    }

    override fun onStart() {
        super.onStart()
        rv.postDelayed({ focusAnchor() }, 150)
    }

    private fun focusAnchor() {
        if (rows.isEmpty()) return
        val idx = rows.indexOf(anchorRow).coerceAtLeast(0)
        (rv.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(120))
        rv.postDelayed({ rv.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 80)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK || e.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (e.action == KeyEvent.ACTION_UP) tryClose()
            return true
        }
        if (e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f != null) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_RIGHT -> if (rv.findContainingItemView(f) != null) {
                        buttons.getOrNull(lastButton)?.requestFocus(); return true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> if (buttons.any { it === f }) { focusAnchor(); return true }
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------- yerdəyişmə əməliyyatları ----------
    private fun targets(): Set<Row> {
        val s = rows.filter { it.sel }
        return if (s.isNotEmpty()) s.toHashSet() else setOfNotNull(anchorRow)
    }

    private fun moved(t: Set<Row>) {
        changed = true
        anchorRow = rows.firstOrNull { it in t } ?: anchorRow
        rv.adapter?.notifyDataSetChanged()
        val idx = rows.indexOf(anchorRow)
        if (idx >= 0) rv.scrollToPosition(idx)
    }

    private fun moveBy(d: Int) {
        val t = targets()
        if (t.isEmpty()) return
        if (d < 0) {
            for (i in 1 until rows.size) if (rows[i] in t && rows[i - 1] !in t) java.util.Collections.swap(rows, i, i - 1)
        } else {
            for (i in rows.size - 2 downTo 0) if (rows[i] in t && rows[i + 1] !in t) java.util.Collections.swap(rows, i, i + 1)
        }
        moved(t)
    }

    private fun moveEdge(top: Boolean) {
        val t = targets()
        if (t.isEmpty()) return
        val (a, b) = rows.partition { it in t }
        rows = (if (top) a + b else b + a).toMutableList()
        moved(t)
    }

    private fun moveTo(n: Int) {
        val t = targets()
        if (t.isEmpty()) return
        val rest = rows.filter { it !in t }
        val block = rows.filter { it in t }
        val at = (n - 1).coerceIn(0, rest.size)
        rows = (rest.take(at) + block + rest.drop(at)).toMutableList()
        moved(t)
    }

    private fun selectAll(v: Boolean) {
        rows.forEach { it.sel = v }
        rv.adapter?.notifyDataSetChanged()
        updateTitle()
    }

    private fun askNumber() {
        val n = selCount().takeIf { it > 0 } ?: 1
        val et = EditText(act).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "1 – ${rows.size}"
            setSingleLine()
        }
        val box = FrameLayout(act).apply { setPadding(dp(24), dp(8), dp(24), 0); addView(et) }
        AlertDialog.Builder(act)
            .setTitle(if (selCount() > 0) "Seçilmiş $n kanal neçənci mövqeyə aparılsın?" else "Kanal neçənci mövqeyə aparılsın?")
            .setView(box)
            .setPositiveButton("Apar") { _, _ -> et.text.toString().toIntOrNull()?.let { moveTo(it) } }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(act)
            .setTitle("İlkin sıraya qaytarılsın?")
            .setMessage("“$group” qrupunun sırası playlistdəki ilkin vəziyyətə qayıdacaq.")
            .setPositiveButton("Qaytar") { _, _ -> onReset(); dismiss() }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun save() {
        if (changed) onSave(rows.map { it.ch })
        dismiss()
    }

    private fun tryClose() {
        if (!changed) { dismiss(); return }
        AlertDialog.Builder(act)
            .setTitle("Dəyişikliklər saxlanılsın?")
            .setPositiveButton("Saxla") { _, _ -> save() }
            .setNegativeButton("Saxlama") { _, _ -> dismiss() }
            .setNeutralButton("Davam et", null)
            .show()
    }
}
