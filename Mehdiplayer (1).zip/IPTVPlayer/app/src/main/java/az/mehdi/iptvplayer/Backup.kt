package az.mehdi.iptvplayer

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import java.util.Locale

/**
 * Ehtiyat link: playlistdəki əsas link işləməsə, yoda.az səhifəsi gizli WebView-da açılır,
 * səhifənin pleyerinin göndərdiyi tokenli .m3u8 linki tutulur və pleyerə verilir.
 * Token IP və User-Agent-ə bağlıdır, buna görə link bu cihazda, WebView-nın User-Agent-i ilə alınır.
 */
object Backup {
    /**
     * Azərbaycan kanalları → yoda.az səhifəsi. Qrupun və kanalın adı nə olursa olsun (HD/FHD, "AZ:" prefiksi, "TV"/"Televiziyası",
     * Ə/E, İ/I fərqləri) ad "əsas ada" gətirilib bu siyahıdakı ləqəblərlə tam uyğunlaşdırılır.
     * aliases: qrupdan asılı olmayaraq uyğunlaşan adlar. azOnlyAliases: Türkiyə kanalı ilə qarışa bilən adlar (ATV, NTV) –
     * yalnız Azərbaycan konteksti varsa (qrup/ad/tvg-id) uyğunlaşır.
     */
    private class Site(val id: String, val page: String, val aliases: List<String>, val azOnlyAliases: List<String> = emptyList()) {
        val keys: Set<String> = aliases.map { baseOf(analyze(it).first) }.toSet()
        val azKeys: Set<String> = azOnlyAliases.map { baseOf(analyze(it).first) }.toSet()
    }

    private val SITES: List<Site> by lazy {
        listOf(
            Site("aztv", "https://yoda.az/tv/azertv/", listOf("aztv", "azertv", "azerbaycan tv", "azerbaycan", "azerbaijan tv", "azerbaijan")),
            Site("medeniyyettv", "https://yoda.az/tv/medeniyyettele/", listOf("medeniyyet tv", "medeniyyet", "medeniyyet tele", "medeniyyet televiziyasi")),
            Site("idmantv", "https://yoda.az/tv/idmantele/", listOf("idman tv", "idman", "idman tele", "idman televiziyasi")),
            Site("biznestv", "https://yoda.az/tv/biznestv/", listOf("biznes tv", "biznes")),
            Site("bakutv", "https://yoda.az/tv/bakutv/", listOf("baku tv", "baki tv", "baku", "baki")),
            Site("apatv", "https://yoda.az/tv/apatv/", listOf("apa tv", "apa")),
            Site("realtv", "https://yoda.az/tv/real/", listOf("real tv", "real")),
            Site("arb24", "https://yoda.az/tv/arb24/", listOf("arb 24", "arb24")),
            Site("arbgunes", "https://yoda.az/arbgunesh/", listOf("arb gunes", "arb gunesh", "arbgunes", "arbgunesh")),
            Site("arb", "https://yoda.az/tv/arb/", listOf("arb", "arb tv")),
            Site("ictimaitv", "https://yoda.az/tv/ictimaitele/", listOf("ictimai tv", "ictimai", "ictimai tele", "ictimai televiziyasi")),
            Site("spacetv", "https://yoda.az/tv/space/", listOf("space tv", "space")),
            Site("atv", "https://yoda.az/tv/atv/", emptyList(), listOf("atv", "atv azad", "atv az")),
            Site("xezertv", "https://yoda.az/tv/xazartv/", listOf("xezer tv", "xezer", "xazar tv", "xazar", "khazar tv", "khazar")),
            Site("dunyatv", "https://yoda.az/tv/dunyatv/", listOf("dunya tv", "dunya")),
            Site("naxcivantv", "https://yoda.az/tv/ntv/", listOf("naxcivan tv", "naxcivan"), listOf("ntv")),
            Site("kanal35", "https://yoda.az/tv/kanal35/", listOf("kanal 35", "kanal35")),
            Site("qafqaztv", "https://yoda.az/tv/qafkaz/", listOf("qafqaz tv", "qafqaz", "qafkaz tv", "qafkaz")),
            Site("eltv", "https://yoda.az/tv/eltv/", listOf("el tv", "el"))
        )
    }

    internal fun norm(name: String): String {
        val sb = StringBuilder()
        for (c in name) {
            when (c) {
                'Ə', 'ə', 'E', 'e' -> sb.append('e')
                'İ', 'I', 'ı', 'i' -> sb.append('i')
                'Ö', 'ö', 'O', 'o' -> sb.append('o')
                'Ü', 'ü', 'U', 'u' -> sb.append('u')
                'Ç', 'ç', 'C', 'c' -> sb.append('c')
                'Ş', 'ş', 'S', 's' -> sb.append('s')
                'Ğ', 'ğ', 'G', 'g' -> sb.append('g')
                else -> if (c.isLetterOrDigit()) sb.append(c.lowercaseChar())
            }
        }
        var r = sb.toString()
        if (r.endsWith("hd") && r.length > 4) r = r.removeSuffix("hd")
        return r
    }

    private val NOISE = setOf("hd", "fhd", "uhd", "sd", "4k", "8k", "hevc", "h265", "h264", "backup", "ehtiyat", "biraz", "canli", "live", "1080p", "720p", "576p", "480p")
    private val TV_WORDS = setOf("tv", "tele", "televiziya", "televiziyasi", "televizya", "televizyon")
    private val AZ_WORDS = setOf("az", "azerbaycan", "azerbaijan")

    /** Ad → (söz siyahısı, adda "AZ/Azərbaycan" sözü varmı). Keyfiyyət sözləri atılır, AZ sözü başqa söz qalırsa atılır. */
    private fun analyze(name: String): Pair<List<String>, Boolean> {
        val all = name.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
            .map { norm(it) }.filter { it.isNotEmpty() && it !in NOISE }
        val rest = all.filter { it !in AZ_WORDS }
        val hasAz = rest.size != all.size
        // Yalnız "AZ TV" / "Azərbaycan" kimi adlarda AZ sözü adın özüdür, atılmır.
        val keep = if (rest.any { it !in TV_WORDS }) rest else all
        return keep to hasAz
    }

    /** Sonundakı TV/Televiziyası sözləri və "...tv" şəkilçisi atılır: "Xəzər TV", "Xəzər", "XəzərTV" eyni əsas ad verir. */
    private fun baseOf(words: List<String>): String {
        val l = words.toMutableList()
        while (l.isNotEmpty() && l.last() in TV_WORDS) l.removeAt(l.size - 1)
        var s = l.joinToString("")
        if (s.endsWith("tv") && s.length > 2) s = s.removeSuffix("tv")
        return s
    }

    private fun azContext(ch: Channel, nameHasAz: Boolean): Boolean {
        val g = norm(ch.group)
        val id = (ch.tvgId ?: "").lowercase()
        val turkish = g.contains("turk") || g == "tr" || id.endsWith(".tr")
        if (turkish) return false
        return nameHasAz || g == "az" || g.contains("azer") || id.endsWith(".az")
    }

    private fun siteFor(ch: Channel): Site? {
        for (nm in listOf(ch.name, ch.tvgName)) {
            if (nm.isNullOrBlank()) continue
            val (words, hasAz) = analyze(nm)
            val b = baseOf(words)
            if (b.isEmpty()) continue
            SITES.firstOrNull { b in it.keys }?.let { return it }
            if (azContext(ch, hasAz)) SITES.firstOrNull { b in it.azKeys }?.let { return it }
        }
        return null
    }

    /** Əvvəl yoda.az-dan açılan kanallar (playlistdəki link yalnız ehtiyatdır). */
    private val YODA_FIRST = setOf("apatv")

    /** true: bu kanal əvvəl yoda.az linki ilə açılır, alınmasa/işləməsə playlistdəki linkə keçilir. */
    fun yodaFirst(ch: Channel): Boolean = YODA_FIRST.contains(siteFor(ch)?.id ?: "")

    /** Kanalın yoda.az ehtiyat səhifəsi: qrupdan asılı deyil; yalnız ATV/NTV üçün Azərbaycan konteksti tələb olunur (Türkiyə ATV/NTV ilə qarışmasın). */
    fun pageFor(ch: Channel): String? = siteFor(ch)?.page
}

/** Gizli WebView ilə yoda.az səhifəsindən tokenli yayım linkini alır. Yalnız lazım olanda yaradılır, iş bitəndə yaddaşdan silinir. */
class YodaResolver(private val activity: Activity, private val container: ViewGroup) {

    class Result(val url: String, val referer: String, val userAgent: String)

    companion object {
        const val TIMEOUT_MS = 20_000L
        // Tokensiz .m3u8 görünsə də, tokenli link üçün bu qədər əlavə gözlənilir.
        private const val TOKEN_GRACE_MS = 4_000L
        private const val AUTOPLAY_JS = """
(function(){
  function go(){
    try{ document.querySelectorAll('video').forEach(function(v){ v.muted=true; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }); }catch(e){}
    try{ var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="big-play"],[class*="PlayButton"]'); if(b) b.click(); }catch(e){}
  }
  go(); setTimeout(go,1500); setTimeout(go,4000); setTimeout(go,8000);
})();
"""
    }

    private val ui = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var done = false
    private var candidate: Result? = null
    private var cb: ((Result?) -> Unit)? = null
    private var page = ""
    private var ua = ""

    private val timeoutRun = Runnable { finish(candidate) }
    private val graceRun = Runnable { finish(candidate) }

    @SuppressLint("SetJavaScriptEnabled")
    fun resolve(pageUrl: String, onResult: (Result?) -> Unit) {
        cancel()
        done = false
        candidate = null
        cb = onResult
        page = pageUrl
        try {
            val w = WebView(activity)
            web = w
            val s = w.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.cacheMode = WebSettings.LOAD_NO_CACHE
            s.blockNetworkImage = true // şəkillər lazım deyil: WebView prosesinin RAM-ı xeyli azalır
            ua = s.userAgentString
            w.alpha = 0.01f
            val px = (8 * activity.resources.displayMetrics.density).toInt()
            container.addView(w, FrameLayout.LayoutParams(px, px, Gravity.BOTTOM or Gravity.END))
            w.webChromeClient = WebChromeClient()
            w.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val req = request ?: return null
                    val u = req.url.toString()
                    if (u.substringBefore("?").lowercase(Locale.ROOT).endsWith(".m3u8")) {
                        val ref = req.requestHeaders?.get("Referer")?.takeIf { it.startsWith("http") } ?: page
                        val r = Result(u, ref, ua)
                        ui.post { onM3u8(r) }
                    }
                    return null
                }

                // WebView render prosesi (2 GB RAM-da yaddaş azlığından) ölərsə, bunu tutmayan tətbiq TAM ÇÖKÜR.
                // true qaytarılır: tətbiq yaşayır, WebView atılır və ehtiyat link prosesi nəticəsiz bitir.
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    android.util.Log.w("IPTV-BACKUP", "WebView prosesi dayandı (çökmə=${detail?.didCrash()})")
                    ui.post { if (!done) finish(candidate) }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!done && url != null && url != "about:blank") view?.evaluateJavascript(AUTOPLAY_JS, null)
                }
            }
            ui.postDelayed(timeoutRun, TIMEOUT_MS)
            w.loadUrl(pageUrl)
        } catch (e: Throwable) {
            android.util.Log.e("IPTV-BACKUP", "WebView açıla bilmədi", e)
            finish(null)
        }
    }

    private fun onM3u8(r: Result) {
        if (done) return
        if (r.url.contains("token=")) {
            finish(r)
        } else if (candidate == null) {
            candidate = r
            ui.postDelayed(graceRun, TOKEN_GRACE_MS)
        }
    }

    private fun finish(r: Result?) {
        if (done) return
        done = true
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(graceRun)
        val callback = cb
        cb = null
        destroyWeb()
        android.util.Log.i("IPTV-BACKUP", "yoda.az nəticə: " + (r?.url ?: "tapılmadı") + " (səhifə: $page)")
        callback?.invoke(r)
    }

    private fun destroyWeb() {
        val w = web ?: return
        web = null
        runCatching {
            w.stopLoading()
            w.loadUrl("about:blank")
            container.removeView(w)
            w.destroy()
        }
    }

    /** Gedən işi dayandırır (nəticə qaytarılmır). */
    fun cancel() {
        done = true
        cb = null
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(graceRun)
        destroyWeb()
    }
}
