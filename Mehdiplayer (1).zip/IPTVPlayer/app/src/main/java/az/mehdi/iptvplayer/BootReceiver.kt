package az.mehdi.iptvplayer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** TV box yandıqda (açılış tamamlananda) tətbiq özü başlayır. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val a = intent?.action ?: return
        if (a != Intent.ACTION_BOOT_COMPLETED && !a.endsWith("QUICKBOOT_POWERON")) return
        runCatching {
            context.startActivity(
                Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        }
    }
}
