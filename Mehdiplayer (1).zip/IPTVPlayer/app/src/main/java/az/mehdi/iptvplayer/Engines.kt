package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceView
import android.view.View
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import io.github.anilbeesetti.nextlib.media3ext.renderer.NextRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** Media3 hər cəhd düz EXO_TIMEOUT_MS (5 s) çəkir, əlavə gözləmə yoxdur (0). */
private const val EXO_EXTEND_MAX_MS = 0L

/** Media3 → VLC keçidinin YEGANƏ səbəbi: codec/dekoder və ya format/konteyner dəstəklənmir. */
const val CODEC_UNSUPPORTED = "Codec dəstəklənmir"

/** Hər iki mühərrikin (Media3 ExoPlayer, VLC) ümumi geri çağırışları. */
interface PlayerCallback {
    fun onLoading()
    /** Yüklənmə/keçid mesajı və həmin cəhd üçün təxmini taymer. */
    fun onStatus(message: String, countdownMs: Long = 0L) {}
    fun onPlaying()
    fun onBuffering(active: Boolean)
    fun onFailed(message: String)
    /**
     * Hər iki pleyer yayımı aça bilmədi. true qaytarılırsa ehtiyat link prosesi (yoda.az) başladılıb,
     * pleyer xəta göstərmir; isBackup = oynadılan link artıq yoda.az-dan alınmış linkdir.
     */
    fun onStreamFailed(isBackup: Boolean): Boolean = false
}

/** Əsas mühərrik: Media3 ExoPlayer. Codec dəstəklənmirsə və ya xəta olarsa PlayerManager VLC-yə keçir. */
class ExoEngine(
    private val context: Context,
    private val view: SurfaceView,
    private val callback: PlayerCallback
) {
    private val ui = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var url: String? = null
    private var playing = false
    private var buffering = false
    private var lastBufferingAt = 0L
    private var openTimeout: Runnable? = null
    private val speed = SpeedMeter()
    private var selector: DefaultTrackSelector? = null
    // Yoxlama (probe) rejimi: VLC oynayarkən Media3 səssiz və dekodersiz açılıb codec-ləri yoxlayır.
    // Hər şey dəstəklənirsə promote() ilə Media3 əsas pleyerə çevrilir.
    private var probeMode = false
    private var probeReported = false
    private var promoted = false
    // true/false = codec dəstəyi haqqında QƏTİ nəticə; null = nəticəsiz (vaxt aşımı/şəbəkə xətası) — kanal VLC-yə "yapışdırılmır".
    var onProbe: ((Boolean?) -> Unit)? = null
    // Bu kanalın açılma anı: əvvəlki kanalın gecikmiş xətaları (timestampMs bundan əvvəl) ignor olunur.
    private var startedAt = 0L
    private var firstFrameCheck: Runnable? = null
    // IPTV serverlərində tez-tez vaxtı keçmiş/özü imzalı sertifikat olur; yayım linkləri açılsın deyə
    // sertifikat yoxlaması söndürülüb.
    private val httpClient: OkHttpClient = run {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val b = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .dispatcher(Dispatcher().apply { maxRequests = 8; maxRequestsPerHost = 4 })
            .readTimeout(10, TimeUnit.SECONDS)
            // 2 GB RAM: kiçik bağlantı hovuzu, HTTP/1.1 (IPTV serverlərində ən sabit; HTTP/2 əlavə yaddaş tələb edir)
            .connectionPool(ConnectionPool(2, 30, TimeUnit.SECONDS))
            .protocols(listOf(Protocol.HTTP_1_1))
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .hostnameVerifier { _, _ -> true }
        runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            b.sslSocketFactory(ctx.socketFactory, trustAll)
        }
        b.build()
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (url == null || probeMode) return
            // Gecikmiş hadisə: pleyerin real vəziyyəti artıq başqadırsa (əvvəlki kanaldan qalıb) ignor.
            if (player?.playbackState != state) return
            when (state) {
                Player.STATE_READY -> {
                    markPlaying()
                    if (buffering) { buffering = false; callback.onBuffering(false) }
                }
                Player.STATE_BUFFERING -> if (playing) {
                    buffering = true
                    lastBufferingAt = SystemClock.elapsedRealtime()
                    callback.onBuffering(true)
                }
                Player.STATE_ENDED -> if (playing) fail("Yayım bitdi")
            }
        }

        override fun onRenderedFirstFrame() {
            if (promoted && !probeMode && url != null && player?.playbackState == Player.STATE_READY) markPlaying()
        }

        override fun onPlayerError(error: PlaybackException) {
            if (url == null) return
            // Əvvəlki kanalın gecikmiş xətası yeni kanala aid edilmir.
            if (error.timestampMs < startedAt) return
            if (probeMode) { reportProbe(null); return }
            // Canlı HLS-də pleyer pəncərədən geridə qalıbsa, kanalı yenidən açmadan canlı nöqtəyə qayıdır.
            if (playing && error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                player?.let { it.seekToDefaultPosition(); it.prepare() }
                return
            }
            val codec = when (error.errorCode) {
                PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
                PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
                PlaybackException.ERROR_CODE_DECODING_FAILED,
                PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
                PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
                // Format/konteyner Media3 tərəfindən oxuna bilmir (VLC aça bilər) — bu da keçid səbəbidir.
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> true
                else -> false
            }
            fail(if (codec) CODEC_UNSUPPORTED else "Media3 xətası: ${error.errorCodeName}")
        }

        override fun onTracksChanged(tracks0: Tracks) {
            if (url == null) return
            // Hadisənin gətirdiyi (köhnə ola bilən) treklər yox, pleyerin hazırkı treklərinə baxılır.
            val tracks = player?.currentTracks ?: tracks0
            if (probeMode) {
                if (tracks.groups.isEmpty()) return
                var ok = true
                for (type in intArrayOf(C.TRACK_TYPE_VIDEO, C.TRACK_TYPE_AUDIO)) {
                    if (tracks.containsType(type) && !tracks.isTypeSupported(type, true)) ok = false
                }
                reportProbe(ok)
                return
            }
            // Video və ya audio codec cihazda dəstəklənmirsə, VLC-yə keçmək üçün xəta bildirilir.
            for (type in intArrayOf(C.TRACK_TYPE_VIDEO, C.TRACK_TYPE_AUDIO)) {
                if (tracks.containsType(type) && !tracks.isTypeSupported(type, true)) {
                    fail(CODEC_UNSUPPORTED)
                    return
                }
            }
        }
    }

    init {
        try {
            // 2 GB RAM TV box üçün sıfırdan seçilmiş Media3 parametrləri:
            // - Dekoder: əvvəl cihazın MediaCodec-i (HW, açılmasa SW ehtiyatı); cihaz audio codec-i açmayanda FFmpeg
            //   FFmpeg (NextLib) audio+video renderer ehtiyat kimi işləyir (EXTENSION_RENDERER_MODE_ON = MediaCodec-dən SONRA), asinxron bufer növbəsi.
            val renderers = NextRenderersFactory(context.applicationContext)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true)
            // - Bufer: min 15 s, max 30 s, başlamaq 2.5 s, təkrar buferdən sonra 5 s. Yaddaş limiti 32 MB
            //   (1080p ~8 Mbit/s üçün 30 s ≈ 30 MB; 4K-da limit işləyir və RAM-ı doldurmur). Geriyə bufer yoxdur.
            val load = DefaultLoadControl.Builder()
                .setBufferDurationsMs(10_000, 20_000, 2_500, 5_000)
                .setTargetBufferBytes(20 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .setBackBuffer(0, false)
                .build()
            // - Keyfiyyət: 1080p-dən yuxarı seçilmir (yalnız 4K varsa o açılır), 30 kadr/san-dən yuxarı olmayan variant
            //   üstünlük alır, mono/stereo səs, tunneling söndürülüb.
            val selector = DefaultTrackSelector(context.applicationContext)
            this.selector = selector
            selector.setParameters(
                selector.buildUponParameters()
                    .setMaxVideoSize(1920, 1080)
                    .setMaxVideoFrameRate(30)
                    .setViewportSizeToPhysicalDisplaySize(context.applicationContext, true)
                    .setExceedVideoConstraintsIfNecessary(true)
                    .setForceHighestSupportedBitrate(false)
                    .setTunnelingEnabled(false)
            )
            val p = ExoPlayer.Builder(context.applicationContext, renderers)
                .setLoadControl(load)
                .setTrackSelector(selector)
                .build()
            p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT // ekranı tam doldurur (stretch)
            p.setVideoSurfaceView(view)
            p.addListener(listener)
            p.playWhenReady = true
            player = p
        } catch (t: Throwable) {
            android.util.Log.e("IPTV-EXO", "Media3 başladılmadı", t)
            player = null
        }
    }

    private fun markPlaying() {
        if (playing) return
        playing = true
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        callback.onPlaying()
    }

    private fun fail(message: String) {
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        callback.onFailed(message)
    }

    private fun reportProbe(ok: Boolean?) {
        if (probeReported) return
        probeReported = true
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        onProbe?.invoke(ok)
    }

    /** Yoxlama zamanı video/audio söndürülür (dekoder açılmır), yalnız treklərin dəstəyi öyrənilir. */
    private fun setTracksDisabled(disabled: Boolean) {
        val s = selector ?: return
        s.setParameters(
            s.buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, disabled)
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, disabled)
        )
    }

    fun play(newUrl: String, ua: String?, ref: String?, timeoutMs: Long) = start(newUrl, ua, ref, timeoutMs, false)

    /** VLC oynayarkən: codec-lər cihazda dəstəklənirmi? Nəticə onProbe ilə bildirilir. Heç nə göstərilmir/səslənmir. */
    fun probe(newUrl: String, ua: String?, ref: String?, timeoutMs: Long) = start(newUrl, ua, ref, timeoutMs, true)

    /** Yoxlama uğurlu oldu: Media3 əsas pleyerə çevrilir (treklər açılır, oynatma başlayır). */
    /** Açılış vaxt aşımı: real irəliləyiş varsa (manifest/trek/bufer) pleyer dəyişmir, məhdud müddət əlavə gözləyir. */
    private fun armOpen(waitMs: Long, baseMs: Long, probe: Boolean) {
        openTimeout?.let { ui.removeCallbacks(it) }
        val r = Runnable {
            openTimeout = null
            if (url == null) return@Runnable
            if (!probe && playing) return@Runnable
            val p = player
            val now = SystemClock.elapsedRealtime()
            val progressed = p != null && (p.totalBufferedDuration > 0 || p.currentTracks.groups.isNotEmpty())
            if (progressed && now - startedAt < baseMs + EXO_EXTEND_MAX_MS) { armOpen(3_000L, baseMs, probe); return@Runnable }
            if (probe) reportProbe(null) else fail("Media3 ${baseMs / 1000} saniyədə açmadı")
        }
        openTimeout = r
        ui.postDelayed(r, waitMs)
    }

    fun promote(timeoutMs: Long) {
        val p = player
        if (p == null || url == null) { fail("Media3 işə düşmədi"); return }
        probeMode = false
        promoted = true
        playing = false
        buffering = false
        speed.reset()
        setTracksDisabled(false)
        p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
        p.playWhenReady = true
        startedAt = SystemClock.elapsedRealtime()
        armOpen(timeoutMs, timeoutMs, false)
        // Yalnız səsli yayımda ilk kadr hadisəsi gəlmir; hazırdırsa 1 s sonra oynayır sayılır.
        firstFrameCheck?.let { ui.removeCallbacks(it) }
        val ffc = Runnable {
            if (promoted && !playing && url != null && p.playbackState == Player.STATE_READY && p.playWhenReady) markPlaying()
        }
        firstFrameCheck = ffc
        ui.postDelayed(ffc, 1000)
    }

    private fun start(newUrl: String, ua: String?, ref: String?, timeoutMs: Long, probe: Boolean) {
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        firstFrameCheck?.let { ui.removeCallbacks(it) }
        firstFrameCheck = null
        url = newUrl
        startedAt = SystemClock.elapsedRealtime()
        playing = false
        buffering = false
        probeMode = probe
        probeReported = false
        promoted = false
        speed.reset()
        val p = player
        if (p == null) { if (probe) reportProbe(null) else fail("Media3 işə düşmədi"); return }
        setTracksDisabled(probe)
        try {
            val http = OkHttpDataSource.Factory(httpClient)
                .setUserAgent(ua?.takeIf { it.isNotBlank() } ?: "VLC/3.0.20 LibVLC/3.0.20")
            ref?.takeIf { it.isNotBlank() }?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
            // Yayım başlamamışdan əvvəl 4 təkrar cəhd (1 s fasilə): yavaş/qəfil xətalı kanal dərhal pleyer dəyişməsin;
            // ardınca VLC-yə keçilir. Yayım başladıqdan sonra standart təkrar cəhd işləyir.
            val policy = object : DefaultLoadErrorHandlingPolicy(6) {
                override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long =
                    if (playing) super.getRetryDelayMsFor(loadErrorInfo)
                    else if (loadErrorInfo.errorCount <= 4) 1000L
                    else C.TIME_UNSET
            }
            // IPTV MPEG-TS yayımları: IDR olmayan açar kadrlar qəbul edilir və kadr sərhədləri özü tapılır (AUD yoxdursa da),
            // beləliklə video başlanğıcda və kəsilmədən sonra daha tez bərpa olunur.
            val extractors = DefaultExtractorsFactory().setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
            )
            val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(context.applicationContext, http), extractors)
                .setLoadErrorHandlingPolicy(policy)
            // Canlı yayımda bufer/gecikmə yığılarsa (14 s-dən çox), pleyer 1.04x sürətlə yığılanı avtomatik əridir.
            // Canlı yayım: hədəf gecikmə yayımın öz siyahısından (HLS-də adətən 3 seqment) götürülür, məcburi 8 s qoyulmur;
            // səs sürəti dəyişdirilmir (0.97x/1.04x səs/video ilişməsi yaradırdı).
            val live = MediaItem.LiveConfiguration.Builder()
                .setMinPlaybackSpeed(1.0f)
                .setMaxPlaybackSpeed(1.0f)
                .build()
            val item = MediaItem.Builder().setUri(newUrl).setLiveConfiguration(live).apply {
                val l = newUrl.lowercase()
                // Genişlənməsi gizli qalan HLS/DASH linkləri də düzgün tanınsın.
                if (l.contains(".m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8)
                else if (l.contains(".mpd")) setMimeType(MimeTypes.APPLICATION_MPD)
                else if (l.contains(".ism/manifest")) setMimeType(MimeTypes.APPLICATION_SS)
            }.build()
            p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            // Əvvəlki kanalın bufer və vəziyyəti tam boşaldılır, yalnız sonra yeni mənbə verilir.
            runCatching { p.stop(); p.clearMediaItems() }
            p.setMediaSource(factory.createMediaSource(item))
            p.prepare()
            p.playWhenReady = !probe
            armOpen(timeoutMs, timeoutMs, probe)
        } catch (t: Throwable) {
            android.util.Log.e("IPTV-EXO", "Yayım açıla bilmədi", t)
            if (probe) reportProbe(null) else fail("Media3 yayımı aça bilmədi")
        }
    }

    fun stop() {
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        firstFrameCheck?.let { ui.removeCallbacks(it) }
        firstFrameCheck = null
        url = null
        probeMode = false
        probeReported = false
        promoted = false
        playing = false
        buffering = false
        player?.let { runCatching { it.stop(); it.clearMediaItems() } }
    }

    fun togglePause() {
        val p = player ?: return
        if (!playing) return
        p.playWhenReady = !p.playWhenReady
    }

    /** Oynatma mövqeyi (ms); yayım donanda dəyişmir. */
    fun position(): Long = player?.currentPosition ?: -1L

    fun stats(): PlayerStats? {
        val p = player ?: return null
        if (!playing) return null
        val now = SystemClock.elapsedRealtime()
        val size = p.videoSize
        val level = when {
            buffering -> 2
            now - lastBufferingAt < 12_000L -> 1
            else -> 0
        }
        val vb = p.videoFormat?.let { if (it.bitrate > 0) it.bitrate else it.averageBitrate } ?: -1
        val ab = p.audioFormat?.let { if (it.bitrate > 0) it.bitrate else it.averageBitrate } ?: -1
        val br = if (vb > 0) (vb + maxOf(ab, 0)).toLong() else -1L
        return PlayerStats(size.width, size.height, p.totalBufferedDuration, level, speed.sample(uidRxBytes(), now), "", br)
    }

    fun release() {
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        url = null
        player?.let { runCatching { it.release() } }
        player = null
    }
}

/**
 * Kanal linkinin serverinə ilkin sorğu (pleyerlərdən əvvəl).
 * false = server xəta qaytardı (HTTP 4xx/5xx) və ya qoşulmadı (DNS/refused/SSL) → kanal işləmir;
 * true = server normal cavab verdi; null = nəticəsiz (vaxt aşımı və ya yanlış link) → pleyerlər yoxlayır.
 */
private object Preflight {
    private val client: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val b = OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .callTimeout(5, TimeUnit.SECONDS)
            .protocols(listOf(Protocol.HTTP_1_1))
            .followRedirects(true)
            .followSslRedirects(true)
            .hostnameVerifier { _, _ -> true }
        runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            b.sslSocketFactory(ctx.socketFactory, trustAll)
        }
        b.build()
    }

    fun check(url: String, ua: String?, ref: String?): Boolean? {
        return try {
            val rb = okhttp3.Request.Builder().url(url)
                .header("User-Agent", ua?.takeIf { it.isNotBlank() } ?: "VLC/3.0.20 LibVLC/3.0.20")
            ref?.takeIf { it.isNotBlank() }?.let { rb.header("Referer", it) }
            // Yalnız başlıqlar oxunur, yayımın gövdəsi endirilmir (use bağlantını bağlayır).
            client.newCall(rb.build()).execute().use { r -> r.code < 400 }
        } catch (e: java.net.SocketTimeoutException) {
            null
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: java.io.IOException) {
            false
        } catch (e: Throwable) {
            // Ayrıca thread-də tutulmayan istənilən xəta bütün tətbiqi çökdürür: nəticəsiz sayılır, pleyerlər yoxlayır.
            null
        }
    }
}

/**
 * Pleyer meneceri: yeni kanal Media3 (5 s) → VLC (5 s) → Media3 (5 s); hansı açsa yadda saxlanılır; hamısı açmasa xəta göstərilir.
 */
class PlayerManager(
    context: Context,
    private val exoView: SurfaceView,
    private val vlcView: SurfaceView,
    private val cb: PlayerCallback
) {
    private enum class Stage { EXO, VLC }
    // Yoxlama: VLC oynayandan sonra Media3 codec-ləri yoxlayır (PENDING → RUNNING → DONE); OFF = yoxlama yoxdur.
    private enum class Probe { OFF, PENDING, RUNNING, DONE }

    private companion object {
        // YENİ kanal açılışı: Media3 5 s → VLC 5 s → Media3 5 s (cəmi 15 s); hamısı açmasa "Kanal İşləmir".
        // İŞLƏYƏN kanal buferdə 5 s qalıb açılmasa: VLC 5 s → Media3 5 s (bərpa ardıcıllığı).
        // Hansı pleyerlə açılsa, o yadda saxlanılır.
        const val EXO_TIMEOUT_MS = 5_000L
        const val PROBE_TIMEOUT_MS = 6_000L
        const val PREFLIGHT_MS = 5_000L
        const val VLC_TIMEOUT_MS = 5_000L
        // Media3-ün oxuya bilmədiyi protokollar birbaşa VLC-yə verilir.
        val VLC_ONLY_SCHEMES = setOf("rtmp", "rtmps", "rtmpt", "rtmpe", "mms", "mmsh", "mmst", "rtp", "udp", "srt", "rist", "ftp", "sftp", "smb", "dvb", "tcp")
        // Tez-tez yaradıb-silmək native çökmə riskini artırır: VLC yalnız Media3 uzun müddət işləyəndə boşaldılır.
        const val VLC_UNLOAD_DELAY_MS = 45_000L
        // Avtomatik bərpa: bufer 6 s dolmursa və ya görüntü 6 s donursa kanal yenidən qoşulur.
        const val STALL_BUFFERING_MS = 5_000L
        const val STALL_FREEZE_MS = 5_000L
        // VLC-də donma/bufer 5 s-dən uzun çəkərsə bərpa ardıcıllığı başlayır (VLC 5 s → Media3 5 s).
        const val VLC_STALL_MS = 5_000L
        const val VLC_NO_TIME_MS = 10_000L
        const val WATCHDOG_MS = 1_000L
        const val RECONNECT_DELAY_MS = 0L
        // Əvvəl işləmiş kanalın bərpası bu müddətdən uzun çəksə yüklənmə göstəricisi çıxır; qısa bərpa görünmür.
        const val SILENT_RECOVERY_MS = 3_500L
        const val RETRY_ALL_DELAY_MS = 2_000L
        const val FLAP_WINDOW_MS = 60_000L
        const val FLAP_LIMIT = 4
    }

    private val ui = Handler(Looper.getMainLooper())
    // Media3 işləyirsə, VLC 2 dəqiqə sonra yaddaşdan boşaldılır (2 GB RAM).
    private val unloadVlcRun = Runnable { if (!released && stage == Stage.EXO) vlc.unload(full = true) }
    private var stage = Stage.EXO
    private var probe = Probe.OFF
    private var promotedAttempt = false
    private var url: String? = null
    private var ua: String? = null
    private var ref: String? = null
    // true: oynadılan link yoda.az ehtiyat linkidir (tokenlidir, pleyer yaddaşına yazılmır)
    private var usingBackup = false
    private var resume = false
    private var released = false
    private var playedOk = false
    private var everPlayed = false
    private var reconnecting = false
    private var userPaused = false
    private var bufferingSince = 0L
    private var lastPos = -1L
    private var lastPosAt = 0L
    private val reconnectTimes = ArrayDeque<Long>()
    // VLC döngüyə düşəndə (60 s-də FLAP_LIMIT dəfə yenidən qoşulma) kanal Media3-ə verilir.
    private var toExo = false
    private val watchdogRun = object : Runnable {
        override fun run() {
            if (released || url == null || !playedOk) return
            val now = SystemClock.elapsedRealtime()
            var stalled = false
            if (!userPaused) {
                // VLC də Media3 ilə eyni limitləri işlədir (bufer/donma 5 s): daha qısa limit sonsuz təkrar qoşulma döngüsü yaradırdı.
                val bufLimit = STALL_BUFFERING_MS
                val frzLimit = STALL_FREEZE_MS
                if (bufferingSince != 0L && now - bufferingSince >= bufLimit) {
                    stalled = true
                } else {
                    val pos = if (stage == Stage.EXO) exo.position() else vlc.position()
                    if (pos > 0) {
                        if (pos != lastPos) { lastPos = pos; lastPosAt = now }
                        else if (now - lastPosAt >= frzLimit) stalled = true
                    } else if (stage == Stage.VLC && now - lastPosAt > VLC_NO_TIME_MS) {
                        // VLC "oynayır" dedi, amma vaxt heç irəliləmir (qara ekran/boş yayım): yenidən qoşulur.
                        stalled = true
                    }
                }
            }
            if (stalled) { reconnect("Yayım donub"); return }
            ui.postDelayed(this, WATCHDOG_MS)
        }
    }
    private val slowRecoveryRun = Runnable { if (!released && url != null && reconnecting) cb.onLoading() }
    private val restartRun = Runnable {
        if (released || url == null) return@Runnable
        reconnecting = false
        if (toExo) { toExo = false; startExo(transition = true) }
        else if (stage == Stage.EXO) startExo(retry = true) else startVlc(retry = true)
    }
    private val retryAllRun = Runnable {
        if (released || url == null) return@Runnable
        exoTried = false
        vlcTried = false
        exoRetry = 0
        reconnecting = false
        promotedAttempt = false
        begin()
    }

    private inner class StageCb(private val src: Stage) : PlayerCallback {
        private fun active() = !released && url != null && (src == Stage.EXO) == (stage == Stage.EXO)
        override fun onLoading() {}
        override fun onPlaying() {
            if (!active()) return
            if (src == Stage.EXO) {
                ui.removeCallbacks(unloadVlcRun)
                ui.postDelayed(unloadVlcRun, VLC_UNLOAD_DELAY_MS)
            }
            playedOk = true
            everPlayed = true
            reconnecting = false
            bufferingSince = 0L
            lastPos = -1L
            lastPosAt = SystemClock.elapsedRealtime()
            ui.removeCallbacks(watchdogRun)
            ui.postDelayed(watchdogRun, WATCHDOG_MS)
            // Kanal hansı pleyerlə açıldısa (VLC və ya Media3), o yadda saxlanılır.
            remember(src)
            cb.onPlaying()
            if (src == Stage.VLC && probe == Probe.PENDING) startProbe()
        }
        override fun onBuffering(active: Boolean) {
            if (!active()) return
            if (active) { if (bufferingSince == 0L) bufferingSince = SystemClock.elapsedRealtime() }
            else bufferingSince = 0L
            cb.onBuffering(active)
        }
        override fun onFailed(message: String) {
            if (!active() || reconnecting) return
            // Yayım əvvəl işləyibsə (sonra qırılıbsa) eyni pleyerlə yenidən qoşulur; ilk açılışda isə pleyer dəyişir.
            if (playedOk) reconnect(message) else fallback(message)
        }
    }

    private val exo = ExoEngine(context, exoView, StageCb(Stage.EXO))
    private val vlc = VlcEngine(context, vlcView, StageCb(Stage.VLC))

    init { exo.onProbe = { ok -> onProbeResult(ok) } }

    /** VLC oynayır: Media3 səssiz olaraq codec-ləri yoxlayır. */
    private fun startProbe() {
        val u = url ?: return
        probe = Probe.RUNNING
        exo.probe(u, ua, ref, PROBE_TIMEOUT_MS)
    }

    private fun onProbeResult(ok: Boolean?) {
        if (released || url == null || probe != Probe.RUNNING || stage != Stage.VLC) return
        probe = Probe.DONE
        if (ok == null) {
            // Nəticəsiz (yavaş/şəbəkə xətası): kanal VLC ilə qalır, amma "VLC-yə yapışdırılmır" — növbəti dəfə yenidən yoxlanılır.
            exo.stop()
            return
        }
        if (!ok) {
            // Codec problemi var (və ya Media3 açmadı): VLC ilə qalır, seçim yadda saxlanır.
            exo.stop()
            remember(Stage.VLC)
            return
        }
        promote()
    }

    /** Codec problemi yoxdur: VLC dayandırılır, Media3 əsas pleyer olur. */
    private fun promote() {
        promotedAttempt = true
        exoTried = true
        playedOk = false
        bufferingSince = 0L
        ui.removeCallbacks(watchdogRun)
        stage = Stage.EXO
        vlc.stop()
        showExo(true)
        cb.onLoading()
        cb.onStatus("Media3 Playerə keçid edilir", EXO_TIMEOUT_MS)
        exo.promote(EXO_TIMEOUT_MS)
    }

    private fun showExo(exoVisible: Boolean) {
        exoView.visibility = if (exoVisible) View.VISIBLE else View.GONE
        vlcView.visibility = if (exoVisible) View.GONE else View.VISIBLE
    }

    // ---------- Kanal hansı pleyerlə açılır: yadda saxlanılır ----------
    private val memory = context.applicationContext.getSharedPreferences("player_memory_v3", Context.MODE_PRIVATE)
    private var exoTried = false
    private var vlcTried = false
    private var exoRetry = 0
    // Açılış ardıcıllığı (hər addım 5 s): yeni kanal [EXO, VLC, EXO]; VLC ilə yadda qalıbsa [VLC, EXO, VLC]. seqStep = hazırda gedən addım.
    private var seq: List<Stage> = emptyList()
    private var seqStep = 0
    // İlkin server sorğusunun nömrəsi: kanal dəyişəndə/dayandırılanda köhnə nəticə ignor edilir.
    private var preflightGen = 0

    // Yeni kanal: [first, other, first] (15 s). Bərpa (işləyən kanal buferdə qalıb): [first, other] (10 s).
    private fun seqFrom(first: Stage, withRetry: Boolean = true): List<Stage> {
        val other = if (first == Stage.EXO) Stage.VLC else Stage.EXO
        return if (withRetry) listOf(first, other, first) else listOf(first, other)
    }

    private fun memKey(u: String): String = try {
        java.security.MessageDigest.getInstance("SHA-1").digest(u.toByteArray())
            .joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { u.hashCode().toString() }

    private fun remembered(u: String): String? = memory.getString(memKey(u), null)

    /** Playlistdə artıq olmayan (dəyişmiş/silinmiş) linklərin pleyer yaddaşı silinir; yeni link yenidən Media3 → VLC sırası ilə yoxlanılır. */
    fun pruneMemory(urls: Collection<String>) {
        if (urls.isEmpty()) return
        val valid = HashSet<String>(urls.size * 2)
        for (u in urls) valid.add(memKey(u))
        val stale = memory.all.keys.filter { it !in valid }
        if (stale.isNotEmpty()) {
            val e = memory.edit()
            for (k in stale) e.remove(k)
            e.apply()
        }
    }

    private fun remember(src: Stage) {
        if (usingBackup) return
        val u = url ?: return
        if (u.substringBefore("://", "").lowercase() in VLC_ONLY_SCHEMES) return
        val v = if (src == Stage.EXO) "exo" else "vlc"
        val k = memKey(u)
        if (memory.getString(k, null) != v) memory.edit().putString(k, v).apply()
    }

    private fun startExo(transition: Boolean = false, retry: Boolean = false) {
        val u = url ?: return
        val isRetry = retry || reconnecting || exoRetry > 0 || exoTried
        if (probe == Probe.RUNNING || probe == Probe.PENDING) probe = Probe.DONE
        if (!(retry && everPlayed)) cb.onStatus(
            when {
                transition -> "Media3 Playerə keçid edilir"
                isRetry -> "Təkrar cəhd edilir (Media3 Player)"
                else -> "Yüklənir (Media3 Player)"
            },
            EXO_TIMEOUT_MS
        )
        exoTried = true
        playedOk = false
        stage = Stage.EXO
        vlc.stop()
        showExo(true)
        exo.play(u, ua, ref, EXO_TIMEOUT_MS)
    }

    private fun startVlc(transition: Boolean = false, retry: Boolean = false) {
        val u = url ?: return
        val isRetry = retry || reconnecting || vlcTried
        if (probe == Probe.RUNNING) probe = Probe.PENDING
        // Əvvəl işləmiş kanalın təkrar cəhdində yükləmə paneli dərhal çıxmır: son kadr ekranda qalır, bərpa fonda gedir.
        if (!(retry && everPlayed)) cb.onStatus(
            when {
                transition -> "VLC Playerə keçid edilir"
                isRetry -> "Təkrar cəhd edilir (VLC Player)"
                else -> "Yüklənir (VLC Player)"
            },
            VLC_TIMEOUT_MS
        )
        vlcTried = true
        playedOk = false
        stage = Stage.VLC
        exo.stop()
        showExo(false)
        vlc.play(u, ua, ref, VLC_TIMEOUT_MS, isRetry)
    }

    fun play(newUrl: String, newUa: String? = null, newRef: String? = null, backup: Boolean = false) {
        if (released) return
        url = newUrl; ua = newUa; ref = newRef
        usingBackup = backup
        resume = false
        exoTried = false
        vlcTried = false
        exoRetry = 0
        playedOk = false
        everPlayed = false
        reconnecting = false
        userPaused = false
        bufferingSince = 0L
        reconnectTimes.clear()
        toExo = false
        cancelRecovery()
        ui.removeCallbacks(unloadVlcRun)
        exo.stop()
        // Başqa kanala keçid: VLC yaddaşdan tam boşaldılır (lazım olsa yeni kanal üçün təzədən yaradılacaq).
        vlc.stop()
        vlc.unload()
        promotedAttempt = false
        cb.onLoading()
        begin()
    }

    /**
     * Açılış ardıcıllığı: yeni kanal Media3 ExoPlayer 5 s → VLC 5 s → Media3 5 s (15 s yerində qalır).
     * Hansı pleyerlə açılsa, o yadda saxlanılır və növbəti dəfə kanal əvvəl həmin pleyerlə açılır.
     * Media3-ün oxuya bilmədiyi protokollar (rtmp, udp...) yalnız VLC ilə açılır.
     */
    private fun begin() {
        val u = url ?: return
        val scheme = u.substringBefore("://", "").lowercase()
        probe = Probe.OFF
        // Əvvəl kanalın serverinə sorğu: xəta cavabı (404/403/5xx, qoşulmur) alınırsa kanal işləmir, pleyerlər yoxlanmır.
        // Ehtiyat (yoda.az tokenli) linkdə sorğu göndərilmir.
        if (!usingBackup && (scheme == "http" || scheme == "https")) {
            val g = ++preflightGen
            val pu = u; val pua = ua; val pref = ref
            cb.onStatus("Server yoxlanılır", PREFLIGHT_MS)
            Thread {
                val r = Preflight.check(pu, pua, pref)
                ui.post {
                    if (released || g != preflightGen || url != pu) return@post
                    if (r == false) {
                        android.util.Log.w("IPTV-PLAYER", "Server xəta qaytardı/qoşulmadı → kanal işləmir: $pu")
                        failAll()
                    } else startSequence(pu, scheme)
                }
            }.start()
            return
        }
        startSequence(u, scheme)
    }

    private fun startSequence(u: String, scheme: String) {
        seqStep = 0
        when {
            // Media3-ün oxuya bilmədiyi protokollar yalnız VLC ilə (3 × 5 s).
            scheme in VLC_ONLY_SCHEMES -> { seq = listOf(Stage.VLC, Stage.VLC, Stage.VLC); startVlc() }
            // Media3 ilə artıq işləmiş kanal: VLC-yə keçid yoxdur, yalnız Media3 təkrar yoxlanılır (3 × 5 s).
            remembered(u) == "exo" && everPlayed -> { seq = listOf(Stage.EXO, Stage.EXO, Stage.EXO); startExo() }
            // Media3 ilə yadda qalmış kanal (bu seansda hələ açılmayıb): Media3 5 s → VLC 5 s → Media3 5 s.
            remembered(u) == "exo" -> { seq = seqFrom(Stage.EXO); startExo() }
            // VLC ilə yadda qalmış kanal: VLC 5 s → Media3 5 s → VLC 5 s.
            remembered(u) == "vlc" -> { seq = seqFrom(Stage.VLC); startVlc() }
            // YENİ kanal (yaddaşda yoxdur): Media3 5 s → VLC 5 s → Media3 5 s.
            else -> { seq = seqFrom(Stage.EXO); startExo() }
        }
    }

    private fun fallback(message: String) {
        android.util.Log.w("IPTV-PLAYER", "Keçid ($stage, addım ${seqStep + 1}/${seq.size}): $message")
        // Növbəti addım (hər biri 5 s): seq-də göstərilən sıra. Hamısı uğursuz olarsa kanal işləmir.
        seqStep++
        if (seqStep >= seq.size) { failAll(); return }
        probe = Probe.OFF
        when (seq[seqStep]) {
            Stage.EXO -> startExo(transition = true)
            Stage.VLC -> startVlc(transition = true)
        }
    }

    private fun failAll() {
        exo.stop()
        vlc.stop()
        // Əsas link işləmir: ehtiyat link (yoda.az) prosesi başladılırsa xəta göstərilmir.
        if (!released && url != null && cb.onStreamFailed(usingBackup)) return
        if (everPlayed) {
            // Kanal əvvəl işləyib: server müvəqqəti düşübsə, hər 3 s-dən bir avtomatik təkrar yoxlanılır.
            cb.onLoading()
            cb.onStatus("Kanal cavab vermir — yenidən yoxlanılır", RETRY_ALL_DELAY_MS)
            ui.removeCallbacks(retryAllRun)
            ui.postDelayed(retryAllRun, RETRY_ALL_DELAY_MS)
        } else {
            cb.onFailed("Kanal İşləmir")
        }
    }

    private fun cancelRecovery() {
        preflightGen++
        ui.removeCallbacks(watchdogRun)
        ui.removeCallbacks(restartRun)
        ui.removeCallbacks(retryAllRun)
        ui.removeCallbacks(slowRecoveryRun)
    }

    /** Yayım işləyərkən qırılıb/donub: kanalı avtomatik yenidən qoşur. */
    private fun reconnect(reason: String) {
        if (released || url == null || reconnecting) return
        android.util.Log.w("IPTV-PLAYER", "Yenidən qoşulma ($stage): $reason")
        if (!everPlayed) cb.onStatus("Təkrar cəhd edilir", if (stage == Stage.EXO) EXO_TIMEOUT_MS else VLC_TIMEOUT_MS)
        reconnecting = true
        playedOk = false
        bufferingSince = 0L
        // Bərpa: VLC ilə işləyən kanal → VLC 5 s → Media3 5 s. Media3 ilə işləyən kanalda pleyer dəyişmir: yalnız Media3 yenidən qoşulur.
        seq = if (stage == Stage.EXO) listOf(Stage.EXO, Stage.EXO) else seqFrom(stage, withRetry = false)
        seqStep = 0
        ui.removeCallbacks(watchdogRun)
        val now = SystemClock.elapsedRealtime()
        while (reconnectTimes.isNotEmpty() && now - reconnectTimes.first() > FLAP_WINDOW_MS) reconnectTimes.removeFirst()
        reconnectTimes.addLast(now)
        if (stage == Stage.VLC && reconnectTimes.size >= FLAP_LIMIT) {
            android.util.Log.w("IPTV-PLAYER", "VLC döngüyə düşdü → Media3-ə keçid")
            reconnectTimes.clear()
            seq = listOf(Stage.EXO, Stage.EXO)
            seqStep = 0
            toExo = true
        }
        // Əvvəl oynamış kanalın bərpası sakit gedir: son kadr ekranda qalır, yüklənmə yalnız uzun çəkəndə görünür.
        ui.removeCallbacks(slowRecoveryRun)
        if (everPlayed) ui.postDelayed(slowRecoveryRun, SILENT_RECOVERY_MS) else cb.onLoading()
        // Pleyer yalnız codec dəstəklənməyəndə və ya Media3 açmayanda dəyişir; donma/qırılma pleyer dəyişmək səbəbi deyil.
        // Heç nə gözlənmir: təkrar cəhd dərhal (eyni döngədə) başlayır.
        ui.removeCallbacks(restartRun)
        if (RECONNECT_DELAY_MS <= 0L) ui.post(restartRun) else ui.postDelayed(restartRun, RECONNECT_DELAY_MS)
    }

    fun attach() {
        if (released) return
        vlc.attach()
        val u = url
        if (resume && u != null) play(u, ua, ref, usingBackup)
    }

    /** Yayımı tam dayandırır (yoda.az linki gözlənərkən köhnə kanal səsi/şəkli qalmasın). */
    fun halt() {
        if (released) return
        cancelRecovery()
        ui.removeCallbacks(unloadVlcRun)
        exo.stop()
        vlc.stop()
        vlc.unload()
        url = null
        resume = false
        playedOk = false
        everPlayed = false
        reconnecting = false
    }

    fun stopForBackground() {
        if (released) return
        resume = url != null
        cancelRecovery()
        ui.removeCallbacks(unloadVlcRun)
        exo.stop()
        vlc.stopForBackground()
    }

    fun isPaused(): Boolean = userPaused

    /**
     * Sistem yaddaş azlığı bildirəndə (onTrimMemory): Media3 işləyirsə, işlənməyən VLC (pleyer + libVLC) dərhal boşaldılır.
     * VLC oynayırsa toxunulmur (yayım kəsilməsin).
     */
    fun trimMemory() {
        if (released || stage != Stage.EXO) return
        ui.removeCallbacks(unloadVlcRun)
        vlc.unload(full = true)
    }

    fun hasUrl(): Boolean = url != null

    fun togglePause() {
        userPaused = !userPaused
        if (userPaused) ui.removeCallbacks(watchdogRun)
        else { lastPosAt = SystemClock.elapsedRealtime(); lastPos = -1L; bufferingSince = 0L; if (playedOk) ui.postDelayed(watchdogRun, WATCHDOG_MS) }
        if (stage == Stage.EXO) exo.togglePause() else vlc.togglePause()
    }

    fun stats(): PlayerStats? {
        val s = (if (stage == Stage.EXO) exo.stats() else vlc.stats()) ?: return null
        // Pleyer işarəsi: 💙 = Media3, 🧡 = VLC
        val name = if (stage == Stage.EXO) "\uD83D\uDC99" else "\uD83E\uDDE1"
        return PlayerStats(s.width, s.height, s.bufferMs, s.level, s.bps, name, s.bitrate)
    }

    fun release() {
        if (released) return
        released = true
        cancelRecovery()
        ui.removeCallbacks(unloadVlcRun)
        exo.release()
        vlc.release()
    }
}
