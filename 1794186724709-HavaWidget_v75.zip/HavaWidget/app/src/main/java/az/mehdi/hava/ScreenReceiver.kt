package az.mehdi.hava

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build

/**
 * Ekran açılanda / kilid açılanda (telefona baxanda) vidcet yaddaşdakı məlumatla yenilənir:
 * şarj dəqiqəsi, gün və s. təzələnir. İnternet işlənmir.
 */
class ScreenReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        when (i?.action) {
            Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED -> FullCharge.check(c.applicationContext)
        }
        val now = System.currentTimeMillis()
        if (now - last < 3000) return // eyni anda gələn SCREEN_ON + USER_PRESENT bir dəfə işləsin
        last = now
        val app = c.applicationContext
        val pr = goAsync()
        Thread {
            try {
                WeatherWidget.refresh(app)
                FullCharge.check(app)
                if (Battery.charging(app)) ChargeTick.schedule(app) else ChargeWatch.arm(app)
            } finally {
                pr.finish()
            }
        }.start()
    }

    companion object {
        @Volatile private var last = 0L
        private var registered = false

        /** Proses canlı olduqca ekran/şarj hadisələrini tutur (manifestdə yalnız USER_PRESENT var) */
        fun register(c: Context) {
            if (registered) return
            registered = true
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
            }
            try {
                val app = c.applicationContext
                if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(ScreenReceiver(), f, Context.RECEIVER_NOT_EXPORTED)
                else app.registerReceiver(ScreenReceiver(), f)
            } catch (e: Exception) {
                registered = false
            }
        }
    }
}
