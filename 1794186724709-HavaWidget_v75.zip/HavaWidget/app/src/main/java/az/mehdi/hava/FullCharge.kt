package az.mehdi.hava

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import java.time.LocalTime

/**
 * Şarj 100% olanda xəbər verir.
 *  - 09:00–22:59: alarm səsi + vibrasiya
 *  - 23:00–08:59: yalnız vibrasiya (səssiz)
 * Necə işləyir: şarja taxılanda Androidin "100%-ə qalan vaxt" təxminindən dəqiq alarm qurulur;
 * vaxt çatanda şarj yoxlanılır, hələ dolmayıbsa yeni təxminlə yenidən qurulur.
 * Tətbiqin prosesi canlıdırsa, əlavə olaraq batareya dəyişikliyi də dinlənir (tez aşkar etmək üçün).
 * Eyni doldurma üçün bildiriş yalnız bir dəfə verilir.
 */
object FullCharge {
    private const val PREF = "fullcharge"
    private const val CH_ALARM = "full_alarm"
    private const val CH_QUIET = "full_quiet"
    private val VIB = longArrayOf(0, 500, 250, 500, 250, 800)

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = prefs(c).getBoolean("on", true)

    fun setEnabled(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("on", on).apply()
        if (!on) cancel(c) else if (Battery.pluggedIn(c)) check(c)
    }

    private fun pending(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 400, Intent(c, FullChargeReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun cancel(c: Context) {
        try { c.getSystemService(AlarmManager::class.java).cancel(pending(c)) } catch (e: Exception) { }
    }

    /** Növbəti yoxlamanı 100%-ə qalan təxmini vaxta qurur */
    fun schedule(c: Context) {
        if (!enabled(c)) return
        val rem = Battery.remainingMs(c)
        val delay = when {
            rem == null -> 60_000L                                   // dolub və ya şarjda deyil: tezliklə yoxla
            rem > 0 -> (rem + 20_000L).coerceIn(60_000L, 30 * 60_000L)
            else -> 5 * 60_000L                                      // Android təxmin vermir
        }
        val at = System.currentTimeMillis() + delay
        val pi = pending(c)
        try {
            val am = c.getSystemService(AlarmManager::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (e: Exception) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: Exception) { }
    }

    /** Hazırkı vəziyyəti yoxlayır: dolubsa xəbər verir, yoxsa növbəti yoxlamanı qurur */
    fun check(c: Context) {
        if (!enabled(c)) return
        val p = prefs(c)
        if (!Battery.pluggedIn(c)) {
            p.edit().putBoolean("done", false).apply()
            cancel(c)
            return
        }
        if (Battery.full(c)) {
            if (!p.getBoolean("done", false)) {
                p.edit().putBoolean("done", true).apply()
                notifyFull(c)
            }
            cancel(c)
            return
        }
        if (Battery.percent(c) <= 97) p.edit().putBoolean("done", false).apply()
        schedule(c)
    }

    private fun quietNow(): Boolean {
        val h = LocalTime.now().hour
        return h >= 23 || h < 9
    }

    private fun channels(c: Context) {
        val m = c.getSystemService(NotificationManager::class.java)
        val alarm = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val loud = NotificationChannel(CH_ALARM, "Şarj 100% (alarm)", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(alarm, AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            enableVibration(true)
            vibrationPattern = VIB
        }
        val quiet = NotificationChannel(CH_QUIET, "Şarj 100% (gecə, səssiz)", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null)
            enableVibration(false) // vibrasiya ayrıca, birbaşa verilir (səssiz rejimdə də işləsin)
        }
        m.createNotificationChannel(loud)
        m.createNotificationChannel(quiet)
    }

    private fun vibrate(c: Context) {
        try {
            val v = c.getSystemService(Vibrator::class.java) ?: return
            if (!v.hasVibrator()) return
            v.vibrate(VibrationEffect.createWaveform(VIB, -1))
        } catch (e: Exception) { }
    }

    private fun notifyFull(c: Context) {
        val quiet = quietNow()
        if (quiet) vibrate(c) // 23:00–09:00: yalnız vibrasiya
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            channels(c)
            val n = Notification.Builder(c, if (quiet) CH_QUIET else CH_ALARM)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Şarj 100%")
                .setContentText("Telefon tam doldu, şarjdan çıxara bilərsiniz.")
                .setCategory(Notification.CATEGORY_ALARM)
                .setContentIntent(Notif.open(c))
                .setAutoCancel(true)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(20, n)
        } catch (e: Exception) { }
    }

    private var registered = false

    /** Proses canlı olduqca batareya dəyişikliyini dinləyir (tez aşkar etmək üçün; alarm zəncirinin üstünə əlavə) */
    fun register(c: Context) {
        if (registered) return
        registered = true
        try {
            val app = c.applicationContext
            val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val r = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, i: Intent?) {
                    if (Battery.pluggedIn(ctx) || prefs(ctx).getBoolean("done", false)) check(ctx)
                }
            }
            if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED) else app.registerReceiver(r, f)
        } catch (e: Exception) { registered = false }
    }
}

class FullChargeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        FullCharge.check(c.applicationContext)
    }
}
