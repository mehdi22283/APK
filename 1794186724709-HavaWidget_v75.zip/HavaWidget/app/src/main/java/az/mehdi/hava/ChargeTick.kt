package az.mehdi.hava

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager

/**
 * Şarj dəqiqəsi hər dəqiqə yenilənsin, amma YALNIZ telefon şarjdadırsa, ekran açıqdırsa və ana ekrandasınızsa.
 * Ekran sönəndə zəncir dayanır (heç nə işləmir); ekran açılanda ScreenReceiver yenidən başladır.
 * Hər yeniləmə internetsizdir: yalnız Androidin cari təxmini oxunur və vidcet yenidən çəkilir.
 */
object ChargeTick {
    private fun pending(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 300, Intent(c, ChargeTickReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Növbəti dəqiqənin əvvəlinə qurur */
    fun schedule(c: Context, exact: Boolean = true) {
        if (!Home.hasAccess(c)) return // "İstifadə girişi" icazəsi olmadan ana ekranı bilmək olmur — dəqiqəlik yeniləmə işləmir
        val am = c.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        val at = now - now % 60_000L + 60_000L + 300L
        val pi = pending(c)
        try {
            if (!exact || (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, at, pi)
            }
        } catch (e: Exception) {
            try { am.setAndAllowWhileIdle(AlarmManager.RTC, at, pi) } catch (e2: Exception) { }
        }
    }

    fun cancel(c: Context) {
        try { c.getSystemService(AlarmManager::class.java).cancel(pending(c)) } catch (e: Exception) { }
    }
}

class ChargeTickReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        val app = c.applicationContext
        val interactive = try { app.getSystemService(PowerManager::class.java).isInteractive } catch (e: Exception) { false }
        val charging = Battery.charging(app)
        if (charging && !interactive) return // ekran sönükdür: dayan, ekran açılanda davam edəcək
        val pr = goAsync()
        Thread {
            try {
                if (!charging) {
                    WeatherWidget.refresh(app) // çıxarılıb: göstərici silinsin
                    ChargeWatch.arm(app)
                } else {
                    val home = Home.onHome(app) // null: icazə yoxdur, zəncir dayanır
                    if (home == true) WeatherWidget.refreshCharge(app) // yalnız ana ekranda və yalnız ⚡ mətni dəyişibsə
                    // ana ekranda deyilsə: vidceta toxunmur, yalnız yüngül (qeyri-dəqiq) yoxlama
                    if (home != null) ChargeTick.schedule(app, exact = home == true)
                }
            } finally {
                pr.finish()
            }
        }.start()
    }
}
