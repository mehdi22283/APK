package az.mehdi.hava

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process

/**
 * Ana ekran (launcher) hazırda ön plandadır? "İstifadə girişi" icazəsi lazımdır.
 * Hər çağırışda yalnız son yoxlamadan bəri olan hadisələr oxunur (çox yüngüldür).
 */
object Home {
    private const val ACTIVITY_RESUMED = 1 // UsageEvents.Event.MOVE_TO_FOREGROUND / ACTIVITY_RESUMED

    fun hasAccess(c: Context): Boolean = try {
        val ao = c.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else
            @Suppress("DEPRECATION") ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        mode == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    @Volatile private var cachedLauncher: String? = null
    private var cachedAt = 0L

    private fun launcherPkg(c: Context): String? {
        val t = System.currentTimeMillis()
        if (cachedLauncher != null && t - cachedAt < 10 * 60_000L) return cachedLauncher
        cachedLauncher = resolveLauncher(c); cachedAt = t
        return cachedLauncher
    }

    private fun resolveLauncher(c: Context): String? = try {
        c.packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
    } catch (e: Exception) { null }

    /** true — ana ekrandadır; false — başqa tətbiqdədir; null — icazə yoxdur və ya oxuna bilmədi */
    fun onHome(c: Context): Boolean? {
        if (!hasAccess(c)) return null
        return try {
            val usm = c.getSystemService(UsageStatsManager::class.java)
            val pr = c.getSharedPreferences("home", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val since = pr.getLong("since", now - 3 * 3600_000L).coerceAtLeast(now - 3 * 3600_000L)
            val ev = usm.queryEvents(since, now)
            val e = UsageEvents.Event()
            var last = pr.getString("pkg", null)
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == ACTIVITY_RESUMED) last = e.packageName
            }
            pr.edit().putLong("since", now).putString("pkg", last).apply()
            val home = launcherPkg(c)
            home != null && last == home
        } catch (e: Exception) { null }
    }
}
