package az.mehdi.hava

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val BG = Color.parseColor("#000000") // AMOLED: təmiz qara
    private val CARD = Color.parseColor("#0D0D0D")
    private val GREY = Color.parseColor("#90A4AE")
    private val BLUE = Color.parseColor("#4FC3F7")
    private val YELLOW = Color.parseColor("#FFD54F")
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var sv: ScrollView
    private lateinit var srl: SwipeRefreshLayout
    @Volatile private var fetching = false
    private var chargeTv: TextView? = null
    private val chargeHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val chargeTick = object : Runnable {
        override fun run() { updateCharge(); chargeHandler.postDelayed(this, 1_000L) }
    }

    /** Yenilə düyməsinin altında şarj gücü və 100%-ə qalan dəqiqə (yalnız şarjdadırsa) */
    private fun updateCharge() {
        val tv = chargeTv ?: return
        val lines = Battery.appLines(this)
        if (lines == null) { tv.visibility = View.GONE } else { tv.text = lines.joinToString("\n"); tv.visibility = View.VISIBLE }
    }
    private val anchors = HashMap<String, android.view.View>()
    private var stepsView: TextView? = null
    private var kmView: TextView? = null
    private var stopSteps: (() -> Unit)? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        sv.addView(root)
        // yuxarıdan aşağı çəkdikdə məlumat yenilənir
        srl = SwipeRefreshLayout(this)
        srl.setBackgroundColor(BG)
        srl.setColorSchemeColors(BLUE)
        srl.setProgressBackgroundColorSchemeColor(CARD)
        srl.addView(sv)
        srl.setOnRefreshListener { fetch() }
        setContentView(srl)
        Scheduler.start(this)
        Midnight.schedule(this)
        RainAlert.schedule(this)
        askPermissions()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    /** Vidcetdən gələn "sec" açarına görə müvafiq bölməyə sürüşdürür */
    private fun scrollToPending() {
        val key = intent?.getStringExtra("sec") ?: return
        intent.removeExtra("sec")
        sv.postDelayed({
            val v = anchors[key]
            var y = 0
            if (v != null) {
                var x: android.view.View = v
                while (x !== root && x.parent is android.view.View) { y += x.top; x = x.parent as android.view.View }
            }
            sv.smoothScrollTo(0, (y - dp(8)).coerceAtLeast(0))
        }, 300)
    }

    override fun onResume() {
        super.onResume()
        render()
        chargeHandler.removeCallbacks(chargeTick)
        chargeHandler.postDelayed(chargeTick, 1_000L) // hər saniyə, yalnız tətbiq açıq olanda
        Thread { StepReader.readBlocking(this); runOnUiThread { updateSteps() } }.start()
        stopSteps = StepReader.watch(this) { runOnUiThread { updateSteps() } }
        fetch() // tətbiqə hər daxil olduqda məlumat yenilənir
    }

    override fun onPause() {
        chargeHandler.removeCallbacks(chargeTick)
        stopSteps?.invoke()
        stopSteps = null
        super.onPause()
    }

    private fun fetch() {
        if (fetching) { srl.isRefreshing = false; return }
        fetching = true
        srl.post { if (fetching) srl.isRefreshing = true }
        Thread {
            val w = WeatherApi.refresh(this)
            WeatherWidget.refresh(this)
            if (w != null) Alerts.check(this, w)
            fetching = false
            runOnUiThread {
                srl.isRefreshing = false
                if (w != null) render()
                else Toast.makeText(this, "İnternet yoxdur, məlumat yenilənmədi", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 2) {
            if (r.any { it == PackageManager.PERMISSION_GRANTED }) addGps()
            else Toast.makeText(this, "Yer icazəsi verilmədi", Toast.LENGTH_SHORT).show()
            return
        }
        Scheduler.now(this)
    }

    // ---------- UI ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** res/drawable/ic_<ad>.xml ikonunu verilən dp ölçüsündə qaytarır */
    private fun ic(name: String, size: Int): Drawable {
        val d = resources.getDrawable(Ic.id(this, name), theme).mutate()
        val px = dp(size)
        d.setBounds(0, 0, px, px)
        return d
    }

    private fun TextView.icon(name: String, size: Int, pad: Int = 6) {
        setCompoundDrawablesRelative(ic(name, size), null, null, null)
        compoundDrawablePadding = dp(pad)
        gravity = android.view.Gravity.CENTER_VERTICAL
    }

    private fun label(s: CharSequence, sp: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false, parent: LinearLayout = root, icon: String? = null): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        if (icon != null) t.icon(icon, (sp * 1.2f).toInt(), (sp / 2).toInt().coerceAtLeast(4))
        parent.addView(t)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(CARD)
        bg.setStroke(dp(1), Color.parseColor("#1C1C1C"))
        bg.cornerRadius = dp(16).toFloat()
        c.background = bg
        c.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        root.addView(c, lp)
        return c
    }

    private fun section(s: String, key: String? = null) {
        val t = label(s, 14f, GREY, true)
        if (key != null) anchors[key] = t
        t.setPadding(0, dp(16), 0, 0)
    }

    private fun row(p: LinearLayout, a: String, b: String, c: String, d: String, hi: Boolean, bIcon: String? = null, dIcon: String? = null) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(0, dp(5), 0, dp(5))
        fun cell(s: String, wt: Float, col: Int, bold: Boolean, icon: String? = null) {
            val t = TextView(this)
            t.text = s
            t.textSize = 13f
            t.setTextColor(col)
            if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
            if (icon != null) t.icon(icon, 18, 5)
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, wt))
        }
        cell(a, 2.1f, GREY, false)
        cell(b, 3.6f, Color.WHITE, false, bIcon)
        cell(c, 2.0f, Color.WHITE, true)
        cell(d, 1.7f, if (hi) BLUE else GREY, hi, dIcon)
        p.addView(r)
    }

    private fun button(caption: String, icon: String? = null, onClick: () -> Unit) {
        val b = Button(this)
        b.text = caption
        if (icon != null) {
            b.setCompoundDrawablesRelative(ic(icon, 20), null, null, null)
            b.compoundDrawablePadding = dp(8)
            b.setPadding(dp(24), 0, dp(24), 0)
        }
        b.setOnClickListener { onClick() }
        root.addView(b)
    }

    private fun render() {
        root.removeAllViews()
        anchors.clear()
        stepsView = null
        kmView = null
        val w = WeatherApi.cached(this)
        val n = w?.nowIndex() ?: -1
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = android.view.Gravity.CENTER_VERTICAL
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val here = Locations.current(this)
        val nameTv = label(here.name + "  ▾", 16f, GREY, true, head)
        nameTv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        nameTv.setOnClickListener { scrollToAnchor("places") }
        val rb = ImageView(this)
        rb.setImageResource(Ic.id(this, "refresh", "xl"))
        rb.scaleType = ImageView.ScaleType.FIT_CENTER
        rb.setPadding(dp(9), dp(9), dp(9), dp(9))
        val rbBg = GradientDrawable()
        rbBg.shape = GradientDrawable.OVAL
        rbBg.setColor(CARD)
        rbBg.setStroke(dp(2), BLUE)
        rb.background = rbBg
        rb.contentDescription = "Yenilə"
        rb.setOnClickListener { fetch() }
        val rcol = LinearLayout(this)
        rcol.orientation = LinearLayout.VERTICAL
        rcol.gravity = android.view.Gravity.CENTER_HORIZONTAL
        rcol.addView(rb, LinearLayout.LayoutParams(dp(44), dp(44)))
        chargeTv = TextView(this).apply {
            textSize = 11f
            setTextColor(GREY)
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        }
        rcol.addView(chargeTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        head.addView(rcol, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        updateCharge()
        // ---- Batareya ----
        section("Batareya", "battery")
        val bc = card()
        val bh = Battery.health(this)
        if (bh == null) {
            label("Batareya məlumatı oxuna bilmədi", 14f, GREY, false, bc)
        } else {
            label("🔋 Doldurma: ${Battery.percent(this)}%", 15f, Color.WHITE, true, bc)
            bh.cycles?.let { label("🔁 Dövr sayı: $it", 15f, Color.WHITE, false, bc).setPadding(0, dp(6), 0, 0) }
            bh.capMah?.let { label("📦 Təxmini cari tutum: $it mAh", 15f, Color.WHITE, false, bc).setPadding(0, dp(6), 0, 0) }
            bh.tempC?.let { label("🌡️ Temperatur: ${String.format(java.util.Locale.US, "%.1f", it)}°", 15f, Color.WHITE, false, bc).setPadding(0, dp(6), 0, 0) }
            bh.volt?.let { label("⚡ Gərginlik: ${String.format(java.util.Locale.US, "%.2f", it)} V", 15f, Color.WHITE, false, bc).setPadding(0, dp(6), 0, 0) }
        }
        button(if (FullCharge.enabled(this)) "100% şarj siqnalı: AÇIQ (söndür)" else "100% şarj siqnalı: SÖNÜLÜ (aç)", "plus") {
            FullCharge.setEnabled(this, !FullCharge.enabled(this))
            render()
        }

        if (w == null || n < 0) {
            label("Məlumat yüklənir…", 18f, Color.WHITE, true)
        } else {
            val h = w.hours[n]
            label("${h.temp.roundToInt()}°", 56f, Color.WHITE, true, icon = T.iconName(h.code))
            label("${T.desc(h.code)}", 16f)
            w.infoParts(n).forEach { p ->
                val v = label(p.second, 15f, GREY, icon = p.first)
                if (!anchors.containsKey(p.first)) anchors[p.first] = v
            }

            val o = w.outlook()
            val pr = w.preciseRain()
            if (o != null || pr != null) {
                val oc = card()
                anchors["outlook"] = oc
                if (o != null) label(o.text, 17f, YELLOW, true, oc, T.kindIcon(o.kind))
                if (pr != null) label(pr, 15f, BLUE, true, oc, "drop").setPadding(0, dp(if (o != null) 8 else 0), 0, 0)
            }

            w.fogNote()?.let { label(it, 15f, YELLOW, true, card(), "fog") }

            // ---- Geyim məsləhəti ----
            val wear = Wear.now(w, n)
            section("Geyim məsləhəti", "wear")
            val wc = card()
            label(wear.headline, 17f, YELLOW, true, wc, "shirt")
            wear.lines.forEach { l ->
                val em = when {
                    l.second.startsWith("Üst:") -> "👕"
                    l.second.startsWith("Alt:") -> "👖"
                    l.second.startsWith("Ayaqqabı:") -> "👟"
                    else -> null
                }
                // Üst / Alt / Ayaqqabı emoji ilə, digər sətirlər (aksesuar, UV və s.) əvvəlki ikonla
                if (em != null) label("$em ${l.second}", 14f, Color.WHITE, false, wc).setPadding(0, dp(6), 0, 0)
                else label(l.second, 14f, Color.WHITE, false, wc, l.first).setPadding(0, dp(6), 0, 0)
            }

            // ---- Külək ----
            section("Külək", "wind")
            val wd = card()
            label(WindInfo.detail(h.wind, h.dir), 15f, Color.WHITE, true, wd, "wind")
            w.gustNote()?.let { label(it, 14f, Color.WHITE, false, wd, "wind").setPadding(0, dp(6), 0, 0) }

            section("Növbəti saatlar", "hours")
            val hc = card()
            listOf(1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 21, 24).filter { n + it < w.hours.size }.forEach {
                val x = w.hours[n + it]
                val gTxt = if (!x.gust.isNaN() && x.gust >= x.wind + 10) ", hamlə ${x.gust.roundToInt()}" else ""
                val wTxt = if (gTxt.isNotEmpty()) "\n${x.wind.roundToInt()} km/s$gTxt" else ""
                row(hc, x.time.substring(11, 16), T.desc(x.code) + "\nYağıntı: ${fmtPrecip(x.mm, x.snow)} — ${precipLabel(x.mm, x.snow)}" + wTxt, "${x.temp.roundToInt()}°", "${x.prob}%", x.prob >= 50, T.iconName(x.code), "drop")
            }

            section("Saatlıq yağıntı (24 saat)", "chart")
            val cc = card()
            val sub = w.hours.subList(n, minOf(n + 24, w.hours.size))
            cc.addView(PrecipChart(this, sub, BLUE, GREY), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val totMm = sub.sumOf { it.mm }
            val totSn = sub.sumOf { it.snow }
            val totTxt = if (totSn >= 0.1) "${fmtMm(totMm)} (qar: ${fmtSnow(totSn)})" else fmtMm(totMm)
            label("24 saatda cəmi: $totTxt", 14f, Color.WHITE, true, cc, "drop").setPadding(0, dp(6), 0, 0)
            val pk = sub.maxByOrNull { it.mm }
            if (pk != null && pk.mm >= 0.1) {
                label("Ən çox: saat ${pk.time.substring(11, 16)} — ${fmtPrecip(pk.mm, pk.snow)} (${precipLabel(pk.mm, pk.snow)})", 13f, GREY, false, cc).setPadding(0, dp(4), 0, 0)
            } else {
                label("Növbəti 24 saatda yağıntı gözlənilmir", 13f, GREY, false, cc).setPadding(0, dp(4), 0, 0)
            }
            label("Ağ sütun — qar. Sütun hündürlüyü saatlıq su ekvivalentidir (mm).", 11f, GREY, false, cc).setPadding(0, dp(4), 0, 0)

            section("Bu gün və növbəti 7 gün", "days")
            val dc = card()
            w.upcomingDays().forEachIndexed { i, d ->
                val name = if (i == 0) "Bu gün" else "${T.dayName(d.date)} ${d.date.substring(8, 10)}.${d.date.substring(5, 7)}"
                row(dc, name, "${T.desc(d.code)}\nYağıntı: ${w.precipHours(d)} saat\nMiqdar: ${fmtPrecip(d.mm, d.snow)} — ${precipLabel(d.mm, d.snow)}\n${WindInfo.label(d.wind, d.dir)}${if (!d.gust.isNaN() && d.gust >= d.wind + 10) "\nAni külək: ${d.gust.roundToInt()} km/s" else ""}", "${d.max.roundToInt()}°/${d.min.roundToInt()}°", "${d.prob}%", d.prob >= 50, T.iconName(d.code), "drop")
            }
        }

        if (w != null && n >= 0) {
            section("Növbəti günlər üçün geyim")
            val gc = card()
            w.upcomingDays().forEachIndexed { i, d ->
                val nm = if (i == 0) "Bu gün" else "${T.dayName(d.date)} ${d.date.substring(8, 10)}.${d.date.substring(5, 7)}"
                label("$nm: ${Wear.forDay(w, d)}", 13f, Color.WHITE, false, gc, "shirt").setPadding(0, dp(4), 0, dp(4))
            }
        }
        w?.sea?.let { renderSea(it) }
        renderVerify()
        renderSky(w)

        section("Addımölçən", "steps")
        val sc = card()
        stepsView = label("", 26f, Color.WHITE, true, sc, "steps")
        kmView = label("", 18f, BLUE, true, sc, "ruler")
        val sm = getSystemService(SensorManager::class.java)
        if (sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null) {
            label("Bu cihazda addımölçən sensoru yoxdur", 13f, GREY, false, sc)
        }
        updateSteps()

        section("Addımlar · son 7 gün", "stepsweek")
        val wc7 = card()
        val wk = Steps.week(this)
        wc7.addView(StepsChart(this, wk, BLUE, Color.parseColor("#3D7EA6"), GREY), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val tot = wk.sumOf { it.second }
        val withData = wk.filter { it.second > 0 }
        val avg = if (withData.isEmpty()) 0 else tot / withData.size
        val best = withData.maxByOrNull { it.second }
        fun grp(v: Int) = String.format(java.util.Locale.US, "%,d", v).replace(',', ' ')
        label("7 gündə cəmi: ${grp(tot)} addım (≈ ${String.format(java.util.Locale.US, "%.1f", tot * Steps.height(this) * 0.415 / 100000.0)} km)", 14f, Color.WHITE, true, wc7, "steps").setPadding(0, dp(6), 0, 0)
        if (best != null) label("Gündəlik orta: ${grp(avg)} · ən çox: ${T.dayName(best.first)} (${grp(best.second)})", 13f, GREY, false, wc7).setPadding(0, dp(4), 0, 0)
        if (withData.size <= 1) label("Əvvəlki günlərin tarixçəsi bu versiyadan etibarən yığılır.", 11f, GREY, false, wc7).setPadding(0, dp(4), 0, 0)

        section("Ürək döyüntüsü")
        val heartCard = card()
        val lastHr = Heart.last(this)
        label(
            if (lastHr == null) "Hələ ölçülməyib" else "${lastHr.second} döyüntü/dəq  ·  ${Heart.timeText(lastHr.first)}",
            20f, Color.WHITE, true, heartCard, "heart"
        )
        label("Barmağı arxa kameranın və flaşın üzərinə qoyaraq ölçün", 13f, GREY, false, heartCard)

        renderPlaces()

        val gap = TextView(this)
        gap.height = dp(12)
        root.addView(gap)
        button("Ürək döyüntüsünü ölç", "heart") { startActivity(Intent(this, HeartActivity::class.java).putExtra("auto", true)) }
        button("Xəritədən əlavə məkan seç", "plus") { startActivityForResult(Intent(this, MapPickActivity::class.java), 3) }
        button("Cari yeri əsas məkan et (GPS)", "plus") { addGps() }
        button("Ana ekrana widget əlavə et", "plus") { pinWidget() }
        if (!Home.hasAccess(this)) button("Şarj dəqiqəsi ana ekranda yenilənsin: icazə ver", "plus") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        scrollToPending()
    }

    private fun renderVerify() {
        section("Proqnoz yoxlaması", "verify")
        val c = card()
        val rs = Verify.results(this, Locations.current(this))
        if (rs.isEmpty()) {
            label("Hələ nəticə yoxdur. Hər gün sabahın proqnozu saxlanır və həmin gün keçəndən sonra real nəticə ilə müqayisə olunur — ilk nəticə sabah-biri gün görünəcək.", 13f, GREY, false, c)
            return
        }
        val ok = rs.sumOf { it.okCount }
        val total = rs.size * 3
        val pct = (ok * 100f / total).roundToInt()
        label("Son ${rs.size} gündə proqnoz $pct% düz çıxdı", 17f, YELLOW, true, c)
        val tOk = rs.count { it.maxOk } + rs.count { it.minOk }
        val avg = rs.sumOf { (kotlin.math.abs(it.fMax - it.aMax) + kotlin.math.abs(it.fMin - it.aMin)) / 2.0 } / rs.size
        label("Temperatur ±2° daxilində: $tOk/${rs.size * 2} · orta səhv ${String.format(java.util.Locale.US, "%.1f", avg)}°", 13f, Color.WHITE, false, c).setPadding(0, dp(6), 0, 0)
        label("Yağış (olub/olmayıb) düz: ${rs.count { it.rainOk }}/${rs.size}", 13f, Color.WHITE, false, c).setPadding(0, dp(2), 0, 0)
        val good = Color.parseColor("#66BB6A")
        val bad = Color.parseColor("#EF5350")
        rs.forEach { r ->
            val d = "${r.date.substring(8, 10)}.${r.date.substring(5, 7)}"
            val mark = if (r.okCount == 3) "✓" else if (r.okCount == 0) "✗" else "~"
            val t = label("$mark $d · proqnoz ${r.fMax.roundToInt()}°/${r.fMin.roundToInt()}°, yağış ${if (r.fRain) "var" else "yox"}\n    real ${r.aMax.roundToInt()}°/${r.aMin.roundToInt()}°, ${fmtMm(r.aMm)}", 12f, if (r.okCount >= 2) good else bad, false, c)
            t.setPadding(0, dp(8), 0, 0)
        }
        label("Real dəyər Open-Meteo-nun təhlil məlumatıdır, rəsmi meteostansiya ölçüsü deyil. Qeyd: ✓ üçü də düz, ~ qismən, ✗ heç biri.", 11f, GREY, false, c).setPadding(0, dp(8), 0, 0)
    }

    private fun renderSea(s: Sea) {
        section("Xəzər dənizi", "sea")
        val c = card()
        if (!s.wave.isNaN()) {
            label("Dalğa: ${fmtWave(s.wave)} · ${waveLevel(s.wave)}", 17f, Color.WHITE, true, c, "wind")
            val per = if (!s.period.isNaN()) " · dövr ${s.period.roundToInt()} san" else ""
            if (!s.dir.isNaN()) label("İstiqamət: ${compassName(s.dir)}$per", 14f, GREY, false, c).setPadding(0, dp(4), 0, 0)
        }
        if (!s.sst.isNaN()) label("Suyun temperaturu: ${s.sst.roundToInt()}° (${seaTempLevel(s.sst)})", 15f, Color.WHITE, true, c, "drop").setPadding(0, dp(6), 0, 0)
        if (!s.max24.isNaN()) label("Növbəti 24 saatda ən hündür dalğa: ${fmtWave(s.max24)} (${waveLevel(s.max24)})", 13f, GREY, false, c).setPadding(0, dp(6), 0, 0)
        label(if (Locations.isBaku(Locations.current(this))) "Model məlumatıdır (Bakı körfəzi yaxınlığı), sahil üçün təxminidir." else "Model məlumatıdır (seçilmiş yerə ən yaxın dəniz nöqtəsi), təxminidir.", 11f, GREY, false, c).setPadding(0, dp(4), 0, 0)
    }

    private fun renderSky(w: Weather?) {
        section("Ay və gün uzunluğu", "sky")
        val mi = Moon.info()
        val mc = card()
        label("${mi.name} · ${mi.illum}% işıqlanıb", 18f, Color.WHITE, true, mc, mi.icon)
        label("Ayın yaşı: ${mi.age.roundToInt()} gün", 14f, GREY, false, mc).setPadding(0, dp(4), 0, 0)
        label("Növbəti dolunay: ${Moon.fmt(mi.nextFull)} (${Moon.inText(mi.nextFull)})", 14f, Color.WHITE, false, mc, "moon4").setPadding(0, dp(6), 0, 0)
        label("Növbəti yeni ay: ${Moon.fmt(mi.nextNew)} (${Moon.inText(mi.nextNew)})", 14f, Color.WHITE, false, mc, "moon0").setPadding(0, dp(6), 0, 0)
        val dl = w?.dayLight() ?: return
        val sc = card()
        label("Gün doğur ${dl.sunrise}  ·  batır ${dl.sunset}", 15f, Color.WHITE, true, sc, "sunrise")
        label("Gün uzunluğu: ${dl.lenText}", 15f, Color.WHITE, false, sc, "clock").setPadding(0, dp(6), 0, 0)
        dl.diffText?.let { label(it, 13f, GREY, false, sc).setPadding(0, dp(4), 0, 0) }
        label(dl.remaining, 14f, YELLOW, true, sc, "sunset").setPadding(0, dp(6), 0, 0)
        label(dl.solstice, 13f, GREY, false, sc).setPadding(0, dp(4), 0, 0)
    }

    private fun updateSteps() {
        stepsView?.text = "${Steps.stepsText(this)} addım"
        kmView?.text = "Bu gün ${Steps.kmText(this)} gəzdiniz"
    }

    private fun scrollToAnchor(key: String) {
        val v = anchors[key] ?: return
        var y = 0
        var x: android.view.View = v
        while (x !== root && x.parent is android.view.View) { y += x.top; x = x.parent as android.view.View }
        sv.smoothScrollTo(0, (y - dp(8)).coerceAtLeast(0))
    }

    // ---------- Yerlər ----------
    private fun renderPlaces() {
        section("Yerlər", "places")
        val pc = card()
        val list = Locations.all(this)
        val sel = Locations.selected(this)
        list.forEachIndexed { i, pl ->
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = android.view.Gravity.CENTER_VERTICAL
            val t = TextView(this)
            t.text = pl.name + (if (pl.main) "  (əsas)" else "") + (if (i == sel) "  ✓" else "")
            t.textSize = 16f
            t.setTextColor(if (i == sel) BLUE else Color.WHITE)
            if (i == sel) t.setTypeface(t.typeface, Typeface.BOLD)
            t.setPadding(0, dp(12), 0, dp(12))
            t.setOnClickListener { if (Locations.select(this, i)) locationChanged() }
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (list.size > 1 && !pl.main) {
                val d = TextView(this)
                d.text = "Sil"
                d.textSize = 14f
                d.setTextColor(Color.parseColor("#EF5350"))
                d.setPadding(dp(14), dp(12), 0, dp(12))
                d.setOnClickListener { confirmDelete(i, pl) }
                r.addView(d)
            }
            pc.addView(r)
        }
        label("Yeri seçmək üçün adına toxunun. Əsas məkan GPS ilə tapılır, xəritədən seçilən yer əlavə məkan kimi əlavə olunur.", 11f, GREY, false, pc).setPadding(0, dp(4), 0, 0)
    }

    private fun confirmDelete(i: Int, pl: Place) {
        android.app.AlertDialog.Builder(this)
            .setMessage("\"${pl.name}\" silinsin?")
            .setPositiveButton("Sil") { _, _ -> if (Locations.remove(this, i)) locationChanged() else render() }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    /** Seçilmiş yer dəyişəndə: köhnə məlumat təmizlənir, yenisi yüklənir, widget yenilənir */
    private fun locationChanged() {
        WeatherApi.clearCache(this)
        render()
        WeatherWidget.refresh(this)
        fetch()
    }

    private fun addGps() {
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 2)
            return
        }
        Toast.makeText(this, "Yer müəyyən edilir…", Toast.LENGTH_SHORT).show()
        Locations.locate(this) { loc ->
            if (loc == null) {
                Toast.makeText(this, "Yer tapılmadı. GPS və ya məkan xidmətini yandırın", Toast.LENGTH_LONG).show()
            } else {
                Thread {
                    val nm = Locations.nameFor(this, loc.latitude, loc.longitude)
                    Locations.setMain(this, Place(nm, loc.latitude, loc.longitude, true, true))
                    runOnUiThread { locationChanged() }
                }.start()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc != 3 || res != RESULT_OK || data == null || !data.hasExtra("lat")) return
        val lat = data.getDoubleExtra("lat", 0.0)
        val lon = data.getDoubleExtra("lon", 0.0)
        Thread {
            val nm = Locations.nameFor(this, lat, lon, "Seçilmiş yer")
            Locations.add(this, Place(nm, lat, lon, false))
            runOnUiThread {
                Toast.makeText(this, "Əlavə məkan əlavə olundu: $nm", Toast.LENGTH_SHORT).show()
                render()
            }
        }.start()
    }

    private fun pinWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) {
            m.requestPinAppWidget(ComponentName(this, WeatherWidget::class.java), null, null)
        } else {
            Toast.makeText(this, "Ana ekranda boş yerə uzun basın → Widgetlər → Mehdi Hava", Toast.LENGTH_LONG).show()
        }
    }
}
