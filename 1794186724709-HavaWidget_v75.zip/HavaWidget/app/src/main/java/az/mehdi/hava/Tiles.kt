package az.mehdi.hava

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlin.math.roundToInt

/** Android-in aşağı çəkilən sürətli ayarlar panelindəki düymələr (Quick Settings tiles). */
abstract class BaseTile : TileService() {
    protected abstract val code: Int
    protected abstract fun fill(t: Tile)
    protected abstract fun target(): Intent

    override fun onStartListening() = refreshTile()
    override fun onTileAdded() = refreshTile()

    private fun refreshTile() {
        val t = qsTile ?: return
        try { fill(t) } catch (e: Exception) { t.state = Tile.STATE_INACTIVE }
        t.updateTile()
    }

    protected fun sub(t: Tile, s: String) {
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = s else t.label = "${t.label} · $s"
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        val i = target().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            startActivityAndCollapse(i)
        }
    }
}

/** Hava: indiki temperatur, vəziyyət və yağış ehtimalı */
class HavaTile : BaseTile() {
    override val code = 1
    override fun target() = Intent(this, MainActivity::class.java)
    override fun fill(t: Tile) {
        val w = WeatherApi.cached(this)
        val n = w?.nowIndex() ?: -1
        t.state = Tile.STATE_ACTIVE
        if (w == null || n < 0) { t.label = "Hava"; sub(t, "Aç"); return }
        val h = w.hours[n]
        t.label = "${h.temp.roundToInt()}° ${Locations.current(this).name}"
        sub(t, "${T.desc(h.code)} · 💧${h.prob}%")
    }
}

/** Ürək: son ölçmə; toxunanda ölçmə ekranı açılır */
class YurekTile : BaseTile() {
    override val code = 2
    override fun target() = Intent(this, HeartActivity::class.java).putExtra("auto", true)
    override fun fill(t: Tile) {
        t.label = "Ürək"
        t.state = Tile.STATE_INACTIVE
        val last = Heart.last(this)
        sub(t, if (last == null) "Ölç" else "${last.second} döy/dəq · ${Heart.timeText(last.first)}")
    }
}

/** Şarj: faiz, şarj gücü və 100%-ə qalan vaxt */
class SarjTile : BaseTile() {
    override val code = 3
    override fun target() = Intent(this, MainActivity::class.java).putExtra("sec", "battery")
    override fun fill(t: Tile) {
        val p = Battery.percent(this)
        t.label = if (p >= 0) "Şarj $p%" else "Şarj"
        val lines = Battery.appLines(this)
        if (lines != null) {
            t.state = Tile.STATE_ACTIVE
            sub(t, lines.joinToString(" · "))
        } else {
            t.state = Tile.STATE_INACTIVE
            sub(t, if (Battery.full(this)) "Tam doludur" else "Şarj olunmur")
        }
    }
}

/** Addım: bu günkü addım və km */
class AddimTile : BaseTile() {
    override val code = 4
    override fun target() = Intent(this, MainActivity::class.java).putExtra("sec", "steps")
    override fun fill(t: Tile) {
        t.label = "${Steps.stepsText(this)} addım"
        t.state = Tile.STATE_ACTIVE
        sub(t, Steps.kmText(this))
    }
}
