# Mehdi Hava (HavaWidget)
- Bakı: bu gün + 7 gün, hər gün üçün yağış ehtimalı (Open-Meteo, API açarı lazım deyil)
- "3 saat sonra yağış yağacaq" tipli proqnoz — tətbiqdə, widgetdə və bildirişdə
- Yağış / qar / tufan / güclü külək xəbərdarlığı (bildiriş), səhər proqnozu
- UV indeksi (indiki + günün maksimumu) və hava keyfiyyəti AQI + PM2.5 (Open-Meteo Air Quality, açar lazım deyil)
- Addımölçən + km (boyunuza görə), widgetdə də görünür
- Widget: ana ekran → uzun bas → Widgetlər → Mehdi Hava (və ya tətbiqdəki "widget əlavə et" düyməsi)

Build: layihəni GitHub-a yükləyin → Actions → "Build APK" → artifact: HavaWidget-apk

## Yeniliklər (FIXED9)
- Widgetin kənar boşluqları sıfırlandı (Xiaomi 12T)
- Tarixin altında hər gün üçün fərqli "günün sözü" 💡 və "atalar sözü" 📜 (365 ədəd; fayllar: app/src/main/res/raw/gunun_sozu.txt və atalar_sozu.txt — hər sətir bir cümlə, istədiyiniz kimi dəyişə bilərsiniz)
- 8 günlük sırada çərçivə: yağış → göy, güclü külək (≥40 km/saat) → boz, qar → ağ

## Yeniliklər (FIXED10)
- Saat, hava və 7 günlük proqnoz arasındakı boşluqlar silindi
- Android emojiləri əvəzinə tətbiqin öz vektor ikonları (res/drawable/ic_*.xml)
- Şrift: Arial ölçülü Liberation Sans (res/font/arial_*.ttf), bütün tətbiqdə və widgetdə
- Bu gün və 7 günlük proqnozda yağıntı saatları (Open-Meteo precipitation_hours); widgetdə, tətbiqdə və səhər bildirişində

## FIXED11
- Widgetdə xüsusi şrift faylı "Widget yüklənə bilmir" xətası verə bilirdi; şrift sistemin Sans (sans-serif) şriftinə keçirildi (widget + tətbiq)

## FIXED12
- Tətbiqdə canlı (animasiyalı) ikonlar: günəş şüaları fırlanır, buludlar yırğalanır, yağış/qar düşür, ildırım parlayır, ürək döyünür, saatın əqrəbi dönür və s. (res/drawable/ic_*_a.xml, res/animator/)
- Widgetdə Android animasiyanı dəstəkləmir, orada adi ikonlar qalır

## FIXED13
- Canlı (animasiyalı) ikonlar silindi; əvəzinə daha canlı rəngli, çoxqatlı sabit ikonlar (günəş, bulud, damla, ürək və s.)

## FIXED14
- Qar ikonu düzəldildi: bulud + altında üç qar dənəsi

## FIXED15
- Qar ikonları simmetrik edildi: buludun hər iki tərəfi eyni, altında bərabər aralıqlı üç qar dənəsi; iri qar dənəsi tam altıbucaqlı simmetriyadadır

## FIXED16
- Bütün ikonlar yenidən çəkildi: rəngli dairəvi lövhə üzərində ağ simvollar (hava, külək, günəş çıxma/batma, addım, ürək və s.)
- Şrift standart (sistem şrifti): xüsusi şrift təyini tamamilə silindi

## Hava mənbəyi
- Açar tələb etməyən Open-Meteo (proqnoz + air-quality), 8 günlük proqnoz

## Yeni: geyim məsləhəti, ay fazası, gün uzunluğu
- Geyim məsləhəti (tətbiq + widget + səhər bildirişi): hiss olunan temperatura görə üst/alt/ayaqqabı/aksesuar; yağış-qar-tufan, külək, UV, rütubət, duman, AQI və gün ərzində temperatur dəyişməsi nəzərə alınır; növbəti günlər üçün də qısa məsləhət
- Ay fazası: Meeus alqoritmi ilə hesablanır (internet lazım deyil): faza adı, işıqlanma %, ayın yaşı, növbəti dolunay və yeni ay; widgetdə ikon
- Gün uzunluğu: doğuş/batış, gün uzunluğu, sabahla fərq, günəş batmağa qalan vaxt, ən uzun/qısa günə qalan gün
- Yeni ikonlar: ic_moon0..7 (ay fazaları), ic_shirt

## Yağıntı radarı, addımölçən
- Yağıntı radarı: tətbiqdə "Yağıntı radarı" düyməsi — RainViewer (açar lazım deyil), son 2 saatın radar kadrları, oynat/dayandır, sürüşdür, yaxınlaşdır; xəritə CARTO/OpenStreetMap. Bakı qırmızı nöqtə ilə göstərilir. Qeyd: RainViewer pulsuz planda zoom 7-yə qədərdir, bölgədə radar əhatəsi zəif ola bilər
- Addımölçən maksimum batareya qənaəti: sensor 15 dəq. toplu çatdırılır (addımı aparat özü sayır), bildiriş/widget 10 dəq.-də bir yenilənir, tətbiq açılanda flush ilə dərhal dəqiqləşir, dəyişiklik yoxdursa yaddaşa yazılmır
- Boy sabit 180 sm; "Saxla" düyməsi və boy sahəsi silindi

## FIXED17
- Yağıntı radarı və xəritə tamamilə silindi (RadarActivity, düymə, manifest qeydi)
- Widget: geyim məsləhəti ürək ölçənin soluna köçürüldü; ay/gün uzunluğu sətri silindi
- Widget: növbəti 8 saat (tək sətirdə) — 8 sadə TextView (iç-içə RemoteViews yoxdur, "widget yüklənə bilmir" riskini azaldır)
- Tətbiq: "Yenilə" düyməsi ən yuxarıda dairəvi ikon oldu
- Addımölçən bildirişi: yeni gizli kanal (steps2) — səssiz, ən aşağı əhəmiyyət, kilid ekranında görünmür, nişan yoxdur
- Widget: yalnız şarja taxılanda 100%-ə qalan vaxt (tarixin altında); geyim məsləhəti (yalnız üst, alt, ayaqqabı, bir sətirdə) tarixin altına köçdü; günün sözü və atalar sözü ürək ölçənin soluna keçdi
- Widget ölçüsü dəyişmədən 8 günlük xanalarda yağış ehtimalı tam görünsün deyə saatlıq ikonlar (20dp) və gün ikonları (24dp) kiçildi, boşluqlar azaldıldı

## FIXED18
- Yerlər: "Cari yeri əsas məkan et (GPS)" — GPS ilə tapılan yer əsas məkan olur və silinmir, yalnız yenidən GPS ilə yenilənir; "Xəritədən əlavə məkan seç" (OpenStreetMap/osmdroid, açar lazım deyil) — seçilən yer əlavə məkan kimi siyahıya əlavə olunur (seçim dəyişmir), silmək olar; koordinat göstərilmir
- Hava, AQI, dəniz məlumatı və bildirişlər seçilmiş yerə görə yüklənir; yer dəyişəndə köhnə keş təmizlənir
- Yeni icazə: ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION (yalnız tətbiq açıq olanda, düyməyə basanda)
- Tətbiqin adı: Mehdi Hava. Yuxarıdan aşağı çəkdikdə (pull-to-refresh) məlumat yenilənir; hər uğurlu yenilənmədə "Məlumat yeniləndi · HH:mm" bildirişi (toast) çıxır (arxa plan yeniləmələrində də)
- Addımlar: son 7 günün sütun qrafiki (tətbiqdə, "Addımölçən"in altında) + 7 günlük cəm, orta, ən çox gəzilən gün; tarixçə 00:00-da avtomatik yazılır (son 60 gün saxlanır)

## Yeniliklər (v71)
- Android-in aşağı çəkilən paneli üçün sürətli ayar düymələri (Quick Settings tiles): **Hava** (temperatur, vəziyyət, yağış %), **Ürək** (son ölçmə, toxunanda ölçmə açılır), **Şarj** (faiz, güc, 100%-ə qalan vaxt), **Addım** (addım + km). Əlavə etmək: paneli aşağı çək → qələm (redaktə) → düyməni panelə sürüklə
- AMOLED tema: təmiz qara (#000000) fon, #0D0D0D kartlar, nazik haşiyə; status/naviqasiya paneli, ürək ölçmə və xəritə ekranı da qara
- Proqnoz yoxlaması: hər gün sabahın proqnozu saxlanır, gün keçəndən sonra real (Open-Meteo təhlil) dəyərlə müqayisə olunur — maksimum/minimum temperatur ±2° və yağış (olub/olmayıb). Tətbiqdə "Proqnoz yoxlaması" bölməsi: son 7 gündə neçə faiz düz çıxdı + hər günün nəticəsi. İlk nəticə sabah-biri gün görünür
- Batareya bölməsindən "Vəziyyət" və "Sağlamlıq" sətirləri silindi
