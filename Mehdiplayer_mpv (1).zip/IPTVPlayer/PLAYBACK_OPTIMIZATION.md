# Oynatma konfiqurasiyası (2 GB RAM TV box) — v1.22, yalnız mpv

## Açılış ardıcıllığı
Əvvəl serverə sorğu göndərilir (5 s); xəta cavabı (404/403/5xx, qoşulmur) alınarsa mpv yoxlanmır. Ehtiyat (yoda.az tokenli) linkdə sorğu göndərilmir.

| Vəziyyət | Ardıcıllıq |
|---|---|
| Yeni kanal | mpv × 3 cəhd (hər biri 8 s) |
| İşləyən kanal qırılıb/donub | mpv × 2 cəhd (dərhal, gözləmədən) |
| Hamısı açmasa | ehtiyat link (yoda.az) və ya "Kanal İşləmir" |
| Əvvəl işləmiş kanal, hamısı açmasa | xəta göstərilmir, hər 2 s-dən bir avtomatik təkrar yoxlanılır |

Sabitlər: `Engines.kt` → `PlayerManager` (`MPV_TIMEOUT_MS`, `NEW_ATTEMPTS`, `RECOVER_ATTEMPTS`).

## mpv seçimləri (`MpvEngine.initMpv`)
- **Video:** `vo=gpu`, `gpu-context=android`, `opengl-es=yes`, `profile=fast`, `keepaspect=no` (həmişə stretch — ekranı tam doldurur).
- **Dekoder:** `hwdec=mediacodec,mediacodec-copy` (`hwdec-codecs=h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1`); açılmasa proqram (FFmpeg) dekoderi; `vd-lavc-threads` ən çox 4.
- **Səs:** `ao=audiotrack,opensles`.
- **Bufer:** `cache=yes`, `cache-secs=20`, `demuxer-readahead-secs=20`, `demuxer-max-bytes=24 MB`, `demuxer-max-back-bytes=4 MB`, `cache-pause=yes`, `cache-pause-wait=2.5`.
- **Şəbəkə:** `network-timeout=8`, `tls-verify=no` (vaxtı keçmiş/özü imzalı sertifikatlı IPTV serverləri üçün), `stream-lavf-o=reconnect=1,reconnect_streamed=1,reconnect_delay_max=2`.
- **User-Agent:** standart `VLC/3.0.20 LibVLC/3.0.20`; kanalın öz User-Agent və Referer-i varsa o işlədilir (`user-agent`, `referrer`).
- **Digər:** altyazı söndürülüb (`sid=no`, `sub-auto=no`), `ytdl=no`, `idle=yes`.

## Hadisələr və vəziyyət
- "Oynayır" = `START_FILE` + `PLAYBACK_RESTART` hadisələri gəlib və `core-idle=false`.
- Bufer göstəricisi: `paused-for-cache`.
- Yayım bitdi/açılmadı: `idle-active=true` (yalnız həmin kanalın `START_FILE`-ından sonra).
- Ölçü: `video-params/w`, `video-params/h`; bufer: `demuxer-cache-duration`; bitrate: `video-bitrate` + `audio-bitrate`; mövqe: `time-pos`.
- Əsas thread mpv-dən property oxumur, hamısı `observeProperty` ilə keşlənir.

## Avtomatik bərpa (davamlı izləmə)
- Yayım işləyərkən qırılsa (xəta, yayım bitdi) kanal gözləmədən (0 s) yenidən qoşulur.
- Bufer 5 s dolmursa və ya mövqe (`time-pos`) 5 s dəyişmirsə yenidən qoşulur; "oynayır" deyir, amma vaxt 10 s gəlmirsə də yenilənir.
- Watchdog hər 1 s yoxlayır; istifadəçi pauza edibsə bərpa işləmir.
- Əvvəl işləmiş kanalın bərpasında yükləmə paneli dərhal çıxmır (son kadr ekranda qalır); yalnız 3.5 s-dən uzun çəkərsə görünür.

## Yaddaş (2 GB RAM)
- `largeHeap=true`, ABI yalnız `armeabi-v7a`.
- Bir video səthi (`mpvView`).
- **Loqo keşi:** bitmap keşi 3–8 MB, eyni anda 2 dekod / 2 endirmə. `onTrimMemory ≥ 10`-da loqo keşi təmizlənir.
- **EPG:** proqram təsviri 160 simvol.
- **Ehtiyat link WebView:** yalnız lazım olanda yaradılır, şəkil yükləmə söndürülüb, iş bitəndə silinir.

## Stabillik qeydləri
- `loadfile` / `stop` / `pause` tək `mpv-ctl` thread-ində; köhnəlmiş əmrlər generation ilə atlanır.
- Video səthi hazır olmadan `loadfile` verilmir; səth `surfaceChanged`-dən sonra hazır sayılır. Fona keçəndə `vo=null` + `detachSurface`, qayıdanda `attachSurface` + `vo=gpu`.
- **yoda.az WebView:** `onRenderProcessGone` ilə render prosesi ölərsə tətbiq çökmür.
- **İlkin server sorğusu:** gözlənilməz xəta nəticəsiz sayılır, mpv yoxlayır; kanal dəyişəndə köhnə sorğunun nəticəsi ignor edilir.
- **Təhlükəsizlik toru (`App.kt`):** tutulmayan Java/Kotlin xətasında tətbiq yenidən açılır (15 s-də təkrar çökərsə açılmır). Native çökmələr bununla tutulmur.

## Stream linkləri
http/https (m3u8, ts, mp4, mpd və genişlənməsiz linklər), rtsp, rtmp, udp, srt və s. — mpv (FFmpeg) bütün bu protokolları özü açır.

## Playlist linki dəyişəndə
İzlənən kanalın linki yeni playlistdə dəyişibsə, kanal yeni linklə avtomatik yenidən açılır. Son kanal link, ad, qrup və tvg-id ilə saxlanılır.

## Pleyer işarəsi
EPG-nin sağında üstdə 💜 (mpv), yanında ölçü, altında bufer (🟢🟡🔴) • endirmə sürəti • bitrate yazılır.
