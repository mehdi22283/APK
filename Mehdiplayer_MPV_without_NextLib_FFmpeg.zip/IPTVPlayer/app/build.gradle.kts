import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "az.mehdi.iptvplayer"
    compileSdk = 36

    defaultConfig {
        applicationId = "az.mehdi.iptvplayer"
        minSdk = 24
        targetSdk = 33
        versionCode = 26
        versionName = "1.25"

        // 2 GB RAM TV box: yalnız 32-bit ARM (arm64 cihazlar da 32-bit tətbiqi açır). APK kiçilir.
        ndk { abiFilters += listOf("armeabi-v7a") }
    }

    buildTypes {
        // Debug imza ilə qalır, amma debuggable söndürülür: TV box-da ART tam optimallaşdırma ilə işləyir.
        debug {
            isDebuggable = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Android 7.1 (API 25) üçün java.time və yeni Java API-lərini uyğunlaşdırır.
        isCoreLibraryDesugaringEnabled = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // java.time API-ləri API 26-dan aşağı Android versiyalarında da işləsin.
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // OkHttp: playlist/EPG yükləmə və kanalın serverinə ilkin sorğu üçün (pleyer deyil).
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Birinci pleyer: Media3 (ExoPlayer, yalnız http/https). Codec dəstəklənməyəndə dərhal mpv-yə keçilir.
    val media3 = "1.9.3"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-datasource-okhttp:$media3")

    // Ehtiyat pleyer: mpv. Native kitabxanalar (libmpv, libplayer, libav*) app/src/main/jniLibs/armeabi-v7a içindədir,
    // JNI körpüsü: app/src/main/java/is/xyz/mpv/MPVLib.kt (mpv-android 2026-09-17 build-ndən).
}
