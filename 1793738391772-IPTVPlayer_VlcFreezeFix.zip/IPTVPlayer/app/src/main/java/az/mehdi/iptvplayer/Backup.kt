package az.mehdi.iptvplayer

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import java.util.Locale

/**
 * Ehtiyat link: playlistdəki əsas link işləməsə, yoda.az səhifəsi gizli WebView-da açılır,
 * səhifənin pleyerinin göndərdiyi tokenli .m3u8 linki tutulur və pleyerə verilir.
 * Token IP və User-Agent-ə bağlıdır, buna görə link bu cihazda, WebView-nın User-Agent-i ilə alınır.
 */
object Backup {
    /** Playlistdəki "Azərbaycan" qrupunun kanalları → yoda.az səhifəsi (normallaşdırılmış ad ilə). */
    private val PAGES: Map<String, String> = mapOf(
        "aztv" to "https://yoda.az/tv/azertv/",
        "medeniyyettv" to "https://yoda.az/tv/medeniyyettele/",
        "idmantv" to "https://yoda.az/tv/idmantele/",
        "biznestv" to "https://yoda.az/tv/biznestv/",
        "bakutv" to "https://yoda.az/tv/bakutv/",
        "apatv" to "https://yoda.az/tv/apatv/",
        "realtv" to "https://yoda.az/tv/real/",
        "arb24" to "https://yoda.az/tv/arb24/",
        "arbgunes" to "https://yoda.az/arbgunesh/",
        "arb" to "https://yoda.az/tv/arb/",
        "ictimaitv" to "https://yoda.az/tv/ictimaitele/",
        "spacetv" to "https://yoda.az/tv/space/",
        "atv" to "https://yoda.az/tv/atv/",
        "xezertv" to "https://yoda.az/tv/xazartv/",
        "dunyatv" to "https://yoda.az/tv/dunyatv/",
        "naxcivantv" to "https://yoda.az/tv/ntv/",
        "kanal35" to "https://yoda.az/tv/kanal35/",
        "qafqaztv" to "https://yoda.az/tv/qafkaz/",
        "eltv" to "https://yoda.az/tv/eltv/"
    )

    internal fun norm(name: String): String {
        val sb = StringBuilder()
        for (c in name) {
            when (c) {
                'Ə', 'ə', 'E', 'e' -> sb.append('e')
                'İ', 'I', 'ı', 'i' -> sb.append('i')
                'Ö', 'ö', 'O', 'o' -> sb.append('o')
                'Ü', 'ü', 'U', 'u' -> sb.append('u')
                'Ç', 'ç', 'C', 'c' -> sb.append('c')
                'Ş', 'ş', 'S', 's' -> sb.append('s')
                'Ğ', 'ğ', 'G', 'g' -> sb.append('g')
                else -> if (c.isLetterOrDigit()) sb.append(c.lowercaseChar())
            }
        }
        var r = sb.toString()
        if (r.endsWith("hd") && r.length > 4) r = r.removeSuffix("hd")
        return r
    }

    /** Əvvəl yoda.az-dan açılan kanallar (playlistdəki link yalnız ehtiyatdır). */
    private val YODA_FIRST = setOf("apatv")

    /** true: bu kanal əvvəl yoda.az linki ilə açılır, alınmasa/işləməsə playlistdəki linkə keçilir. */
    fun yodaFirst(ch: Channel): Boolean = pageFor(ch) != null && norm(ch.name) in YODA_FIRST

    /** Kanalın yoda.az ehtiyat səhifəsi; yalnız "Azərbaycan" qrupunda (Türkiyə ATV/NTV ilə qarışmasın). */
    fun pageFor(ch: Channel): String? {
        if (ch.group != "Azərbaycan") return null
        return PAGES[norm(ch.name)]
    }
}

/** Gizli WebView ilə yoda.az səhifəsindən tokenli yayım linkini alır. Yalnız lazım olanda yaradılır, iş bitəndə yaddaşdan silinir. */
class YodaResolver(private val activity: Activity, private val container: ViewGroup) {

    class Result(val url: String, val referer: String, val userAgent: String)

    companion object {
        const val TIMEOUT_MS = 20_000L
        // Tokensiz .m3u8 görünsə də, tokenli link üçün bu qədər əlavə gözlənilir.
        private const val TOKEN_GRACE_MS = 4_000L
        private const val AUTOPLAY_JS = """
(function(){
  function go(){
    try{ document.querySelectorAll('video').forEach(function(v){ v.muted=true; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }); }catch(e){}
    try{ var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="big-play"],[class*="PlayButton"]'); if(b) b.click(); }catch(e){}
  }
  go(); setTimeout(go,1500); setTimeout(go,4000); setTimeout(go,8000);
})();
"""
    }

    private val ui = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var done = false
    private var candidate: Result? = null
    private var cb: ((Result?) -> Unit)? = null
    private var page = ""
    private var ua = ""

    private val timeoutRun = Runnable { finish(candidate) }
    private val graceRun = Runnable { finish(candidate) }

    @SuppressLint("SetJavaScriptEnabled")
    fun resolve(pageUrl: String, onResult: (Result?) -> Unit) {
        cancel()
        done = false
        candidate = null
        cb = onResult
        page = pageUrl
        try {
            val w = WebView(activity)
            web = w
            val s = w.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.cacheMode = WebSettings.LOAD_NO_CACHE
            ua = s.userAgentString
            w.alpha = 0.01f
            val px = (8 * activity.resources.displayMetrics.density).toInt()
            container.addView(w, FrameLayout.LayoutParams(px, px, Gravity.BOTTOM or Gravity.END))
            w.webChromeClient = WebChromeClient()
            w.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val req = request ?: return null
                    val u = req.url.toString()
                    if (u.substringBefore("?").lowercase(Locale.ROOT).endsWith(".m3u8")) {
                        val ref = req.requestHeaders?.get("Referer")?.takeIf { it.startsWith("http") } ?: page
                        val r = Result(u, ref, ua)
                        ui.post { onM3u8(r) }
                    }
                    return null
                }

                // WebView render prosesi (2 GB RAM-da yaddaş azlığından) ölərsə, bunu tutmayan tətbiq TAM ÇÖKÜR.
                // true qaytarılır: tətbiq yaşayır, WebView atılır və ehtiyat link prosesi nəticəsiz bitir.
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    android.util.Log.w("IPTV-BACKUP", "WebView prosesi dayandı (çökmə=${detail?.didCrash()})")
                    ui.post { if (!done) finish(candidate) }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!done && url != null && url != "about:blank") view?.evaluateJavascript(AUTOPLAY_JS, null)
                }
            }
            ui.postDelayed(timeoutRun, TIMEOUT_MS)
            w.loadUrl(pageUrl)
        } catch (e: Throwable) {
            android.util.Log.e("IPTV-BACKUP", "WebView açıla bilmədi", e)
            finish(null)
        }
    }

    private fun onM3u8(r: Result) {
        if (done) return
        if (r.url.contains("token=")) {
            finish(r)
        } else if (candidate == null) {
            candidate = r
            ui.postDelayed(graceRun, TOKEN_GRACE_MS)
        }
    }

    private fun finish(r: Result?) {
        if (done) return
        done = true
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(graceRun)
        val callback = cb
        cb = null
        destroyWeb()
        android.util.Log.i("IPTV-BACKUP", "yoda.az nəticə: " + (r?.url ?: "tapılmadı") + " (səhifə: $page)")
        callback?.invoke(r)
    }

    private fun destroyWeb() {
        val w = web ?: return
        web = null
        runCatching {
            w.stopLoading()
            w.loadUrl("about:blank")
            container.removeView(w)
            w.destroy()
        }
    }

    /** Gedən işi dayandırır (nəticə qaytarılmır). */
    fun cancel() {
        done = true
        cb = null
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(graceRun)
        destroyWeb()
    }
}
