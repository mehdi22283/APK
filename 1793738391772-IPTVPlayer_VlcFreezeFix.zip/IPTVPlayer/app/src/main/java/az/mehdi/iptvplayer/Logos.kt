package az.mehdi.iptvplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Collections
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * Loqo ƏVVƏL birinci playlistdəki tvg-logo="..." linkindən götürülür; olmasa və ya endirilməsə
 * EPG mənbəsindən (https://iptvx.one/EPG_NOARCH, XML-dəki <icon src="...">).

 * Birinci mənbədən loqo YALNIZ dəqiq adla (latın Azərbaycan hərf qarşılığı, Kiril→latın çevrilməsi ilə) uyğunlaşdırılır;
 * oxşar ad axtarışı yoxdur (Kanal S ≠ Kanal D, Ayaz TV ≠ AzTV).
 *  - Offline keş: filesDir/logo_cache2 (fayl adı EPG kanal id-sinin hash-i).
 *  - Toplu yeniləmə (refreshAll): çatışan / linki dəyişən / (ETag, Last-Modified-ə görə) məzmunu dəyişən bütün loqolar
 *    16 paralel axınla müvəqqəti qovluğa (logo_new) endirilir, hamısı tam bitəndən sonra bir anda əvəz olunur.
 */
private const val WORKERS = 6
private const val CHANNEL_CHECK_MS = 5L * 60 * 1000

class LogoStore(private val ctx: Context, private val epg: EpgStore) {
    private val dir = File(ctx.filesDir, "logo_cache2").apply { mkdirs() }
    private val stage = File(ctx.filesDir, "logo_new")
    private val failed = Collections.synchronizedSet(HashSet<String>())
    private val locks = java.util.concurrent.ConcurrentHashMap<String, Mutex>()
    private val refreshMutex = Mutex()

    /** Kanal üçün keş açarı və namizəd linklər: əvvəl playlistdəki tvg-logo, sonra EPG-nin loqosu. */
    private class Target(val key: String, val urls: List<String>)

    private fun targetFor(ch: Channel): Target? {
        // 1) Birinci playlistdəki tvg-logo="..." linki (ən yüksək prioritet)
        val own = ch.logo?.takeIf { it.startsWith("http") }
        // 2) EPG (yalnız dəqiq ad)
        val id = epg.logoIdFor(ch)
        val urls = listOfNotNull(own, id?.let { epg.iconUrl(it) }).distinct()
        if (urls.isEmpty()) return null
        val key = if (own != null) "p:$own" else id ?: ("x:" + urls.first())
        return Target(key, urls)
    }
    private val lastCheck = java.util.concurrent.ConcurrentHashMap<String, Long>()
    // Bitmap keşi cihazın yaddaşına görə (1/16, 6–16 MiB arası); eyni anda yalnız az sayda dekod/endirmə gedir.
    private val decodeGate = Semaphore(3)
    private val fetchGate = Semaphore(3)
    private val mem = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 16).toInt().coerceIn(6 * 1024, 16 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    // Toplu yeniləmə gedərkən kartlar tək-tək endirməsin: yeniləmənin bitməsini gözləyir.
    private val batchLock = Any()
    private var batchUsers = 0
    private var batch: CompletableDeferred<Unit>? = null
    fun beginBatch() = synchronized(batchLock) { if (batchUsers++ == 0) batch = CompletableDeferred() }
    fun endBatch() = synchronized(batchLock) {
        if (batchUsers > 0 && --batchUsers == 0) { batch?.complete(Unit); batch = null }
    }

    init {
        runCatching { stage.deleteRecursively() }
    }

    private fun md5(s: String) = MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun fileFor(key: String) = File(dir, md5(key) + ".img")
    private fun metaFor(key: String) = File(dir, md5(key) + ".meta")

    private class Meta(val url: String, val etag: String?, val lm: String?)
    private fun readMeta(key: String): Meta? = runCatching {
        val l = metaFor(key).readLines()
        Meta(l[0], l.getOrNull(1)?.takeIf { it.isNotEmpty() }, l.getOrNull(2)?.takeIf { it.isNotEmpty() })
    }.getOrNull()
    private fun writeMeta(key: String, url: String, etag: String?, lm: String?) {
        runCatching { metaFor(key).writeText(url + "\n" + (etag ?: "") + "\n" + (lm ?: "")) }
    }

    private fun isImage(f: File): Boolean {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        return o.outWidth > 0
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) return null
        var s = 1
        val maxDimension = maxOf(o.outWidth, o.outHeight)
        while (maxDimension / s > 192) s *= 2
        return try {
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (e: OutOfMemoryError) {
            mem.evictAll(); null
        }
    }

    private suspend fun fromDisk(key: String): Bitmap? {
        val file = fileFor(key)
        if (!(file.exists() && file.length() > 0L)) return null
        val b = decodeGate.withPermit { withContext(Dispatchers.IO) { decode(file) } }
        if (b != null) { mem.put(key, b); return b }
        file.delete() // zədəli fayl
        return null
    }

    /** Yaddaş keşində hazır loqo varsa dərhal verir (korutin açmadan, siyahı sürüşəndə yüngüldür). */
    fun peek(ch: Channel): Bitmap? {
        if (!epg.ready.isCompleted) return null
        val key = targetFor(ch)?.key ?: epg.logoIdFor(ch) ?: return null
        return mem.get(key)?.takeIf { !it.isRecycled }
    }

    /** Sistem yaddaş azlığı bildirəndə bitmap keşi boşaldılır. */
    fun trim() = mem.evictAll()

    suspend fun bitmapFor(ch: Channel): Bitmap? {
        epg.ready.await() // kanal -> EPG id uyğunluğu hazır olsun
        val t0 = targetFor(ch)
        val key = t0?.key ?: epg.logoIdFor(ch) ?: return null
        mem.get(key)?.let { return it }
        fromDisk(key)?.let { return it }

        // Toplu yeniləmə gedirsə onun bitməsini gözlə (hamısı birdən gəlsin)
        synchronized(batchLock) { batch }?.await()
        fromDisk(key)?.let { return it }
        if (failed.contains(key)) return null

        // Ehtiyat: toplu yeniləmə bu loqonu gətirməyibsə, tək endirmə cəhdi (playlistdəki tvg-logo, olmasa/alınmasa EPG linki)
        val t = targetFor(ch) ?: run { failed.add(key); return null }
        locks.computeIfAbsent(key) { Mutex() }.withLock {
            mem.get(key)?.let { return it }
            val tmp = File(dir, md5(key) + ".dl")
            val ok = fetchGate.withPermit { withContext(Dispatchers.IO) {
                var res = false
                for (u in t.urls) {
                    try {
                        val r = fetchConditional(u, tmp, null, null, 10000)
                        if (!r.notModified && isImage(tmp)) {
                            val f = fileFor(key); if (f.exists()) f.delete(); tmp.renameTo(f)
                            writeMeta(key, u, r.etag, r.lastMod); res = true; break
                        } else tmp.delete()
                    } catch (e: CancellationException) { throw e } catch (e: Throwable) { tmp.delete() }
                }
                res
            } }
            if (ok) fromDisk(key)?.let { return it }
        }
        failed.add(key) // yalnız bu sessiya üçün
        return null
    }

    /**
     * Kanal dəyişəndə çağırılır: həmin kanalın loqosu mənbədə dəyişibsə (link, ETag/Last-Modified və ya məzmun)
     * dərhal yenisini endirib əvəz edir. Eyni kanal üçün 5 dəqiqədən tez təkrar yoxlanmır. Yenilənibsə true.
     */
    suspend fun refreshChannel(ch: Channel): Boolean {
        epg.ready.await()
        val t = targetFor(ch) ?: return false
        val key = t.key
        synchronized(batchLock) { batch }?.await() // toplu endirmə gedirsə onu gözlə
        val now = SystemClock.elapsedRealtime()
        val prev = lastCheck[key]
        if (prev != null && now - prev < CHANNEL_CHECK_MS) return false
        lastCheck[key] = now
        return locks.computeIfAbsent(key) { Mutex() }.withLock {
            val live = fileFor(key)
            val have = live.exists() && live.length() > 0L
            val meta = readMeta(key)
            val first = t.urls.first()
            val same = have && meta?.url == first
            val updated = withContext(Dispatchers.IO) {
                var res = false
                for ((i, u) in t.urls.withIndex()) {
                    // Əsas link alınmasa da, artıq əsas linkdən gələn mövcud loqo ehtiyatla əvəz edilmir.
                    if (i > 0 && have && meta?.url == first) break
                    val tmp = File(dir, md5(key) + ".chk")
                    try {
                        val useMeta = i == 0 && same
                        val r = fetchConditional(u, tmp, if (useMeta) meta?.etag else null, if (useMeta) meta?.lm else null, 8000)
                        if (r.notModified) { tmp.delete(); break }
                        if (!isImage(tmp)) { tmp.delete(); continue }
                        if (have && tmp.length() == live.length() && tmp.readBytes().contentEquals(live.readBytes())) {
                            writeMeta(key, u, r.etag, r.lastMod); tmp.delete(); break // məzmun eynidir
                        }
                        if (live.exists()) live.delete()
                        val ok = tmp.renameTo(live) || runCatching { tmp.copyTo(live, true); tmp.delete(); true }.getOrDefault(false)
                        if (ok) { writeMeta(key, u, r.etag, r.lastMod); res = true }
                        break
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        tmp.delete()
                    }
                }
                res
            }
            if (updated) { mem.remove(key); fromDisk(key) }
            updated
        }
    }

    private class Item(val key: String, val urls: List<String>, val etag: String?, val lm: String?)
    private class Staged(val key: String, val url: String, val etag: String?, val lm: String?, val file: File)

    /**
     * Çatışan, linki dəyişən (və ya `force` / 6 saatdan bir ETag-Last-Modified yoxlamasına görə məzmunu dəyişən) bütün
     * loqoları 16 paralel axınla müvəqqəti qovluğa endirir; HAMISI tam bitəndən sonra birdən əvəz edir.
     * Əvəz olunan loqoların sayını qaytarır.
     */
    suspend fun refreshAll(channels: List<Channel>, force: Boolean): Int = refreshMutex.withLock {
        failed.clear()
        val targets = LinkedHashMap<String, Target>()
        for (ch in channels) targetFor(ch)?.let { targets.putIfAbsent(it.key, it) }
        if (targets.isEmpty()) return@withLock 0
        val revalidate = force

        val todo = ArrayList<Item>()
        for ((key, t) in targets) {
            val u = t.urls.first()
            val have = fileFor(key).let { it.exists() && it.length() > 0L }
            val meta = readMeta(key)
            if (!have || meta == null || meta.url != u) todo.add(Item(key, t.urls, null, null))
            else if (revalidate && (force || meta.etag != null || meta.lm != null)) todo.add(Item(key, t.urls, meta.etag, meta.lm))
        }
        if (todo.isEmpty()) return@withLock 0

        stage.deleteRecursively(); stage.mkdirs()
        val done = ConcurrentLinkedQueue<Staged>()
        val next = AtomicInteger(0)
        coroutineScope {
            repeat(minOf(WORKERS, todo.size)) {
                launch(Dispatchers.IO) { lowPriority {
                    while (true) {
                        val i = next.getAndIncrement()
                        if (i >= todo.size) break
                        val it = todo[i]
                        val tmp = File(stage, md5(it.key) + ".img")
                        var attempt = 0
                        while (attempt < 2) {
                            attempt++
                            var settled = false
                            for ((ui, u) in it.urls.withIndex()) {
                                try {
                                    val r = fetchConditional(u, tmp, if (ui == 0) it.etag else null, if (ui == 0) it.lm else null, 10000)
                                    if (r.notModified) { tmp.delete(); settled = true; break }
                                    if (isImage(tmp)) { done.add(Staged(it.key, u, r.etag, r.lastMod, tmp)); settled = true; break }
                                    tmp.delete()
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Throwable) {
                                    tmp.delete()
                                }
                            }
                            if (settled) break
                        }
                    }
                } }
            }
        }

        // Hamısı endirildi -> bir anda əvəz et
        var replaced = 0
        withContext(Dispatchers.IO) {
            for (s in done) {
                val live = fileFor(s.key)
                if (live.exists()) live.delete()
                val ok = s.file.renameTo(live) || runCatching { s.file.copyTo(live, true); true }.getOrDefault(false)
                if (ok) { writeMeta(s.key, s.url, s.etag, s.lm); replaced++ }
            }
            stage.deleteRecursively()
        }
        if (replaced > 0) mem.evictAll()
        replaced
    }
}
