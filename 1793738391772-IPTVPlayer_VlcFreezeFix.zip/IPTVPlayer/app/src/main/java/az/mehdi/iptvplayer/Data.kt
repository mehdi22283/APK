package az.mehdi.iptvplayer

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request

data class Channel(
    val number: Int, val name: String, val url: String, val group: String, val logo: String?,
    val tvgId: String? = null, val tvgName: String? = null,
    val ua: String? = null, val referer: String? = null
)

const val PLAYLIST_URL = "https://m3u8.mehdimyev.workers.dev/"
/** Keş faylı yeni mənbəyə aiddir; köhnə mənbədən qalan "playlist.m3u" silinir ki, köhnə kanallar açılmasın. */
const val PLAYLIST_CACHE_NAME = "playlist_mehdimyev.m3u"
fun dropLegacyPlaylistCache(dir: File) { runCatching { File(dir, "playlist.m3u").delete(); File(dir, "playlist.m3u.new").delete() } }
private const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) OTTPlayer/1.0"

fun fetchToFile(src: String, dest: File, timeout: Int = 15000) {
    // OkHttp idarə olunan TLS/redirect davranışı ilə köhnə Android TV cihazlarında
    // HttpURLConnection-dan daha sabit bağlantı yarada bilər.
    val client = OkHttpClient.Builder()
        .connectTimeout(timeout.toLong(), TimeUnit.MILLISECONDS)
        .readTimeout((timeout * 2L), TimeUnit.MILLISECONDS)
        .callTimeout((timeout * 3L), TimeUnit.MILLISECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()
    val request = Request.Builder()
        .url(src)
        .header("User-Agent", UA)
        .header("Accept", "*/*")
        .build()
    val tmp = File(dest.path + ".tmp")
    try {
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val body = response.body ?: throw IOException("Server boş cavab qaytardı")
            body.byteStream().use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
            if (tmp.length() == 0L) throw IOException("Server boş fayl qaytardı")
        }
        if (dest.exists() && !dest.delete()) throw IOException("Keş faylı silinmədi")
        if (!tmp.renameTo(dest)) throw IOException("Müvəqqəti faylı saxlamaq mümkün olmadı")
    } catch (e: Exception) {
        tmp.delete()
        throw e
    } finally {
        client.connectionPool.evictAll()
        client.cache?.close()
    }
}

class Fetched(val notModified: Boolean, val etag: String?, val lastMod: String?)

/** ETag / Last-Modified ilə şərti endirmə: server 304 qaytarırsa fayl dəyişməyib (dest-ə toxunulmur). */
fun fetchConditional(src: String, dest: File, etag: String?, lastMod: String?, timeout: Int = 15000): Fetched {
    val c = URL(src).openConnection() as HttpURLConnection
    c.connectTimeout = timeout
    c.readTimeout = timeout * 2
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", UA)
    if (!etag.isNullOrEmpty()) c.setRequestProperty("If-None-Match", etag)
    if (!lastMod.isNullOrEmpty()) c.setRequestProperty("If-Modified-Since", lastMod)
    try {
        val code = c.responseCode
        if (code == 304) return Fetched(true, etag, lastMod)
        if (code !in 200..299) throw IOException("HTTP $code")
        val expected = c.contentLengthLong
        if (dest.exists()) dest.delete()
        c.inputStream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        // Yarımçıq endirmə qəbul edilmir
        if (expected > 0 && dest.length() != expected && c.contentEncoding == null) {
            dest.delete(); throw IOException("incomplete")
        }
        return Fetched(false, c.getHeaderField("ETag"), c.getHeaderField("Last-Modified"))
    } finally {
        c.disconnect()
    }
}

class PlaylistCheck(val text: String, val changed: Boolean)

private fun normalizePlaylist(s: String) = s.replace("\r\n", "\n").trim()

/**
 * Açılışda ilk iş: playlist serverdən yoxlanılır. Məzmun keşdəkindən fərqlidirsə, keş yenilənir (changed=true);
 * eynidirsə keş olduğu kimi qalır (changed=false). Xəta olarsa istisna atılır və keşə toxunulmur.
 */
fun checkPlaylist(cache: File, timeout: Int): PlaylistCheck {
    val fresh = File(cache.path + ".new")
    try {
        fetchToFile(PLAYLIST_URL, fresh, timeout)
        val text = fresh.readText()
        if (!text.contains("#EXTINF")) throw IOException("Playlist boşdur")
        val old = runCatching { if (cache.exists()) cache.readText() else null }.getOrNull()
        val changed = old == null || normalizePlaylist(old) != normalizePlaylist(text)
        if (changed) {
            if (cache.exists()) cache.delete()
            if (!fresh.renameTo(cache)) cache.writeText(text)
        } else {
            cache.setLastModified(System.currentTimeMillis())
        }
        return PlaylistCheck(text, changed)
    } finally {
        fresh.delete()
    }
}

fun parsePlaylist(text: String): List<Channel> {
    val res = ArrayList<Channel>()
    val attr = Regex("([\\w-]+)=\"([^\"]*)\"")
    var name: String? = null
    var group = "Digər"
    var logo: String? = null
    var tvgId: String? = null
    var tvgName: String? = null
    var optUa: String? = null
    var optRef: String? = null
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        if (line.isEmpty()) continue
        if (line.startsWith("#EXTINF")) {
            val comma = line.lastIndexOf(',')
            name = if (comma >= 0) line.substring(comma + 1).trim() else ""
            val head = if (comma >= 0) line.substring(0, comma) else line
            val a = attr.findAll(head).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
            group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Digər"
            logo = a["tvg-logo"]?.takeIf { it.startsWith("http") }
            tvgId = a["tvg-id"]?.takeIf { it.isNotBlank() }
            tvgName = a["tvg-name"]?.takeIf { it.isNotBlank() }
        } else if (line.startsWith("#EXTGRP:")) {
            group = line.substringAfter(':').trim().ifEmpty { "Digər" }
        } else if (line.startsWith("#EXTVLCOPT:", ignoreCase = true)) {
            val kv = line.substringAfter(':')
            val v = kv.substringAfter('=', "").trim().takeIf { it.isNotEmpty() }
            when (kv.substringBefore('=').trim().lowercase()) {
                "http-user-agent" -> optUa = v
                "http-referrer", "http-referer" -> optRef = v
            }
        } else if (!line.startsWith("#")) {
            if (name != null) {
                // Kodi üslubu: http://host/x.m3u8|User-Agent=...&Referer=...
                var link = line
                var ua = optUa
                var ref = optRef
                val bar = line.indexOf('|')
                if (bar > 0) {
                    link = line.substring(0, bar).trim()
                    for (part in line.substring(bar + 1).split('&')) {
                        val k = part.substringBefore('=').trim().lowercase()
                        val v = decodeParam(part.substringAfter('=', "").trim()).takeIf { it.isNotEmpty() } ?: continue
                        when (k) {
                            "user-agent" -> ua = v
                            "referer", "referrer" -> ref = v
                        }
                    }
                }
                res.add(Channel(res.size + 1, name.ifBlank { link }, link, group, logo, tvgId, tvgName, ua, ref))
            }
            name = null; group = "Digər"; logo = null; tvgId = null; tvgName = null; optUa = null; optRef = null
        }
    }
    return res
}

private fun decodeParam(v: String): String = try { java.net.URLDecoder.decode(v, "UTF-8") } catch (e: Exception) { v }

/** Ağır fon işi (EPG parse, loqo endirmə) oynatmanı ac qoymasın: iş bitənə qədər thread prioriteti aşağı olur. */
inline fun <T> lowPriority(block: () -> T): T {
    android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
    try {
        return block()
    } finally {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DEFAULT)
    }
}
