package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.view.View
import android.widget.RemoteViews
import kotlin.math.roundToInt

class WeatherWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        Scheduler.start(context)
        Midnight.schedule(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Scheduler.start(context)
        Midnight.schedule(context)
        refresh(context)
        if (WeatherApi.ageMin(context) > 10) Scheduler.now(context)
    }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return
            m.updateAppWidget(ids, build(c))
        }

        private val INFO_IDS = intArrayOf(R.id.w_i1, R.id.w_i2, R.id.w_i3, R.id.w_i4, R.id.w_i5, R.id.w_i6)

        /** Mətnin solunda ikon göstərir (sol ikon: ad + ölçü) */
        private fun left(c: Context, rv: RemoteViews, id: Int, text: CharSequence, icon: String, size: String) {
            rv.setTextViewText(id, text)
            rv.setTextViewCompoundDrawables(id, Ic.id(c, icon, size), 0, 0, 0)
            rv.setViewVisibility(id, View.VISIBLE)
        }

        private fun build(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val w = WeatherApi.cached(c)
            val n = w?.nowIndex() ?: -1
            rv.setTextViewText(R.id.w_date, T.dateLine())
            left(c, rv, R.id.w_word, Daily.word(c), "bulb", "s")
            left(c, rv, R.id.w_proverb, Daily.proverb(c), "book", "s")
            rv.removeAllViews(R.id.w_days)
            INFO_IDS.forEach { rv.setViewVisibility(it, View.GONE) }
            rv.removeAllViews(R.id.w_hr1)
            rv.removeAllViews(R.id.w_hr2)
            rv.setViewVisibility(R.id.w_wear, View.GONE)
            if (w == null || n < 0) {
                rv.setTextViewText(R.id.w_title, "Yenilənir…")
                rv.setTextViewCompoundDrawables(R.id.w_title, 0, 0, 0, 0)
                rv.setTextViewText(R.id.w_outlook, "İnternet bağlantısı olanda məlumat yüklənəcək")
                rv.setTextViewCompoundDrawables(R.id.w_outlook, 0, 0, 0, 0)
            } else {
                val h = w.hours[n]
                left(c, rv, R.id.w_title, "${h.temp.roundToInt()}°  ${T.desc(h.code)}", T.iconName(h.code), "xl")
                val o = w.outlook()
                left(c, rv, R.id.w_outlook, o?.text ?: "", T.kindIcon(o?.kind), "")
                left(c, rv, R.id.w_wear, Wear.now(w, n).short.replaceFirstChar { it.uppercase() }, "shirt", "s")
                w.widgetInfo(n).forEachIndexed { r, row ->
                    row.take(3).forEachIndexed { i, p -> left(c, rv, INFO_IDS[r * 3 + i], p.second, p.first, "s") }
                }
                // növbəti 12 saat: yuxarıda 6, aşağıda 6
                for (j in 1..12) {
                    val idx = n + j
                    if (idx >= w.hours.size) break
                    val hh = w.hours[idx]
                    val r = RemoteViews(c.packageName, R.layout.widget_hour)
                    r.setTextViewText(R.id.h_time, hh.time.substring(11, 16))
                    r.setImageViewResource(R.id.h_icon, Ic.id(c, T.iconName(hh.code), "xl"))
                    r.setTextViewText(R.id.h_temp, "${hh.temp.roundToInt()}°")
                    r.setTextViewText(R.id.h_rain, "${hh.prob}%")
                    r.setTextViewCompoundDrawables(R.id.h_rain, Ic.id(c, "drop", "s"), 0, 0, 0)
                    rv.addView(if (j <= 6) R.id.w_hr1 else R.id.w_hr2, r)
                }
                w.upcomingDays().forEachIndexed { i, d ->
                    val r = RemoteViews(c.packageName, R.layout.widget_day)
                    r.setTextViewText(R.id.d_name, if (i == 0) "Bu gün" else T.dayName(d.date))
                    r.setImageViewResource(R.id.d_icon, Ic.id(c, T.iconName(d.code), "xl"))
                    r.setTextViewText(R.id.d_max, "${d.max.roundToInt()}°")
                    r.setTextViewText(R.id.d_min, "${d.min.roundToInt()}°")
                    r.setTextViewText(R.id.d_rain, "${d.prob}%")
                    r.setTextViewCompoundDrawables(R.id.d_rain, Ic.id(c, "drop", "s"), 0, 0, 0)
                    r.setTextViewText(R.id.d_hours, "${w.precipHours(d)} saat")
                    r.setTextViewCompoundDrawables(R.id.d_hours, Ic.id(c, "clock", "s"), 0, 0, 0)
                    val frame = when (d.frameKind()) {
                        "qar" -> R.drawable.frame_snow
                        "yağış" -> R.drawable.frame_rain
                        "külək" -> R.drawable.frame_wind
                        else -> R.drawable.frame_none
                    }
                    r.setInt(R.id.d_box, "setBackgroundResource", frame)
                    rv.addView(R.id.w_days, r)
                }
            }
            left(c, rv, R.id.w_steps, Steps.stepsText(c), "steps", "")
            left(c, rv, R.id.w_km, Steps.kmText(c), "ruler", "")
            val hr = Heart.last(c)
            rv.setTextViewText(R.id.w_heart, if (hr == null) "Ölç" else "${hr.second}\n${Heart.timeText(hr.first)}")
            rv.setTextViewCompoundDrawables(R.id.w_heart, 0, Ic.id(c, "heart", "l"), 0, 0)
            rv.setOnClickPendingIntent(R.id.w_root, Notif.open(c))
            rv.setOnClickPendingIntent(R.id.w_heart, Heart.open(c))
            return rv
        }
    }
}
