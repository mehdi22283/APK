package az.mehdi.hava

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

object Notif {
    fun channels(c: Context) {
        val m = c.getSystemService(NotificationManager::class.java)
        // Addım bildirişi artıq yoxdur: köhnə kanalları sil
        for (id in listOf("steps", "steps2", "info")) try { m.deleteNotificationChannel(id) } catch (e: Exception) { }
        m.createNotificationChannel(NotificationChannel("alert", "Hava xəbərdarlığı", NotificationManager.IMPORTANCE_HIGH))
        try { m.deleteNotificationChannel("full") } catch (e: Exception) { }
        m.createNotificationChannel(NotificationChannel("daily", "Gündəlik proqnoz", NotificationManager.IMPORTANCE_DEFAULT))
    }

    /** Widgetdən tətbiqi verilən bölmədə açır */
    fun openSection(c: Context, key: String): PendingIntent =
        PendingIntent.getActivity(
            c, 100 + (key.hashCode() and 0xFFF),
            Intent(c, MainActivity::class.java).putExtra("sec", key)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun open(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun post(c: Context, id: Int, ch: String, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        channels(c)
        val n = Notification.Builder(c, ch)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open(c))
            .setOnlyAlertOnce(ch != "alert")
            .setAutoCancel(true)
            .build()
        c.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

object Alerts {
    fun check(c: Context, w: Weather) {
        val n = w.nowIndex()
        if (n < 0) return
        val o = w.outlook() ?: return
        @Suppress("UNUSED_VARIABLE") val h = w.hours[n]
        val p = c.getSharedPreferences("alerts", Context.MODE_PRIVATE)

        // Cari vəziyyət bildirişi silindi (hər yenilənmədə lazımsız bildiriş yaradırdı).
        // Yağış/qar xəbərdarlığını RainAlert verir; burada yalnız tufan və güclü külək (təkrar bildiriş olmasın)
        // 2) Xəbərdarlıq: 3 saat ərzində tufan/güclü külək və ya hazırda var
        if ((o.kind == "tufan" || o.kind == "külək") && (o.ongoing || o.inHours <= 3) && p.getString("key", "") != o.key) {
            Notif.post(c, 11, "alert", "Hava xəbərdarlığı", o.text)
            p.edit().putString("key", o.key).apply()
        }

        // 3) Səhər proqnozu (07:00–10:59, gündə bir dəfə)
        val today = LocalDate.now(BAKU).toString()
        val hr = LocalDateTime.now(BAKU).hour
        if (hr in 7..10 && p.getString("daily", "") != today) {
            val d = w.upcomingDays().firstOrNull()
            if (d != null) {
                val sb = StringBuilder("${T.desc(d.code)} · ${d.max.roundToInt()}°/${d.min.roundToInt()}° · yağış ehtimalı ${d.prob}% · yağıntı ${w.precipHours(d)} saat · miqdar ${fmtPrecip(d.mm, d.snow)} (${precipLabel(d.mm, d.snow)})")
                sb.append("\nGeyim: ${Wear.forDay(w, d)}")
                w.dayLight()?.let { sb.append("\nGün ${it.lenText} (${it.sunrise}–${it.sunset})") }
                val mi = Moon.info()
                sb.append("\nAy: ${mi.name}, ${mi.illum}% işıqlanıb")
                Notif.post(c, 12, "daily", "Bu gün · ${Locations.current(c).name}", sb.toString())
                p.edit().putString("daily", today).apply()
            }
        }
    }
}

object Scheduler {
    private fun net() = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build()

    fun start(c: Context) {
        try { c.getSystemService(NotificationManager::class.java).cancel(1) } catch (e: Exception) { } // köhnə addım bildirişi
        try { c.getSystemService(NotificationManager::class.java).cancel(10) } catch (e: Exception) { } // köhnə "cari hava" bildirişi
        // Avtomatik yeniləmə yalnız 00:00-da (Midnight) və tətbiqə girəndə olur; köhnə saatlıq iş ləğv edilir
        WorkManager.getInstance(c).cancelUniqueWork("hava")
    }

    fun now(c: Context) {
        WorkManager.getInstance(c).enqueue(OneTimeWorkRequestBuilder<UpdateWorker>().setConstraints(net()).build())
    }

    fun hasActivityPerm(c: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

}

class UpdateWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        StepReader.readBlocking(ctx)
        val w = WeatherApi.refresh(ctx)
        WeatherWidget.refresh(ctx)
        if (w != null) Alerts.check(ctx, w)
        return if (w != null) Result.success() else Result.retry()
    }
}
