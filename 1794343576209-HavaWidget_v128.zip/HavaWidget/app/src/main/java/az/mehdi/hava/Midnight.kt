package az.mehdi.hava

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate

object Midnight {
    /** Növbəti 00:00-a (Bakı vaxtı) yenilənmə siqnalı qurur */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val next = LocalDate.now(BAKU).plusDays(1).atStartOfDay(BAKU).toInstant().toEpochMilli()
        val pi = PendingIntent.getBroadcast(
            c, 100, Intent(c, MidnightReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            }
        } catch (e: Exception) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        }
    }
}

class MidnightReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Midnight.schedule(c) // sabahkı 00:00
        StepTicker.schedule(c)
        WeatherWidget.refresh(c) // "Bu gün" sütunu yeni günə keçsin
        val pr = goAsync()
        Thread {
            try {
                StepReader.readBlocking(c) // yeni günün addım bazası məhz 00:00-da yazılır
                val w = WeatherApi.refresh(c)
                WeatherWidget.refresh(c)
                if (w != null) Alerts.check(c, w) else Scheduler.now(c)
            } finally {
                pr.finish()
            }
        }.start()
    }
}
