package az.mehdi.iptvplayer

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import java.util.Locale

/**
 * Logosu olmayan (və ya yüklənməyən) kanal üçün avtomatik əvəzedici: kanal adından alınan rəng + baş hərflər.
 * Eyni ad həmişə eyni rəngi verir. Bitmap saxlanmır, hər dəfə Canvas ilə çəkilir (yaddaş yeməz).
 */
class LogoPlaceholder(name: String) : Drawable() {
    private val initials = initialsOf(name)
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colorOf(name)
    }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }
    private val rect = RectF()

    override fun getIntrinsicWidth() = 240
    override fun getIntrinsicHeight() = 120

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        // Sahənin ortasında 2:1 nisbətli yumru düzbucaqlı (fitCenter ilə uyğun)
        val h = minOf(b.height().toFloat(), b.width() / 2f)
        val w = h * 2f
        rect.set(b.exactCenterX() - w / 2, b.exactCenterY() - h / 2, b.exactCenterX() + w / 2, b.exactCenterY() + h / 2)
        canvas.drawRoundRect(rect, h * 0.18f, h * 0.18f, bg)
        fg.textSize = h * if (initials.length > 1) 0.46f else 0.56f
        val y = rect.centerY() - (fg.descent() + fg.ascent()) / 2
        canvas.drawText(initials, rect.centerX(), y, fg)
    }

    override fun setAlpha(alpha: Int) { bg.alpha = alpha; fg.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { bg.colorFilter = cf; fg.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT

    private companion object {
        fun initialsOf(name: String): String {
            val words = name.trim().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
            val s = when {
                words.isEmpty() -> "?"
                words.size == 1 -> words[0].take(2)
                else -> "${words[0].first()}${words[1].first()}"
            }
            return s.uppercase(Locale("az"))
        }

        fun colorOf(name: String): Int {
            val key = name.trim().lowercase(Locale.ROOT)
            var hash = 7
            for (c in key) hash = hash * 31 + c.code
            val hue = ((hash % 360) + 360) % 360
            // Tünd, doymuş ton: ağ yazı həmişə oxunur, kartın tünd fonu ilə uyuşur
            return Color.HSVToColor(floatArrayOf(hue.toFloat(), 0.55f, 0.50f))
        }
    }
}
