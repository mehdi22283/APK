package az.mehdi.iptvplayer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Yüklənmə göstəricisi: 5 nöqtə ardıcıl dalğa kimi böyüyüb-kiçilir və solur.
 * Yalnız görünəndə animasiya işləyir (zəif TV box-da boş yerə CPU işlətmir).
 */
class LoaderView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6EC6FF.toInt() }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1300
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    private fun refresh() {
        val show = isAttachedToWindow && visibility == VISIBLE && windowVisibility == VISIBLE
        if (show) { if (!anim.isStarted) anim.start() } else anim.cancel()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) { super.onVisibilityChanged(changedView, visibility); refresh() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); refresh() }

    override fun onDraw(c: Canvas) {
        val n = 5
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val step = w / n
        val maxR = min(step * 0.42f, h / 2f)
        for (i in 0 until n) {
            // hər nöqtə öncəkindən bir az gec başlayır -> dalğa
            val phase = (((t - i * 0.12f) % 1f) + 1f) % 1f
            val k = ((sin(phase * 2.0 * PI - PI / 2) + 1.0) / 2.0).toFloat()
            paint.alpha = (70 + 185 * k).toInt()
            c.drawCircle(step * (i + 0.5f), h / 2f, maxR * (0.4f + 0.6f * k), paint)
        }
    }
}
