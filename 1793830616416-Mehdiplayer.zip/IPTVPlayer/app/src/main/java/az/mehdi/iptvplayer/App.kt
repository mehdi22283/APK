package az.mehdi.iptvplayer

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.os.Process
import kotlin.system.exitProcess

/**
 * Təhlükəsizlik toru: tətbiq açıqkən tutulmayan (Java/Kotlin) xəta olarsa, TV box-da ana ekrana atılmaq əvəzinə
 * tətbiq avtomatik yenidən açılır (son kanal özü açılır). 15 s ərzində təkrar çökərsə döngü olmasın deyə yenidən açılmır.
 * Qeyd: native (libVLC / MediaCodec) çökmələri və sistemin yaddaş azlığından prosesi öldürməsi burada tutulmur.
 */
class App : Application() {
    @Volatile private var started = 0

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) { started++ }
            override fun onActivityStopped(activity: Activity) { if (started > 0) started-- }
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                android.util.Log.e("IPTV-CRASH", "Tutulmamış xəta (thread: ${t.name})", e)
                restartAfterCrash()
            } catch (_: Throwable) {
            }
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }

    private fun restartAfterCrash() {
        if (started <= 0) return // tətbiq fonda idi: ekrana çıxarılmır
        val prefs = getSharedPreferences("crash_guard", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last", 0L)
        prefs.edit().putLong("last", now).commit()
        if (now - last < 15_000L) return // çökmə döngüsü: yenidən açılmır
        val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(launch)
    }
}
