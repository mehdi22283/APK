package az.mehdi.iptvplayer

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.widget.TextView

/**
 * Yazının arxasında qalın qara kölgə: standart kölgə bir qat çəkildiyi üçün zəif görünür,
 * burada kölgəli mətn bir neçə dəfə üst-üstə çəkilərək sıx, qalın qara halo yaradılır.
 * Kölgə parametrləri (shadowRadius/shadowColor) layout-dan verilir.
 */
class ShadowTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = android.R.attr.textViewStyle
) : TextView(context, attrs, defStyleAttr) {

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        super.onDraw(canvas)
        super.onDraw(canvas)
        super.onDraw(canvas)
    }
}
