# IPTVPlayer — Media3 + VLC

Əsas pleyer Media3 ExoPlayer, ehtiyat pleyer libVLC-dir. Keçid avtomatikdir. Versiya: **1.15** (versionCode 16).

## Pleyer ardıcıllığı
Kanal açılmazdan əvvəl serverə qısa sorğu göndərilir ("Server yoxlanılır", 5 s). 404/403/5xx və ya qoşulma xətası alınarsa pleyerlər yoxlanmır, kanal işləmir sayılır (ehtiyat link prosesi başlaya bilər).

Sonra hər addım **5 s** olmaqla:
- **Yeni kanal:** Media3 5 s → VLC 5 s → Media3 5 s (cəmi 15 s).
- **VLC ilə yadda qalmış kanal:** VLC 5 s → Media3 5 s → VLC 5 s.
- **Bu seansda Media3 ilə artıq işləmiş kanal:** yalnız Media3 (3 × 5 s), VLC-yə keçid yoxdur.
- **rtmp, udp, srt və s.** (Media3-ün oxuya bilmədiyi protokollar): yalnız VLC (3 × 5 s).
- Hamısı açmasa "Kanal İşləmir" göstərilir.

Alt məlumat zolağında pleyer işarəsi göstərilir: 💙 Media3, 🧡 VLC. Ətraflı: `PLAYBACK_OPTIMIZATION.md`.

## Yadda saxlama
Kanal hansı pleyerlə açılıbsa (Media3 və ya VLC), tətbiq bunu yadda saxlayır (`player_memory_v3`) və növbəti dəfə əvvəl həmin pleyerlə açır. Playlist yüklənəndə siyahıda olmayan köhnə linklərin yaddaşı silinir.

## 2 GB RAM TV box
Kiçik bufer (Media3 10–20 s, 20 MB), 1080p/30 limiti, `largeHeap`, yalnız `armeabi-v7a`. libVLC lazım olanda yaradılır; Media3 işləyəndə 45 s sonra, yaddaş kritik olanda isə dərhal boşaldılır.

## Toolchain
- JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21
- compileSdk 35, targetSdk 33, minSdk 24 (Android 7.0), core library desugaring (java.time köhnə Androidlərdə də işləyir)
- Media3 1.5.1: exoplayer, hls, dash, smoothstreaming, rtsp, datasource-okhttp + okhttp 4.12.0
- VLC: `org.videolan.android:libvlc-all:3.6.0`

## Debug APK
```bash
gradle assembleDebug --no-daemon
```
Debug imza ilə qalır, amma `isDebuggable = false` (TV box-da ART tam optimallaşdırma ilə işləyir).

## TV pultu: kanal paneli
Pultda yuxarı düymə ilə açılan kanal dəyişmə paneli avtomatik vaxt bitiminə görə bağlanmır. Panel geri düyməsi ilə, toxunuşla bağlandıqda və ya kanal seçildikdə bağlanır.

## Telefon / planşet idarəetməsi (toxunma)
- Videoya **tək toxunuş**: yuxarıda kanallar siyahısı, kanal zolağı və proqram cədvəli düymələri çıxır (4 s sonra gizlənir). Alt EPG zolağı kanal dəyişəndə çıxır və 4 s sonra gizlənir.
- **İki dəfə toxunuş**: pauza / davam.
- **Sağa/sola sürüşdür**: əvvəlki / növbəti kanal.
- **Sağ yarıda yuxarı/aşağı sürüşdür**: səs; **sol yarıda**: ekran parlaqlığı.
- Kanallar siyahısı və proqram cədvəlində sağ yuxarıda ✕ düyməsi var; sistem "geri" jesti də işləyir.
- TV pultu işləməyə davam edir (pult düyməsi basılanda toxunma düymələri gizlənir).

## Playlist mənbəsi
Yalnız `m3u8.mehdimyev.workers.dev` playlisti istifadə olunur (`Data.kt` → `PLAYLIST_URL`). Keş faylı `playlist_mehdimyev.m3u`-dur; köhnə mənbədən qalan `playlist.m3u` ilk açılışda silinir. Yükləmə alınmasa təkrar cəhdlər 8 s, 20 s, 45 s, 90 s, 180 s fasilə ilə aparılır.

## Son kanal
Son izlənən kanal link, ad, qrup və tvg-id ilə saxlanılır. Playlistdə linki dəyişsə də, tətbiq yenidən açılanda kanal ad/qrup və ya tvg-id ilə tapılıb açılır.

## VLC sabitliyi
Bütün libVLC native əməliyyatları tək `vlc-ctl` thread-ində ardıcıl icra olunur; kanal sürətlə dəyişəndə yalnız sonuncu istək açılır; əvvəlki yayımın gecikmiş hadisələri ignor edilir. `App.kt`-dəki təhlükəsizlik toru tutulmayan Java/Kotlin xətasında tətbiqi avtomatik yenidən açır (15 s-də təkrar çökərsə açmır).

## EPG əl ilə əlaqələndirmə
`Epg.kt` → `EPG_ALIASES`: cbc-sport, ictimai-tv, muztv, kanal-7-hd-tr, show-hd-tr, star-tv-hd-tr, tv8-tr, tv85-tr, trt-1/2/3-hd, trt-avaz, trt-cocuk-tr, trt-haber-hd, trt-muzik-tr, trt-spor-yild-tr, trt-turk-tr, trt4k-tr, dmax-tr XML kanalları playlistdəki uyğun adlarla (hd/tr/boşluq/diakritikdən asılı olmayaraq) bağlanır. EPG-də proqram təsviri 160 simvolla məhduddur.

## Ehtiyat link (yoda.az)
Playlistdəki link Media3 və VLC ilə açılmasa, tətbiq kanalın **yoda.az** səhifəsini gizli WebView-da açır, səhifənin pleyerinin göndərdiyi tokenli `.m3u8` linkini tutur və pleyerə verir (`Backup.kt`).
- Yalnız playlistdə **"Azərbaycan"** qrupunda olan 19 kanal üçün: AZTV, MƏDƏNİYYƏT TV, İDMAN TV, BİZNES TV, BAKU TV, APA TV, REAL TV, ARB 24 HD, ARB GÜNƏŞ HD, ARB, İCTİMAİ TV, SPACE TV, ATV, XƏZƏR TV HD, DÜNYA TV HD, NAXÇIVAN TV, KANAL 35, QAFQAZ TV, EL TV. Kanal adı normallaşdırılaraq (diakritik, boşluq, sondakı HD atılır) `Backup.PAGES` cədvəli ilə uyğunlaşdırılır; Türkiyə qrupundakı eyni adlı kanallara toxunulmur.
- Token IP və User-Agent-ə bağlıdır: link bu cihazda alınır, oynatma eyni User-Agent və Referer ilə aparılır.
- Ardıcıllıq: playlist linki → pleyer ardıcıllığı (yuxarıda) → (hamısı açmasa) yoda.az-dan tokenli link → Media3/VLC. Ehtiyat link sonradan qırılsa (məs. token bitsə) link yenidən alınır (ardıcıl 3 cəhd; işləyəndə sayğac sıfırlanır).
- Ehtiyat linkdə `.m3u8` sorğusu tapılmasa 20 s sonra "Kanal İşləmir" göstərilir. Loglar: `adb logcat -s IPTV-BACKUP`.
- WebView yalnız lazım olanda yaradılır, şəkil yükləmə söndürülüb, iş bitən kimi yaddaşdan silinir; render prosesi ölərsə tətbiq çökmür. Pleyer yaddaşına tokenli link yazılmır.

### Apa TV: əvvəl yoda.az
Apa TV (`Backup.YODA_FIRST`) əksinə açılır: **yoda.az tokenli link → Media3/VLC**; link alınmasa və ya işləməsə **playlistdəki link** ehtiyat kimi açılır. yoda linki işləyib sonradan qırılsa (token bitsə) əvvəl yenilənir, alınmasa playlistə keçilir. Digər kanallar əvvəlki qaydadadır.
