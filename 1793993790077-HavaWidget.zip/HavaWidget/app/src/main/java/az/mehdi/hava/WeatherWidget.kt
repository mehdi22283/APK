package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

class WeatherWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.update(c)
        Thread {
            val j = Weather.refresh(c)
            if (j != null) { Notifs.check(c, j); WidgetUpdater.update(c) }
        }.start()
        StepService.startIfAllowed(c)
    }
}
