package az.mehdi.hava

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.*

object WidgetUpdater {
    fun km(c: Context): String {
        val p = Weather.prefs(c)
        val stride = p.getInt("height", 180) * 0.415 / 100.0
        return String.format(Locale.US, "%.2f", p.getInt("steps", 0) * stride / 1000.0)
    }

    private fun r(d: Double) = Math.round(d).toInt()

    fun update(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
        if (ids.isEmpty()) return
        val v = RemoteViews(c.packageName, R.layout.widget)
        val j = Weather.cached(c)
        if (j != null) {
            val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
            val dt = d.getJSONArray("time"); val dc = d.getJSONArray("weather_code")
            val mx = d.getJSONArray("temperature_2m_max"); val mn = d.getJSONArray("temperature_2m_min")
            val pp = d.getJSONArray("precipitation_probability_max"); val gm = d.getJSONArray("wind_gusts_10m_max")
            val code = cur.getInt("weather_code")
            v.setTextViewText(R.id.tvNow, "${r(cur.getDouble("temperature_2m"))}°")
            v.setTextViewText(R.id.tvDesc, "${Weather.icon(code)} ${Weather.desc(code)}\n↑${r(mx.getDouble(0))}° ↓${r(mn.getDouble(0))}° · 💧${pp.optInt(0)}%\n💨 ${r(cur.getDouble("wind_speed_10m"))} km/s (zərbə ${r(cur.getDouble("wind_gusts_10m"))})")
            val o = Weather.outlook(j)
            v.setTextViewText(R.id.tvAlert, o.alert)
            v.setTextViewText(R.id.tvHours, o.hours)
            v.setTextViewText(R.id.tvWarn, o.warn)
            v.setViewVisibility(R.id.tvWarn, if (o.warn.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE)
            for (k in 1..7) {
                if (k >= dt.length()) break
                fun id(s: String) = c.resources.getIdentifier("r${k}_$s", "id", c.packageName)
                v.setTextViewText(id("d"), Weather.icon(dc.getInt(k)) + (if (gm.optDouble(k) >= 60) "💨" else "") + " " + Weather.dayName(dt.getString(k), k))
                v.setTextViewText(id("t"), "${r(mx.getDouble(k))}° / ${r(mn.getDouble(k))}°")
                v.setTextViewText(id("p"), "💧${pp.optInt(k)}%")
            }
            val ts = Weather.prefs(c).getLong("ts", 0)
            v.setTextViewText(R.id.tvTime, SimpleDateFormat("HH:mm", Locale.US).format(Date(ts)))
        } else v.setTextViewText(R.id.tvAlert, "Məlumat yüklənir…")
        v.setTextViewText(R.id.tvSteps, "🚶 ${Weather.prefs(c).getInt("steps", 0)} addım")
        v.setTextViewText(R.id.tvKm, "📏 ${km(c)} km")
        v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        m.updateAppWidget(ids, v)
    }
}
