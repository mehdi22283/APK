package az.mehdi.hava

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

object Notifs {
    fun channels(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("steps", "Addımölçən", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel("hava", "Hava xəbərdarlığı", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    @Suppress("DEPRECATION")
    private fun builder(c: Context, ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, ch) else Notification.Builder(c)

    private fun open(c: Context) = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun fg(c: Context): Notification {
        val s = Weather.prefs(c).getInt("steps", 0)
        return builder(c, "steps").setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("🚶 $s addım").setContentText("📏 ${WidgetUpdater.km(c)} km")
            .setOngoing(true).setContentIntent(open(c)).build()
    }

    fun updateFg(c: Context) {
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1, fg(c))
    }

    fun check(c: Context, j: JSONObject) {
        val o = Weather.outlook(j)
        val k = o.notifKey ?: return
        val p = Weather.prefs(c)
        val type = k.substringBefore(':')
        if (p.getString("last_$type", "") == k) return
        p.edit().putString("last_$type", k).apply()
        val n = builder(c, "hava").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(if (type == "rain" || type == "temp") "Bakı havası" else "⚠️ Hava xəbərdarlığı").setContentText(o.notifText)
            .setStyle(Notification.BigTextStyle().bigText(o.notifText + "\n" + o.hours))
            .setAutoCancel(true).setContentIntent(open(c)).build()
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2 + listOf("rain", "temp", "storm", "snow", "wind").indexOf(type), n)
    }
}
