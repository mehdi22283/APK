package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceView
import androidx.media3.common.util.UnstableApi

/** Pleyer (Media3) geri çağırışları. */
interface PlayerCallback {
    fun onLoading()
    /** Yüklənmə/keçid mesajı. */
    fun onStatus(message: String) {}
    fun onPlaying()
    fun onBuffering(active: Boolean)
    fun onFailed(message: String)
    /** Media3 keyfiyyət problemini (çık-çık səs, donan görüntü) həll etmək üçün kanalın bufer səviyyəsini qaldırdı: yadda saxlanır. */
    fun onBufferLevel(level: Int) {}
    /**
     * Yayım açılmadı. true qaytarılırsa ehtiyat link prosesi (yoda.az) başladılıb,
     * pleyer xəta göstərmir; isBackup = oynadılan link artıq yoda.az-dan alınmış linkdir.
     */
    fun onStreamFailed(isBackup: Boolean): Boolean = false
    /**
     * Yayım gedir, amma görüntü statikdir (donub/dəyişmir) və ya təkrarlanır. true qaytarılırsa növbəti linkə keçid başladılıb;
     * false: növbəti link yoxdur, yayım olduğu kimi qalır. isBackup = oynadılan link yoda.az/canlitv linkidir.
     */
    fun onStaleStream(isBackup: Boolean): Boolean = false
}

/**
 * Pleyer meneceri: yalnız Media3 (ExoPlayer, OkHttp ilə). Kanal açılanda başqa yoxlama və cəhd zənciri yoxdur:
 * linki OkHttp açır (HTTP 4xx/5xx və ya qoşulma xətası → dərhal "Kanal İşləmir").
 *
 * İşləyən kanal qırılsa/donsa avtomatik yenidən qoşulur. Çık-çık səs / donan görüntü isə [Media3Engine] daxilində
 * özü-özünə həll olunur (FFmpeg səs dekoderi, daha böyük bufer, FFmpeg video) və kanal üzrə yadda saxlanır.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class PlayerManager(
    context: Context,
    private val view: SurfaceView,
    private val cb: PlayerCallback
) {
    private companion object {
        // Avtomatik bərpa: görüntü/vaxt (bufer göstərilmədən) 5 s donursa kanal yenidən qoşulur.
        // Buferlənmə zamanı pleyer ÖZÜ qaldığı yerdən davam edir (yenidən qoşulma canlı yayımın sonuna tullandırardı):
        // yalnız bufer 30 s-dən uzun dolmursa kanal yenidən qoşulur.
        const val STALL_BUFFERING_MS = 30_000L
        const val STALL_FREEZE_MS = 5_000L
        // Pleyer "oynayır" deyir, amma vaxt göstəricisi heç gəlmirsə (qara ekran/boş yayım).
        const val NO_TIME_MS = 10_000L
        const val WATCHDOG_MS = 1_000L
        const val RECONNECT_DELAY_MS = 0L
        // Əvvəl işləmiş kanalın bərpası bu müddətdən uzun çəksə yüklənmə göstəricisi çıxır; qısa bərpa görünmür.
        const val SILENT_RECOVERY_MS = 3_500L
        const val RETRY_ALL_DELAY_MS = 2_000L
        // Ağıllı bufer: 2 dəqiqədə 3 buferlənmə → səviyyə +1; 20 dəqiqə buferlənmə yoxdursa → səviyyə -1.
        const val STALL_WINDOW_MS = 120_000L
        const val STALLS_TO_RAISE = 3
        const val CALM_LOWER_MS = 20 * 60_000L
    }

    private val ui = Handler(Looper.getMainLooper())
    private var url: String? = null
    private var ua: String? = null
    private var ref: String? = null
    // true: oynadılan link yoda.az ehtiyat linkidir (tokenlidir)
    private var usingBackup = false
    private var resume = false
    private var released = false
    private var playedOk = false
    private var everPlayed = false
    private var reconnecting = false
    private var userPaused = false
    private var bufferingSince = 0L
    private var lastPos = -1L
    private var lastPosAt = 0L
    // Kanal başına ağıllı bufer.
    private val bufMemory = BufferMemory(context)
    private var bufLevel = 0
    private val stallTimes = ArrayDeque<Long>()
    private var lastStallAt = 0L

    private val watchdogRun: Runnable = object : Runnable {
        override fun run() {
            if (released || url == null || !playedOk) return
            val now = SystemClock.elapsedRealtime()
            var stalled = false
            var frozen = false
            // Uzun müddət buferlənmədən işləyən kanalın bufer səviyyəsi bir pillə azalır (növbəti açılışdan tətbiq olunur).
            if (bufLevel > 0 && bufferingSince == 0L && now - lastStallAt >= CALM_LOWER_MS) {
                lastStallAt = now
                setBufLevel(bufLevel - 1)
            }
            if (!userPaused) {
                if (bufferingSince != 0L) {
                    // Buferlənmə gedir: vaxtın donması normaldır, yenidən qoşulmur; pleyer qaldığı yerdən davam edəcək.
                    lastPosAt = now
                    if (now - bufferingSince >= STALL_BUFFERING_MS) stalled = true
                } else {
                    val p = exo.position()
                    if (p > 0) {
                        if (p != lastPos) { lastPos = p; lastPosAt = now }
                        else if (now - lastPosAt >= STALL_FREEZE_MS) { stalled = true; frozen = true }
                    } else if (now - lastPosAt > NO_TIME_MS) {
                        // "Oynayır" dedi, amma vaxt heç irəliləmir: yenidən qoşulur.
                        stalled = true; frozen = true
                    }
                }
            }
            if (stalled) { if (frozen) exo.onFrozen(); reconnect("Yayım donub"); return }
            ui.postDelayed(this, WATCHDOG_MS)
        }
    }
    // Statik / təkrarlanan görüntü: tapılanda növbəti linkə (yoda.az/canlitv/playlist) dərhal keçilir.
    private val stale: StaleDetector = StaleDetector(
        view, ui,
        canSample = { !released && url != null && playedOk && !userPaused && !reconnecting && bufferingSince == 0L },
        onStale = { reason -> onStaleDetected(reason) }
    )

    private fun onStaleDetected(reason: String) {
        if (released || url == null) return
        android.util.Log.w("IPTV-PLAYER", "Statik/təkrar görüntü ($reason) → növbəti link")
        stale.stop()
        cb.onStaleStream(usingBackup)
    }

    private val slowRecoveryRun: Runnable = Runnable { if (!released && url != null && reconnecting) cb.onLoading() }
    private val restartRun: Runnable = Runnable {
        if (released || url == null) return@Runnable
        reconnecting = false
        startExo(retry = true)
    }
    private val retryAllRun: Runnable = Runnable {
        if (released || url == null) return@Runnable
        reconnecting = false
        begin()
    }

    /** Buferlənmə başladı: tez-tez təkrarlanırsa kanalın bufer səviyyəsi qalxır. */
    private fun noteStall() {
        val now = SystemClock.elapsedRealtime()
        lastStallAt = now
        stallTimes.addLast(now)
        while (stallTimes.isNotEmpty() && now - stallTimes.first() > STALL_WINDOW_MS) stallTimes.removeFirst()
        if (stallTimes.size >= STALLS_TO_RAISE && bufLevel < BufferProfile.MAX_LEVEL) {
            stallTimes.clear()
            setBufLevel(bufLevel + 1)
        }
    }

    /** Bufer səviyyəsini dəyişir və yadda saxlayır. Növbəti (təkrar) açılışdan tətbiq olunur. */
    private fun setBufLevel(level: Int) {
        val l = level.coerceIn(0, BufferProfile.MAX_LEVEL)
        if (l == bufLevel) return
        android.util.Log.i("IPTV-PLAYER", "Bufer səviyyəsi $bufLevel → $l")
        bufLevel = l
        if (!usingBackup) url?.let { bufMemory.set(it, l) }
    }

    private val exo: Media3Engine = Media3Engine(context, view, object : PlayerCallback {
        override fun onLoading() {}
        override fun onPlaying() {
            if (released || url == null) return
            playedOk = true
            everPlayed = true
            reconnecting = false
            bufferingSince = 0L
            lastPos = -1L
            lastPosAt = SystemClock.elapsedRealtime()
            ui.removeCallbacks(watchdogRun)
            ui.postDelayed(watchdogRun, WATCHDOG_MS)
            stale.start()
            cb.onPlaying()
        }
        override fun onBuffering(active: Boolean) {
            if (released || url == null) return
            if (active) {
                if (bufferingSince == 0L) { bufferingSince = SystemClock.elapsedRealtime(); noteStall() }
            } else bufferingSince = 0L
            cb.onBuffering(active)
        }
        override fun onFailed(message: String) {
            if (released || url == null || reconnecting) return
            // Yayım əvvəl işləyibsə (sonra qırılıbsa) yenidən qoşulur; ilk açılışda isə kanal işləmir.
            if (playedOk) reconnect(message) else failAll(message)
        }
        override fun onBufferLevel(level: Int) {
            if (released || url == null) return
            setBufLevel(level)
        }
    })

    private fun startExo(retry: Boolean = false) {
        val u = url ?: return
        // Əvvəl işləmiş kanalın təkrar cəhdində yükləmə paneli dərhal çıxmır: son kadr ekranda qalır, bərpa fonda gedir.
        if (!(retry && everPlayed)) cb.onStatus(if (retry || reconnecting) "Təkrar cəhd edilir" else "Yüklənir")
        playedOk = false
        exo.play(u, ua, ref, bufLevel, persist = !usingBackup)
    }

    fun play(newUrl: String, newUa: String? = null, newRef: String? = null, backup: Boolean = false) {
        if (released) return
        url = newUrl; ua = newUa; ref = newRef
        usingBackup = backup
        resume = false
        playedOk = false
        everPlayed = false
        reconnecting = false
        userPaused = false
        bufferingSince = 0L
        // Kanalın yadda saxlanmış bufer səviyyəsi (ehtiyat tokenli link üçün həmişə 0).
        bufLevel = if (backup) 0 else bufMemory.level(newUrl)
        stallTimes.clear()
        lastStallAt = SystemClock.elapsedRealtime()
        cancelRecovery()
        exo.stop()
        cb.onLoading()
        begin()
    }

    /**
     * Oynayan yayımı dayandırmadan linki (tokeni) dəyişir: son kadr ekranda qalır, keçid sakit gedir
     * (yüklənmə paneli yalnız uzun çəkəndə görünür). Yayım oynamırsa heç nə etmir.
     */
    fun swapLink(newUrl: String, newUa: String?, newRef: String?) {
        if (released || url == null || !everPlayed) return
        url = newUrl; ua = newUa; ref = newRef
        usingBackup = true
        reconnecting = false
        reconnect("Link (token) fonda yeniləndi")
    }

    /** Açılış: yalnız Media3 (OkHttp). Xəta olarsa kanal işləmir (ehtiyat link və ya "Kanal İşləmir"). */
    private fun begin() {
        if (url == null) return
        startExo()
    }

    private fun failAll(message: String) {
        android.util.Log.w("IPTV-PLAYER", "Kanal açılmadı: $message")
        exo.stop()
        // Əsas link işləmir: ehtiyat link (yoda.az) prosesi başladılırsa xəta göstərilmir.
        if (!released && url != null && cb.onStreamFailed(usingBackup)) return
        if (everPlayed) {
            // Kanal əvvəl işləyib: server müvəqqəti düşübsə, avtomatik təkrar yoxlanılır.
            cb.onLoading()
            cb.onStatus("Kanal cavab vermir — yenidən yoxlanılır")
            ui.removeCallbacks(retryAllRun)
            ui.postDelayed(retryAllRun, RETRY_ALL_DELAY_MS)
        } else {
            cb.onFailed("Kanal İşləmir")
        }
    }

    private fun cancelRecovery() {
        stale.stop()
        ui.removeCallbacks(watchdogRun)
        ui.removeCallbacks(restartRun)
        ui.removeCallbacks(retryAllRun)
        ui.removeCallbacks(slowRecoveryRun)
    }

    /** Yayım işləyərkən qırılıb/donub: kanalı avtomatik yenidən qoşur. */
    private fun reconnect(reason: String) {
        if (released || url == null || reconnecting) return
        android.util.Log.w("IPTV-PLAYER", "Yenidən qoşulma: $reason")
        if (!everPlayed) cb.onStatus("Təkrar cəhd edilir")
        reconnecting = true
        playedOk = false
        bufferingSince = 0L
        stale.reset()
        ui.removeCallbacks(watchdogRun)
        // Əvvəl oynamış kanalın bərpası sakit gedir: son kadr ekranda qalır, yüklənmə yalnız uzun çəkəndə görünür.
        ui.removeCallbacks(slowRecoveryRun)
        if (everPlayed) ui.postDelayed(slowRecoveryRun, SILENT_RECOVERY_MS) else cb.onLoading()
        // Heç nə gözlənmir: təkrar cəhd dərhal (eyni döngədə) başlayır.
        ui.removeCallbacks(restartRun)
        if (RECONNECT_DELAY_MS <= 0L) ui.post(restartRun) else ui.postDelayed(restartRun, RECONNECT_DELAY_MS)
    }

    fun attach() {
        if (released) return
        val u = url
        if (resume && u != null) play(u, ua, ref, usingBackup)
    }

    /** Yayımı tam dayandırır (yoda.az linki gözlənərkən köhnə kanal səsi/şəkli qalmasın). */
    fun halt() {
        if (released) return
        cancelRecovery()
        exo.stop()
        url = null
        resume = false
        playedOk = false
        everPlayed = false
        reconnecting = false
    }

    fun stopForBackground() {
        if (released) return
        resume = url != null
        cancelRecovery()
        exo.stopForBackground()
    }

    fun isPaused(): Boolean = userPaused

    fun hasUrl(): Boolean = url != null

    fun togglePause() {
        userPaused = !userPaused
        if (userPaused) ui.removeCallbacks(watchdogRun)
        else { lastPosAt = SystemClock.elapsedRealtime(); lastPos = -1L; bufferingSince = 0L; if (playedOk) ui.postDelayed(watchdogRun, WATCHDOG_MS) }
        exo.togglePause()
    }

    fun stats(): PlayerStats? {
        val s = exo.stats() ?: return null
        return PlayerStats(s.width, s.height, s.bufferMs, s.level, s.bps, "", s.bitrate, s.videoTag)
    }

    fun release() {
        if (released) return
        released = true
        cancelRecovery()
        stale.release()
        exo.release()
    }
}
