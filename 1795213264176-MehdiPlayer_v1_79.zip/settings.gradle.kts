pluginManagement {
    repositories {
        google()
        // Maven Central-ın Google güzgüsü: GitHub Actions-da repo.maven.apache.org 429 (Too Many Requests) verəndə ehtiyat.
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositories {
        google()
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
    }
}
rootProject.name = "IPTVPlayer"
include(":app")
