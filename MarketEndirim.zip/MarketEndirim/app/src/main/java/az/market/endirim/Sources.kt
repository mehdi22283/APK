package az.market.endirim

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Sources {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun get(url: String): Document =
        Jsoup.connect(url).userAgent(UA).timeout(25_000).followRedirects(true).maxBodySize(0).get()

    // ---------- Bravo: special-offers səhifəsindəki ƏN ÜSTDƏKİ (ilk) slayd → mənbə koddakı publuu.com linki ----------
    suspend fun bravo(): List<Catalog> = withContext(Dispatchers.IO) {
        val base = "https://bravosupermarket.az/special-offers/"
        // https://publuu.com/... (həm adi, həm də JSON-da \/ ilə yazılmış formada)
        val publuu = Regex("""https?:(?://|\\?/\\?/)publuu\.com[^"'\s<>)\\]*""")
        val list = get(base)
        // ilk slayd: /special-offers/<ad>/ formalı ilk link (leaflet-1, made-in-azerbaijan-5 və s. — ada baxmır)
        val first = list.select("a[href]").firstOrNull { a ->
            val u = a.absUrl("href").substringBefore('#').substringBefore('?').trimEnd('/')
            u.startsWith(base.trimEnd('/') + "/") && u.length > base.length - 1 &&
                !u.removePrefix(base.trimEnd('/') + "/").contains('/')
        } ?: throw IllegalStateException("Slayd linki tapılmadı")
        val pageUrl = first.absUrl("href")
        val page = get(pageUrl)
        val raw = page.html()
        val link = (publuu.find(raw)?.value
            ?: page.select("iframe[src*=publuu], a[href*=publuu], [data-src*=publuu]").firstOrNull()
                ?.let { it.absUrl("src").ifEmpty { it.absUrl("href") }.ifEmpty { it.attr("data-src") } }
                ?.ifEmpty { null })
            ?.replace("\\/", "/")?.replace("\\", "")
            ?: throw IllegalStateException("Publuu linki tapılmadı")
        val title = page.selectFirst("h1")?.text()?.trim()?.ifEmpty { null } ?: "Bravo kataloqu"
        val date = DateUtil.find(page.body().text()) ?: DateUtil.find(list.body().text())
        listOf(
            Catalog("Bravo Market", title, date, Kind.WEB, listOf(link), "Veb-jurnal")
        )
    }

    // ---------- Araz: səhifədə PDF + tarix ----------
    suspend fun araz(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://www.arazmarket.az/az/discount-magazine")
        val links = doc.select("a[href*=.pdf]").toList().filter { it.absUrl("href").isNotEmpty() }
        if (links.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        val seen = HashSet<String>()
        links.mapNotNull { a ->
            val url = a.absUrl("href")
            if (!seen.add(url)) return@mapNotNull null
            val date = dateAround(a) ?: DateUtil.find(doc.body().text())
            Catalog("Araz Market", "Endirim jurnalı", date, Kind.PDF, listOf(url), "PDF")
        }
    }

    // ---------- Oba: səhifədəki bütün PDF-lər, tarix PDF-dən OCR ilə oxunur (Tamstore məntiqi) ----------
    suspend fun oba(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://oba.az/endirim-jurnali/")
        // sıra ilə: h2 başlıq → ondan sonrakı "Jurnalı yüklə" PDF linki
        val found = LinkedHashMap<String, String>()
        var lastTitle = ""
        doc.select("h2, a[href*=.pdf]").forEach { el ->
            if (el.tagName() == "h2") {
                lastTitle = el.text().trim()
            } else {
                val u = el.absUrl("href")
                if (u.isNotEmpty() && !found.containsKey(u)) found[u] = lastTitle
            }
        }
        Regex("""https?://[^"'\s)<>]+\.pdf""").findAll(doc.html()).forEach {
            if (it.value.contains("oba.az")) found.putIfAbsent(it.value, "")
        }
        // "SOBA dadı" jurnalı siyahıya düşmür
        found.entries.removeAll { (u, t) ->
            (t + " " + u).lowercase().let { it.contains("soba") }
        }
        if (found.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        found.entries.mapIndexed { i, (u, t) ->
            // tarix PDF-dən OCR ilə oxunacaq (MainActivity)
            Catalog("Oba Market", t.ifEmpty { "Endirim jurnalı ${i + 1}" }, null, Kind.PDF, listOf(u), "PDF")
        }
    }

    private fun dateAround(el: Element): String? {
        var cur: Element? = el
        repeat(5) {
            cur = cur?.parent()
            val d = cur?.text()?.let { DateUtil.find(it) }
            if (d != null) return d
        }
        return null
    }

    // ---------- Rahat: iki PDF, tarix fayl adından ----------
    suspend fun rahat(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://rahatmarket.az/az/aksiyalar/rahat-market")
        val urls = doc.select("a[href*=.pdf]").map { it.absUrl("href") }.filter { it.isNotEmpty() }.distinct()
        if (urls.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        urls.mapIndexed { i, u ->
            val name = u.substringAfterLast('/').substringBefore(".pdf")
            Catalog("Rahat Market", "Jurnal ${i + 1}", DateUtil.fromFileName(name), Kind.PDF, listOf(u), "PDF")
        }
    }

    // ---------- Tamstore: "Elektron jurnal" bölməsindəki bütün PDF-lər ----------
    suspend fun tamstore(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://www.tamstore.az/az/kampaniyalar")
        val urls = LinkedHashSet<String>()
        doc.select("a[href*=.pdf]").forEach { val u = it.absUrl("href"); if (u.isNotEmpty()) urls.add(u) }
        Regex("""https?://[^"'\s)<>]+\.pdf""").findAll(doc.html()).forEach {
            if (it.value.contains("tamstore.az")) urls.add(it.value)
        }
        if (urls.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.US)
        val sorted = urls.sortedByDescending { ts(it) }
        // siyahının sonundakı (ən köhnə) 2 PDF atılır
        val kept = if (sorted.size > 2) sorted.dropLast(2) else sorted
        kept.mapIndexed { i, u ->
            val t = ts(u)
            val note = if (t > 0) "Yüklənib: " + fmt.format(Date(t * 1000)) else null
            // tarix PDF-dən OCR ilə oxunacaq (MainActivity)
            Catalog("Tamstore", "Elektron jurnal ${i + 1}", null, Kind.PDF, listOf(u), note)
        }
    }

    private fun ts(u: String): Long = u.substringAfterLast('/').substringBefore('-').toLongOrNull() ?: 0L

    // ---------- Al Market: Telegram kanalından son albom ----------
    private data class Msg(val id: Int, val time: String, val text: String, val photos: List<String>)

    private val bgUrl = Regex("""url\(['"]?([^'")]+)""")

    private fun parseMsg(el: Element): Msg? {
        val post = el.selectFirst(".tgme_widget_message")?.attr("data-post") ?: return null
        val id = post.substringAfterLast('/').toIntOrNull() ?: return null
        val time = el.selectFirst(".tgme_widget_message_date time")?.attr("datetime") ?: ""
        val text = el.selectFirst(".tgme_widget_message_text")?.text() ?: ""
        val photos = el.select(".tgme_widget_message_photo_wrap")
            .mapNotNull { bgUrl.find(it.attr("style"))?.groupValues?.get(1) }
        return Msg(id, time, text, photos)
    }

    suspend fun al(): List<Catalog> = withContext(Dispatchers.IO) {
        val all = ArrayList<Msg>()
        var url = "https://t.me/s/almarketler"
        for (page in 0 until 3) {
            val msgs = get(url).select(".tgme_widget_message_wrap").mapNotNull { parseMsg(it) }
            if (msgs.isEmpty()) break
            all.addAll(0, msgs)
            url = "https://t.me/s/almarketler?before=" + msgs.first().id
        }
        // eyni dəqiqədə paylaşılan ardıcıl şəkilli mesajlar = bir albom
        val groups = ArrayList<MutableList<Msg>>()
        for (m in all) {
            if (m.photos.isEmpty()) continue
            val last = groups.lastOrNull()
            if (last != null && last.last().time.take(16) == m.time.take(16)) last.add(m) else groups.add(mutableListOf(m))
        }
        val kw = Regex("kataloq|endirim|aksiya|kampaniya", RegexOption.IGNORE_CASE)
        val pick = groups.lastOrNull { g -> kw.containsMatchIn(g.joinToString(" ") { it.text }) }
            ?: groups.lastOrNull { g -> g.sumOf { it.photos.size } >= 5 }
            ?: throw IllegalStateException("Kataloq paylaşımı tapılmadı")
        val photos = pick.flatMap { it.photos }
        val text = pick.joinToString(" ") { it.text }
        listOf(Catalog("Al Market", "Kataloq", DateUtil.find(text), Kind.IMAGES, photos, "${photos.size} şəkil"))
    }
}
