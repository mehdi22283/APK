package az.mehdi.hava

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Yağıntı radarı: RainViewer (açar lazım deyil) — son 2 saatın radar kadrları, Bakı mərkəzdə.
 * Xəritə: CARTO dark (OpenStreetMap məlumatı). Heç bir xarici kitabxana yoxdur, xəritəni özümüz çəkirik.
 */
class RadarActivity : Activity() {
    private lateinit var web: WebView
    private val BG = Color.parseColor("#0F1B2A")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        web = WebView(this)
        web.setBackgroundColor(BG)
        web.settings.javaScriptEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = true
        }
        setContentView(web)
        show(page("[]", "", "Radar yüklənir…"))
        Thread {
            val html = try {
                val con = URL("https://api.rainviewer.com/public/weather-maps.json").openConnection() as HttpURLConnection
                con.connectTimeout = 15000
                con.readTimeout = 15000
                val s = con.inputStream.bufferedReader().use { r -> r.readText() }
                val o = JSONObject(s)
                val host = o.getString("host")
                val past = o.getJSONObject("radar").getJSONArray("past")
                val arr = JSONArray()
                for (i in 0 until past.length()) {
                    val f = past.getJSONObject(i)
                    arr.put(JSONObject().put("t", f.getLong("time")).put("p", f.getString("path")))
                }
                if (arr.length() == 0) page("[]", host, "Radar məlumatı yoxdur") else page(arr.toString(), host, "")
            } catch (e: Exception) {
                page("[]", "", "İnternet yoxdur və ya radar xidməti cavab vermir")
            }
            runOnUiThread { show(html) }
        }.start()
    }

    private fun show(html: String) {
        web.loadDataWithBaseURL("https://hava.local/", html, "text/html", "utf-8", null)
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    private fun page(frames: String, host: String, msg: String): String = """
<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
html,body{margin:0;height:100%;background:#0F1B2A;color:#fff;font-family:sans-serif;overflow:hidden;touch-action:none}
#top{position:absolute;top:0;left:0;right:0;z-index:5;padding:10px 14px;background:linear-gradient(#0F1B2Aee,#0F1B2A00);font-size:16px;font-weight:bold}
#time{font-size:13px;color:#FFD54F;margin-top:2px}
#map{position:absolute;inset:0;overflow:hidden}
#layer{position:absolute;left:0;top:0;width:100%;height:100%}
.t{position:absolute;width:256px;height:256px;user-select:none;-webkit-user-drag:none;pointer-events:none}
.r{opacity:.75}
#me{position:absolute;width:14px;height:14px;margin:-9px 0 0 -9px;border-radius:50%;background:#FF5252;border:2px solid #fff;z-index:3;pointer-events:none}
#ctl{position:absolute;left:0;right:0;bottom:0;z-index:5;padding:8px 12px 22px;background:linear-gradient(#0F1B2A00,#0F1B2Aee)}
#row{display:flex;align-items:center;gap:10px}
button{background:#1B2B3F;color:#fff;border:1px solid #4FC3F7;border-radius:10px;font-size:20px;min-width:44px;height:44px}
input[type=range]{flex:1}
#zoom{position:absolute;right:10px;top:70px;z-index:5;display:flex;flex-direction:column;gap:8px}
#att{font-size:10px;color:#90A4AE;margin-top:6px}
#msg{position:absolute;left:0;right:0;top:45%;text-align:center;z-index:6;font-size:16px;color:#FFD54F;padding:0 24px}
</style></head><body>
<div id="top">Yağıntı radarı · Bakı<div id="time"></div></div>
<div id="map"><div id="layer"></div><div id="me"></div></div>
<div id="zoom"><button id="zin">+</button><button id="zout">−</button><button id="home">◎</button></div>
<div id="msg">$msg</div>
<div id="ctl"><div id="row"><button id="play">▶</button><input id="sl" type="range" min="0" max="0" value="0"></div>
<div id="att">Rəng nə qədər tünddürsə, yağış o qədər güclüdür · Radar: RainViewer (rainviewer.com) · Xəritə: © OpenStreetMap, © CARTO</div></div>
<script>
var frames=$frames, host="$host", LAT=40.427565, LON=49.822425, ZMIN=4, ZMAX=7;
var z=6, cx=0, cy=0, idx=Math.max(0,frames.length-1), timer=null;
var map=document.getElementById('map'), layer=document.getElementById('layer'), me=document.getElementById('me');
function wx(lon,zz){return (lon+180)/360*Math.pow(2,zz)*256}
function wy(lat,zz){var s=Math.sin(lat*Math.PI/180);return (0.5-Math.log((1+s)/(1-s))/(4*Math.PI))*Math.pow(2,zz)*256}
function home(){cx=wx(LON,z);cy=wy(LAT,z);render()}
function label(){
  if(!frames.length){document.getElementById('time').textContent='';return}
  var t=frames[idx].t, d=new Date((t+4*3600)*1000);
  var hh=('0'+d.getUTCHours()).slice(-2)+':'+('0'+d.getUTCMinutes()).slice(-2);
  var ago=Math.round((Date.now()/1000-t)/60);
  document.getElementById('time').textContent=hh+' (Bakı vaxtı) · '+(ago<=1?'indi':ago+' dəq əvvəl');
}
function render(){
  var w=map.clientWidth,h=map.clientHeight,n=Math.pow(2,z);
  var x0=Math.floor((cx-w/2)/256),x1=Math.floor((cx+w/2)/256),y0=Math.floor((cy-h/2)/256),y1=Math.floor((cy+h/2)/256);
  var html='',sub=['a','b','c','d'],k=0;
  for(var y=y0;y<=y1;y++){ if(y<0||y>=n)continue;
    for(var x=x0;x<=x1;x++){ var xm=((x%n)+n)%n, l=Math.round(x*256-(cx-w/2)), t=Math.round(y*256-(cy-h/2));
      html+='<img class="t" style="left:'+l+'px;top:'+t+'px" src="https://'+sub[(k++)%4]+'.basemaps.cartocdn.com/dark_all/'+z+'/'+xm+'/'+y+'.png">';
      if(frames.length&&host){ html+='<img class="t r" style="left:'+l+'px;top:'+t+'px" src="'+host+frames[idx].p+'/256/'+z+'/'+xm+'/'+y+'/2/1_1.png">'; }
    } }
  layer.innerHTML=html; layer.style.transform='translate(0,0)';
  me.style.left=Math.round(wx(LON,z)-(cx-w/2))+'px'; me.style.top=Math.round(wy(LAT,z)-(cy-h/2))+'px';
  label();
}
function zoom(d){var nz=z+d; if(nz<ZMIN||nz>ZMAX)return; var f=Math.pow(2,d); z=nz; cx*=f; cy*=f; render()}
var sx=0,sy=0,drag=false;
map.addEventListener('pointerdown',function(e){drag=true;sx=e.clientX;sy=e.clientY;map.setPointerCapture(e.pointerId)});
map.addEventListener('pointermove',function(e){if(!drag)return;var dx=e.clientX-sx,dy=e.clientY-sy;layer.style.transform='translate('+dx+'px,'+dy+'px)';me.style.transform='translate('+dx+'px,'+dy+'px)'});
map.addEventListener('pointerup',function(e){if(!drag)return;drag=false;cx-=e.clientX-sx;cy-=e.clientY-sy;me.style.transform='';render()});
document.getElementById('zin').onclick=function(){zoom(1)};
document.getElementById('zout').onclick=function(){zoom(-1)};
document.getElementById('home').onclick=home;
var sl=document.getElementById('sl'), pb=document.getElementById('play');
sl.max=Math.max(0,frames.length-1); sl.value=idx;
sl.oninput=function(){idx=parseInt(sl.value);render()};
function step(){idx=(idx+1)%frames.length; sl.value=idx; render()}
function stop(){if(timer){clearInterval(timer);timer=null}pb.textContent='\u25B6'}
pb.onclick=function(){
  if(timer){stop();return}
  if(!frames.length)return;
  pb.textContent='\u23F8'; if(idx===frames.length-1){idx=0;sl.value=0;render()}
  timer=setInterval(step,700);
};
document.getElementById('msg').style.display='${if (msg.isEmpty()) "none" else "block"}';
home();
</script></body></html>
"""
}
