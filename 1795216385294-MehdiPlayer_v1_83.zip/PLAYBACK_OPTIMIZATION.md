# Oynatma konfiqurasiyası (2 GB RAM TV box) — Media3

## Açılış
Pleyer yalnız Media3-dür. Link OkHttp ilə açılır; açılmazdan əvvəl HTTP 4xx/5xx cavabı alınarsa təkrar cəhd olmadan dərhal xəta verilir (`FastFailPolicy`). OkHttp vaxtları: qoşulma 5 s, oxuma 6 s. Ayrıca vaxt aşımı sayğacı və geri sayım yoxdur; yüklənmə zamanı yalnız status mətni və nöqtələr göstərilir.

| Vəziyyət | Davranış |
|---|---|
| Yeni kanal | Media3 bir dəfə açır; xəta olarsa ehtiyat link (yoda.az) və ya "Kanal İşləmir" |
| İşləyən kanal qırılıb/donub | avtomatik yenidən qoşulma (dərhal) |
| Əvvəl işləmiş kanal, açılmasa | xəta göstərilmir, hər 2 s-dən bir avtomatik təkrar yoxlanılır |
| Codec heç bir dekoderdə dəstəklənmir | "Kanal İşləmir" |

Qeyd: Media3 rtsp/rtmp/srt açmır (bu modullar əlavə edilməyib); udp:// `DefaultDataSource` ilə cəhd olunur.

## Çık-çık səs / donan görüntü (özü həll edir)
`Media3Engine` `AnalyticsListener` ilə izləyir: səs underrun (AudioTrack boşalır) və atılmış video kadrlar. Oynamağa başladıqdan 4 s sonra, 10 s pəncərədə 3 underrun və ya cəmi 60 atılmış kadr olarsa kanal problemli sayılır (`UNDERRUN_LIMIT`, `DROPPED_FRAMES_LIMIT`, `QUALITY_WINDOW_MS`, `QUALITY_GRACE_MS`).

Düzəliş addımları (hər biri kanalı yenidən açır, ən çox `MAX_HEALS` = 3):
1. Səs problemidirsə və rejim NORMAL isə: səs FFmpeg dekoderi ilə, video MediaCodec ilə (`AUDIO_FFMPEG`).
2. Kanalın bufer səviyyəsi +1 (`BufferMemory`-də saxlanır).
3. Səs və video FFmpeg dekoderləri əvvəl (`ALL_FFMPEG`).

Video problemidirsə (atılan kadrlar) 1-ci addım atlanır. Kanalın düzgün açıldığı rejim `DecoderMemory`-də (`decoder_memory_v1`) saxlanır, kanal növbəti dəfə birbaşa həmin rejimlə başlayır. Dekoder açılmasa/dekodlama xətası olsa kanal bir dəfə `ALL_FFMPEG` ilə təkrar açılır.

## Media3 codec-ləri
- **Renderer-lər:** `ModeRenderersFactory` (`NextRenderersFactory`): NORMAL = MediaCodec əvvəl, çatışmasa FFmpeg; AUDIO_FFMPEG = səs üçün FFmpeg əvvəl; ALL_FFMPEG = səs və video üçün FFmpeg əvvəl.
- **MPEG-TS:** `FLAG_DETECT_ACCESS_UNITS`, `FLAG_ALLOW_NON_IDR_KEYFRAMES`, `FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS` (HLS və düz .ts).
- Canlı yayımda yetişmə sürətləndirməsi söndürülüb (`min/maxPlaybackSpeed = 1`). HLS-də köhnə seqmentlər silinibsə (`BEHIND_LIVE_WINDOW`) canlı yerə keçilir.

## Avtomatik bərpa (`PlayerManager`)
- Watchdog hər 1 s yoxlayır; istifadəçi pauza edibsə bərpa işləmir.
- Buferlənmə zamanı kanal yenidən qoşulmur, pleyer qaldığı yerdən davam edir; bufer 30 s-dən uzun dolmursa və ya görüntü 5 s donursa yenidən qoşulur.

## Ağıllı bufer (kanal başına)
`BufferMemory.kt` → `BufferProfile`:

| Səviyyə | Başlama | Buferlənmədən sonra davam |
|---|---|---|
| 0 (normal) | 1 s | 2,5 s |
| 1 (orta) | 2 s | 6 s |
| 2 (böyük) | 3 s | 12 s |

Kanal 2 dəqiqədə 3 dəfə buferlənərsə səviyyə +1 olur və kanal linki üzrə saxlanır; 20 dəqiqə buferlənmədən işləyərsə −1. Keyfiyyət düzəlişi də səviyyəni qaldıra bilər. Yeni səviyyə növbəti açılışdan tətbiq olunur. Ehtiyat (yoda.az tokenli) linklərdə səviyyə və rejim saxlanmır.

## Playlist linki dəyişəndə
İzlənən kanalın linki yeni playlistdə dəyişibsə, kanal yeni linklə avtomatik yenidən açılır. Son kanal link, ad, qrup və tvg-id ilə saxlanılır.

## v1.35 — MP2 səsi, donma və qırılma
- MP2/MP1 səsli kanal: MediaCodec əvəzinə səs FFmpeg dekoderi ilə açılır (kanal üzrə yadda qalır).
- Səs dekoder/AudioTrack xətası → özünü düzəltmə zənciri işə düşür.
- Video donması (səs gedir, kadr çəkilmir, 5 s): dekoder yenidən açılır → bufer ↑ → (TV deyilsə) FFmpeg video.
- Yayımın vaxtı 2 dəqiqədə 2 dəfə donarsa: səs FFmpeg-ə (passthrough yoxdursa) və ya bufer ↑.
- Yayım işləyərkən yükləmə xətasında 6 təkrar cəhd (qısa şəbəkə kəsilməsi kanalı yenidən qoşmur).

## v1.81 — SW keçidi
- Kanal 3 s-dən uzun buferlənmə 1 dəqiqədə 2 dəfə olarsa səs+video FFmpeg (SW) ilə açılır (`LONG_BUFFER_*`).
- Kanal 10 s-də açılmazsa (`OPEN_TIMEOUT_MS`) SW ilə açılır. Treklər məlum olanda video codec-i cihazın hardware dekoderində, səs codec-i cihaz dekoderində dəstəklənirsə (`CodecSupport`) əvvəlki HW rejiminə qayıdılır; bu kanalda təkrar SW-ə keçilmir (`hwReturned`).
- SW rejimində uğurla oynayan kanalın rejimi `DecoderMemory`-də saxlanır.
- Təkrarlanan görüntü (loop): sübut müddəti 5 s (`MIN_PROOF`), dövr uzunluğu 2–10 s (`MAX_LAG`). Statik görüntü: 6 miniatür ≈ 5 s (`STATIC_SAMPLES`). Tapılanda növbəti linkə keçilir.

## v1.83 — Əsas link ↔ ehtiyat link
- Playlist (əsas) link açılmayanda / statik-loop olanda ehtiyat linkə (yoda.az → canlitv.com) keçiləndə bu `LinkCache`-də `mainbad:<md5>` kimi yazılır (30 dəq, ehtiyat linkin tokeni qədər).
- Kanal növbəti dəfə açılanda işarə və keşdə ehtiyat link varsa, kanal birbaşa ehtiyat linklə açılır (5 s gözləmə yoxdur).
- Ehtiyat link oynayanda əsas link fonda `MainLinkProbe` ilə 10 s yoxlanır (OkHttp; pleyer/dekoder istifadə olunmur): düz axında fasiləsiz bayt axını, HLS-də playlist irəliləməsi + seqment yüklənməsi. Uğursuzdursa 60 s-dən bir təkrar.
- Yoxlama uğurlu olanda yayım dayanmadan əsas linkə qayıdılır (`swapLink`), keşdəki işarə silinir. Əsas link açılmasa 5 s-dən sonra yenə ehtiyata keçilir.
- Qayıdışdan 2 dəqiqə ərzində yenə ehtiyata keçilərsə yoxlama aralığı ikiqat artır (maks. 10 dəq).
- Qeyd: yoxlama şəbəkə səviyyəlidir; əsas linkin məzmun loop-u/statik olması bu yolla tapılmır, belə hal qayıdışdan sonra `StaleDetector` ilə yenə tapılıb ehtiyata keçilir.
