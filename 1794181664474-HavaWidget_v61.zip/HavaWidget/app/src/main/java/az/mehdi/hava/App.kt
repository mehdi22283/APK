package az.mehdi.hava

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ScreenReceiver.register(this)
    }
}
