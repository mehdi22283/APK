package az.mehdi.hava

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Şarja taxılan kimi vidcetdəki "⚡ şarj dəqiqəsi" bir dəfə yenilənir (periodik yeniləmə YOXDUR).
 * Sonrakı yeniləmələr ekran açılanda / kilid açılanda gəlir (bax: ScreenReceiver).
 * "Yalnız şarjdadırsa" şərtli WorkManager işi istifadə olunur: ACTION_POWER_CONNECTED manifestdə işləmir (Android 8+).
 */
object ChargeWatch {
    private const val ON = "charge_on"
    private const val CHECK = "charge_check"

    /** Növbəti şarja taxılmanı gözləyir (artıq gözləyirsə toxunmur) */
    fun arm(c: Context) {
        try {
            val req = OneTimeWorkRequestBuilder<ChargeOnWorker>()
                .setConstraints(Constraints.Builder().setRequiresCharging(true).build())
                .build()
            WorkManager.getInstance(c).enqueueUniqueWork(ON, ExistingWorkPolicy.KEEP, req)
        } catch (e: Exception) { }
    }

    /** Vidcetə toxunmayan səssiz yoxlama: telefon şarjdan çıxarılıbsa növbəti taxılmanı yenidən gözləməyə qurur */
    fun check(c: Context, minutes: Long, policy: ExistingWorkPolicy) {
        try {
            val req = OneTimeWorkRequestBuilder<ChargeCheckWorker>()
                .setInitialDelay(minutes, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(c).enqueueUniqueWork(CHECK, policy, req)
        } catch (e: Exception) { }
    }
}

/** Şarja taxılan an işləyir: vidceti yeniləyir və (ekran açıqsa) dəqiqəlik yeniləməni başladır */
class ChargeOnWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        WeatherWidget.refresh(ctx)
        ChargeTick.schedule(ctx)
        ChargeWatch.check(ctx, 30, ExistingWorkPolicy.REPLACE)
        return Result.success()
    }
}

/** Hər 30 dəqiqədən bir səssiz baxır; şarjdan çıxarılıbsa göstəricini silir və yenidən gözləməyə keçir */
class ChargeCheckWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        if (Battery.charging(ctx)) {
            ChargeWatch.check(ctx, 30, ExistingWorkPolicy.APPEND_OR_REPLACE)
        } else {
            WeatherWidget.refresh(ctx)
            ChargeWatch.arm(ctx)
        }
        return Result.success()
    }
}
