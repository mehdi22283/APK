package az.pt.packettracer

import org.json.JSONArray
import org.json.JSONObject

enum class DType { PC, SERVER, SWITCH, ROUTER }

object Ip {
    fun parse(s: String): Long? {
        val p = s.trim().split(".")
        if (p.size != 4) return null
        var r = 0L
        for (x in p) {
            val n = x.toIntOrNull() ?: return null
            if (n < 0 || n > 255) return null
            r = r * 256 + n
        }
        return r
    }

    fun fmt(v: Long): String =
        "${(v shr 24) and 255L}.${(v shr 16) and 255L}.${(v shr 8) and 255L}.${v and 255L}"

    fun net(ip: Long, m: Long): Long = ip and m

    fun validMask(m: Long): Boolean {
        if (m <= 0L || m > 0xFFFFFFFFL) return false
        val inv = m.inv() and 0xFFFFFFFFL
        return (inv and (inv + 1)) == 0L
    }

    fun prefix(m: Long): Int = java.lang.Long.bitCount(m)
}

fun shortName(n: String): String = n.replace("FastEthernet", "Fa").replace("GigabitEthernet", "Gi")

class Iface(val name: String) {
    var ip = 0L
    var mask = 0L
    var shutdown = false
    var desc = ""
    fun hasIp() = ip != 0L
}

class Route(val net: Long, val mask: Long, val via: Long)

class Device(val id: Int, val type: DType, var name: String, var x: Float, var y: Float) {
    val ifaces = ArrayList<Iface>()
    val routes = ArrayList<Route>()
    val arp = HashSet<Long>()
    var gateway = 0L

    init {
        when (type) {
            DType.PC, DType.SERVER -> ifaces.add(Iface("FastEthernet0"))
            DType.SWITCH -> for (i in 1..8) ifaces.add(Iface("FastEthernet0/$i"))
            DType.ROUTER -> for (i in 0..3) {
                val f = Iface("GigabitEthernet0/$i")
                f.shutdown = true
                ifaces.add(f)
            }
        }
    }

    val isHost: Boolean get() = type == DType.PC || type == DType.SERVER
}

class Link(val a: Int, val ap: Int, val b: Int, val bp: Int)

class Trace {
    val path = ArrayList<Device>()
    var ttl = 0
    var arpMiss = false
    var useArp = false
    var ingressIp = 0L
}

sealed class Out {
    class Reached(val dev: Device) : Out()
    class Unreach(val dev: Device) : Out()
    class Expired(val dev: Device) : Out()
    object Timeout : Out()
}

class PingRes(val line: String, val ok: Boolean, val ch: Char, val tr: Trace)

fun ipOf(d: Device): Long = d.ifaces.firstOrNull { it.hasIp() }?.ip ?: 0L

fun mac(d: Device, i: Int): String = String.format("00d0.%04x.%04x", d.id, i)

class Network {
    val devices = ArrayList<Device>()
    val links = ArrayList<Link>()
    var nextId = 1
    val counters = HashMap<DType, Int>()

    fun clear() {
        devices.clear(); links.clear(); counters.clear(); nextId = 1
    }

    fun clearArp() {
        devices.forEach { it.arp.clear() }
    }

    fun add(type: DType, x: Float, y: Float): Device {
        val n = counters[type] ?: 0
        counters[type] = n + 1
        val p = when (type) {
            DType.PC -> "PC"
            DType.SERVER -> "Server"
            DType.SWITCH -> "Switch"
            DType.ROUTER -> "Router"
        }
        val d = Device(nextId++, type, "$p$n", x, y)
        devices.add(d)
        return d
    }

    fun dev(id: Int): Device? = devices.firstOrNull { it.id == id }

    fun remove(d: Device) {
        links.removeAll { it.a == d.id || it.b == d.id }
        devices.remove(d)
        clearArp()
    }

    fun removeLink(l: Link) {
        links.remove(l)
        clearArp()
    }

    fun linkAt(d: Device, p: Int): Link? =
        links.firstOrNull { (it.a == d.id && it.ap == p) || (it.b == d.id && it.bp == p) }

    fun freePorts(d: Device): List<Int> = d.ifaces.indices.filter { linkAt(d, it) == null }

    fun connect(a: Device, ap: Int, b: Device, bp: Int) {
        links.add(Link(a.id, ap, b.id, bp))
        clearArp()
    }

    fun peer(d: Device, p: Int): Pair<Device, Int>? {
        val l = linkAt(d, p) ?: return null
        return if (l.a == d.id) {
            val o = dev(l.b) ?: return null
            Pair(o, l.bp)
        } else {
            val o = dev(l.a) ?: return null
            Pair(o, l.ap)
        }
    }

    fun linkUp(l: Link): Boolean {
        val a = dev(l.a) ?: return false
        val b = dev(l.b) ?: return false
        return !a.ifaces[l.ap].shutdown && !b.ifaces[l.bp].shutdown
    }

    fun portUp(d: Device, i: Int): Boolean {
        val l = linkAt(d, i) ?: return false
        return linkUp(l)
    }

    /** Switch-lər vasitəsilə L2 domenində şərtə uyğun son nöqtəni tapır. */
    fun l2Find(d: Device, p: Int, pred: (Device, Int) -> Boolean): Pair<List<Device>, Pair<Device, Int>>? {
        val seen = HashSet<Int>()
        fun walk(dv: Device, port: Int, acc: List<Device>): Pair<List<Device>, Pair<Device, Int>>? {
            val l = linkAt(dv, port) ?: return null
            if (!linkUp(l)) return null
            val pr = peer(dv, port) ?: return null
            val nd = pr.first
            val np = pr.second
            if (nd.type == DType.SWITCH) {
                if (!seen.add(nd.id)) return null
                for (i in nd.ifaces.indices) {
                    if (i == np) continue
                    val r = walk(nd, i, acc + nd)
                    if (r != null) return r
                }
                return null
            }
            return if (pred(nd, np)) Pair(acc + nd, pr) else null
        }
        return walk(d, p, emptyList())
    }

    fun ttlOf(d: Device): Int = if (d.isHost) 128 else 255

    fun send(dev: Device, dst: Long, ttlIn: Int, origin: Boolean, tr: Trace): Out {
        tr.path.add(dev)
        if (dev.ifaces.any { it.hasIp() && it.ip == dst && !it.shutdown }) {
            tr.ttl = ttlIn
            return Out.Reached(dev)
        }
        var ttl = ttlIn
        if (!origin) {
            if (dev.isHost) return Out.Timeout
            ttl -= 1
            if (ttl <= 0) return Out.Expired(dev)
        }
        if (dev.type == DType.SWITCH) return Out.Timeout

        var egress = -1
        var nh = 0L
        if (dev.isHost) {
            val f = dev.ifaces[0]
            if (f.hasIp() && !f.shutdown) {
                if (Ip.net(dst, f.mask) == Ip.net(f.ip, f.mask)) {
                    egress = 0; nh = dst
                } else if (dev.gateway != 0L && Ip.net(dev.gateway, f.mask) == Ip.net(f.ip, f.mask)) {
                    egress = 0; nh = dev.gateway
                }
            }
            if (egress < 0) return Out.Unreach(dev)
        } else {
            var bestLen = -1
            for ((i, f) in dev.ifaces.withIndex()) {
                if (!f.hasIp() || f.shutdown) continue
                if (Ip.net(dst, f.mask) == Ip.net(f.ip, f.mask)) {
                    val len = Ip.prefix(f.mask)
                    if (len > bestLen) {
                        bestLen = len; egress = i; nh = dst
                    }
                }
            }
            for (r in dev.routes) {
                if (Ip.net(dst, r.mask) != r.net) continue
                val len = Ip.prefix(r.mask)
                if (len <= bestLen) continue
                for ((i, f) in dev.ifaces.withIndex()) {
                    if (f.hasIp() && !f.shutdown && Ip.net(r.via, f.mask) == Ip.net(f.ip, f.mask)) {
                        bestLen = len; egress = i; nh = r.via
                        break
                    }
                }
            }
            if (egress < 0) return Out.Unreach(dev)
        }

        val target = nh
        val found = l2Find(dev, egress) { d2, p2 ->
            val f = d2.ifaces[p2]
            f.hasIp() && f.ip == target && !f.shutdown
        }
        if (found == null) {
            return if (dev.isHost || origin) Out.Timeout else Out.Unreach(dev)
        }
        tr.path.addAll(found.first.dropLast(1))
        val nd = found.second.first
        val np = found.second.second
        if (origin && tr.useArp && !dev.arp.contains(target)) {
            dev.arp.add(target)
            tr.arpMiss = true
            tr.path.add(nd)
            return Out.Timeout
        }
        tr.ingressIp = nd.ifaces[np].ip
        return send(nd, dst, ttl, false, tr)
    }

    fun srcIpFor(src: Device, dst: Long): Long {
        for (f in src.ifaces) {
            if (f.hasIp() && !f.shutdown && Ip.net(f.ip, f.mask) == Ip.net(dst, f.mask)) return f.ip
        }
        return src.ifaces.firstOrNull { it.hasIp() && !it.shutdown }?.ip ?: 0L
    }

    fun pingOnce(src: Device, dst: Long): PingRes {
        val tf = Trace()
        tf.useArp = true
        val o = send(src, dst, ttlOf(src), true, tf)
        return when (o) {
            is Out.Reached -> {
                val tb = Trace()
                val ob = send(o.dev, srcIpFor(src, dst), ttlOf(o.dev), true, tb)
                if (ob is Out.Reached && ob.dev === src)
                    PingRes("Reply from ${Ip.fmt(dst)}: bytes=32 time<1ms TTL=${tb.ttl}", true, '!', tf)
                else
                    PingRes("Request timed out.", false, '.', tf)
            }
            is Out.Unreach -> {
                val ip = if (tf.ingressIp != 0L) tf.ingressIp else ipOf(o.dev)
                PingRes("Reply from ${Ip.fmt(ip)}: Destination host unreachable.", false, 'U', tf)
            }
            is Out.Expired -> {
                val ip = if (tf.ingressIp != 0L) tf.ingressIp else ipOf(o.dev)
                PingRes("Reply from ${Ip.fmt(ip)}: TTL expired in transit.", false, 'U', tf)
            }
            is Out.Timeout -> PingRes("Request timed out.", false, '.', tf)
        }
    }

    fun macOf(ip: Long): String {
        for (d in devices) for ((i, f) in d.ifaces.withIndex()) if (f.hasIp() && f.ip == ip) return mac(d, i)
        return "0000.0000.0000"
    }

    fun toJson(): String {
        val o = JSONObject()
        o.put("next", nextId)
        val c = JSONObject()
        for (t in DType.values()) c.put(t.name, counters[t] ?: 0)
        o.put("cnt", c)
        val da = JSONArray()
        for (d in devices) {
            val j = JSONObject()
            j.put("id", d.id); j.put("type", d.type.name); j.put("name", d.name)
            j.put("x", d.x.toDouble()); j.put("y", d.y.toDouble()); j.put("gw", d.gateway)
            val ia = JSONArray()
            for (f in d.ifaces) {
                val k = JSONObject()
                k.put("ip", f.ip); k.put("mask", f.mask); k.put("sd", f.shutdown); k.put("desc", f.desc)
                ia.put(k)
            }
            j.put("if", ia)
            val ra = JSONArray()
            for (r in d.routes) {
                val k = JSONObject()
                k.put("n", r.net); k.put("m", r.mask); k.put("v", r.via)
                ra.put(k)
            }
            j.put("rt", ra)
            da.put(j)
        }
        o.put("dev", da)
        val la = JSONArray()
        for (l in links) {
            val a = JSONArray()
            a.put(l.a); a.put(l.ap); a.put(l.b); a.put(l.bp)
            la.put(a)
        }
        o.put("lnk", la)
        return o.toString()
    }

    companion object {
        fun fromJson(s: String): Network? {
            return try {
                val o = JSONObject(s)
                val n = Network()
                n.nextId = o.getInt("next")
                val c = o.optJSONObject("cnt")
                if (c != null) for (t in DType.values()) n.counters[t] = c.optInt(t.name, 0)
                val da = o.getJSONArray("dev")
                for (i in 0 until da.length()) {
                    val j = da.getJSONObject(i)
                    val d = Device(
                        j.getInt("id"), DType.valueOf(j.getString("type")), j.getString("name"),
                        j.getDouble("x").toFloat(), j.getDouble("y").toFloat()
                    )
                    d.gateway = j.optLong("gw", 0L)
                    val ia = j.getJSONArray("if")
                    for (k in 0 until minOf(ia.length(), d.ifaces.size)) {
                        val q = ia.getJSONObject(k)
                        val f = d.ifaces[k]
                        f.ip = q.optLong("ip", 0L); f.mask = q.optLong("mask", 0L)
                        f.shutdown = q.optBoolean("sd", false); f.desc = q.optString("desc", "")
                    }
                    val ra = j.getJSONArray("rt")
                    for (k in 0 until ra.length()) {
                        val q = ra.getJSONObject(k)
                        d.routes.add(Route(q.getLong("n"), q.getLong("m"), q.getLong("v")))
                    }
                    n.devices.add(d)
                }
                val la = o.getJSONArray("lnk")
                for (i in 0 until la.length()) {
                    val a = la.getJSONArray(i)
                    n.links.add(Link(a.getInt(0), a.getInt(1), a.getInt(2), a.getInt(3)))
                }
                n
            } catch (e: Exception) {
                null
            }
        }
    }
}
