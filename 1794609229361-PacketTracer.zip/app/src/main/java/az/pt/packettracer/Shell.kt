package az.pt.packettracer

/** PC/Server üçün Command Prompt, Router/Switch üçün Cisco IOS CLI. */
class Shell(private val net: Network, val dev: Device) {
    val log = StringBuilder()
    private var mode = 0 // 0 user, 1 privileged, 2 config, 3 config-if
    private var curIf: Iface? = null

    init {
        if (dev.isHost) log.append("Packet Tracer ${if (dev.type == DType.PC) "PC" else "Server"} Command Line 1.0\nKömək üçün: help\n\n")
        else log.append("\nPress RETURN to get started!\n\n")
    }

    fun prompt(): String =
        if (dev.isHost) "C:\\>"
        else dev.name + when (mode) {
            0 -> ">"
            1 -> "#"
            2 -> "(config)#"
            else -> "(config-if)#"
        }

    fun submit(line: String) {
        log.append(prompt()).append(line).append('\n')
        val out = if (dev.isHost) hostCmd(line) else ciscoCmd(line)
        if (out.isNotEmpty()) log.append(out).append('\n')
        if (log.length > 30000) log.delete(0, log.length - 20000)
    }

    private fun toks(s: String): List<String> = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun w(t: List<String>, i: Int, full: String): Boolean =
        i < t.size && t[i].isNotEmpty() && full.startsWith(t[i].lowercase())

    private fun m(t: List<String>, vararg p: String): Boolean {
        if (t.size != p.size) return false
        for (i in p.indices) {
            if (p[i] == "*") continue
            if (!w(t, i, p[i])) return false
        }
        return true
    }

    private fun invalid() = "% Invalid input detected."

    // ------------------------------------------------------------ HOST
    private fun hostCmd(line: String): String {
        val t = toks(line)
        if (t.isEmpty()) return ""
        val f = dev.ifaces[0]
        when (t[0].lowercase()) {
            "help", "?" -> return "Mövcud əmrlər:\n  ipconfig [/all]\n  ping <ip>\n  tracert <ip>\n  arp -a\n  hostname\n  cls"
            "cls" -> {
                log.setLength(0); return ""
            }
            "hostname" -> return dev.name
            "ipconfig" -> {
                val sb = StringBuilder("\nFastEthernet0 Connection:(default port)\n\n")
                if (t.size > 1 && t[1].lowercase() == "/all") sb.append("   Physical Address................: ${mac(dev, 0)}\n")
                sb.append("   IPv4 Address....................: ${if (f.hasIp()) Ip.fmt(f.ip) else "0.0.0.0"}\n")
                sb.append("   Subnet Mask.....................: ${if (f.hasIp()) Ip.fmt(f.mask) else "0.0.0.0"}\n")
                sb.append("   Default Gateway.................: ${if (dev.gateway != 0L) Ip.fmt(dev.gateway) else "0.0.0.0"}")
                return sb.toString()
            }
            "ping" -> {
                if (t.size < 2) return "Usage: ping <ip>"
                val dst = Ip.parse(t[1]) ?: return "Ping request could not find host ${t[1]}. Please check the name and try again."
                val sb = StringBuilder("\nPinging ${t[1]} with 32 bytes of data:\n\n")
                var ok = 0
                for (i in 0 until 4) {
                    val r = net.pingOnce(dev, dst)
                    if (r.ok) ok++
                    sb.append(r.line).append('\n')
                }
                sb.append("\nPing statistics for ${t[1]}:\n    Packets: Sent = 4, Received = $ok, Lost = ${4 - ok} (${(4 - ok) * 25}% loss),")
                if (ok > 0) sb.append("\nApproximate round trip times in milli-seconds:\n    Minimum = 0ms, Maximum = 0ms, Average = 0ms")
                return sb.toString()
            }
            "tracert" -> {
                if (t.size < 2) return "Usage: tracert <ip>"
                val dst = Ip.parse(t[1]) ?: return "Unable to resolve target system name ${t[1]}."
                return traceText(dst, "\nTracing route to ${t[1]} over a maximum of 30 hops:\n\n", false)
            }
            "arp" -> {
                if (dev.arp.isEmpty()) return "No ARP Entries Found"
                val sb = StringBuilder("  Internet Address      Physical Address      Type\n")
                for (ip in dev.arp) sb.append("  ${Ip.fmt(ip).padEnd(22)}${net.macOf(ip).padEnd(22)}dynamic\n")
                return sb.toString().trimEnd()
            }
        }
        return "Invalid Command."
    }

    private fun traceText(dst: Long, header: String, cisco: Boolean): String {
        val sb = StringBuilder(header)
        var misses = 0
        for (h in 1..30) {
            val tr = Trace()
            val o = net.send(dev, dst, h, true, tr)
            val hs = h.toString().padStart(3)
            when (o) {
                is Out.Reached -> {
                    sb.append(if (cisco) "$hs ${Ip.fmt(dst)} 0 msec 0 msec 0 msec" else "$hs   <1 ms   <1 ms   <1 ms   ${Ip.fmt(dst)}")
                    if (!cisco) sb.append("\n\nTrace complete.")
                    return sb.toString()
                }
                is Out.Expired -> {
                    val ip = if (tr.ingressIp != 0L) tr.ingressIp else ipOf(o.dev)
                    sb.append(if (cisco) "$hs ${Ip.fmt(ip)} 0 msec 0 msec 0 msec\n" else "$hs   <1 ms   <1 ms   <1 ms   ${Ip.fmt(ip)}\n")
                    misses = 0
                }
                is Out.Unreach -> {
                    val ip = if (tr.ingressIp != 0L) tr.ingressIp else ipOf(o.dev)
                    sb.append(if (cisco) "$hs ${Ip.fmt(ip)} !H" else "$hs   Reply from ${Ip.fmt(ip)}: Destination host unreachable.")
                    if (!cisco) sb.append("\n\nTrace complete.")
                    return sb.toString()
                }
                is Out.Timeout -> {
                    sb.append(if (cisco) "$hs * * *\n" else "$hs     *        *        *     Request timed out.\n")
                    misses++
                    if (misses >= 3) return sb.toString().trimEnd()
                }
            }
        }
        return sb.toString().trimEnd()
    }

    // ------------------------------------------------------------ CISCO
    private fun help(): String = when (mode) {
        0 -> "Exec commands:\n  enable\n  exit\n  ping <ip>\n  traceroute <ip>\n  show ip interface brief"
        1 -> "Privileged commands:\n  configure terminal\n  disable\n  exit\n  ping <ip>\n  traceroute <ip>\n  show ip interface brief | ip route | running-config | interfaces | version | vlan brief\n  write memory"
        2 -> "Config commands:\n  hostname <name>\n  interface <type><num>\n  ip route <net> <mask> <next-hop>\n  no ip route <net> <mask> [next-hop]\n  do <exec-command>\n  exit | end"
        else -> "Interface commands:\n  ip address <ip> <mask>\n  no ip address\n  shutdown | no shutdown\n  description <text>\n  exit | end"
    }

    private fun findIf(arg: String): Iface? {
        val mm = Regex("^([a-zA-Z]+)([0-9/]+)$").find(arg) ?: return null
        val pre = mm.groupValues[1].lowercase()
        val num = mm.groupValues[2]
        return dev.ifaces.firstOrNull {
            it.name.lowercase().startsWith(pre) && it.name.dropWhile { ch -> !ch.isDigit() } == num
        }
    }

    private fun ciscoCmd(line: String): String {
        val t = toks(line)
        if (t.isEmpty()) return ""
        if (t[0] == "?") return help()
        if (mode >= 2 && t.size > 1 && t[0].lowercase() == "do") {
            val sm = mode
            val si = curIf
            mode = 1
            val r = ciscoCmd(t.drop(1).joinToString(" "))
            mode = sm
            curIf = si
            return r
        }
        val isR = dev.type == DType.ROUTER
        when (mode) {
            0 -> {
                if (m(t, "enable")) { mode = 1; return "" }
                if (m(t, "exit")) return ""
            }
            1 -> {
                if (m(t, "disable") || m(t, "exit")) { mode = 0; return "" }
                if (m(t, "configure", "terminal") || m(t, "configure")) {
                    mode = 2
                    return "Enter configuration commands, one per line.  End with CNTL/Z."
                }
                if (m(t, "write", "memory") || m(t, "write") || m(t, "copy", "*", "*")) return "Building configuration...\n[OK]"
            }
            2 -> return cfg(t)
            else -> return cfgIf(t)
        }
        if (w(t, 0, "show") && t.size > 1) return show(t.drop(1)) ?: invalid()
        if (isR && w(t, 0, "ping") && t.size == 2) return routerPing(t[1])
        if (isR && w(t, 0, "traceroute") && t.size == 2) {
            val dst = Ip.parse(t[1]) ?: return "% Unrecognized host or address, or protocol not running."
            return traceText(dst, "Type escape sequence to abort.\nTracing the route to ${t[1]}\n\n", true)
        }
        return invalid()
    }

    private fun cfg(t: List<String>): String {
        if (m(t, "exit") || m(t, "end")) { mode = 1; return "" }
        if (t.size == 2 && w(t, 0, "hostname")) { dev.name = t[1]; return "" }
        if (w(t, 0, "interface") && t.size >= 2) {
            val f = findIf(t.drop(1).joinToString("")) ?: return "% Invalid interface."
            curIf = f
            mode = 3
            return ""
        }
        if (dev.type == DType.ROUTER) {
            if (m(t, "ip", "route", "*", "*", "*")) {
                val n = Ip.parse(t[2])
                val mk = Ip.parse(t[3])
                val v = Ip.parse(t[4])
                if (n == null || mk == null || v == null) return invalid()
                if (mk != 0L && !Ip.validMask(mk)) return "% Bad mask"
                if (Ip.net(n, mk) != n) return "%Inconsistent address and mask"
                dev.routes.removeAll { it.net == n && it.mask == mk }
                dev.routes.add(Route(n, mk, v))
                return ""
            }
            if (t.size >= 5 && w(t, 0, "no") && w(t, 1, "ip") && w(t, 2, "route")) {
                val n = Ip.parse(t[3])
                val mk = Ip.parse(t[4])
                if (n == null || mk == null) return invalid()
                dev.routes.removeAll { it.net == n && it.mask == mk }
                return ""
            }
        }
        return invalid()
    }

    private fun cfgIf(t: List<String>): String {
        val f = curIf ?: return invalid()
        val i = dev.ifaces.indexOf(f)
        if (m(t, "exit")) { mode = 2; curIf = null; return "" }
        if (m(t, "end")) { mode = 1; curIf = null; return "" }
        if (w(t, 0, "interface") && t.size >= 2) {
            val g = findIf(t.drop(1).joinToString("")) ?: return "% Invalid interface."
            curIf = g
            return ""
        }
        if (m(t, "shutdown")) {
            f.shutdown = true
            net.clearArp()
            return "%LINK-5-CHANGED: Interface ${f.name}, changed state to administratively down\n" +
                "%LINEPROTO-5-UPDOWN: Line protocol on Interface ${f.name}, changed state to down"
        }
        if (m(t, "no", "shutdown")) {
            f.shutdown = false
            net.clearArp()
            return if (net.portUp(dev, i))
                "%LINK-5-CHANGED: Interface ${f.name}, changed state to up\n" +
                    "%LINEPROTO-5-UPDOWN: Line protocol on Interface ${f.name}, changed state to up"
            else ""
        }
        if (dev.type == DType.ROUTER) {
            if (m(t, "ip", "address", "*", "*")) {
                val ip = Ip.parse(t[2])
                val mk = Ip.parse(t[3])
                if (ip == null || mk == null) return invalid()
                if (!Ip.validMask(mk)) return "% Invalid mask"
                f.ip = ip
                f.mask = mk
                net.clearArp()
                return ""
            }
            if (m(t, "no", "ip", "address")) {
                f.ip = 0L; f.mask = 0L
                net.clearArp()
                return ""
            }
        }
        if (w(t, 0, "description") && t.size >= 2) { f.desc = t.drop(1).joinToString(" "); return "" }
        if (w(t, 0, "speed") || w(t, 0, "duplex")) return ""
        return invalid()
    }

    private fun routerPing(arg: String): String {
        val ip = Ip.parse(arg) ?: return "% Unrecognized host or address, or protocol not running."
        val sb = StringBuilder("Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to $arg, timeout is 2 seconds:\n")
        var ok = 0
        for (i in 0 until 5) {
            val r = net.pingOnce(dev, ip)
            if (r.ok) ok++
            sb.append(r.ch)
        }
        sb.append("\nSuccess rate is ${ok * 100 / 5} percent ($ok/5)")
        if (ok > 0) sb.append(", round-trip min/avg/max = 0/0/1 ms")
        return sb.toString()
    }

    // ------------------------------------------------------------ SHOW
    private fun show(a: List<String>): String? {
        val isR = dev.type == DType.ROUTER
        if (m(a, "ip", "interface", "brief")) return ipBrief()
        if (isR && m(a, "ip", "route")) return ipRoute()
        if (a.size == 1 && (w(a, 0, "running-config") || w(a, 0, "startup-config"))) return runCfg()
        if (a.size == 1 && w(a, 0, "interfaces")) return interfaces()
        if (a.size == 1 && w(a, 0, "version")) return "Cisco IOS Software (simulated), Packet Tracer Android v1.0\n${dev.name} uptime is 0 minutes"
        if (!isR && m(a, "vlan", "brief")) return vlanBrief()
        return null
    }

    private fun ipBrief(): String {
        val sb = StringBuilder("Interface              IP-Address      OK? Method Status                Protocol\n")
        for ((i, f) in dev.ifaces.withIndex()) {
            val up = net.portUp(dev, i)
            val st = if (f.shutdown) "administratively down" else if (up) "up" else "down"
            val pr = if (!f.shutdown && up) "up" else "down"
            sb.append(f.name.padEnd(23))
                .append((if (f.hasIp()) Ip.fmt(f.ip) else "unassigned").padEnd(16))
                .append("YES ")
                .append((if (f.hasIp()) "manual" else "unset").padEnd(7))
                .append(st.padEnd(22))
                .append(pr).append('\n')
        }
        return sb.toString().trimEnd()
    }

    private fun ipRoute(): String {
        val sb = StringBuilder("Codes: C - connected, S - static\n\n")
        val def = dev.routes.firstOrNull { it.net == 0L && it.mask == 0L }
        sb.append(if (def != null) "Gateway of last resort is ${Ip.fmt(def.via)} to network 0.0.0.0\n\n" else "Gateway of last resort is not set\n\n")
        for ((i, f) in dev.ifaces.withIndex()) {
            if (f.hasIp() && !f.shutdown && net.portUp(dev, i))
                sb.append("C    ${Ip.fmt(Ip.net(f.ip, f.mask))}/${Ip.prefix(f.mask)} is directly connected, ${f.name}\n")
        }
        for (r in dev.routes) sb.append("S    ${Ip.fmt(r.net)}/${Ip.prefix(r.mask)} [1/0] via ${Ip.fmt(r.via)}\n")
        return sb.toString().trimEnd()
    }

    private fun interfaces(): String {
        val sb = StringBuilder()
        for ((i, f) in dev.ifaces.withIndex()) {
            val up = net.portUp(dev, i)
            sb.append("${f.name} is ${if (f.shutdown) "administratively down" else if (up) "up" else "down"}, line protocol is ${if (!f.shutdown && up) "up" else "down"}\n")
            sb.append("  Hardware address is ${mac(dev, i)}\n")
            if (f.desc.isNotEmpty()) sb.append("  Description: ${f.desc}\n")
            if (f.hasIp()) sb.append("  Internet address is ${Ip.fmt(f.ip)}/${Ip.prefix(f.mask)}\n")
        }
        return sb.toString().trimEnd()
    }

    private fun vlanBrief(): String {
        val ports = dev.ifaces.filter { !it.shutdown }.joinToString(", ") { shortName(it.name) }
        return "VLAN Name                             Status    Ports\n" +
            "---- -------------------------------- --------- -------------------------------\n" +
            "1    default                          active    $ports"
    }

    private fun runCfg(): String {
        val sb = StringBuilder("Building configuration...\n\nCurrent configuration : 0 bytes\n!\nhostname ${dev.name}\n!\n")
        for (f in dev.ifaces) {
            sb.append("interface ${f.name}\n")
            if (f.desc.isNotEmpty()) sb.append(" description ${f.desc}\n")
            if (dev.type == DType.ROUTER) {
                if (f.hasIp()) sb.append(" ip address ${Ip.fmt(f.ip)} ${Ip.fmt(f.mask)}\n") else sb.append(" no ip address\n")
            }
            if (f.shutdown) sb.append(" shutdown\n")
            sb.append("!\n")
        }
        for (r in dev.routes) sb.append("ip route ${Ip.fmt(r.net)} ${Ip.fmt(r.mask)} ${Ip.fmt(r.via)}\n")
        sb.append("!\nend")
        return sb.toString()
    }
}
