package az.pt.packettracer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.floor
import kotlin.math.hypot

class TopologyView(ctx: Context, val net: Network) : View(ctx) {
    var tool = 0 // 0 seç/sürüşdür, 1 kabel, 2 sil, 3 PDU, 4 cihaz yerləşdir
    var placeType: DType? = null
    var first: Device? = null
    var env: Pair<Float, Float>? = null

    var onOpenDevice: ((Device) -> Unit)? = null
    var onCable: ((Device, Device) -> Unit)? = null
    var onPdu: ((Device, Device) -> Unit)? = null
    var onDeleteDevice: ((Device) -> Unit)? = null
    var onDeleteLink: ((Link) -> Unit)? = null
    var onChanged: (() -> Unit)? = null

    private val dpv = ctx.resources.displayMetrics.density
    private val rad = 26f * dpv
    private var scale = 1f
    private var offX = 0f
    private var offY = 0f

    private val gridP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFC5CBD3.toInt(); strokeWidth = 3f * dpv; strokeCap = Paint.Cap.ROUND
    }
    private val linkP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 3f * dpv; style = Paint.Style.STROKE }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glyphP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.2f * dpv
        strokeCap = Paint.Cap.ROUND
    }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFB300.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f * dpv
    }
    private val nameP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF212121.toInt(); textSize = 12f * dpv; textAlign = Paint.Align.CENTER
    }
    private val portP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF455A64.toInt(); textSize = 9f * dpv; textAlign = Paint.Align.CENTER
    }
    private val envP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFEB3B.toInt() }
    private val envLineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF5D4037.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.5f * dpv
    }

    private val sgd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (scale * d.scaleFactor).coerceIn(0.4f, 3f)
            offX = d.focusX - (d.focusX - offX) * ns / scale
            offY = d.focusY - (d.focusY - offY) * ns / scale
            scale = ns
            invalidate()
            return true
        }
    })

    private var dragDev: Device? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false

    fun resetView() {
        scale = 1f; offX = 0f; offY = 0f; invalidate()
    }

    private fun hitW(wx: Float, wy: Float): Device? =
        net.devices.lastOrNull { hypot(wx - it.x, wy - it.y) < rad * 1.2f }

    private fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val l2 = dx * dx + dy * dy
        var t = if (l2 == 0f) 0f else ((px - ax) * dx + (py - ay) * dy) / l2
        t = t.coerceIn(0f, 1f)
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }

    private fun linkHit(wx: Float, wy: Float): Link? {
        for (l in net.links) {
            val a = net.dev(l.a) ?: continue
            val b = net.dev(l.b) ?: continue
            if (segDist(wx, wy, a.x, a.y, b.x, b.y) < 14f * dpv / scale) return l
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sgd.onTouchEvent(e)
        if (sgd.isInProgress || e.pointerCount > 1) {
            dragDev = null
            moved = true
            lastX = e.x; lastY = e.y
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; moved = false
                dragDev = if (tool == 0) hitW((e.x - offX) / scale, (e.y - offY) / scale) else null
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.x - downX, e.y - downY) < 8f * dpv) return true
                moved = true
                val dx = e.x - lastX
                val dy = e.y - lastY
                val dd = dragDev
                if (dd != null) {
                    dd.x += dx / scale; dd.y += dy / scale
                } else {
                    offX += dx; offY += dy
                }
                lastX = e.x; lastY = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) tap(e.x, e.y) else if (dragDev != null) onChanged?.invoke()
                dragDev = null
            }
            MotionEvent.ACTION_CANCEL -> dragDev = null
        }
        return true
    }

    private fun tap(sx: Float, sy: Float) {
        val wx = (sx - offX) / scale
        val wy = (sy - offY) / scale
        val d = hitW(wx, wy)
        when (tool) {
            0 -> if (d != null) onOpenDevice?.invoke(d)
            4 -> {
                val pt = placeType
                if (d == null && pt != null) {
                    net.add(pt, wx, wy)
                    onChanged?.invoke()
                    invalidate()
                }
            }
            1, 3 -> if (d != null) {
                val f = first
                if (f == null) {
                    first = d
                } else if (f === d) {
                    first = null
                } else {
                    first = null
                    if (tool == 1) onCable?.invoke(f, d) else onPdu?.invoke(f, d)
                }
                invalidate()
            }
            2 -> {
                if (d != null) onDeleteDevice?.invoke(d)
                else {
                    val l = linkHit(wx, wy)
                    if (l != null) onDeleteLink?.invoke(l)
                }
            }
        }
    }

    private fun colorOf(t: DType): Int = when (t) {
        DType.PC -> 0xFF1976D2.toInt()
        DType.SERVER -> 0xFF6A1B9A.toInt()
        DType.SWITCH -> 0xFF2E7D32.toInt()
        DType.ROUTER -> 0xFFEF6C00.toInt()
    }

    private fun label(c: Canvas, text: String, x: Float, y: Float) {
        c.drawText(text, x, y, portP)
    }

    override fun onDraw(c: Canvas) {
        c.save()
        c.translate(offX, offY)
        c.scale(scale, scale)

        val step = 40f * dpv
        val x0 = -offX / scale
        val y0 = -offY / scale
        val x1 = x0 + width / scale
        val y1 = y0 + height / scale
        var gx = floor(x0 / step) * step
        while (gx < x1) {
            var gy = floor(y0 / step) * step
            while (gy < y1) {
                c.drawPoint(gx, gy, gridP)
                gy += step
            }
            gx += step
        }

        for (l in net.links) {
            val a = net.dev(l.a) ?: continue
            val b = net.dev(l.b) ?: continue
            val up = net.linkUp(l)
            val col = if (up) 0xFF2E7D32.toInt() else 0xFFC62828.toInt()
            linkP.color = col
            c.drawLine(a.x, a.y, b.x, b.y, linkP)
            val dx = b.x - a.x
            val dy = b.y - a.y
            val len = hypot(dx, dy).coerceAtLeast(1f)
            val ux = dx / len
            val uy = dy / len
            dotP.color = col
            val dd = rad + 8f * dpv
            c.drawCircle(a.x + ux * dd, a.y + uy * dd, 4f * dpv, dotP)
            c.drawCircle(b.x - ux * dd, b.y - uy * dd, 4f * dpv, dotP)
            val ld = rad + 26f * dpv
            val off = 9f * dpv
            label(c, shortName(a.ifaces[l.ap].name), a.x + ux * ld - uy * off, a.y + uy * ld + ux * off)
            label(c, shortName(b.ifaces[l.bp].name), b.x - ux * ld - uy * off, b.y - uy * ld + ux * off)
        }

        for (d in net.devices) drawDevice(c, d)

        val ev = env
        if (ev != null) {
            val w = 11f * dpv
            val h = 8f * dpv
            c.drawRect(ev.first - w, ev.second - h, ev.first + w, ev.second + h, envP)
            c.drawRect(ev.first - w, ev.second - h, ev.first + w, ev.second + h, envLineP)
            c.drawLine(ev.first - w, ev.second - h, ev.first, ev.second, envLineP)
            c.drawLine(ev.first + w, ev.second - h, ev.first, ev.second, envLineP)
        }
        c.restore()
    }

    private fun drawDevice(c: Canvas, d: Device) {
        val hh = rad * 0.8f
        fillP.color = colorOf(d.type)
        c.drawRoundRect(RectF(d.x - rad, d.y - hh, d.x + rad, d.y + hh), 10f * dpv, 10f * dpv, fillP)
        when (d.type) {
            DType.PC -> {
                c.drawRect(d.x - rad * 0.5f, d.y - rad * 0.45f, d.x + rad * 0.5f, d.y + rad * 0.2f, glyphP)
                c.drawLine(d.x, d.y + rad * 0.2f, d.x, d.y + rad * 0.45f, glyphP)
                c.drawLine(d.x - rad * 0.3f, d.y + rad * 0.45f, d.x + rad * 0.3f, d.y + rad * 0.45f, glyphP)
            }
            DType.SERVER -> {
                for (k in -1..1) {
                    val cy = d.y + k * rad * 0.42f
                    c.drawRect(d.x - rad * 0.5f, cy - rad * 0.14f, d.x + rad * 0.5f, cy + rad * 0.14f, glyphP)
                }
            }
            DType.SWITCH -> {
                arrow(c, d.x - rad * 0.5f, d.x + rad * 0.5f, d.y - rad * 0.2f)
                arrow(c, d.x + rad * 0.5f, d.x - rad * 0.5f, d.y + rad * 0.25f)
            }
            DType.ROUTER -> {
                c.drawCircle(d.x, d.y, rad * 0.5f, glyphP)
                c.drawLine(d.x - rad * 0.5f, d.y, d.x + rad * 0.5f, d.y, glyphP)
                c.drawLine(d.x, d.y - rad * 0.5f, d.x, d.y + rad * 0.5f, glyphP)
            }
        }
        if (d === first) c.drawCircle(d.x, d.y, rad + 7f * dpv, ringP)
        c.drawText(d.name, d.x, d.y + hh + 15f * dpv, nameP)
    }

    private fun arrow(c: Canvas, xa: Float, xb: Float, y: Float) {
        c.drawLine(xa, y, xb, y, glyphP)
        val dir = if (xb > xa) -1f else 1f
        val hx = xb + dir * rad * 0.22f
        c.drawLine(xb, y, hx, y - rad * 0.16f, glyphP)
        c.drawLine(xb, y, hx, y + rad * 0.16f, glyphP)
    }
}
