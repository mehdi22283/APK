package az.pt.packettracer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.method.DigitsKeyListener
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var net: Network
    private lateinit var view: TopologyView
    private lateinit var status: TextView
    private val shells = HashMap<Int, Shell>()
    private val toolBtns = ArrayList<Triple<Button, Int, DType?>>()
    private var density = 1f

    private fun dp(n: Int): Int = (n * density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun save() {
        getSharedPreferences("pt", MODE_PRIVATE).edit().putString("net", net.toJson()).apply()
    }

    override fun onPause() {
        super.onPause()
        save()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        density = resources.displayMetrics.density
        net = Network.fromJson(getSharedPreferences("pt", MODE_PRIVATE).getString("net", "") ?: "") ?: Network()
        view = TopologyView(this, net)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFFF2F4F7.toInt())

        val bar = HorizontalScrollView(this)
        bar.setBackgroundColor(0xFF263238.toInt())
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        bar.addView(row)

        fun mk(label: String, onClick: () -> Unit): Button {
            val bt = Button(this)
            bt.text = label
            bt.isAllCaps = false
            bt.setTextColor(Color.WHITE)
            bt.setBackgroundColor(0xFF37474F.toInt())
            bt.minWidth = 0
            bt.minimumWidth = 0
            bt.setPadding(dp(12), 0, dp(12), 0)
            bt.setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42))
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            row.addView(bt, lp)
            return bt
        }
        fun tb(label: String, tool: Int, type: DType?) {
            val bt = mk(label) { setTool(tool, type) }
            toolBtns.add(Triple(bt, tool, type))
        }
        tb("Seç", 0, null)
        tb("PC", 4, DType.PC)
        tb("Server", 4, DType.SERVER)
        tb("Switch", 4, DType.SWITCH)
        tb("Router", 4, DType.ROUTER)
        tb("Kabel", 1, null)
        tb("PDU", 3, null)
        tb("Sil", 2, null)
        mk("Nümunə") {
            AlertDialog.Builder(this).setMessage("Cari topologiya silinib nümunə yüklənsin?")
                .setPositiveButton("Bəli") { _, _ -> sample() }.setNegativeButton("Xeyr", null).show()
        }
        mk("Mərkəz") { view.resetView() }
        mk("Təmizlə") {
            AlertDialog.Builder(this).setMessage("Bütün topologiya silinsin?")
                .setPositiveButton("Bəli") { _, _ ->
                    net.clear(); shells.clear(); save(); view.invalidate()
                }.setNegativeButton("Xeyr", null).show()
        }

        status = TextView(this)
        status.setPadding(dp(10), dp(8), dp(10), dp(8))
        status.setTextColor(0xFF263238.toInt())
        status.setBackgroundColor(0xFFE0E4EA.toInt())

        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        view.onOpenDevice = { openDevice(it) }
        view.onCable = { a, c -> cable(a, c) }
        view.onPdu = { a, c -> pdu(a, c) }
        view.onChanged = { save() }
        view.onDeleteDevice = { d ->
            AlertDialog.Builder(this).setMessage("${d.name} silinsin?")
                .setPositiveButton("Bəli") { _, _ ->
                    net.remove(d); shells.remove(d.id); save(); view.invalidate()
                }.setNegativeButton("Xeyr", null).show()
        }
        view.onDeleteLink = { l -> net.removeLink(l); save(); view.invalidate() }

        setTool(0, null)
    }

    private fun setTool(tool: Int, type: DType?) {
        view.tool = tool
        view.placeType = type
        view.first = null
        for ((bt, t, ty) in toolBtns) {
            bt.setBackgroundColor(if (t == tool && ty == type) 0xFF00897B.toInt() else 0xFF37474F.toInt())
        }
        status.setTextColor(0xFF263238.toInt())
        status.text = when (tool) {
            0 -> "Cihaza toxunun: konfiqurasiya / CLI. Sürüşdürün: yerini dəyişin. İki barmaq: yaxınlaşdır."
            4 -> "Boş yerə toxunun: ${type?.name} əlavə olunur."
            1 -> "Kabel: əvvəl birinci, sonra ikinci cihaza toxunun, sonra portları seçin."
            2 -> "Silmək üçün cihaza və ya kabelə toxunun."
            else -> "PDU: mənbə və hədəf cihazı seçin (ilk göndərişdə ARP səbəbilə paket itə bilər)."
        }
        view.invalidate()
    }

    // ------------------------------------------------------------ cable
    private fun cable(a: Device, b: Device) {
        val fa = net.freePorts(a)
        val fb = net.freePorts(b)
        if (fa.isEmpty()) { toast("${a.name}: boş port yoxdur"); return }
        if (fb.isEmpty()) { toast("${b.name}: boş port yoxdur"); return }
        pick(a, fa) { pa ->
            pick(b, fb) { pb ->
                net.connect(a, pa, b, pb)
                save()
                view.invalidate()
            }
        }
    }

    private fun pick(d: Device, ports: List<Int>, ok: (Int) -> Unit) {
        val names = ports.map { d.ifaces[it].name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("${d.name}: port seçin")
            .setItems(names) { _, i -> ok(ports[i]) }.show()
    }

    // ------------------------------------------------------------ PDU
    private fun pdu(a: Device, b: Device) {
        if (a.type == DType.SWITCH || b.type == DType.SWITCH) { toast("PDU üçün PC, Server və ya Router seçin"); return }
        val dst = ipOf(b)
        if (dst == 0L) { toast("Hədəf cihazın IP ünvanı yoxdur"); return }
        val r = net.pingOnce(a, dst)
        val pts = r.tr.path.map { Pair(it.x, it.y) }
        val full = if (r.ok) pts + pts.reversed().drop(1) else pts
        animate(full) {
            if (r.ok) {
                status.setTextColor(0xFF2E7D32.toInt())
                status.text = "PDU ${a.name} → ${b.name}: Uğurlu ✓"
            } else {
                status.setTextColor(0xFFC62828.toInt())
                status.text = "PDU ${a.name} → ${b.name}: Uğursuz ✗ (${r.line})" +
                    if (r.tr.arpMiss) "\nİlk paket ARP üçün itdi - yenidən göndərin." else ""
            }
        }
    }

    private fun animate(pts: List<Pair<Float, Float>>, done: () -> Unit) {
        if (pts.size < 2) { done(); return }
        val n = pts.size - 1
        val va = ValueAnimator.ofFloat(0f, n.toFloat())
        va.duration = 450L * n
        va.interpolator = LinearInterpolator()
        va.addUpdateListener { anim ->
            val v = anim.animatedValue as Float
            val i = minOf(v.toInt(), n - 1)
            val f = v - i
            view.env = Pair(
                pts[i].first + (pts[i + 1].first - pts[i].first) * f,
                pts[i].second + (pts[i + 1].second - pts[i].second) * f
            )
            view.invalidate()
        }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                view.env = null
                view.invalidate()
                done()
            }
        })
        va.start()
    }

    // ------------------------------------------------------------ sample
    private fun sample() {
        net.clear(); shells.clear()
        fun p(v: Int) = v * density
        val pc0 = net.add(DType.PC, p(45), p(70))
        val pc1 = net.add(DType.PC, p(45), p(250))
        val sw0 = net.add(DType.SWITCH, p(125), p(160))
        val r0 = net.add(DType.ROUTER, p(220), p(160))
        val sw1 = net.add(DType.SWITCH, p(310), p(160))
        val srv = net.add(DType.SERVER, p(310), p(280))
        val m24 = Ip.parse("255.255.255.0")!!
        fun cfg(d: Device, ip: String, gw: String) {
            d.ifaces[0].ip = Ip.parse(ip)!!; d.ifaces[0].mask = m24; d.gateway = Ip.parse(gw)!!
        }
        cfg(pc0, "192.168.1.10", "192.168.1.1")
        cfg(pc1, "192.168.1.11", "192.168.1.1")
        cfg(srv, "10.0.0.10", "10.0.0.1")
        r0.ifaces[0].ip = Ip.parse("192.168.1.1")!!; r0.ifaces[0].mask = m24; r0.ifaces[0].shutdown = false
        r0.ifaces[1].ip = Ip.parse("10.0.0.1")!!; r0.ifaces[1].mask = m24; r0.ifaces[1].shutdown = false
        net.connect(pc0, 0, sw0, 0)
        net.connect(pc1, 0, sw0, 1)
        net.connect(r0, 0, sw0, 2)
        net.connect(r0, 1, sw1, 0)
        net.connect(srv, 0, sw1, 1)
        save()
        view.resetView()
        toast("Nümunə yükləndi: PC0 → ping 10.0.0.10 yoxlayın")
    }

    // ------------------------------------------------------------ device dialog
    private fun openDevice(d: Device) {
        val dlg = Dialog(this, android.R.style.Theme_Material_Light_NoActionBar)
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setBackgroundColor(0xFF263238.toInt())
        head.setPadding(dp(12), dp(4), dp(4), dp(4))
        val title = TextView(this)
        title.text = "${d.name}  (${d.type.name})"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val close = Button(this)
        close.text = "Bağla"
        close.isAllCaps = false
        close.setOnClickListener { dlg.dismiss() }
        head.addView(close)
        root.addView(head)

        val body = FrameLayout(this)
        fun showView(v: View) {
            body.removeAllViews()
            body.addView(v)
        }
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val t1 = Button(this)
        t1.text = "Konfiqurasiya"
        t1.isAllCaps = false
        t1.setOnClickListener { showView(configView(d)) }
        val t2 = Button(this)
        t2.text = if (d.isHost) "Command Prompt" else "CLI"
        t2.isAllCaps = false
        t2.setOnClickListener { showView(termView(d)) }
        tabs.addView(t1, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(t2, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(tabs)
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        showView(configView(d))
        dlg.setContentView(root)
        dlg.setOnDismissListener { save(); view.invalidate() }
        dlg.show()
    }

    private fun ed(text: String, hint: String, ip: Boolean): EditText {
        val e = EditText(this)
        e.setText(text)
        e.hint = hint
        e.setSingleLine(true)
        if (ip) {
            e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            e.keyListener = DigitsKeyListener.getInstance("0123456789.")
        }
        return e
    }

    private fun readIp(et: EditText, what: String, out: (Long) -> Unit): String? {
        val s = et.text.toString().trim()
        if (s.isEmpty()) { out(0L); return null }
        val v = Ip.parse(s) ?: return "$what düzgün deyil: $s"
        out(v)
        return null
    }

    private fun applyIf(f: Iface, ipE: EditText, mkE: EditText): String? {
        var ip = 0L
        var mk = 0L
        val e1 = readIp(ipE, "IP") { ip = it }
        if (e1 != null) return e1
        val e2 = readIp(mkE, "Mask") { mk = it }
        if (e2 != null) return e2
        if (ip == 0L) { f.ip = 0L; f.mask = 0L; return null }
        if (mk == 0L) { mk = Ip.parse("255.255.255.0")!!; mkE.setText(Ip.fmt(mk)) }
        if (!Ip.validMask(mk)) return "Subnet mask düzgün deyil"
        f.ip = ip
        f.mask = mk
        return null
    }

    private fun configView(d: Device): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(8), dp(12), dp(16))
        sv.addView(col)
        val applies = ArrayList<() -> String?>()

        fun lbl(t: String) {
            val x = TextView(this)
            x.text = t
            x.setTypeface(null, Typeface.BOLD)
            x.setPadding(0, dp(12), 0, 0)
            col.addView(x)
        }

        lbl("Hostname")
        val hn = ed(d.name, "Hostname", false)
        col.addView(hn)
        applies.add {
            val n = hn.text.toString().trim()
            if (n.isEmpty() || n.contains(" ")) "Hostname düzgün deyil" else { d.name = n; null }
        }

        if (d.isHost) {
            val f = d.ifaces[0]
            lbl("IP ünvanı")
            val ipE = ed(if (f.hasIp()) Ip.fmt(f.ip) else "", "192.168.1.10", true)
            col.addView(ipE)
            lbl("Subnet mask")
            val mkE = ed(if (f.hasIp()) Ip.fmt(f.mask) else "", "255.255.255.0", true)
            col.addView(mkE)
            lbl("Default gateway")
            val gwE = ed(if (d.gateway != 0L) Ip.fmt(d.gateway) else "", "192.168.1.1", true)
            col.addView(gwE)
            applies.add { applyIf(f, ipE, mkE) }
            applies.add { readIp(gwE, "Gateway") { d.gateway = it } }
        } else if (d.type == DType.ROUTER) {
            for (f in d.ifaces) {
                lbl(f.name)
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                val ipE = ed(if (f.hasIp()) Ip.fmt(f.ip) else "", "IP", true)
                val mkE = ed(if (f.hasIp()) Ip.fmt(f.mask) else "", "Mask", true)
                val cb = CheckBox(this)
                cb.text = "On"
                cb.isChecked = !f.shutdown
                r.addView(ipE, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                r.addView(mkE, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                r.addView(cb)
                col.addView(r)
                applies.add {
                    f.shutdown = !cb.isChecked
                    applyIf(f, ipE, mkE)
                }
            }
            val hint = TextView(this)
            hint.text = "\nStatik marşrutlar üçün CLI: enable → conf t → ip route <şəbəkə> <mask> <next-hop>"
            col.addView(hint)
        } else {
            lbl("Portlar")
            for (f in d.ifaces) {
                val cb = CheckBox(this)
                cb.text = f.name
                cb.isChecked = !f.shutdown
                col.addView(cb)
                applies.add { f.shutdown = !cb.isChecked; null }
            }
        }

        val ap = Button(this)
        ap.text = "Tətbiq et"
        ap.isAllCaps = false
        ap.setOnClickListener {
            var err: String? = null
            for (a in applies) {
                err = a()
                if (err != null) break
            }
            if (err != null) toast(err) else {
                net.clearArp(); save(); view.invalidate(); toast("Tətbiq olundu")
            }
        }
        col.addView(ap)
        return sv
    }

    private fun termView(d: Device): View {
        val sh = shells.getOrPut(d.id) { Shell(net, d) }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(Color.BLACK)

        val tv = TextView(this)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(0xFFB9F6CA.toInt())
        tv.textSize = 12f
        tv.setPadding(dp(8), dp(8), dp(8), dp(8))
        val sv = ScrollView(this)
        sv.addView(tv)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), 0, dp(8), 0)
        val pt = TextView(this)
        pt.typeface = Typeface.MONOSPACE
        pt.setTextColor(Color.WHITE)
        pt.textSize = 12f
        val et = EditText(this)
        et.typeface = Typeface.MONOSPACE
        et.setTextColor(Color.WHITE)
        et.textSize = 13f
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        row.addView(pt)
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(row)

        fun refresh() {
            tv.text = sh.log.toString()
            pt.text = sh.prompt()
            sv.post { sv.fullScroll(View.FOCUS_DOWN) }
        }
        et.setOnEditorActionListener { _, _, ev ->
            if (ev != null && ev.action != KeyEvent.ACTION_DOWN) {
                true
            } else {
                val line = et.text.toString()
                et.setText("")
                sh.submit(line)
                refresh()
                true
            }
        }
        refresh()
        return col
    }
}
