Packet Tracer (Android) - sadə şəbəkə simulyatoru.
GitHub-a yükləyin (zip-i açıb fayllarını repo-ya qoyun) -> Actions -> Build APK -> Artifacts: PacketTracer-debug.
