package com.mehdi.calc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class GpsActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var latEt: EditText
    private lateinit var lngEt: EditText
    private lateinit var btn: Button
    private lateinit var status: TextView
    private val h = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("gps", MODE_PRIVATE)
        val lat0 = prefs.getString("lat", "40.409300") ?: "40.409300"
        val lng0 = prefs.getString("lng", "49.867100") ?: "49.867100"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF121212.toInt())
        }

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        web.loadDataWithBaseURL(
            "https://localhost/",
            MAP_HTML.replace("__LAT__", lat0).replace("__LNG__", lng0),
            "text/html", "utf-8", null
        )
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }

        val coords = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        latEt = coordField("Enlik", lat0)
        lngEt = coordField("Uzunluq", lng0)
        coords.addView(latEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        coords.addView(lngEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(coords)

        btn = Button(this).apply {
            text = "BAŞLAT"
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFFFF9F0A.toInt())
            setOnClickListener { toggle() }
        }
        panel.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dev = Button(this).apply {
            text = "Developer settings"
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF333333.toInt())
            setOnClickListener { openDev() }
        }
        val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlp.topMargin = dp(6)
        panel.addView(dev, dlp)

        status = TextView(this).apply {
            setTextColor(0xFF8E8E93.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(8), 0, 0)
        }
        panel.addView(status)
        root.addView(panel)
        setContentView(root)
    }

    private fun coordField(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(0xFF666666.toInt())
        setTextColor(Color.WHITE)
        setText(value)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        setSingleLine(true)
    }

    inner class Bridge {
        @JavascriptInterface
        fun pick(lat: Double, lng: Double) {
            runOnUiThread {
                latEt.setText(String.format(Locale.US, "%.6f", lat))
                lngEt.setText(String.format(Locale.US, "%.6f", lng))
                if (MockService.running) start()
            }
        }
    }

    private fun toggle() {
        if (MockService.running) {
            stopService(Intent(this, MockService::class.java))
            return
        }
        if (!hasLoc()) {
            val p = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermissions(p, 1)
            return
        }
        start()
    }

    private fun hasLoc() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasLoc()) start() else status.text = "Məkan icazəsi lazımdır"
    }

    private fun start() {
        val lat = latEt.text.toString().toDoubleOrNull()
        val lng = lngEt.text.toString().toDoubleOrNull()
        if (lat == null || lng == null || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
            status.text = "Koordinat səhvdir"
            return
        }
        getSharedPreferences("gps", MODE_PRIVATE).edit()
            .putString("lat", latEt.text.toString())
            .putString("lng", lngEt.text.toString())
            .apply()
        MockService.error = null
        startForegroundService(
            Intent(this, MockService::class.java).putExtra("lat", lat).putExtra("lng", lng)
        )
        web.evaluateJavascript("setPos($lat,$lng,true)", null)
    }

    private fun openDev() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS))
            } catch (e2: Exception) {
                status.text = "Settings açılmadı"
            }
        }
    }

    private fun refresh() {
        if (MockService.running) {
            btn.text = "DAYANDIR"
            status.text = "Aktivdir: ${MockService.lat}, ${MockService.lng}"
        } else {
            btn.text = "BAŞLAT"
            status.text = MockService.error ?: "Dayanıb"
        }
    }

    override fun onResume() {
        super.onResume()
        h.post(poll)
    }

    override fun onPause() {
        h.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val MAP_HTML = """<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
html,body,#m{height:100%;margin:0}
#s{position:absolute;z-index:1000;top:8px;left:54px;right:8px;display:flex;gap:4px}
#q{flex:1;min-width:0;padding:8px;font-size:15px;border:0;border-radius:8px;box-shadow:0 1px 4px #0006}
#b{padding:8px 12px;border:0;border-radius:8px;background:#ff9f0a;color:#fff}
</style></head><body>
<div id="s"><input id="q" placeholder="Axtar..."><button id="b">Axtar</button></div>
<div id="m"></div>
<script>
var map=L.map('m').setView([__LAT__,__LNG__],13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'OSM'}).addTo(map);
var mk=L.marker([__LAT__,__LNG__]).addTo(map);
function setPos(a,o,pan){mk.setLatLng([a,o]);if(pan){map.setView([a,o]);}}
map.on('click',function(e){mk.setLatLng(e.latlng);Android.pick(e.latlng.lat,e.latlng.lng);});
function go(){
  var q=document.getElementById('q').value;if(!q)return;
  fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(q))
  .then(function(r){return r.json();})
  .then(function(d){if(d.length){var a=parseFloat(d[0].lat),o=parseFloat(d[0].lon);map.setView([a,o],15);mk.setLatLng([a,o]);Android.pick(a,o);}});
}
document.getElementById('b').onclick=go;
document.getElementById('q').addEventListener('keydown',function(e){if(e.key==='Enter'){go();}});
</script></body></html>"""
    }
}
