package az.mehdi.hava

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin

private val AY_ADLARI = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr", "oktyabr", "noyabr", "dekabr")

private fun hm(m: Int): String = when {
    m < 60 -> "$m dəq"
    m % 60 == 0 -> "${m / 60} saat"
    else -> "${m / 60} saat ${m % 60} dəq"
}

private fun whenTxt(w: Weather, idx: Int, cap: Boolean = false): String {
    val t = w.hours[idx].time
    val tomorrow = t.take(10) != LocalDate.now(BAKU).toString()
    val pre = if (tomorrow) (if (cap) "Sabah saat" else "sabah saat") else (if (cap) "Saat" else "saat")
    return "$pre ${t.substring(11, 16)}"
}

// ===================== KÜLƏK =====================
object WindInfo {
    private val NAMES = listOf("Şimal", "Şimal-Şərq", "Şərq", "Cənub-Şərq", "Cənub", "Cənub-Qərb", "Qərb", "Şimal-Qərb")

    /** Küləyin əsdiyi tərəf (dərəcə → ad) */
    fun dirName(deg: Double): String {
        if (deg.isNaN()) return ""
        val d = ((deg % 360) + 360) % 360
        return NAMES[((d / 45.0) + 0.5).toInt() % 8]
    }

    fun strength(v: Double): String = when {
        v < 12 -> "zəif"
        v < 25 -> "orta"
        v < 40 -> "güclü"
        v < 60 -> "çox güclü"
        else -> "tufan gücündə"
    }

    private val ARROWS = listOf("↑", "↗", "→", "↘", "↓", "↙", "←", "↖")

    /** Ox küləyin əsdiyi tərəfi göstərir: Şimal ↑, Cənub ↓, Şərq →, Qərb ← (8 istiqamət) */
    fun arrow(deg: Double): String {
        if (deg.isNaN()) return ""
        val d = ((deg % 360) + 360) % 360
        return ARROWS[((d / 45.0) + 0.5).toInt() % 8]
    }

    /** Şimal — mavi, cənub — qırmızı, aralarında rəng keçidi */
    fun arrowColor(deg: Double): Int {
        val d = ((deg % 360) + 360) % 360
        val t = (minOf(d, 360 - d) / 180.0).coerceIn(0.0, 1.0)
        val b = intArrayOf(0x40, 0xC4, 0xFF)
        val r = intArrayOf(0xFF, 0x52, 0x52)
        val c = IntArray(3) { (b[it] + (r[it] - b[it]) * t).toInt() }
        return android.graphics.Color.rgb(c[0], c[1], c[2])
    }

    /** Rəngli ox + sürət: "↗ 42 km/s" (istiqamət yoxdursa yalnız sürət) */
    fun colored(speed: Double, deg: Double): CharSequence {
        val sb = android.text.SpannableStringBuilder()
        val a = arrow(deg)
        if (a.isNotEmpty()) {
            sb.append(a)
            val f = android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            sb.setSpan(android.text.style.ForegroundColorSpan(arrowColor(deg)), 0, sb.length, f)
            sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, sb.length, f)
            sb.setSpan(android.text.style.RelativeSizeSpan(1.25f), 0, sb.length, f)
            sb.append(" ")
        }
        sb.append("${speed.roundToInt()} km/s")
        return sb
    }

    /** Rəngsiz variant (mətn şablonları üçün): "↗ 42 km/s" */
    fun label(speed: Double, deg: Double): String {
        val a = arrow(deg)
        return (if (a.isEmpty()) "" else "$a ") + "${speed.roundToInt()} km/s"
    }

    /** Vidcet üçün */
    fun compass(speed: Double, deg: Double): CharSequence = colored(speed, deg)

    fun detail(speed: Double, deg: Double): CharSequence {
        if (speed < 6) return "Külək demək olar ki, yoxdur (${speed.roundToInt()} km/s)"
        val sb = android.text.SpannableStringBuilder("${strength(speed).replaceFirstChar { it.uppercase() }} külək, ")
        sb.append(colored(speed, deg))
        return sb
    }
}

// ===================== AY FAZASI =====================
object Moon {
    class Info(val frac: Double, val illum: Int, val name: String, val icon: String, val age: Double, val nextFull: ZonedDateTime, val nextNew: ZonedDateTime)

    private fun rad(d: Double) = Math.toRadians(d)

    /** Meeus, "Astronomical Algorithms", fəsil 49. k tam ədəd = yeni ay, k+0.5 = dolunay. Nəticə: Unix saniyə */
    private fun phase(k: Double, full: Boolean): Double {
        val t = k / 1236.85
        val t2 = t * t
        val t3 = t2 * t
        val t4 = t3 * t
        val jde0 = 2451550.09766 + 29.530588861 * k + 0.00015437 * t2 - 0.00000015 * t3 + 0.00000000073 * t4
        val e = 1 - 0.002516 * t - 0.0000074 * t2
        val m = rad(2.5534 + 29.10535670 * k - 0.0000014 * t2 - 0.00000011 * t3)
        val mp = rad(201.5643 + 385.81693528 * k + 0.0107582 * t2 + 0.00001238 * t3 - 0.000000058 * t4)
        val f = rad(160.7108 + 390.67050284 * k - 0.0016118 * t2 - 0.00000227 * t3 + 0.000000011 * t4)
        val om = rad(124.7746 - 1.56375588 * k + 0.0020672 * t2 + 0.00000215 * t3)
        val c = if (full) {
            -0.40614 * sin(mp) + 0.17302 * e * sin(m) + 0.01614 * sin(2 * mp) + 0.01043 * sin(2 * f) +
                0.00734 * e * sin(mp - m) - 0.00515 * e * sin(mp + m) + 0.00209 * e * e * sin(2 * m)
        } else {
            -0.40720 * sin(mp) + 0.17241 * e * sin(m) + 0.01608 * sin(2 * mp) + 0.01039 * sin(2 * f) +
                0.00739 * e * sin(mp - m) - 0.00514 * e * sin(mp + m) + 0.00208 * e * e * sin(2 * m)
        }
        val common = -0.00111 * sin(mp - 2 * f) - 0.00057 * sin(mp + 2 * f) + 0.00056 * e * sin(2 * mp + m) -
            0.00042 * sin(3 * mp) + 0.00042 * e * sin(m + 2 * f) + 0.00038 * e * sin(m - 2 * f) -
            0.00024 * e * sin(2 * mp - m) - 0.00017 * sin(om)
        val jde = jde0 + c + common
        return (jde - 2440587.5) * 86400.0
    }

    private fun z(s: Double): ZonedDateTime = Instant.ofEpochSecond(s.toLong()).atZone(BAKU)

    fun info(now: Instant = Instant.now()): Info {
        val ns = now.epochSecond.toDouble()
        val yearsSince2000 = (ns - 946728000.0) / (365.25 * 86400.0)
        var k = floor(yearsSince2000 * 12.3685)
        while (phase(k, false) > ns) k -= 1
        while (phase(k + 1, false) <= ns) k += 1
        val prev = phase(k, false)
        val next = phase(k + 1, false)
        val fullThis = phase(k + 0.5, true)
        val nextFull = if (fullThis > ns) fullThis else phase(k + 1.5, true)
        val frac = ((ns - prev) / (next - prev)).coerceIn(0.0, 1.0)
        val illum = ((1 - cos(2 * Math.PI * frac)) / 2 * 100).roundToInt()
        val (name, idx) = when {
            frac < 0.03 || frac > 0.97 -> "Yeni ay" to 0
            frac < 0.22 -> "Artan hilal" to 1
            frac < 0.28 -> "Birinci rüb" to 2
            frac < 0.47 -> "Artan ay" to 3
            frac < 0.53 -> "Dolunay" to 4
            frac < 0.72 -> "Azalan ay" to 5
            frac < 0.78 -> "Son rüb" to 6
            else -> "Azalan hilal" to 7
        }
        return Info(frac, illum, name, "moon$idx", (ns - prev) / 86400.0, z(nextFull), z(next))
    }

    fun fmt(d: ZonedDateTime): String =
        "${d.dayOfMonth} ${AY_ADLARI[d.monthValue - 1]}, " + String.format("%02d:%02d", d.hour, d.minute)

    fun inText(d: ZonedDateTime): String {
        val h = Duration.between(Instant.now(), d.toInstant()).toHours()
        return when {
            h < 1 -> "1 saatdan az qalıb"
            h < 24 -> "$h saat sonra"
            else -> "${h / 24} gün sonra"
        }
    }
}

// ===================== GÜN UZUNLUĞU =====================
class DayLight(
    val sunrise: String, val sunset: String, val lenMin: Int,
    val diffText: String?, val remaining: String, val solstice: String
) {
    val lenText: String get() = hm(lenMin)
    val lenShort: String get() = "${lenMin / 60}s ${lenMin % 60}d"
}

private fun solstice(today: LocalDate): String {
    fun nxt(m: Int): LocalDate {
        var d = LocalDate.of(today.year, m, 21)
        if (d.isBefore(today)) d = d.plusYears(1)
        return d
    }
    val jun = nxt(6)
    val dec = nxt(12)
    val longest = !jun.isAfter(dec)
    val t = if (longest) jun else dec
    val n = ChronoUnit.DAYS.between(today, t)
    val name = if (longest) "ən uzun" else "ən qısa"
    val mon = if (longest) "iyun" else "dekabr"
    return if (n == 0L) "Bu gün il ərzində $name gündür (təxminən)" else "İlin $name gününə (təxminən 21 $mon) $n gün qalıb"
}

fun Weather.dayLight(): DayLight? {
    val today = LocalDate.now(BAKU)
    val d = days.firstOrNull { it.date == today.toString() } ?: return null
    if (d.sunrise.length < 16 || d.sunset.length < 16) return null
    return try {
        val sr = LocalDateTime.parse(d.sunrise)
        val ss = LocalDateTime.parse(d.sunset)
        val len = Duration.between(sr, ss).toMinutes().toInt()
        val tm = days.firstOrNull { it.date == today.plusDays(1).toString() }
        var diff: String? = null
        var tmSr = ""
        if (tm != null && tm.sunrise.length >= 16 && tm.sunset.length >= 16) {
            val l2 = Duration.between(LocalDateTime.parse(tm.sunrise), LocalDateTime.parse(tm.sunset)).toMinutes().toInt()
            val df = l2 - len
            diff = when {
                df > 0 -> "Sabah gün $df dəq uzun olacaq"
                df < 0 -> "Sabah gün ${-df} dəq qısa olacaq"
                else -> "Sabah gün bu günlə demək olar ki, eyni olacaq"
            }
            tmSr = tm.sunrise.substring(11, 16)
        }
        val now = LocalDateTime.now(BAKU)
        val rem = when {
            now.isBefore(sr) -> "Gün doğmağa ${hm(Duration.between(now, sr).toMinutes().toInt())} qalıb"
            now.isBefore(ss) -> "Gün batmağa ${hm(Duration.between(now, ss).toMinutes().toInt())} qalıb"
            else -> "Gün batıb" + if (tmSr.isNotEmpty()) ", sabah $tmSr-da doğacaq" else ""
        }
        DayLight(d.sunrise.substring(11, 16), d.sunset.substring(11, 16), len, diff, rem, solstice(today))
    } catch (e: Exception) {
        null
    }
}

// ===================== GEYİM MƏSLƏHƏTİ =====================
class WearAdvice(val headline: String, val short: String, val lines: List<Pair<String, String>>)

class Band(val name: String, val top: String, val bottom: String, val shoes: String, val acc: String, val short: String)

object Wear {
    private fun band(t: Double): Band = when {
        t <= -8 -> Band("Çox şaxtalı", "Qalın qış gödəkçəsi (puxa), altından termo alt paltar və qalın sviter",
            "İsti astarlı şalvar, altından termo tayts", "Qalın astarlı qış çəkməsi, yun corab",
            "Papaq, yun şərf, qalın əlcək; qulaq və üzü qoruyun", "qalın qış gödəkçəsi, termo, papaq, əlcək")
        t <= 0 -> Band("Şaxtalı", "Qalın qış gödəkçəsi və isti sviter", "İsti şalvar (mümkünsə termo altlıqla)",
            "İsti bağlı qış ayaqqabısı, qalın corab", "Papaq, şərf, əlcək", "qalın gödəkçə, sviter, papaq, əlcək")
        t <= 6 -> Band("Soyuq", "Qalın gödəkçə və ya palto, altından sviter/kofta", "Uzun isti şalvar",
            "Bağlı, isti ayaqqabı", "Şərf; külək varsa nazik papaq və əlcək", "palto/qalın gödəkçə, sviter, şərf")
        t <= 12 -> Band("Sərin", "Gödəkçə və ya plaş, altından uzunqollu köynək / nazik sviter", "Uzun şalvar və ya cins",
            "Bağlı ayaqqabı", "Külək varsa nazik şərf", "gödəkçə, uzunqollu, uzun şalvar")
        t <= 17 -> Band("Mülayim sərin", "Nazik gödəkçə, cins gödəkçə və ya kardigan; altından uzunqollu köynək", "Uzun şalvar və ya cins",
            "Krossovka / rahat bağlı ayaqqabı", "Lazım deyil", "nazik gödəkçə/kardigan, uzun şalvar")
        t <= 22 -> Band("Mülayim", "Uzunqollu köynək və ya nazik sviter; axşam üçün nazik üst götürün", "Yüngül şalvar və ya cins",
            "Krossovka / rahat ayaqqabı", "Lazım deyil", "uzunqollu köynək, yüngül şalvar")
        t <= 27 -> Band("İsti", "Tişört və ya köynək (pambıq, nəfəs alan)", "Yüngül şalvar və ya şort",
            "Krossovka və ya açıq ayaqqabı", "Günəş eynəyi", "tişört, yüngül şalvar/şort")
        t <= 32 -> Band("Çox isti", "Nazik, açıq rəngli tişört (pambıq/kətan)", "Şort və ya nazik yüngül şalvar",
            "Sandalet / açıq ayaqqabı", "Kepka və ya şlyapa, günəş eynəyi, su şüşəsi", "nazik tişört, şort, kepka")
        else -> Band("Həddindən artıq isti", "Ən yüngül, bol, açıq rəngli geyim", "Şort və ya bol yüngül şalvar",
            "Açıq ayaqqabı", "Şlyapa, günəş eynəyi, bol su; günorta saatlarında kölgədə qalın", "ən yüngül geyim, şlyapa, su")
    }

    fun now(w: Weather, n: Int): WearAdvice {
        val h = w.hours[n]
        fun fe(i: Int): Double = w.hours[i].let { if (it.feels.isNaN()) it.temp else it.feels }
        val feels = fe(n)
        val end14 = minOf(w.hours.size - 1, n + 14)
        val end12 = minOf(w.hours.size - 1, n + 12)
        val end8 = minOf(w.hours.size - 1, n + 8)
        val minF = (n..end14).minOf { fe(it) }
        val maxF = (n..end14).maxOf { fe(it) }
        val b = band(feels)
        val lines = ArrayList<Pair<String, String>>()
        lines.add("shirt" to "Üst: ${b.top}")
        lines.add("shirt" to "Alt: ${b.bottom}")
        lines.add("steps" to "Ayaqqabı: ${b.shoes}")
        if (b.acc != "Lazım deyil") lines.add("check" to "Aksesuar: ${b.acc}")
        val extra = StringBuilder()

        // yağıntı
        var pk: String? = null
        var pi = -1
        var heavy = false
        for (i in n..end12) {
            val k = w.kindOf(w.hours[i], true)
            if (k == "yağış" || k == "qar" || k == "tufan") {
                if (pk == null) { pk = k; pi = i }
                val c = w.hours[i].code
                if (c == 65 || c == 82 || c >= 95) heavy = true
            }
        }
        if (pk != null) {
            val whenS = if (pi == n) "Hazırda" else "${whenTxt(w, pi, true)}-dan"
            when (pk) {
                "yağış" -> {
                    lines.add("drop" to "$whenS yağış: çətir və ya su keçirməyən gödəkçə götürün, ayaqqabı su keçirməyən olsun" +
                        if (heavy) "; güclü yağışda su keçirməz çəkmə və plaş" else "")
                    extra.append(", çətir")
                }
                "qar" -> {
                    lines.add("snow" to "$whenS qar: sürüşməyən altlıqlı su keçirməz çəkmə, əlcək və başı örtən papaq")
                    extra.append(", qar çəkməsi")
                }
                else -> {
                    lines.add("storm" to "$whenS tufan ehtimalı: mümkünsə çölə çıxmayın, açıq sahədən və hündür ağacların altından uzaq durun")
                    extra.append(", çölə çıxmayın")
                }
            }
        }

        // külək
        val maxW = (n..end8).maxOf { w.hours[it].wind }
        when {
            maxW >= 25 -> {
                lines.add("wind" to "Külək güclüdür (${maxW.roundToInt()} km/s): küləkkeçirməz gödəkçə geyin, baş geyimini möhkəm bağlayın")
                extra.append(", küləkkeçirməz")
            }
        }
        if (maxW >= 40) lines.add("wind" to "Çox güclü külək: çətir işə yaramaz, zəif konstruksiyalardan və ağaclardan uzaq durun")

        // UV
        val uv = (n..end8).map { w.hours[it].uv }.filter { !it.isNaN() }.maxOrNull() ?: 0.0
        when {
            uv >= 8 -> { lines.add("clear" to "UV çox yüksəkdir (${uv.roundToInt()}): SPF 50 krem, kepka/şlyapa, günəş eynəyi; 11:00–16:00 arası kölgədə qalın"); extra.append(", eynək+krem") }
            uv >= 6 -> { lines.add("clear" to "UV yüksəkdir (${uv.roundToInt()}): SPF 30+ krem, baş geyimi və günəş eynəyi"); extra.append(", eynək+krem") }
            uv >= 3 -> { lines.add("clear" to "UV orta (${uv.roundToInt()}): günəş eynəyi, uzun müddət çöldə qalsanız krem"); extra.append(", eynək") }
        }

        // gün ərzində dəyişmə
        if (maxF - minF >= 8) {
            lines.add("thermo" to "Növbəti saatlarda hiss olunan temperatur ${minF.roundToInt()}° ilə ${maxF.roundToInt()}° arasında dəyişir: qat-qat geyinin, bir qatı çantada saxlayın")
        }

        // rütubət
        if (!h.hum.isNaN()) {
            if (h.hum >= 80 && feels >= 22) lines.add("drop" to "Rütubət yüksəkdir (${h.hum.roundToInt()}%): pambıq/kətan kimi nəfəs alan parça seçin, sintetikdən qaçın")
            else if (h.hum >= 85 && feels < 8) lines.add("drop" to "Rütubət yüksəkdir (${h.hum.roundToInt()}%): nəmli soyuq daha kəskin hiss olunur, əlavə isti qat geyin")
        }

        // duman
        if (h.code == 45 || h.code == 48) lines.add("fog" to "Duman var: yolda ehtiyatlı olun, açıq rəngli və ya əks etdirici elementli geyim seçin")

        // hava keyfiyyəti
        w.aqi?.let {
            when {
                it.us > 150 -> { lines.add("leaf" to "Hava keyfiyyəti ${T.aqiLevel(it.us)} (AQI ${it.us}): çölə FFP2/N95 maska ilə çıxın, pəncərələri bağlayın, çöldə idmandan çəkinin"); extra.append(", maska") }
                it.us > 100 -> { lines.add("leaf" to "Hava keyfiyyəti ${T.aqiLevel(it.us)} (AQI ${it.us}): həssas insanlar (uşaq, yaşlı, astma) üçün maska faydalıdır, uzun idmandan çəkinin"); extra.append(", maska") }
                else -> {}
            }
        }

        return WearAdvice("${b.name} · hiss ${feels.roundToInt()}°", b.short + extra.toString(), lines)
    }

    /** Növbəti günlər üçün qısa məsləhət */
    fun forDay(w: Weather, d: Day): String {
        val ref = d.max * 0.6 + d.min * 0.4 - (if (d.wind >= 30) 2.0 else 0.0)
        val sb = StringBuilder(band(ref).short)
        when (d.frameKind()) {
            "qar" -> sb.append(", qar çəkməsi")
            "yağış" -> sb.append(", çətir/su keçirməz gödəkçə")
            else -> if (d.prob >= 50) sb.append(", çətir")
        }
        if (d.wind >= 30) sb.append(", küləkkeçirməz")
        if (!d.uvMax.isNaN()) {
            if (d.uvMax >= 6) sb.append(", eynək+krem") else if (d.uvMax >= 3) sb.append(", eynək")
        }
        if (d.max - d.min >= 10) sb.append(", axşam üçün əlavə qat")
        return sb.toString()
    }
}
