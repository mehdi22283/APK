package az.mehdi.hava

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import kotlin.math.roundToInt

/** Şarj vəziyyəti: şarjda olub-olmama və 100%-ə qalan vaxt */
object Battery {
    /** Telefon hazırda şarja taxılıdır? */
    fun charging(c: Context): Boolean = try {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i != null && (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 ||
            i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING)
    } catch (e: Exception) { false }

    /**
     * Vidcetdəki şarj göstəricisi üçün:
     *  null  — göstərmə (şarjda deyil və ya artıq 100%)
     *  -1    — şarjdadır, amma qalan vaxt hələ bilinmir
     *  > 0   — 100%-ə qalan millisaniyə (Androidin computeChargeTimeRemaining dəyəri)
     */
    fun remainingMs(c: Context): Long? {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return null
            val pct = (level * 100f / scale).roundToInt()
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            when {
                status == BatteryManager.BATTERY_STATUS_FULL || (plugged && pct >= 100) -> null
                status == BatteryManager.BATTERY_STATUS_CHARGING || plugged -> {
                    val bm = c.getSystemService(BatteryManager::class.java)
                    var ms = -1L
                    if (Build.VERSION.SDK_INT >= 28) ms = bm.computeChargeTimeRemaining()
                    // yalnız Androidin öz təxmini; vermirsə (-1) vidcetdə "⚡ …" göstərilir
                    if (ms > 0) ms.coerceAtLeast(60_000L) else -1L
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Şarj gücü vatla (təxmini): cari cərəyan × gərginlik. Oxuna bilmirsə null */
    fun speedW(c: Context): Double? {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            val raw = Math.abs(c.getSystemService(BatteryManager::class.java).getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            if (mv <= 0 || raw == 0L) {
                null
            } else {
                // əksər cihazlar mikroamper verir; bəziləri miliamper (kiçik rəqəm) — ona görə yoxlanılır
                val amps = if (raw >= 20_000L) raw / 1_000_000.0 else raw / 1000.0
                amps * mv / 1000.0
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Tətbiqdə yenilə düyməsinin altında göstərmək üçün: iki sətir (güc, 100%-ə qalan dəqiqə). Şarjda deyilsə null */
    fun appLines(c: Context): List<String>? {
        val rem = remainingMs(c) ?: return null
        val out = ArrayList<String>()
        speedW(c)?.let { out.add("⚡ ${String.format(java.util.Locale.US, "%.1f", it)} W") }
        out.add(if (rem > 0) "100%-ə ${(rem / 60000).coerceAtLeast(1)} dəq" else "100%-ə … dəq")
        return out
    }

    private fun sticky(c: Context): Intent? =
        try { c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (e: Exception) { null }

    fun pluggedIn(c: Context): Boolean = (sticky(c)?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0

    fun percent(c: Context): Int {
        val i = sticky(c) ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (l < 0 || sc <= 0) -1 else (l * 100f / sc).roundToInt()
    }

    /** Şarjdadır və 100%-dir */
    fun full(c: Context): Boolean {
        val i = sticky(c) ?: return false
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        return plugged && (i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_FULL || percent(c) >= 100)
    }

    class Health(val status: String, val tempC: Double?, val volt: Double?, val cycles: Int?, val sohPct: Int?, val capMah: Int?)

    /** Batareya sağlamlığı: Androidin verdiyi qədər (bəzi telefonlar faiz və dövr sayını vermir) */
    fun health(c: Context): Health? {
        val i = sticky(c) ?: return null
        val status = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Yaxşı"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Həddindən artıq qızıb"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Sıradan çıxıb"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Gərginlik yüksəkdir"
            BatteryManager.BATTERY_HEALTH_COLD -> "Çox soyuqdur"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Naməlum nasazlıq"
            else -> "Məlum deyil"
        }
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        var cycles: Int? = null
        var soh: Int? = null
        val bm = c.getSystemService(BatteryManager::class.java)
        if (Build.VERSION.SDK_INT >= 34) {
            val cc = i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)
            if (cc > 0) cycles = cc
            try {
                val s = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATE_OF_HEALTH)
                if (s in 1..100) soh = s
            } catch (e: Exception) { }
        }
        // təxmini cari tutum: qalan yük / faiz (20%-dən aşağıda dəqiq deyil)
        var cap: Int? = null
        try {
            val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            val pct = percent(c)
            if (counter > 0 && pct >= 20) {
                val mah = (if (counter >= 50_000L) counter / 1000.0 else counter.toDouble()) * 100.0 / pct
                if (mah in 500.0..30000.0) cap = mah.roundToInt()
            }
        } catch (e: Exception) { }
        return Health(status, if (t == Int.MIN_VALUE) null else t / 10.0, if (mv > 0) mv / 1000.0 else null, cycles, soh, cap)
    }
}
