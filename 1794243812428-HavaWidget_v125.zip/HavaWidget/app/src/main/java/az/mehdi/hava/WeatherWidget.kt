package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.concurrent.atomic.AtomicBoolean
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import android.widget.RemoteViews
import kotlin.math.roundToInt

class WeatherWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        Scheduler.start(context)
        Midnight.schedule(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
    }

    /** Vidcetin ölçüsü dəyişəndə (yalnız bu halda) görünüş yenidən seçilir */
    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, newOptions: android.os.Bundle?) {
        refresh(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Scheduler.start(context)
        Midnight.schedule(context)
        ChargeAlert.arm(context)
        refresh(context)
    }

    companion object {
        fun refresh(c: Context) {
            Battery.drainUpdate(c) // boşalma proqnozu üçün faiz nümunəsi
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return
            val rv = try { build(c, scaleFor(c)) } catch (e: Throwable) {
                // yükləmə xətası vidceti boş/"yüklənə bilmir" qoymasın: sadə ehtiyat görünüş
                RemoteViews(c.packageName, R.layout.widget).apply {
                    try { setTextViewText(R.id.w_title, "Yenilənir…") } catch (t: Throwable) { }
                    try { setOnClickPendingIntent(R.id.w_root, Notif.open(c)) } catch (t: Throwable) { }
                }
            }
            try { m.updateAppWidget(ids, rv) } catch (e: Throwable) {
                // RemoteViews yeniləməsi uğursuz olsa belə widget-ə minimal, etibarlı görünüş göndər.
                try {
                    val safe = RemoteViews(c.packageName, R.layout.widget)
                    safe.setTextViewText(R.id.w_dm, T.dayMonth())
                    safe.setTextViewText(R.id.w_wd, T.weekday())
                    safe.setTextViewText(R.id.w_title, "Hava yenilənir…")
                    safe.setOnClickPendingIntent(R.id.w_root, Notif.open(c))
                    m.updateAppWidget(ids, safe)
                } catch (_: Throwable) { }
            }
        }


        /** Vidcetin real ölçüsünə (dp) görə miqyas: məzmun ~340x380dp-lik dizayndır, 4x4 (≈250dp) üçün 0.55-ə qədər kiçilir */
        private fun scaleFor(c: Context): Float = try {
            val m = AppWidgetManager.getInstance(c)
            val id = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java)).firstOrNull()
            if (id == null) 0.7f else {
                val o = m.getAppWidgetOptions(id)
                val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0).takeIf { it > 0 }
                    ?: o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
                val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
                val sh = if (h > 0) h / 380f else 0.7f
                val sw = if (w > 0) w / 340f else 0.7f
                minOf(sh, sw).coerceIn(0.55f, 1.05f)
            }
        } catch (e: Throwable) { 0.7f }

        private fun ts(rv: RemoteViews, id: Int, base: Float, s: Float) {
            rv.setTextViewTextSize(id, android.util.TypedValue.COMPLEX_UNIT_SP, base * s)
        }

        private fun applySizes(rv: RemoteViews, s: Float) {
            ts(rv, R.id.w_clock, 40f, s); ts(rv, R.id.w_dm, 17f, s); ts(rv, R.id.w_wd, 13f, s)
            ts(rv, R.id.w_sky_t, 9f, s); ts(rv, R.id.w_word, 9f, s); ts(rv, R.id.w_proverb, 9f, s); ts(rv, R.id.w_title, 17f, s)
            INFO_IDS.forEach { ts(rv, it, 10.5f, s) }
            ts(rv, R.id.w_pressure, 10.5f, s); ts(rv, R.id.w_fog, 10.5f, s); ts(rv, R.id.w_prh, 10.5f, s)
            ts(rv, R.id.w_steps, 12f, s); ts(rv, R.id.w_km, 12f, s); ts(rv, R.id.w_heart, 12f, s)
            ts(rv, R.id.w_outlook, 11f, s); ts(rv, R.id.w_wear, 11f, s)
            T_IDS.forEach { ts(rv, it, 11f, s) }
        }

        private val INFO_IDS = intArrayOf(R.id.w_i1, R.id.w_i2, R.id.w_i3, R.id.w_i4, R.id.w_i5, R.id.w_i6)

        private val T_IDS = intArrayOf(R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5, R.id.w_t6,
            R.id.w_t7, R.id.w_t8)

        /** Saatlıq xana mətni: saat / temperatur / yağış % (ikon yuxarıda, ayrıca) */
        private fun hourText(time: String, temp: Int, prob: Int, mm: Double, snow: Double): CharSequence {
            val sb = SpannableStringBuilder()
            fun add(t: String, size: Float, color: Int, bold: Boolean) {
                val s = sb.length
                sb.append(t)
                val f = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                sb.setSpan(RelativeSizeSpan(size), s, sb.length, f)
                sb.setSpan(ForegroundColorSpan(color), s, sb.length, f)
                if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, f)
            }
            add(time, 1.0f, Color.parseColor("#CFD8DC"), false)
            sb.append("\n")
            add("$temp°", 1.2f, Color.WHITE, true)
            sb.append("\n")
            add("$prob%", 0.9f, Color.parseColor("#4FC3F7"), true)
            sb.append("\n")
            add(fmtPrecip(mm, snow), 0.78f, Color.parseColor("#81D4FA"), false)
            sb.append("\n")
            add(precipShort(mm, snow), 0.66f, Color.parseColor("#B3E5FC"), false)
            return sb
        }

        /** Mətnin solunda ikon göstərir (sol ikon: ad + ölçü) */
        private fun left(c: Context, rv: RemoteViews, id: Int, text: CharSequence, icon: String, size: String) {
            rv.setTextViewText(id, text)
            rv.setTextViewCompoundDrawables(id, Ic.id(c, icon, size), 0, 0, 0)
            rv.setViewVisibility(id, View.VISIBLE)
        }


        /** 40dp-lik böyük ikon (xxl); tapılmasa köhnə xl ikonuna qayıdır */
        private fun skyRes(c: Context, name: String): Int {
            val id = Ic.id(c, name, "xxl")
            return if (id != 0) id else Ic.id(c, name, "xl")
        }

        /**
         * Tarix ilə analoq saat arasında: gecə (Ay üfüqdə olan vaxt = Günəş batandan doğana qədər) Ay fazası,
         * gündüz Günəş. Günəşin altında gün uzunluğunun sabaha görə artması (▲) / azalması (▼) dəqiqə ilə yazılır.
         */
        private fun skyIcon(c: Context, rv: RemoteViews, w: Weather?, scale: Float) {
            try {
                // ikon rəqəmsal saatın hündürlüyündə (40dp x miqyas); Android 12+ üçün dinamik, əvvəlkilərdə sabit 40dp
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    val dp = 40f * scale
                    rv.setViewLayoutWidth(R.id.w_sky, dp, android.util.TypedValue.COMPLEX_UNIT_DIP)
                    rv.setViewLayoutHeight(R.id.w_sky, dp, android.util.TypedValue.COMPLEX_UNIT_DIP)
                }
                val dl = w?.dayLight()
                val now = java.time.LocalTime.now(BAKU)
                val m = now.hour * 60 + now.minute
                val sr = if (dl != null && dl.sunriseMin >= 0) dl.sunriseMin else 6 * 60
                val ss = if (dl != null && dl.sunsetMin >= 0) dl.sunsetMin else 19 * 60
                val day = m in sr until ss
                if (day) {
                    rv.setImageViewResource(R.id.w_sky, skyRes(c, "clear"))
                    // işıq gün doğanda zəif, günorta ən güclü, batanda yenə zəif (sinus əyrisi)
                    val f = Math.sin(Math.PI * (m - sr).toDouble() / (ss - sr).coerceAtLeast(1)).coerceIn(0.0, 1.0)
                    rv.setInt(R.id.w_sky, "setImageAlpha", (70 + 185 * f).toInt())
                    val d = dl?.diffMin ?: 0
                    rv.setTextViewText(R.id.w_sky_t, when {
                        d > 0 -> "▲ ${d}d"
                        d < 0 -> "▼ ${-d}d"
                        else -> "="
                    })
                    rv.setTextColor(R.id.w_sky_t, if (d < 0) Color.parseColor("#FF8A80") else Color.parseColor("#B9F6CA"))
                } else {
                    val mi = Moon.info()
                    rv.setImageViewResource(R.id.w_sky, skyRes(c, mi.icon))
                    rv.setInt(R.id.w_sky, "setImageAlpha", 255)
                    rv.setTextViewText(R.id.w_sky_t, "${mi.illum}%")
                    rv.setTextColor(R.id.w_sky_t, Color.parseColor("#FFD54F"))
                }
                rv.setOnClickPendingIntent(R.id.w_sky_box, Notif.openSection(c, "sky"))
            } catch (e: Throwable) { }
        }

        private fun build(c: Context, scale: Float): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            applySizes(rv, scale)
            if (android.os.Build.VERSION.SDK_INT >= 31) try {
                rv.setViewLayoutHeight(R.id.w_sp1, 6f * scale, android.util.TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutHeight(R.id.w_sp2, 9f * scale, android.util.TypedValue.COMPLEX_UNIT_DIP)
            } catch (e: Throwable) { }
            val ics = if (scale >= 0.95f) "xl" else if (scale >= 0.75f) "l" else ""
            val w = WeatherApi.cached(c)
            val n = w?.nowIndex() ?: -1
            rv.setTextViewText(R.id.w_dm, T.dayMonth())
            rv.setTextViewText(R.id.w_wd, T.weekday())
            skyIcon(c, rv, w, scale)
            left(c, rv, R.id.w_word, Daily.word(c), "bulb", "s")
            left(c, rv, R.id.w_proverb, Daily.proverb(c), "book", "s")
            rv.removeAllViews(R.id.w_days)
            INFO_IDS.forEach { rv.setViewVisibility(it, View.GONE) }
            rv.setViewVisibility(R.id.w_wear, View.GONE)
            if (w == null || n < 0) {
                rv.setTextViewText(R.id.w_title, "Yenilənir…")
                rv.setTextViewCompoundDrawables(R.id.w_title, 0, 0, 0, 0)
                rv.setTextViewText(R.id.w_outlook, "İnternet bağlantısı olanda məlumat yüklənəcək")
                rv.setTextViewCompoundDrawables(R.id.w_outlook, 0, 0, 0, 0)
            } else {
                val h = w.hours[n]
                // 6 ikonlu tək sətir: təzyiq, duman, yağıntı saatı (söz əvəzinə ikon)
                left(c, rv, R.id.w_pressure, if (!h.press.isNaN()) "${(h.press * 0.750062).roundToInt()}" else "—", "press", "")
                val fogText = when {
                    h.code == 45 || h.code == 48 -> if (!h.vis.isNaN()) visText(h.vis).toString() else "var"
                    !h.vis.isNaN() && h.vis < 1000 -> visText(h.vis).toString()
                    !h.vis.isNaN() -> "yox"
                    else -> "—"
                }
                left(c, rv, R.id.w_fog, fogText, "fog", "")
                val today = w.upcomingDays().firstOrNull()
                left(c, rv, R.id.w_prh, "${if (today != null) w.precipHours(today) else 0} saat", "rain", "")
                rv.setOnClickPendingIntent(R.id.w_pressure, Notif.openSection(c, "top"))
                rv.setOnClickPendingIntent(R.id.w_fog, Notif.openSection(c, "top"))
                rv.setOnClickPendingIntent(R.id.w_prh, Notif.openSection(c, "hours"))
                left(c, rv, R.id.w_title, "${h.temp.roundToInt()}°  ${T.desc(h.code)}", T.iconName(h.code), ics)
                val o = w.outlook()
                left(c, rv, R.id.w_outlook, o?.text ?: "", T.kindIcon(o?.kind), "")
                // geyim: hər sətir öz emojisi ilə — 👕 Üst, 👖 Alt, 👟 Ayaqqabı (mətn kəsilmədən tam)
                val emoji = listOf("👕", "👖", "👟")
                val wear = Wear.now(w, n).lines.take(3).mapIndexed { i, l -> "${emoji[i]} ${l.second}" }.joinToString("\n")
                rv.setTextViewText(R.id.w_wear, wear)
                rv.setTextViewCompoundDrawables(R.id.w_wear, 0, 0, 0, 0)
                rv.setViewVisibility(R.id.w_wear, View.VISIBLE)
                w.widgetInfo(n).forEachIndexed { r, row ->
                    row.take(3).forEachIndexed { i, p ->
                        left(c, rv, INFO_IDS[r * 3 + i], p.second, p.first, "")
                        val sec = when (p.first) { "thermo" -> "wear"; "sunrise", "sunset" -> "sky"; "wind", "clear", "leaf", "drop" -> p.first; else -> "top" }
                        rv.setOnClickPendingIntent(INFO_IDS[r * 3 + i], Notif.openSection(c, sec))
                    }
                }
                // növbəti 8 saat: tək sətirdə
                for (j in 1..8) {
                    val idx = n + j
                    if (idx >= w.hours.size) break
                    val hh = w.hours[idx]
                    val id = T_IDS[j - 1]
                    rv.setTextViewText(id, hourText(hh.time.substring(11, 16), hh.temp.roundToInt(), hh.prob, hh.mm, hh.snow))
                    rv.setTextViewCompoundDrawables(id, 0, Ic.id(c, T.iconName(hh.code), ics), 0, 0)
                    // Yağıntılı saatlərdə də həftəlik kartlardakı kimi yumşaq, bir qədər tünd fon
                    when (w.kindOf(hh, true)) {
                        "yağış", "tufan" -> rv.setInt(id, "setBackgroundResource", R.drawable.frame_rain)
                        "qar" -> rv.setInt(id, "setBackgroundResource", R.drawable.frame_snow)
                        else -> rv.setInt(id, "setBackgroundResource", R.drawable.frame_none)
                    }
                    rv.setOnClickPendingIntent(id, Notif.openSection(c, "hours"))
                }
                w.upcomingDays().forEachIndexed { i, d ->
                    val r = RemoteViews(c.packageName, R.layout.widget_day)
                    ts(r, R.id.d_name, 10.5f, scale); ts(r, R.id.d_max, 13.5f, scale); ts(r, R.id.d_min, 11.5f, scale)
                    ts(r, R.id.d_rain, 9.5f, scale); ts(r, R.id.d_mm, 9.5f, scale); ts(r, R.id.d_label, 8f, scale); ts(r, R.id.d_hours, 9.5f, scale)
                    r.setTextViewText(R.id.d_name, if (i == 0) "Bu gün" else T.dayName(d.date))
                    r.setImageViewResource(R.id.d_icon, Ic.id(c, T.iconName(d.code), ics))
                    if (android.os.Build.VERSION.SDK_INT >= 31) try {
                        r.setViewLayoutWidth(R.id.d_icon, 24f * scale, android.util.TypedValue.COMPLEX_UNIT_DIP)
                        r.setViewLayoutHeight(R.id.d_icon, 24f * scale, android.util.TypedValue.COMPLEX_UNIT_DIP)
                    } catch (e: Throwable) { }
                    r.setTextViewText(R.id.d_max, "${d.max.roundToInt()}°")
                    r.setTextViewText(R.id.d_min, "${d.min.roundToInt()}°")
                    r.setTextViewText(R.id.d_rain, "${d.prob}%")
                    r.setTextViewText(R.id.d_mm, fmtPrecip(d.mm, d.snow))
                    r.setTextViewText(R.id.d_label, if (d.snow < 0.1 && d.mm < 0.05) "Yağıntı yoxdur" else precipShort(d.mm, d.snow))
                    r.setTextViewText(R.id.d_hours, "${w.precipHours(d)} saat")
                    val frame = when (d.frameKind()) {
                        "qar" -> R.drawable.frame_snow
                        "yağış" -> R.drawable.frame_rain
                        "külək" -> R.drawable.frame_wind
                        else -> R.drawable.frame_none
                    }
                    r.setInt(R.id.d_box, "setBackgroundResource", frame)
                    r.setOnClickPendingIntent(R.id.d_box, Notif.openSection(c, "days"))
                    rv.addView(R.id.w_days, r)
                }
            }
            left(c, rv, R.id.w_steps, Steps.stepsText(c), "steps", "")
            left(c, rv, R.id.w_km, Steps.kmText(c).replace(" km", ""), "ruler", "")
            val hr = Heart.last(c)
            rv.setTextViewText(R.id.w_heart, if (hr == null) "❤️ Ölç" else "❤️ ${hr.second}")
            rv.setOnClickPendingIntent(R.id.w_root, Notif.open(c))
            rv.setOnClickPendingIntent(R.id.w_title, Notif.openSection(c, "top"))
            rv.setOnClickPendingIntent(R.id.w_outlook, Notif.openSection(c, "outlook"))
            rv.setOnClickPendingIntent(R.id.w_wear, Notif.openSection(c, "wear"))
            rv.setOnClickPendingIntent(R.id.w_steps, Notif.openSection(c, "steps"))
            rv.setOnClickPendingIntent(R.id.w_km, Notif.openSection(c, "steps"))
            rv.setOnClickPendingIntent(R.id.w_heart, Heart.open(c))
            return rv
        }
    }
}
