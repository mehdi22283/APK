package `is`.xyz.mpv

import android.content.Context
import android.graphics.Bitmap
import android.view.Surface

/**
 * mpv-android JNI körpüsü. libplayer.so bu sinfin adına (is.xyz.mpv.MPVLib) bağlıdır — paket/ad dəyişdirilməməlidir.
 * Native tərəf event/eventProperty/logMessage statik metodlarını çağırır (hamısı @JvmStatic olmalıdır).
 */
object MPVLib {
    init {
        // Sıra vacibdir: libplayer.so libmpv.so və libav* kitabxanalarından asılıdır.
        for (lib in arrayOf("mpv", "player")) System.loadLibrary(lib)
    }

    external fun create(appctx: Context)
    external fun init()
    external fun destroy()
    external fun attachSurface(surface: Surface)
    external fun detachSurface()

    external fun command(cmd: Array<out String>)

    external fun setOptionString(name: String, value: String): Int

    external fun grabThumbnail(dimension: Int): Bitmap?

    external fun getPropertyInt(property: String): Int?
    external fun setPropertyInt(property: String, value: Int)
    external fun getPropertyDouble(property: String): Double?
    external fun setPropertyDouble(property: String, value: Double)
    external fun getPropertyBoolean(property: String): Boolean?
    external fun setPropertyBoolean(property: String, value: Boolean)
    external fun getPropertyString(property: String): String?
    external fun setPropertyString(property: String, value: String)

    external fun observeProperty(property: String, format: Int)

    private val observers = java.util.concurrent.CopyOnWriteArrayList<EventObserver>()
    private val logObservers = java.util.concurrent.CopyOnWriteArrayList<LogObserver>()

    fun addObserver(o: EventObserver) { observers.add(o) }
    fun removeObserver(o: EventObserver) { observers.remove(o) }
    fun addLogObserver(o: LogObserver) { logObservers.add(o) }
    fun removeLogObserver(o: LogObserver) { logObservers.remove(o) }

    // ---- native tərəfdən çağırılan geri çağırışlar (mpv event thread-i) ----
    @JvmStatic fun eventProperty(property: String, value: Long) { for (o in observers) o.eventProperty(property, value) }
    @JvmStatic fun eventProperty(property: String, value: Boolean) { for (o in observers) o.eventProperty(property, value) }
    @JvmStatic fun eventProperty(property: String, value: Double) { for (o in observers) o.eventProperty(property, value) }
    @JvmStatic fun eventProperty(property: String, value: String) { for (o in observers) o.eventProperty(property, value) }
    @JvmStatic fun eventProperty(property: String) { for (o in observers) o.eventProperty(property) }
    @JvmStatic fun event(eventId: Int) { for (o in observers) o.event(eventId) }
    @JvmStatic fun logMessage(prefix: String, level: Int, text: String) { for (o in logObservers) o.logMessage(prefix, level, text) }

    interface EventObserver {
        fun eventProperty(property: String)
        fun eventProperty(property: String, value: Long)
        fun eventProperty(property: String, value: Boolean)
        fun eventProperty(property: String, value: Double)
        fun eventProperty(property: String, value: String)
        fun event(eventId: Int)
    }

    interface LogObserver {
        fun logMessage(prefix: String, level: Int, text: String)
    }

    object MpvFormat {
        const val NONE = 0
        const val STRING = 1
        const val FLAG = 3
        const val INT64 = 4
        const val DOUBLE = 5
    }

    object MpvEvent {
        const val SHUTDOWN = 1
        const val START_FILE = 6
        const val END_FILE = 7
        const val FILE_LOADED = 8
        const val VIDEO_RECONFIG = 17
        const val AUDIO_RECONFIG = 18
        const val PLAYBACK_RESTART = 21
    }
}
