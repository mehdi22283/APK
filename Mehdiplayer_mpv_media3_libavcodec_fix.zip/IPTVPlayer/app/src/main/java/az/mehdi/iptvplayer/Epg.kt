package az.mehdi.iptvplayer

import android.content.Context
import android.util.Xml
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.FileOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.zip.GZIPInputStream

/** Yeganə mənbə: EPG (proqram cədvəli) və kanal loqoları buradan alınır. Fayl .gz-dir, açılıb XML kimi oxunur. */
const val EPG_URL = "https://iptvx.one/EPG_NOARCH"

class Prog(val start: Long, var stop: Long, val title: String, val desc: String)

/** Təsvir uzunluğu limiti (2 GB RAM: bütün kanalların proqramları yaddaşda durur) və təkrarlanan başlıqlar üçün ortaq sətir hovuzu. */
private const val EPG_DESC_MAX = 160

private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm").withZone(ZoneId.systemDefault())
fun hm(t: Long): String = HM.format(Instant.ofEpochSecond(t))

/** Bu gün üçün boş, sabah üçün "Sabah", sonrası üçün "dd.MM". */
fun dayLabel(t: Long): String {
    val d = Instant.ofEpochSecond(t).atZone(ZoneId.systemDefault()).toLocalDate()
    val today = java.time.LocalDate.now()
    return when (d) {
        today -> ""
        today.plusDays(1) -> "Sabah"
        else -> "%02d.%02d".format(d.dayOfMonth, d.monthValue)
    }
}

private val BRACKETS = Regex("[\\[(].*?[\\])]")
private val QUALITY = Regex("\\b(hd|fhd|uhd|sd|4k|8k|hevc|h265|backup|ehtiyat|biraz|tr|az)\\b")
private val MODIFIERS = Regex("\\p{Lm}+")
private val NON_ALNUM = Regex("[^\\p{L}\\p{N}]")
private val MARKS = Regex("\\p{Mn}+")

/** Kanal adını müqayisə üçün sadələşdirir (kiril hərfləri də qalır). */
fun normKey(s: String): String {
    var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
    t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(MARKS, "")
    t = t.replace(MODIFIERS, " ").replace(BRACKETS, " ").replace(QUALITY, " ")
    return t.replace(NON_ALNUM, "")
}

/**
 * Loqo üçün SƏRT ad açarı: yalnız eyni adın latın (Azərbaycan əlifbası) hərf qarşılığı ilə yazılışı eyni sayılır.
 * Kiril hərfləri latın Azərbaycan qarşılığına çevrilir; oxşar/yaxın adlar (Kanal S ≠ Kanal D, Ayaz TV ≠ AzTV) eyni DEYİL.
 */
private val CYR_TO_AZ = mapOf(
    'а' to "a", 'б' to "b", 'в' to "v", 'г' to "q", 'д' to "d", 'е' to "e", 'ё' to "yo", 'ж' to "j", 'з' to "z",
    'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
    'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "x", 'ц' to "c", 'ч' to "ç", 'ш' to "ş", 'щ' to "ş",
    'ы' to "ı", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ә' to "ə", 'ғ' to "ğ", 'ү' to "ü", 'ө' to "ö", 'қ' to "q",
    'ң' to "n", 'һ' to "h", 'ъ' to "", 'ь' to ""
)
private val LOGO_QUALITY = Regex("\\b(hd|fhd|uhd|sd|4k|8k|hevc|h265|backup|ehtiyat)\\b")

fun logoKey(s: String): String {
    val sb = StringBuilder()
    for (ch in s.replace('İ', 'i').replace('I', 'ı').lowercase()) sb.append(CYR_TO_AZ[ch] ?: ch.toString())
    var t = sb.toString().replace('ə', 'e').replace('ı', 'i')
    t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(MARKS, "")
    t = t.replace(MODIFIERS, " ").replace(BRACKETS, " ").replace(LOGO_QUALITY, " ")
    return t.replace(NON_ALNUM, "")
}

/** Diakritiksiz, durğusuz sadə açar (hd/tr/4k kimi sözlər SAXLANILIR). */
fun rawKey(s: String): String {
    var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
    t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(MARKS, "")
    return t.replace(NON_ALNUM, "")
}

private val ALIAS_SUFFIXES = listOf("fhd", "uhd", "hd", "tr", "az", "sd")

/** Ad üçün namizəd açarlar: tam açar + sonundakı hd/tr/sd... atılmış variantlar + sadələşdirilmiş açar. */
fun aliasCandidates(name: String): Set<String> {
    val out = LinkedHashSet<String>()
    var k = rawKey(name.replace(BRACKETS, " "))
    if (k.isNotEmpty()) out.add(k)
    var changed = true
    while (changed) {
        changed = false
        for (suf in ALIAS_SUFFIXES) {
            if (k.length > suf.length + 2 && k.endsWith(suf)) { k = k.removeSuffix(suf); out.add(k); changed = true; break }
        }
    }
    normKey(name).takeIf { it.isNotEmpty() }?.let { out.add(it) }
    return out
}

/**
 * Əl ilə əlaqələndirmə: XML-dəki kanal adı/id-si (slug) -> playlistdəki kanal adlarının açarları.
 * Adlar hd/tr/boşluq/diakritikdən asılı olmadan tutulur (məs. "TRT 4K", "TV8.5", "TRT Çocuk").
 * Qeyd: "trtspor" burada YOXDUR — TRT Spor ilə TRT Spor Yıldız fərqli kanallardır.
 */
private val EPG_ALIASES: List<Pair<String, List<String>>> = listOf(
    "cbc-sport" to listOf("cbcsport"),
    "ictimai-tv" to listOf("ictimaitv", "ictimai", "ictimaitelevizyasi"),
    "muztv" to listOf("muztv", "muz"),
    "kanal-7-hd-tr" to listOf("kanal7", "kanal7tv"),
    "show-hd-tr" to listOf("showtv", "show"),
    "star-tv-hd-tr" to listOf("startv", "star"),
    "tv8-tr" to listOf("tv8"),
    "tv85-tr" to listOf("tv85"),
    "trt-1-hd" to listOf("trt1"),
    "trt-2-hd" to listOf("trt2"),
    "trt-3-hd" to listOf("trt3"),
    "trt-avaz" to listOf("trtavaz"),
    "trt-cocuk-tr" to listOf("trtcocuk"),
    "trt-haber-hd" to listOf("trthaber"),
    "trt-muzik-tr" to listOf("trtmuzik"),
    "trt-spor-yild-tr" to listOf("trtsporyildiz", "trtsporyild", "trtspor2"),
    "trt-turk-tr" to listOf("trtturk"),
    "trt4k-tr" to listOf("trt4k"),
    "dmax-tr" to listOf("dmax", "dmaxtv")
)

private const val SNAP_MAGIC = 0x45504704

private class Snap(
    val idByUrl: Map<String, String>,
    val logoIdByUrl: Map<String, String>,
    val icons: Map<String, String>,
    val progs: Map<String, List<Prog>>,
    val time: Long = System.currentTimeMillis()
)

class EpgStore(private val ctx: Context) {
    @Volatile private var snap = Snap(emptyMap(), emptyMap(), emptyMap(), emptyMap())
    /** İlk yükləmə cəhdi bitəndə (uğurlu və ya uğursuz) tamamlanır; loqo axtarışı bunu gözləyir. */
    val ready = CompletableDeferred<Unit>()
    private val lock = Mutex()
    private var sig = 0
    private val file = File(ctx.filesDir, "epg_source.bin")
    /** Hazır (parse olunmuş) EPG + loqo linkləri: açılışda böyük XML-i yenidən oxumadan dərhal, offline yüklənir. */
    private val snapFile = File(ctx.filesDir, "epg_snap.bin")

    private fun saveSnap(s: Snap, sg: Int) {
        val tmp = File(snapFile.path + ".tmp")
        try {
            DataOutputStream(BufferedOutputStream(FileOutputStream(tmp), 64 * 1024)).use { o ->
                o.writeInt(SNAP_MAGIC); o.writeInt(sg)
                o.writeUTF(prefs.getString("sha", null) ?: "")
                o.writeLong(s.time)
                o.writeInt(s.idByUrl.size)
                for ((k, v) in s.idByUrl) { o.writeUTF(k); o.writeUTF(v) }
                o.writeInt(s.logoIdByUrl.size)
                for ((k, v) in s.logoIdByUrl) { o.writeUTF(k); o.writeUTF(v) }
                o.writeInt(s.icons.size)
                for ((k, v) in s.icons) { o.writeUTF(k); o.writeUTF(v) }
                o.writeInt(s.progs.size)
                for ((id, l) in s.progs) {
                    o.writeUTF(id); o.writeInt(l.size)
                    for (p in l) { o.writeLong(p.start); o.writeLong(p.stop); o.writeUTF(p.title); o.writeUTF(p.desc) }
                }
            }
            if (snapFile.exists()) snapFile.delete()
            if (!tmp.renameTo(snapFile)) tmp.delete()
        } catch (e: Throwable) {
            tmp.delete()
        }
    }

    /** Playlist və EPG mənbəyi dəyişməyibsə hazır nüsxəni qaytarır, əks halda null (o zaman fayl parse olunur). */
    private fun loadSnap(sg: Int): Snap? {
        if (!snapFile.exists()) return null
        val sha = prefs.getString("sha", null)?.takeIf { it.isNotEmpty() } ?: return null
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(snapFile), 64 * 1024)).use { i ->
                if (i.readInt() != SNAP_MAGIC || i.readInt() != sg || i.readUTF() != sha) return null
                val time = i.readLong()
                val n1 = i.readInt()
                if (n1 < 0 || n1 > 2_000_000) return null
                val ids = HashMap<String, String>(n1 * 2)
                repeat(n1) { val k = i.readUTF(); val v = i.readUTF(); ids[k] = v }
                val nl = i.readInt()
                if (nl < 0 || nl > 2_000_000) return null
                val lids = HashMap<String, String>(nl * 2)
                repeat(nl) { val k = i.readUTF(); val v = i.readUTF(); lids[k] = v }
                val n2 = i.readInt()
                if (n2 < 0 || n2 > 2_000_000) return null
                val icons = HashMap<String, String>(n2 * 2)
                repeat(n2) { val k = i.readUTF(); val v = i.readUTF(); icons[k] = v }
                val n3 = i.readInt()
                if (n3 < 0 || n3 > 2_000_000) return null
                val progs = HashMap<String, List<Prog>>(n3 * 2)
                val pool = HashMap<String, String>()
                repeat(n3) {
                    val id = i.readUTF()
                    val n = i.readInt()
                    val l = ArrayList<Prog>(n.coerceIn(0, 10_000))
                    repeat(n) {
                        val st = i.readLong(); val sp = i.readLong(); val t0 = i.readUTF(); val d0 = i.readUTF()
                        val t = pool.getOrPut(t0) { t0 }
                        val d = if (d0.length > EPG_DESC_MAX) d0.substring(0, EPG_DESC_MAX) else d0
                        l.add(Prog(st, sp, t, d))
                    }
                    progs[id] = l
                }
                Snap(ids, lids, icons, progs, time)
            }
        } catch (e: Throwable) {
            null
        }
    }

    /** Kanalın proqram siyahısı: əvvəl kanala xas əlavə EPG (azepg.ddns.net), yoxdursa əsas mənbə. */
    private fun listFor(ch: Channel): List<Prog>? =
        ext[ch.url] ?: snap.idByUrl[ch.url]?.let { snap.progs[it] }
    /** Loqo üçün SƏRT uyğunlaşma (tvg-id və ya dəqiq ad); oxşar ad axtarışı yoxdur. */
    fun logoIdFor(ch: Channel): String? = snap.logoIdByUrl[ch.url]
    fun iconUrl(id: String): String? = snap.icons[id]

    /** Kanalın indi gedən və sonrakı bütün proqramları (cədvəl). */
    fun programs(ch: Channel): List<Prog> {
        val t = System.currentTimeMillis() / 1000
        return listFor(ch).orEmpty().filter { it.stop > t }
    }

    fun nowNext(ch: Channel): Pair<Prog?, Prog?> {
        val list = listFor(ch) ?: return null to null
        val t = System.currentTimeMillis() / 1000
        var now: Prog? = null
        var next: Prog? = null
        for (p in list) {
            if (p.start <= t && t < p.stop) now = p
            else if (p.start > t) { next = p; break }
        }
        return now to next
    }

    // ---------- Kanala xas əlavə EPG (azepg.ddns.net) ----------
    /** Kanal url-i -> proqramlar. Boş fayl/köhnə tarix olan kanallar bura düşmür, onlar əsas mənbədən qalır. */
    @Volatile private var ext: Map<String, List<Prog>> = emptyMap()
    private val extLock = Mutex()
    private val extLast = HashMap<String, Long>()

    private fun extFile(key: String) = File(ctx.filesDir, "epg_ext_$key.xml")

    private fun buildExt(channels: List<Channel>): Map<String, List<Prog>> {
        val now = System.currentTimeMillis() / 1000
        val perKey = HashMap<String, List<Prog>>()
        val out = HashMap<String, List<Prog>>()
        for (c in channels) {
            val k = ExtEpg.key(c) ?: continue
            val l = perKey.getOrPut(k) {
                val f = extFile(k)
                if (f.exists()) runCatching { ExtEpg.parse(f, now) }.getOrNull().orEmpty() else emptyList()
            }
            if (l.isNotEmpty()) out[c.url] = l
        }
        return out
    }

    private fun sameExt(a: Map<String, List<Prog>>, b: Map<String, List<Prog>>): Boolean {
        if (a.size != b.size) return false
        for ((k, v) in a) if (!sameProgs(v, b[k])) return false
        return true
    }

    /** Telefondakı əlavə EPG fayllarını (şəbəkəsiz) oxuyur. Dəyişiklik olubsa true. */
    suspend fun loadExtCached(channels: List<Channel>): Boolean = extLock.withLock {
        try {
            withContext(Dispatchers.IO) {
                val m = lowPriority { buildExt(channels) }
                val changed = !sameExt(ext, m)
                ext = m
                changed
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Əlavə EPG fayllarını yeniləyir (hər fayl ən çox 30 dəqiqədə bir; force=true olsa dərhal).
     * dlOnly verilibsə yalnız o kanalın faylı endirilir (ən çox 10 dəqiqədə bir). Endirmə alınmasa köhnə fayl qalır.
     */
    suspend fun updateExt(channels: List<Channel>, force: Boolean = false, dlOnly: Channel? = null): Boolean = extLock.withLock {
        try {
            withContext(Dispatchers.IO) {
                val nowMs = android.os.SystemClock.elapsedRealtime()
                val keys = if (dlOnly != null) listOfNotNull(ExtEpg.key(dlOnly)) else channels.mapNotNull { ExtEpg.key(it) }.distinct()
                for (k in keys) {
                    val f = extFile(k)
                    val last = extLast[k] ?: 0L
                    val minGap = if (dlOnly != null) 10 * 60 * 1000L else 30 * 60 * 1000L
                    if (f.exists() && nowMs - last < minGap && !(force && dlOnly == null)) continue
                    extLast[k] = nowMs
                    try { fetchToFile(ExtEpg.url(k), f, 20000) } catch (e: Exception) { /* köhnə fayl qalır */ }
                }
                val m = lowPriority { buildExt(channels) }
                val changed = !sameExt(ext, m)
                ext = m
                changed
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            false
        }
    }

    /** Kanal dəyişəndə: əlavə EPG-si olan kanalın indi/sonrakı proqramı yoxdursa faylı yenidən yoxlayır. */
    suspend fun refreshExtChannel(ch: Channel, channels: List<Channel>): Boolean {
        if (ExtEpg.key(ch) == null) return false
        val (n, x) = nowNext(ch)
        if (n != null && x != null) return false
        return updateExt(channels, true, ch)
    }

    private fun sigOf(channels: List<Channel>) =
        channels.size * 31 + channels.fold(0) { a, c -> a * 31 + c.url.hashCode() }

    /** Telefonda saxlanılan EPG nüsxəsini dərhal yükləyir (şəbəkə gözləmədən). Dəyişiklik olubsa true. */
    suspend fun loadCached(channels: List<Channel>): Boolean = lock.withLock {
        val s = sigOf(channels)
        if (s == sig || !(file.exists() || snapFile.exists())) return@withLock false
        var changed = false
        try {
            withContext(Dispatchers.IO) {
                val fast = loadSnap(s)
                if (fast != null) {
                    snap = fast; sig = s; changed = true      // hazır nüsxə: parse yoxdur, dərhal açılır
                } else if (file.exists()) {
                    val ns = parse(file, channels)
                    snap = ns; sig = s; changed = true
                    saveSnap(ns, s)
                }
            }
            if (changed) ready.complete(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            changed = false
        }
        changed
    }

    /**
     * Mənbədə yenilik varsa (ETag / Last-Modified / məzmun hash-i) tam endirir, .gz-i açıb yoxlayır və
     * yalnız tam uğurlu olarsa bütün EPG-ni birdəfəlik əvəz edir. Playlist dəyişibsə keşdən yenidən uyğunlaşdırır.
     * Dəyişiklik olubsa true; mənbənin özü yenilənibsə `sourceUpdated` true olur.
     */
    @Volatile private var sourceUpdated = false
    /** Mənbə yenilənibsə true qaytarır və bayrağı təmizləyir. */
    fun consumeSourceUpdated(): Boolean { val v = sourceUpdated; sourceUpdated = false; return v }

    suspend fun update(channels: List<Channel>, force: Boolean = false): Boolean = lock.withLock {
        val s = sigOf(channels)
        var changed = false
        try {
            withContext(Dispatchers.IO) {
                var newSnap: Snap? = null
                var dl: Dl? = null
                val nowMs = android.os.SystemClock.elapsedRealtime()
                if (force || nowMs - lastCheck > 60 * 1000L || !file.exists()) {
                    lastCheck = nowMs
                    val got = download()
                    if (got != null) {
                        newSnap = runCatching { parse(got.f, channels) }.getOrNull()
                        if (newSnap == null) got.f.delete() // zədəli/yarımçıq: köhnə qalır
                        else dl = got
                    }
                }
                if (newSnap == null && file.exists() && s != sig) newSnap = parse(file, channels)
                if (newSnap != null) {
                    if (dl != null) {
                        if (file.exists()) file.delete()
                        dl.f.renameTo(file)
                        prefs.edit().putString("etag", dl.etag).putString("lm", dl.lm).putString("sha", dl.sha).apply()
                        sourceUpdated = true
                    }
                    snap = newSnap; sig = s; changed = true // hamısı birdən dəyişir
                    saveSnap(newSnap, s)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            changed = false
        } finally {
            ready.complete(Unit)
        }
        changed
    }

    private var lastRescan = 0L

    private fun sameProgs(a: List<Prog>?, b: List<Prog>?): Boolean {
        if (a == null || b == null) return a == b
        if (a.size != b.size) return false
        for (i in a.indices) if (a[i].start != b[i].start || a[i].stop != b[i].stop || a[i].title != b[i].title) return false
        return true
    }

    /**
     * Kanal dəyişəndə çağırılır: bu kanalın EPG-si köhnəlibsə (indi/sonrakı proqram yoxdur və ya məlumat 30 dəqiqədən köhnədir)
     * telefondakı EPG faylında yenidən yoxlayıb yeniləyir. Fayl yoxlaması ən çox 10 dəqiqədə bir edilir.
     * Kanalın proqramı dəyişibsə true.
     */
    suspend fun refreshChannel(ch: Channel, channels: List<Channel>): Boolean = lock.withLock {
        val id = snap.idByUrl[ch.url]
        if (id == null || !file.exists()) return@withLock false
        val (n, x) = nowNext(ch)
        if (n != null && x != null && System.currentTimeMillis() - snap.time < 30 * 60 * 1000L) return@withLock false
        val nowMs = android.os.SystemClock.elapsedRealtime()
        if (nowMs - lastRescan < 10 * 60 * 1000L) return@withLock false
        lastRescan = nowMs
        var changed = false
        try {
            withContext(Dispatchers.IO) {
                val before = snap.progs[id]
                val ns = parse(file, channels)
                snap = ns; sig = sigOf(channels)
                saveSnap(ns, sig)
                changed = !sameProgs(before, ns.progs[id])
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            changed = false
        }
        changed
    }

    private class Dl(val f: File, val etag: String?, val lm: String?, val sha: String)
    private val prefs = ctx.getSharedPreferences("epg", Context.MODE_PRIVATE)
    private var lastCheck = 0L

    private fun sha1(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-1")
        f.inputStream().use { i -> val buf = ByteArray(64 * 1024); while (true) { val n = i.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Yeni məzmun varsa fresh fayla endirib qaytarır; dəyişiklik yoxdursa (304 / eyni hash) null. */
    private fun download(): Dl? {
        val fresh = File(ctx.filesDir, "epg_new.bin")
        return try {
            val have = file.exists()
            val r = fetchConditional(
                EPG_URL, fresh,
                if (have) prefs.getString("etag", null) else null,
                if (have) prefs.getString("lm", null) else null, 30000
            )
            if (r.notModified) { fresh.delete(); null }
            else if (fresh.length() <= 200 || !looksValid(fresh)) { fresh.delete(); null }
            else {
                val sha = sha1(fresh)
                if (have && sha == prefs.getString("sha", null)) {
                    prefs.edit().putString("etag", r.etag).putString("lm", r.lastMod).apply()
                    fresh.delete(); null
                } else Dl(fresh, r.etag, r.lastMod, sha)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fresh.delete(); null
        }
    }

    private fun looksValid(f: File): Boolean = f.inputStream().use {
        val a = it.read(); val b = it.read()
        (a == 0x1f && b == 0x8b) || a == '<'.code || a == 0xEF // gzip, XML və ya BOM-lu XML
    }

    /** .gz isə açır, deyilsə (server artıq açıb göndərib) olduğu kimi oxuyur. */
    private fun open(f: File): InputStream {
        val b = BufferedInputStream(FileInputStream(f), 64 * 1024)
        b.mark(2)
        val b0 = b.read(); val b1 = b.read()
        b.reset()
        return if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(b, 64 * 1024) else b
    }

    /** Playlistdəki kanalın adı əl ilə əlaqələndirmə cədvəlində varsa, uyğun XML id-sini qaytarır. */
    private fun aliasId(ch: Channel, ovIndex: Map<String, String>): String? {
        if (ovIndex.isEmpty()) return null
        for (nm in listOf(ch.name, ch.tvgName)) {
            if (nm.isNullOrBlank()) continue
            for (k in aliasCandidates(nm)) ovIndex[k]?.let { return it }
        }
        return null
    }

    private fun match(
        ch: Channel, ids: Set<String>, idsLower: Map<String, String>, keyToId: Map<String, String>,
        fuzzy: Lazy<NameFuzzy>, ovIndex: Map<String, String>
    ): String? {
        aliasId(ch, ovIndex)?.let { return it }
        ch.tvgId?.let { t ->
            if (t in ids) return t
            idsLower[t.lowercase()]?.let { return it }
        }
        val keys = listOf(ch.tvgName, ch.name).mapNotNull { c -> c?.let { normKey(it) }?.takeIf { it.isNotEmpty() } }
        for (n in keys) {
            keyToId[n]?.let { return it }
            keyToId[n.removeSuffix("tv")]?.let { return it }
            keyToId[n + "tv"]?.let { return it }
        }
        for (n in keys) fuzzy.value.find(n)?.let { return it }
        return null
    }

    private fun parse(f: File, channels: List<Channel>): Snap = lowPriority { parseImpl(f, channels) }

    private fun parseImpl(f: File, channels: List<Channel>): Snap {
        val now = System.currentTimeMillis() / 1000
        val horizon = now + 48 * 3600
        val names = ArrayList<Pair<String, String>>()
        val iconAll = HashMap<String, String>()
        val ids = HashSet<String>()
        val wanted = HashSet<String>()
        var idByUrl: Map<String, String> = emptyMap()
        var logoIdByUrl: Map<String, String> = emptyMap()
        var built = false
        val progs = HashMap<String, ArrayList<Prog>>()
        val titlePool = HashMap<String, String>()

        fun build() {
            built = true
            val keyToId = HashMap<String, String>()
            for ((id, n) in names) { val k = normKey(n); if (k.isNotEmpty()) keyToId.putIfAbsent(k, id) }
            val idsLower = HashMap<String, String>()
            for (id in ids) idsLower.putIfAbsent(id.lowercase(), id)
            val rawKeyToId = HashMap<String, String>()
            for ((id, n) in names) { val k = rawKey(n); if (k.isNotEmpty()) rawKeyToId.putIfAbsent(k, id) }

            // XML-dəki slug (id və ya ad) -> həqiqi XML kanal id-si
            fun resolveSlug(slug: String, keys: List<String>): String? {
                for (v in listOf(slug, slug.replace('-', '_'), slug.replace('-', ' '), slug.replace("-", ""))) {
                    if (v in ids) return v
                    idsLower[v.lowercase()]?.let { return it }
                }
                for (k in aliasCandidates(slug) + keys) {
                    rawKeyToId[k]?.let { return it }
                    keyToId[k]?.let { return it }
                }
                return null
            }
            val ovIndex = HashMap<String, String>()
            for ((slug, keys) in EPG_ALIASES) {
                val rid = resolveSlug(slug, keys) ?: continue
                for (k in keys + aliasCandidates(slug)) ovIndex.putIfAbsent(k, rid)
            }

            val m = HashMap<String, String>()
            val fuzzy = lazy { NameFuzzy(keyToId) }
            for (c in channels) match(c, ids, idsLower, keyToId, fuzzy, ovIndex)?.let { m[c.url] = it }
            idByUrl = m
            wanted.addAll(m.values)

            // Loqo: yalnız dəqiq ad (latın Azərbaycan qarşılığı); loqosu olan EPG kanalı üstün tutulur
            val logoKeyToId = HashMap<String, String>()
            for ((id, n) in names) {
                val k = logoKey(n)
                if (k.isEmpty()) continue
                val old = logoKeyToId[k]
                if (old == null || (!iconAll.containsKey(old) && iconAll.containsKey(id))) logoKeyToId[k] = id
            }
            val lm = HashMap<String, String>()
            for (c in channels) {
                var hit: String? = null
                val ar = aliasId(c, ovIndex)
                if (ar != null && iconAll.containsKey(ar)) hit = ar
                val t = c.tvgId
                if (hit == null && t != null) {
                    val r = if (t in ids) t else idsLower[t.lowercase()]
                    if (r != null && iconAll.containsKey(r)) hit = r
                }
                if (hit == null) {
                    for (nm in listOf(c.tvgName, c.name)) {
                        val n = nm?.let { logoKey(it) } ?: continue
                        if (n.isEmpty()) continue
                        val r = logoKeyToId[n] ?: logoKeyToId[n.removeSuffix("tv")] ?: logoKeyToId[n + "tv"]
                        if (r != null && iconAll.containsKey(r)) { hit = r; break }
                    }
                }
                if (hit != null) lm[c.url] = hit
            }
            logoIdByUrl = lm
        }

        var curId: String? = null
        var inProg = false
        var pId = ""; var pStart = 0L; var pStop = 0L
        var pTitle: String? = null; var pDesc: String? = null

        open(f).use { input ->
            val p = Xml.newPullParser()
            p.setInput(input, null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "channel" -> { curId = p.getAttributeValue(null, "id"); curId?.let { ids.add(it) } }
                        "display-name" -> {
                            val cid = curId
                            if (cid != null) { val t = p.nextText().trim(); if (t.isNotEmpty()) names.add(cid to t) }
                        }
                        "icon" -> {
                            val cid = curId
                            val src = p.getAttributeValue(null, "src")
                            if (cid != null && src != null && src.startsWith("http")) iconAll.putIfAbsent(cid, src)
                        }
                        "programme" -> {
                            if (!built) build()
                            inProg = false
                            val cid = p.getAttributeValue(null, "channel")
                            if (cid != null && cid in wanted) {
                                val st = xmltvTime(p.getAttributeValue(null, "start"))
                                val sp = xmltvTime(p.getAttributeValue(null, "stop"))
                                val keep = st > 0 && st < horizon && (if (sp > 0) sp > now else st > now - 4 * 3600)
                                if (keep) {
                                    inProg = true; pId = cid; pStart = st; pStop = sp
                                    pTitle = null; pDesc = null
                                }
                            }
                        }
                        "title" -> if (inProg && pTitle == null) pTitle = p.nextText().trim()
                        "desc" -> if (inProg && pDesc == null) pDesc = p.nextText().trim()
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.name) {
                        "channel" -> curId = null
                        "programme" -> if (inProg) {
                            inProg = false
                            val title = pTitle
                            if (!title.isNullOrEmpty()) {
                                progs.getOrPut(pId) { ArrayList() }.add(Prog(pStart, pStop, titlePool.getOrPut(title) { title }, pDesc.orEmpty().take(EPG_DESC_MAX)))
                            }
                        }
                    }
                }
                ev = p.next()
            }
        }
        if (!built) build()

        val out = HashMap<String, List<Prog>>()
        for ((id, l) in progs) {
            l.sortBy { it.start }
            for (i in l.indices) if (l[i].stop <= 0) l[i].stop = if (i + 1 < l.size) l[i + 1].start else l[i].start + 3600
            out[id] = l
        }
        val icons = HashMap<String, String>()
        for (id in logoIdByUrl.values) iconAll[id]?.let { icons[id] = it }
        return Snap(idByUrl, logoIdByUrl, icons, out)
    }
}

/** XMLTV vaxtı: 20261023183000 +0300 */
private fun xmltvTime(s: String?): Long {
    if (s == null) return 0
    val t = s.trim()
    if (t.length < 12) return 0
    return try {
        val y = t.substring(0, 4).toInt(); val mo = t.substring(4, 6).toInt(); val d = t.substring(6, 8).toInt()
        val h = t.substring(8, 10).toInt(); val mi = t.substring(10, 12).toInt()
        val sec = if (t.length >= 14 && t[12].isDigit()) t.substring(12, 14).toInt() else 0
        val rest = t.drop(if (t.length >= 14 && t[12].isDigit()) 14 else 12).trim()
        var off = 0
        if (rest.length >= 5 && (rest[0] == '+' || rest[0] == '-')) {
            val sign = if (rest[0] == '-') -1 else 1
            off = sign * (rest.substring(1, 3).toInt() * 3600 + rest.substring(3, 5).toInt() * 60)
        }
        LocalDateTime.of(y, mo, d, h, mi, sec).toEpochSecond(ZoneOffset.ofTotalSeconds(off))
    } catch (e: Throwable) { 0 }
}


private fun digitsOf(x: String) = x.filter { it.isDigit() }

private fun levDist(a: String, b: String, max: Int): Int {
    if (kotlin.math.abs(a.length - b.length) > max) return max + 1
    var prev = IntArray(b.length + 1) { it }
    var cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
        cur[0] = i
        var rowMin = cur[0]
        for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            if (cur[j] < rowMin) rowMin = cur[j]
        }
        if (rowMin > max) return max + 1
        val t = prev; prev = cur; cur = t
    }
    return prev[b.length]
}

/**
 * Oxşar ad axtarışı (EPG və loqo mənbələri üçün ortaq): açar -> dəyər xəritəsində
 * bir-birini ehtiva edən və ya 1-2 hərf fərqli adlar tapılır (rəqəmlər eyni olmalıdır).
 */
class NameFuzzy(keyToVal: Map<String, String>) {
    private val byLen = HashMap<Int, ArrayList<Pair<String, String>>>()
    init { for ((k, v) in keyToVal) byLen.getOrPut(k.length) { ArrayList() }.add(k to v) }

    fun find(n: String): String? {
        if (n.length < 3) return null
        val dn = digitsOf(n)
        var best: String? = null
        var bestScore = 0.0
        for (l in maxOf(3, n.length - 8)..(n.length + 8)) {
            val bucket = byLen[l] ?: continue
            for ((k, v) in bucket) {
                val sh = if (k.length <= n.length) k else n
                val lo = if (k.length <= n.length) n else k
                if (sh.length < 4 || !lo.contains(sh)) continue
                if (digitsOf(k) != dn) continue
                val sc = sh.length.toDouble() / lo.length
                if (sc >= 0.55 && sc > bestScore) { bestScore = sc; best = v }
            }
        }
        if (best != null) return best
        if (n.length < 5) return null
        val maxD = if (n.length >= 10) 2 else 1
        var bd = maxD + 1
        for (l in (n.length - maxD)..(n.length + maxD)) {
            val bucket = byLen[l] ?: continue
            for ((k, v) in bucket) {
                if (k[0] != n[0] && k.last() != n.last()) continue
                if (digitsOf(k) != dn) continue
                val d = levDist(n, k, maxD)
                if (d < bd) { bd = d; best = v }
            }
        }
        return best
    }
}


/**
 * Kanal adına görə əlavə EPG (azepg.ddns.net/aztv). Fayllarda vaxt Unix saniyədir (UTC), kanal id-si hamısında "1"dir,
 * ona görə fayl kanala ad ilə bağlanır. Yalnız "Azərbaycan" qrupu (Türkiyə ATV və s. ilə qarışmasın).
 * Boş fayllar (arb, space, atv, qafkaz, eltv) və tarixi keçmiş fayl (biznestv) heç nə əlavə etmir, əsas EPG qalır.
 */
object ExtEpg {
    private const val BASE = "https://azepg.ddns.net/aztv/15_days_archive__"

    /** Backup.norm(kanal adı) -> fayl açarı */
    private val FILES: Map<String, String> = mapOf(
        "biznestv" to "biznestv",
        "bakutv" to "bakutv", "bakitv" to "bakutv",
        "arb" to "arb",
        "spacetv" to "space", "space" to "space",
        "atv" to "atv",
        "xezertv" to "xezer",
        "naxcivantv" to "nxtv", "nxtv" to "nxtv",
        "qafqaztv" to "qafkaz",
        "eltv" to "eltv"
    )

    fun key(ch: Channel): String? {
        if (ch.group != "Azərbaycan") return null
        return FILES[Backup.norm(ch.name)]
    }

    fun url(key: String) = "${BASE}${key}_desc.xml"

    /** Saniyə (10 rəqəm) və ya XMLTV (20261029183000 +0400) formatını epoch saniyəyə çevirir. */
    private fun time(s: String?): Long {
        val t = s?.trim() ?: return 0
        if (t.isNotEmpty() && t.length <= 11 && t.all { it.isDigit() }) return t.toLong()
        return xmltvTime(t)
    }

    private fun clean(s: String?): String {
        var t = (s ?: "").replace('`', ' ').replace(Regex("\\s+"), " ").trim()
        // yarımçıq qalmış tək dırnaq: Sahibkarların bir günu"
        if (t.count { it == '"' } == 1 && t.endsWith("\"")) t = t.dropLast(1).trim()
        return t
    }

    fun parse(f: File, now: Long): List<Prog> {
        val horizon = now + 48 * 3600
        val raw = ArrayList<Prog>()
        f.inputStream().buffered(64 * 1024).use { input ->
            val p = Xml.newPullParser()
            p.setInput(input, null)
            var inProg = false
            var st = 0L; var sp = 0L
            var title: String? = null; var desc: String? = null
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "programme" -> {
                            st = time(p.getAttributeValue(null, "start"))
                            sp = time(p.getAttributeValue(null, "stop"))
                            title = null; desc = null
                            inProg = st > now - 12 * 3600 && st < horizon
                        }
                        "title" -> if (inProg && title == null) title = p.nextText()
                        "desc" -> if (inProg && desc == null) desc = p.nextText()
                    }
                } else if (ev == XmlPullParser.END_TAG && p.name == "programme") {
                    if (inProg) {
                        val t = clean(title)
                        if (t.isNotEmpty()) raw.add(Prog(st, sp, t, clean(desc).take(400)))
                    }
                    inProg = false
                }
                ev = p.next()
            }
        }
        raw.sortBy { it.start }
        // Bitmə vaxtı yoxdursa və ya başlanğıcdan əvvəldirsə (məs. günün son proqramında) növbəti başlanğıca bərabər edilir
        for (i in raw.indices) {
            val c = raw[i]
            if (c.stop <= c.start) c.stop = if (i + 1 < raw.size && raw[i + 1].start > c.start) raw[i + 1].start else c.start + 3600
        }
        return raw.filter { it.stop > now }
    }
}
