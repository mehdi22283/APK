package az.mehdi.xezertv

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.ui.PlayerView
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    companion object {
        const val PAGE_URL = "https://canlitv.com/xezer-tv?ulke=az"
        const val LINK_PREFIX = "https://yayin2.canlitv.fun/live/xezertv.stream/playlist.m3u8?hash="
        const val SITE = "https://canlitv.com/"
        const val TIMEOUT_MS = 30_000L
        const val SCAN_EVERY_MS = 400L
        const val MAX_RETRY = 5

        // JS: səhifədəki bütün resurs adlarını + DOM mətnini qaytarır
        const val SCAN_JS = """(function(){var r=[];try{performance.getEntriesByType('resource').forEach(function(e){r.push(e.name)})}catch(e){}
try{document.querySelectorAll('video,source,iframe,script').forEach(function(e){if(e.src)r.push(e.src)})}catch(e){}
r.push(document.documentElement.outerHTML);return r.join('\n');})()"""
    }

    private val blockExt = setOf("png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "css",
        "woff", "woff2", "ttf", "otf", "eot", "mp4", "webm")
    private val blockHosts = listOf("doubleclick", "googlesyndication", "google-analytics",
        "googletagmanager", "googleadservices", "adservice", "facebook.net", "facebook.com",
        "yandex", "adsystem", "adnxs", "taboola", "outbrain", "histats", "mc.yandex")

    private fun shouldBlock(u: String): Boolean {
        if (u.contains(".m3u8", true)) return false
        val noQuery = u.substringBefore('?').substringBefore('#')
        val ext = noQuery.substringAfterLast('.', "").lowercase()
        if (ext in blockExt) return true
        val host = android.net.Uri.parse(u).host ?: return false
        return blockHosts.any { host.contains(it) }
    }

    private val ui = Handler(Looper.getMainLooper())
    private val m3u8Regex = Regex("""https?://[^\s"'<>\\]+?\.m3u8[^\s"'<>\\]*""")

    private lateinit var playerView: PlayerView
    private lateinit var statusView: TextView
    private lateinit var linkView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var webContainer: FrameLayout

    private var player: ExoPlayer? = null
    private var webView: WebView? = null
    private var done = false
    private var candidate: String? = null
    private var attempt = 0
    private var currentUrl: String? = null
    private var playHeaders: Map<String, String> = emptyMap()
    private var userAgent: String = ""
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val scanRunnable = object : Runnable {
        override fun run() {
            val wv = webView ?: return
            if (done) return
            wv.evaluateJavascript(SCAN_JS) { raw -> onScanResult(raw) }
            ui.postDelayed(this, SCAN_EVERY_MS)
        }
    }

    private val timeoutRunnable = Runnable {
        if (done) return@Runnable
        val c = candidate
        if (c != null) {
            log("⏱ Vaxt bitdi, namizəd link istifadə olunur")
            accept(c, "namizəd")
        } else {
            log("✖ 30 saniyədə m3u8 tapılmadı")
            setStatus("Link tapılmadı — 🔄 Yenilə düyməsini bas")
            stopFetch()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.playerView)
        statusView = findViewById(R.id.statusView)
        linkView = findViewById(R.id.linkView)
        logView = findViewById(R.id.logView)
        logScroll = findViewById(R.id.logScroll)
        webContainer = findViewById(R.id.webContainer)

        userAgent = WebSettings.getDefaultUserAgent(this)

        findViewById<Button>(R.id.btnRefresh).setOnClickListener {
            attempt = 0
            startFetch()
        }
        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val u = currentUrl
            if (u == null) {
                Toast.makeText(this, "Hələ link yoxdur", Toast.LENGTH_SHORT).show()
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("m3u8", u))
                Toast.makeText(this, "Link kopyalandı", Toast.LENGTH_SHORT).show()
            }
        }

        initPlayer()
        val cached = getSharedPreferences("xezer", MODE_PRIVATE).getString("url", null)
        if (cached != null) {
            log("⚡ Keşdəki link ilə dərhal oynadılır (xəta olarsa avtomatik yenilənəcək)")
            playHeaders = mapOf("Referer" to SITE, "Origin" to SITE.trimEnd('/'))
            currentUrl = cached
            linkView.text = cached
            play(cached)
        } else {
            startFetch()
        }
    }

    private fun initPlayer() {
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 800, 1_500)
            .build()
        val p = ExoPlayer.Builder(this).setLoadControl(lc).build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> setStatus("Yüklənir...")
                    Player.STATE_READY -> {
                        attempt = 0
                        setStatus("▶ Canlı yayım gedir")
                        log("▶ Oynadılır")
                    }
                    else -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                log("✖ Player xətası: ${error.errorCodeName} — ${error.cause?.message ?: error.message}")
                if (attempt < MAX_RETRY) {
                    log("↻ Token köhnələ bilər, link yenidən çəkilir...")
                    startFetch()
                } else {
                    setStatus("Oynatma alınmadı — 🔄 Yenilə düyməsini bas")
                }
            }
        })
        playerView.player = p
        player = p
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun startFetch() {
        stopFetch()
        done = false
        candidate = null
        attempt++
        log("━━━ Cəhd #$attempt ━━━")
        log("1) Gizli WebView açılır: $PAGE_URL")
        setStatus("Link axtarılır...")

        val wv = WebView(this)
        webView = wv
        webContainer.addView(wv, ViewGroup.LayoutParams(1, 1))
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = userAgent
            loadsImagesAutomatically = false
            blockNetworkImage = true
        }
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url.toString()
                if (shouldBlock(u)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                if (u.contains(".m3u8", ignoreCase = true)) {
                    val h = request.requestHeaders
                    ui.post { onUrlSeen(u, "şəbəkə sorğusu (JS player sorğusu)", h) }
                }
                return null
            }

            override fun onPageFinished(view: WebView, url: String) {
                log("2) Səhifə yükləndi")
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                if (request.isForMainFrame) log("✖ Səhifə xətası: ${error.description}")
            }
        }
        wv.loadUrl(PAGE_URL, mapOf("Referer" to SITE))
        ui.postDelayed(timeoutRunnable, TIMEOUT_MS)
        ui.postDelayed(scanRunnable, 300)
    }

    private fun stopFetch() {
        ui.removeCallbacks(scanRunnable)
        ui.removeCallbacks(timeoutRunnable)
        webView?.let {
            it.stopLoading()
            webContainer.removeView(it)
            it.destroy()
        }
        webView = null
    }

    private fun onScanResult(raw: String?) {
        if (done || raw == null || raw == "null") return
        val text = (JSONTokener(raw).nextValue() as? String) ?: return
        val norm = normalize(text)
        for (m in m3u8Regex.findAll(norm)) {
            onUrlSeen(m.value, "səhifə JS/DOM mətni", emptyMap())
            if (done) return
        }
    }

    private fun normalize(s: String): String = s
        .replace("\\/", "/")
        .replace("\\u0026", "&")
        .replace("\\u003d", "=")
        .replace("&amp;", "&")

    private fun clean(u: String): String =
        normalize(u).trimEnd(')', ']', ';', ',', '}')

    private fun onUrlSeen(raw: String, source: String, headers: Map<String, String>) {
        if (done) return
        val u = clean(raw)
        if (u.startsWith(LINK_PREFIX) || (u.contains("hash=") && u.contains("canlitv"))) {
            accept(u, source, headers)
        } else if (candidate == null) {
            candidate = u
            log("• Namizəd m3u8 ($source): $u")
        }
    }

    private fun accept(url: String, source: String, headers: Map<String, String> = emptyMap()) {
        if (done) return
        done = true
        val keep = setOf("referer", "origin", "user-agent", "cookie")
        val h = headers.filterKeys { it.lowercase() in keep }
        playHeaders = if (h.isEmpty()) mapOf("Referer" to SITE, "Origin" to SITE.trimEnd('/')) else h
        log("3) ✔ m3u8 TAPILDI — mənbə: $source")
        log("   $url")
        log("   Header-lər: $playHeaders")
        currentUrl = url
        linkView.text = url
        getSharedPreferences("xezer", MODE_PRIVATE).edit().putString("url", url).apply()
        stopFetch()
        play(url)
    }

    private fun play(url: String) {
        val p = player ?: return
        val ua = playHeaders.entries.firstOrNull { it.key.equals("user-agent", true) }?.value ?: userAgent
        val props = playHeaders.filterKeys { !it.equals("user-agent", true) }
        val dsf = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(props)
        val src = HlsMediaSource.Factory(dsf).createMediaSource(MediaItem.fromUri(url))
        p.setMediaSource(src)
        p.prepare()
        p.playWhenReady = true
        log("4) ExoPlayer HLS ilə oynatma başladı")
    }

    private fun setStatus(s: String) {
        statusView.text = s
    }

    private fun log(s: String) {
        val line = "[${timeFmt.format(Date())}] $s\n"
        runOnUiThread {
            logView.append(line)
            logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        stopFetch()
        player?.release()
        player = null
        super.onDestroy()
    }
}
