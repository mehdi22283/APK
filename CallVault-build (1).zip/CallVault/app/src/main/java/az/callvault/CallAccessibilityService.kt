package az.callvault

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class CallAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: CallAccessibilityService? = null
        val WA_PKGS = setOf("com.whatsapp", "com.whatsapp.w4b")
    }

    override fun onServiceConnected() {
        instance = this
        Svc.send(this)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg !in WA_PKGS) return
        val cls = e.className?.toString() ?: ""
        // WhatsApp zəng ekranı: ...voipcalling.VoipActivityV2 və s.
        if (cls.contains("Voip", ignoreCase = true)) {
            Svc.send(this, RecorderService.A_WA)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** WhatsApp zəng ekranından danışılan şəxsin adını təxmin edir. */
    fun guessWaName(): String? {
        try {
            val root = rootInActiveWindow ?: return null
            if (root.packageName?.toString() !in WA_PKGS) return null
            val q = ArrayDeque<AccessibilityNodeInfo>()
            q.add(root)
            var n = 0
            val skip = setOf("whatsapp", "calling", "ringing", "connecting", "reconnecting",
                "whatsapp voice call", "whatsapp video call", "end-to-end encrypted")
            val timer = Regex("[0-9:]+")
            while (q.isNotEmpty() && n < 400) {
                val x = q.removeFirst(); n++
                val id = x.viewIdResourceName ?: ""
                val t = x.text?.toString()?.trim()
                if (!t.isNullOrEmpty() && t.length < 40 &&
                    (id.contains("name", true) || id.contains("title", true)) &&
                    skip.none { t.equals(it, true) } && !t.matches(timer)
                ) return t
                for (i in 0 until x.childCount) x.getChild(i)?.let { q.add(it) }
            }
        } catch (e: Exception) { /* ignore */ }
        return null
    }
}
