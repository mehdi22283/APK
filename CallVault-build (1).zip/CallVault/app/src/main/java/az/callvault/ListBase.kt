package az.callvault

import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class Row(
    val title: String, val sub: String,
    val onClick: () -> Unit, val onLong: (() -> Unit)? = null
)

class RowAdapter : RecyclerView.Adapter<RowAdapter.VH>() {
    var rows: List<Row> = emptyList()

    class VH(val root: LinearLayout, val t: TextView, val s: TextView) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(p: ViewGroup, vt: Int): VH {
        val c = p.context
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(16), c.dp(12), c.dp(16), c.dp(12))
            layoutParams = RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT)
            val tv = TypedValue()
            c.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            setBackgroundResource(tv.resourceId)
        }
        val t = TextView(c).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD }
        val s = TextView(c).apply { textSize = 13f; alpha = 0.7f }
        root.addView(t); root.addView(s)
        return VH(root, t, s)
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val r = rows[i]
        h.t.text = r.title; h.s.text = r.sub
        h.root.setOnClickListener { r.onClick() }
        h.root.setOnLongClickListener { r.onLong?.invoke(); r.onLong != null }
    }

    override fun getItemCount() = rows.size
}

abstract class ListBase : Fragment() {
    abstract val heading: String
    abstract fun rows(): List<Row>
    open fun onAdd() {}
    open val emptyText = "Hələ heç nə yoxdur"

    private val adapter = RowAdapter()
    private var query = ""
    private var emptyView: TextView? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val root = FrameLayout(ctx)
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(ctx).apply {
            text = heading; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setPadding(ctx.dp(16), ctx.dp(20), ctx.dp(16), ctx.dp(4))
        })
        col.addView(EditText(ctx).apply {
            hint = "🔍 Axtar…"; setSingleLine()
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(ctx.dp(16), 0, ctx.dp(16), 0); layoutParams = lp
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { query = e?.toString() ?: ""; refresh() }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        })
        val rv = RecyclerView(ctx).apply {
            layoutManager = LinearLayoutManager(ctx); adapter = this@ListBase.adapter
            clipToPadding = false; setPadding(0, 0, 0, ctx.dp(90))
        }
        col.addView(rv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        emptyView = TextView(ctx).apply { text = emptyText; gravity = Gravity.CENTER; alpha = 0.6f }
        root.addView(emptyView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val fab = FloatingActionButton(ctx).apply {
            setImageResource(android.R.drawable.ic_input_add)
            setOnClickListener { onAdd() }
        }
        root.addView(fab, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, ctx.dp(20), ctx.dp(20)) })
        return root
    }

    override fun onResume() { super.onResume(); refresh() }

    fun refresh() {
        if (!isAdded) return
        val all = rows()
        val f = if (query.isBlank()) all else all.filter { (it.title + " " + it.sub).contains(query, true) }
        adapter.rows = f
        adapter.notifyDataSetChanged()
        emptyView?.visibility = if (f.isEmpty()) View.VISIBLE else View.GONE
    }
}

class RecordingsFragment : ListBase() {
    override val heading = "Zəng yazıları"
    override val emptyText = "Hələ yazı yoxdur.\n🎙 düyməsi ilə test yazısı edə bilərsiniz."

    override fun rows(): List<Row> {
        val db = Db.get(requireContext())
        return db.recs().map { r ->
            val icon = when (r.type) { "phone" -> "📞"; "whatsapp" -> "💬"; else -> "🎙" }
            val dir = when (r.dir) { "in" -> " · ↙ Gələn"; "out" -> " · ↗ Gedən"; else -> "" }
            val warn = when (r.status) { "silent" -> " · ⚠ səssiz"; "recording" -> " · ⚠ yarımçıq"; else -> "" }
            val nn = db.notes(r.id).size; val rr = db.reminders(r.id).size
            val extra = (if (nn > 0) " · 📝$nn" else "") + (if (rr > 0) " · ⏰$rr" else "")
            Row("$icon ${r.label()}", "${Fmt.dt(r.started)} · ${Fmt.dur(r.dur)}$dir$warn$extra",
                { RecordingDialog.show(requireActivity(), r.id) { refresh() } },
                { Dialogs.confirm(requireContext(), "Bu yazı silinsin?") { db.deleteRec(r.id); refresh() } })
        }
    }

    override fun onAdd() {
        // Test / əl ilə yazı: başlat-dayandır
        Svc.send(requireContext(), RecorderService.A_MANUAL)
        view?.postDelayed({ refresh() }, 800)
        android.widget.Toast.makeText(requireContext(),
            if (RecState.recording) "Yazı dayandırılır…" else "Əl ilə yazı başladı (yenidən basın — dayanır)",
            android.widget.Toast.LENGTH_SHORT).show()
    }
}

class NotesFragment : ListBase() {
    override val heading = "Qeydlər"
    override val emptyText = "Qeyd yoxdur. ➕ ilə əlavə edin."

    override fun rows(): List<Row> {
        val db = Db.get(requireContext())
        return db.notes().map { n ->
            val rec = if (n.recId > 0) db.rec(n.recId)?.let { " · 📞 ${it.label()}" } ?: "" else ""
            Row(n.title.ifBlank { n.body.lineSequence().firstOrNull() ?: "(boş)" },
                "${Fmt.dt(n.created)}$rec\n${n.body.take(120)}",
                { Dialogs.noteDialog(requireContext(), n.recId, n) { refresh() } },
                { Dialogs.confirm(requireContext(), "Qeyd silinsin?") { db.deleteNote(n.id); refresh() } })
        }
    }

    override fun onAdd() { Dialogs.noteDialog(requireContext(), 0, null) { refresh() } }
}

class RemindersFragment : ListBase() {
    override val heading = "Xatırlatmalar"
    override val emptyText = "Xatırlatma yoxdur. ➕ ilə əlavə edin."

    override fun rows(): List<Row> {
        val db = Db.get(requireContext())
        val now = System.currentTimeMillis()
        return db.reminders().map { r ->
            val mark = when { r.done -> "✔"; r.time < now -> "⚠"; else -> "⏰" }
            val rec = if (r.recId > 0) db.rec(r.recId)?.let { " · 📞 ${it.label()}" } ?: "" else ""
            Row("$mark ${r.title}", "${Fmt.dt(r.time)}$rec" + if (r.body.isNotBlank()) "\n${r.body.take(100)}" else "",
                { Dialogs.reminderDialog(requireContext(), r.recId, r) { refresh() } },
                { Dialogs.confirm(requireContext(), "Xatırlatma silinsin?") {
                    Reminders.cancel(requireContext(), r.id); db.deleteReminder(r.id); refresh() } })
        }
    }

    override fun onAdd() { Dialogs.reminderDialog(requireContext(), 0, null) { refresh() } }
}
