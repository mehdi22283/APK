package az.callvault

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.CallLog
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

class RecorderService : Service() {

    companion object {
        const val A_PHONE = "az.callvault.PHONE"
        const val A_WA = "az.callvault.WA"
        const val A_STOP = "az.callvault.STOP"
        const val A_MANUAL = "az.callvault.MANUAL"
        const val NID = 1
        private const val TAG = "CallVault"
    }

    private val h = Handler(Looper.getMainLooper())
    private val db by lazy { Db.get(this) }
    private lateinit var am: AudioManager
    private lateinit var nm: NotificationManager

    private var mr: MediaRecorder? = null
    private var active = false
    private var curId = -1L
    private var curType = ""
    private var curStart = 0L
    private var curFile: File? = null
    private var curName: String? = null
    private var peak = 0
    private var srcList: List<Pair<String, Int>> = emptyList()
    private var srcIdx = 0

    private var sawRinging = false
    private var pendingNumber: String? = null
    private var waSeen = 0L
    private var notComm = 0
    private var speakerWas = false
    private var speakerChanged = false

    private var overlayView: View? = null
    private var overlayWm: WindowManager? = null
    private var overlayTimer: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            try { onTick() } catch (e: Exception) { Log.e(TAG, "tick", e) }
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AudioManager::class.java)
        nm = getSystemService(NotificationManager::class.java)
        Notifs.init(this)
        RecState.up = true
        cleanupOld()
        h.post(tick)
    }

    override fun onDestroy() {
        stopRecording()
        RecState.up = false
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        when (intent?.action) {
            A_PHONE -> onPhone(intent.getStringExtra("state") ?: "", intent.getStringExtra("number"))
            A_WA -> waSeen = System.currentTimeMillis()
            A_STOP -> stopRecording()
            A_MANUAL -> if (active) stopRecording() else startRecording("manual", null, "unknown")
        }
        return START_STICKY
    }

    // ------------------------------------------------------------------ foreground
    private fun baseNotif(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (active) "● Yazılır: ${curName ?: curType}" else "Zəng yazıcı hazırdır"
        return Notification.Builder(this, Notifs.CH_SVC)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("CallVault")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun goForeground() {
        try {
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(NID, baseNotif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(NID, baseNotif())
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
        }
    }

    private fun updateNotif() { try { nm.notify(NID, baseNotif()) } catch (e: Exception) { } }

    // ------------------------------------------------------------------ triggers
    private fun onPhone(state: String, number: String?) {
        if (!number.isNullOrBlank()) pendingNumber = number
        when (state) {
            "RINGING" -> sawRinging = true
            "OFFHOOK" -> if (!active && P.bool(this, "rec_phone")) {
                startRecording("phone", pendingNumber, if (sawRinging) "in" else "out")
            }
            "IDLE" -> {
                sawRinging = false
                if (active && curType == "phone") stopRecording()
                pendingNumber = null
            }
        }
    }

    private fun onTick() {
        val mode = am.mode
        if (!active) {
            if (waSeen > 0 && P.bool(this, "rec_wa")) {
                if (System.currentTimeMillis() - waSeen > 90_000) waSeen = 0
                else if (mode == AudioManager.MODE_IN_COMMUNICATION) startRecording("whatsapp", null, "unknown")
            }
            return
        }
        val el = (System.currentTimeMillis() - curStart) / 1000
        try { mr?.let { peak = max(peak, it.maxAmplitude) } } catch (e: Exception) { }
        overlayTimer?.text = Fmt.dur(el * 1000)

        // 4 saniyə səssizlik olarsa növbəti audio mənbəyinə keç
        if (el == 4L && peak <= 0 && srcIdx + 1 < srcList.size) switchSource()

        if (curType == "whatsapp") {
            if (mode != AudioManager.MODE_IN_COMMUNICATION) notComm++ else notComm = 0
            if (notComm >= 4) { stopRecording(); return }
            if (curName == null && el % 3 == 0L) {
                CallAccessibilityService.instance?.guessWaName()?.let {
                    curName = it
                    db.updateRec(curId, ContentValues().apply { put("name", it) })
                    updateNotif()
                }
            }
        }
    }

    // ------------------------------------------------------------------ recording
    private fun sourcesFor(type: String): List<Pair<String, Int>> {
        val all = mapOf(
            "voice_call" to MediaRecorder.AudioSource.VOICE_CALL,
            "voice_recognition" to MediaRecorder.AudioSource.VOICE_RECOGNITION,
            "mic" to MediaRecorder.AudioSource.MIC,
            "voice_comm" to MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            "unprocessed" to MediaRecorder.AudioSource.UNPROCESSED
        )
        val def = if (type == "phone") listOf("voice_call", "voice_recognition", "mic", "voice_comm")
        else listOf("voice_recognition", "mic", "voice_comm", "unprocessed")
        val pref = P.str(this, "source", "auto")
        val order = if (pref != "auto") listOf(pref) + def else def
        return order.distinct().mapNotNull { k -> all[k]?.let { k to it } }
    }

    private fun buildRecorder(src: Int, f: File): MediaRecorder? {
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        return try {
            r.setAudioSource(src)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            r
        } catch (e: Exception) {
            Log.w(TAG, "source $src failed: ${e.message}")
            try { r.release() } catch (e2: Exception) { }
            null
        }
    }

    @Synchronized
    private fun startRecording(type: String, number: String?, dir: String) {
        if (active) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "RECORD_AUDIO not granted"); return
        }
        val folder = File(getExternalFilesDir(null), "recordings").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val f = File(folder, "${stamp}_$type.m4a")

        srcList = sourcesFor(type)
        var rec: MediaRecorder? = null
        srcIdx = 0
        for ((i, s) in srcList.withIndex()) {
            rec = buildRecorder(s.second, f)
            if (rec != null) { srcIdx = i; break }
        }
        if (rec == null) { f.delete(); Log.e(TAG, "no audio source worked"); return }

        mr = rec
        active = true
        RecState.recording = true
        peak = 0
        notComm = 0
        curType = type
        curStart = System.currentTimeMillis()
        curFile = f
        curName = Contacts.name(this, number)
        curId = db.insertRec(f.absolutePath, number, curName, type, dir, curStart, srcList[srcIdx].first)
        RecState.currentId = curId

        if (type == "phone" && P.bool(this, "speaker", false)) {
            speakerWas = am.isSpeakerphoneOn
            am.isSpeakerphoneOn = true
            speakerChanged = true
        }
        showOverlay()
        updateNotif()
    }

    private fun switchSource() {
        val old = mr ?: return
        val f = curFile ?: return
        try { old.stop() } catch (e: Exception) { }
        try { old.release() } catch (e: Exception) { }
        mr = null
        var i = srcIdx + 1
        while (i < srcList.size) {
            val r = buildRecorder(srcList[i].second, f)
            if (r != null) {
                mr = r; srcIdx = i; peak = 0
                db.updateRec(curId, ContentValues().apply { put("source", srcList[i].first) })
                return
            }
            i++
        }
        mr = buildRecorder(srcList[srcIdx].second, f)  // son çarə: əvvəlki mənbə
    }

    @Synchronized
    private fun stopRecording() {
        if (!active) return
        active = false
        RecState.recording = false
        val r = mr
        mr = null
        var failed = r == null
        if (r != null) {
            try { r.stop() } catch (e: Exception) { failed = true }
            try { r.release() } catch (e: Exception) { }
        }
        hideOverlay()
        if (speakerChanged) { am.isSpeakerphoneOn = speakerWas; speakerChanged = false }
        waSeen = 0; notComm = 0

        val dur = System.currentTimeMillis() - curStart
        val id = curId
        val f = curFile
        val type = curType
        curId = -1; RecState.currentId = -1
        curName = null

        if (failed || dur < 2500 || f == null || !f.exists() || f.length() < 1000) {
            f?.delete(); db.deleteRecRow(id); updateNotif(); return
        }
        val status = if (peak < 50) "silent" else "ok"
        db.updateRec(id, ContentValues().apply { put("dur", dur); put("status", status) })
        if (type == "phone") h.postDelayed({ syncFromCallLog(id) }, 2000)
        notifySaved(id)
        updateNotif()
    }

    private fun syncFromCallLog(id: Long) {
        if (checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return
        try {
            val args = Bundle().apply {
                putStringArray(android.content.ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(CallLog.Calls.DATE))
                putInt(android.content.ContentResolver.QUERY_ARG_SORT_DIRECTION, android.content.ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
                putInt(android.content.ContentResolver.QUERY_ARG_LIMIT, 1)
            }
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                args, null
            )?.use { c ->
                if (!c.moveToFirst()) return
                val rec = db.rec(id) ?: return
                val num = c.getString(0)
                val nm = c.getString(1)
                val type = c.getInt(2)
                val date = c.getLong(3)
                if (abs(date - rec.started) > 120_000) return
                val cv = ContentValues()
                if (!num.isNullOrBlank()) cv.put("number", num)
                val name = nm?.takeIf { it.isNotBlank() } ?: Contacts.name(this, num)
                if (name != null) cv.put("name", name)
                when (type) {
                    CallLog.Calls.INCOMING_TYPE -> cv.put("dir", "in")
                    CallLog.Calls.OUTGOING_TYPE -> cv.put("dir", "out")
                }
                if (cv.size() > 0) db.updateRec(id, cv)
            }
        } catch (e: Exception) { Log.w(TAG, "call log sync", e) }
    }

    private fun notifySaved(id: Long) {
        val r = db.rec(id) ?: return
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, id.toInt(),
            Intent(this, MainActivity::class.java).putExtra("open_rec", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), fl
        )
        fun quick(kind: String, code: Int) = PendingIntent.getActivity(
            this, code + id.toInt(),
            Intent(this, QuickNoteActivity::class.java).putExtra("rec", id).putExtra("kind", kind)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), fl
        )
        val title = "Zəng yazıldı" + if (r.status == "silent") " (⚠ səssiz!)" else ""
        val n = Notification.Builder(this, Notifs.CH_SAVED)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(title)
            .setContentText("${r.label()} · ${Fmt.dur(r.dur)}")
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, "📝 Qeyd", quick("note", 100000))
            .addAction(0, "⏰ Xatırlat", quick("reminder", 200000))
            .build()
        nm.notify(5000 + id.toInt(), n)
    }

    private fun cleanupOld() {
        val days = P.str(this, "keep_days", "0").toIntOrNull() ?: 0
        if (days <= 0) return
        val limit = System.currentTimeMillis() - days * 86_400_000L
        db.recs().filter { it.started < limit }.forEach { db.deleteRec(it.id) }
    }

    // ------------------------------------------------------------------ overlay
    private fun showOverlay() {
        if (!P.bool(this, "overlay")) return
        hideOverlay()
        val acc = CallAccessibilityService.instance
        val ctx: Context
        val type: Int
        if (acc != null) { ctx = acc; type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY }
        else if (Settings.canDrawOverlays(this)) { ctx = this; type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY }
        else return
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(6), ctx.dp(6))
                background = GradientDrawable().apply {
                    cornerRadius = ctx.dp(24).toFloat(); setColor(0xE6202020.toInt())
                }
            }
            val label = TextView(ctx).apply {
                text = "● REC"; setTextColor(0xFFFF4444.toInt()); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            }
            val timer = TextView(ctx).apply {
                text = "00:00"; setTextColor(0xFFFFFFFF.toInt()); textSize = 13f
                setPadding(ctx.dp(8), 0, ctx.dp(8), 0)
            }
            fun btn(t: String, f: () -> Unit) = TextView(ctx).apply {
                text = t; textSize = 18f; setPadding(ctx.dp(8), ctx.dp(2), ctx.dp(8), ctx.dp(2))
                setOnClickListener { f() }
            }
            val note = btn("📝") { openQuick("note") }
            val rem = btn("⏰") { openQuick("reminder") }
            val stop = btn("⏹") { stopRecording() }
            box.addView(label); box.addView(timer); box.addView(note); box.addView(rem); box.addView(stop)

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = ctx.dp(16); lp.y = ctx.dp(110)

            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            val drag = View.OnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(box, lp) } catch (ex: Exception) { }
                    }
                }
                true
            }
            label.setOnTouchListener(drag); timer.setOnTouchListener(drag)

            wm.addView(box, lp)
            overlayView = box; overlayWm = wm; overlayTimer = timer
        } catch (e: Exception) {
            Log.w(TAG, "overlay failed", e)
        }
    }

    private fun openQuick(kind: String) {
        try {
            startActivity(
                Intent(this, QuickNoteActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("rec", curId).putExtra("kind", kind)
            )
        } catch (e: Exception) { Log.w(TAG, "quick note", e) }
    }

    private fun hideOverlay() {
        try { overlayView?.let { overlayWm?.removeView(it) } } catch (e: Exception) { }
        overlayView = null; overlayWm = null; overlayTimer = null
    }
}
