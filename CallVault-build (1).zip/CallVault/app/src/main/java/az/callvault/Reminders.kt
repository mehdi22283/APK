package az.callvault

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

object Reminders {
    private fun pi(c: Context, id: Long) = PendingIntent.getBroadcast(
        c, id.toInt(), Intent(c, ReminderReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** setAlarmClock istifadə olunur: dəqiq vaxtda işləyir və xüsusi icazə tələb etmir. */
    fun schedule(c: Context, r: Reminder) {
        val am = c.getSystemService(AlarmManager::class.java)
        val p = pi(c, r.id)
        if (r.done || r.time <= System.currentTimeMillis()) { am.cancel(p); return }
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).putExtra("tab", "rem"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(r.time, show), p)
    }

    fun cancel(c: Context, id: Long) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id))
    }

    fun rescheduleAll(c: Context) {
        Db.get(c).reminders().forEach { schedule(c, it) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", -1)
        val nm = c.getSystemService(NotificationManager::class.java)
        val db = Db.get(c)
        if (i.action == "az.callvault.DONE") {
            db.setDone(id, true); nm.cancel(1000 + id.toInt()); return
        }
        val r = db.reminder(id) ?: return
        if (r.done) return
        Notifs.init(c)
        val open = Intent(c, MainActivity::class.java)
            .putExtra("tab", "rem")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (r.recId > 0) open.putExtra("open_rec", r.recId)
        val tap = PendingIntent.getActivity(c, id.toInt(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val done = PendingIntent.getBroadcast(
            c, 50000 + id.toInt(),
            Intent(c, ReminderReceiver::class.java).setAction("az.callvault.DONE").putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = r.body.ifBlank { Fmt.dt(r.time) }
        val n = Notification.Builder(c, Notifs.CH_REM)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ " + r.title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(tap)
            .addAction(0, "Bitdi ✔", done)
            .build()
        nm.notify(1000 + id.toInt(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Reminders.rescheduleAll(c)
        Svc.send(c)
    }
}

class PhoneStateReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != android.telephony.TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val s = i.getStringExtra(android.telephony.TelephonyManager.EXTRA_STATE) ?: return
        @Suppress("DEPRECATION")
        val n = i.getStringExtra(android.telephony.TelephonyManager.EXTRA_INCOMING_NUMBER)
        Svc.send(c, RecorderService.A_PHONE) { putExtra("state", s); putExtra("number", n) }
    }
}
