package az.callvault

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.google.android.material.materialswitch.MaterialSwitch

class SetupFragment : Fragment() {

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { build() }
    private var root: LinearLayout? = null
    private val logBuf = StringBuilder()
    private var logView: TextView? = null
    private var portText = "5555"

    private val sources = listOf("auto", "voice_call", "voice_recognition", "mic", "voice_comm", "unprocessed")
    private val keepDays = listOf("0", "7", "30", "90")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val sv = ScrollView(ctx)
        root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), ctx.dp(16), ctx.dp(16), ctx.dp(32))
        }
        sv.addView(root)
        return sv
    }

    override fun onResume() { super.onResume(); build() }

    // ---------------------------------------------------------------- helpers
    private fun perms(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add("android.permission.POST_NOTIFICATIONS")
        return l.toTypedArray()
    }

    private fun permsOk(ctx: Context) = perms().all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun accOk(ctx: Context): Boolean {
        if (CallAccessibilityService.instance != null) return true
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(ctx.packageName + "/")
    }

    private fun LinearLayout.head(t: String) = addView(TextView(context).apply {
        text = t; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, context.dp(20), 0, context.dp(4))
    })

    private fun LinearLayout.para(t: String) = addView(TextView(context).apply { text = t; textSize = 14f; setPadding(0, context.dp(2), 0, context.dp(2)) })
    private fun LinearLayout.status(ok: Boolean, t: String) = para((if (ok) "✅ " else "❌ ") + t)
    private fun LinearLayout.btn(t: String, f: () -> Unit) = addView(Button(context).apply { text = t; setOnClickListener { f() } })
    private fun LinearLayout.sw(label: String, key: String, def: Boolean) = addView(MaterialSwitch(context).apply {
        text = label; isChecked = P.bool(context, key, def)
        setOnCheckedChangeListener { _, v -> P.setBool(context, key, v) }
    })

    private fun go(i: Intent) {
        try { startActivity(i) } catch (e: Exception) {
            android.widget.Toast.makeText(requireContext(), "Açıla bilmədi: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- UI
    private fun build() {
        val r = root ?: return
        if (!isAdded) return
        val ctx = requireContext()
        val pkg = ctx.packageName
        r.removeAllViews()

        r.head("Status")
        r.status(RecState.up, "Yazıcı xidməti işləyir")
        r.status(permsOk(ctx), "İcazələr (mikrofon, telefon, zəng jurnalı, kontaktlar)")
        r.status(Settings.canDrawOverlays(ctx), "Digər tətbiqlərin üzərində göstər (overlay)")
        r.status(accOk(ctx), "Əlçatımlılıq xidməti (WhatsApp aşkarlama + overlay)")
        r.status(ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg), "Batareya məhdudiyyəti söndürülüb")

        r.head("Kompüter lazım deyil")
        r.para("Aşağıdakı 1-ci bölmədəki düymələrlə hər şeyi telefonun özündən quraşdıra bilərsiniz. ADB (2-ci bölmə) tamamilə ixtiyaridir.")
        r.head("1. Telefondan quraşdırma (5 addım)")
        r.para("① İcazələri ver  ② Overlay  ③ Əlçatımlılıq  ④ Batareya  ⑤ Avtostart + 🔒 kilid. Hamısı ✅ olanda hazırdır.")
        r.btn("İcazələri ver") { permLauncher.launch(perms()) }
        r.btn("Overlay icazəsi") { go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg"))) }
        r.btn("Əlçatımlılığı aç (CallVault → aktiv et)") { go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        r.btn("Batareya optimallaşdırmasını söndür") {
            go(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")))
        }
        r.btn("MIUI Avtostart səhifəsi") {
            try {
                startActivity(Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")))
            } catch (e: Exception) {
                go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
            }
        }
        r.para("MIUI üçün: Son tətbiqlər ekranında CallVault kartını aşağı çəkib 🔒 kilidləyin. Tətbiq məlumatı → 'Digər icazələr' içində 'Arxa planda pəncərə göstər' və 'Kilid ekranında göstər'i açın.")

        r.head("2. Lokal ADB (ixtiyari, irəli səviyyə)")
        r.para("Yalnız telefonun ADB-si artıq TCP portunda (məs. 5555) dinləyirsə işləyir; sonra düymə icazələri, əlçatımlılığı, avtostartı və batareya istisnasını avtomatik verir. Əksər istifadəçi üçün 1-ci bölmə kifayətdir.")
        r.btn("Developer options (Tərtibatçı seçimləri)") { go(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
        val port = EditText(ctx).apply { hint = "ADB port"; setText(portText); inputType = InputType.TYPE_CLASS_NUMBER }
        r.addView(port)
        r.btn("ADB ilə quraşdır") {
            portText = port.text.toString()
            val p = portText.toIntOrNull() ?: 5555
            val app = ctx.applicationContext
            logBuf.clear()
            Thread {
                AdbSetup.run(app, p) { line ->
                    logBuf.append(line).append('\n')
                    activity?.runOnUiThread { logView?.text = logBuf }
                }
                activity?.runOnUiThread { build() }
            }.start()
        }
        logView = TextView(ctx).apply { text = logBuf; textSize = 11f; typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        r.addView(logView)

        r.head("3. Parametrlər")
        r.sw("Telefon zənglərini yaz", "rec_phone", true)
        r.sw("WhatsApp zənglərini yaz", "rec_wa", true)
        r.sw("Yazı zamanı ekranda göstərici (overlay)", "overlay", true)
        r.sw("Telefon zənginde avto-dinamik (qarşı tərəfin səsi üçün)", "speaker", false)
        r.btn("Audio mənbəyi: ${P.str(ctx, "source", "auto")}  (dəyiş)") {
            val cur = sources.indexOf(P.str(ctx, "source", "auto"))
            P.setStr(ctx, "source", sources[(cur + 1) % sources.size]); build()
        }
        r.btn("Köhnə yazıları avto-sil: ${P.str(ctx, "keep_days", "0").let { if (it == "0") "heç vaxt" else "$it gün" }}  (dəyiş)") {
            val cur = keepDays.indexOf(P.str(ctx, "keep_days", "0"))
            P.setStr(ctx, "keep_days", keepDays[(cur + 1) % keepDays.size]); build()
        }

        r.head("4. Xidmət")
        r.btn("Yazıcı xidmətini (yenidən) başlat") { Svc.send(ctx); r.postDelayed({ build() }, 700) }

        r.head("Hüquqi qeyd")
        r.para("Zəng yazmaq bir çox ölkədə qarşı tərəfin razılığını tələb edir. Yalnız qanunun icazə verdiyi hallarda və öz məsuliyyətinizlə istifadə edin. Yazı zamanı overlay göstəricisi məhz bunun üçündür.")
    }
}
