package az.callvault

import android.content.Intent
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var nav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifs.init(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val frame = FrameLayout(this).apply { id = R.id.container }
        nav = BottomNavigationView(this)
        nav.inflateMenu(R.menu.nav)
        root.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        nav.setOnItemSelectedListener { show(it.itemId); true }
        if (savedInstanceState == null) nav.selectedItemId = tabOf(intent)

        Svc.send(this)           // tətbiq görünən vaxt xidməti başlat (mikrofon icazəsi üçün vacibdir)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        nav.selectedItemId = tabOf(intent)
        handle(intent)
    }

    private fun tabOf(i: Intent?): Int = when (i?.getStringExtra("tab")) {
        "notes" -> R.id.nav_notes
        "rem" -> R.id.nav_rem
        "setup" -> R.id.nav_setup
        else -> R.id.nav_rec
    }

    private fun handle(i: Intent?) {
        val id = i?.getLongExtra("open_rec", -1) ?: -1
        if (id > 0) window.decorView.post { RecordingDialog.show(this, id) }
        i?.removeExtra("open_rec")
    }

    private fun show(itemId: Int) {
        val f: Fragment = when (itemId) {
            R.id.nav_notes -> NotesFragment()
            R.id.nav_rem -> RemindersFragment()
            R.id.nav_setup -> SetupFragment()
            else -> RecordingsFragment()
        }
        supportFragmentManager.beginTransaction().replace(R.id.container, f).commit()
    }
}
