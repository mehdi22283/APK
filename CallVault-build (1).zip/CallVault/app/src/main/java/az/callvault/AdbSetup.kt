package az.callvault

import android.content.Context
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File

/**
 * Telefonun öz-özünə lokal ADB qoşulması (127.0.0.1).
 * Əvvəlcə kompüterdən BİR DƏFƏ:  adb tcpip 5555   (telefon yenidən yüklənənə qədər qalır)
 * Sonra tətbiqdən "ADB ilə quraşdır" düyməsi bütün icazələri özü verir.
 */
object AdbSetup {

    fun run(ctx: Context, port: Int, log: (String) -> Unit) {
        val pkg = ctx.packageName
        try {
            val priv = File(ctx.filesDir, "adbkey")
            val pub = File(ctx.filesDir, "adbkey.pub")
            if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
            val kp = AdbKeyPair.read(priv, pub)

            log("127.0.0.1:$port ünvanına qoşulur…\n(Telefonda 'USB debugging-ə icazə ver' pəncərəsi çıxsa — 'Həmişə icazə ver' seçib təsdiqləyin)")
            Dadb.create("127.0.0.1", port, kp).use { d ->
                fun sh(cmd: String) {
                    try {
                        val r = d.shell(cmd)
                        val out = (r.output + r.errorOutput).trim()
                        log("» $cmd\n   " + (if (r.exitCode == 0) "OK" else "XƏTA(${r.exitCode})") + (if (out.isNotEmpty()) " — $out" else ""))
                    } catch (e: Exception) {
                        log("» $cmd\n   İSTİSNA: ${e.message}")
                    }
                }

                log("✔ Qoşuldu")
                // Runtime icazələr
                listOf(
                    "RECORD_AUDIO", "READ_PHONE_STATE", "READ_CALL_LOG", "READ_CONTACTS", "WRITE_SECURE_SETTINGS"
                ).forEach { sh("pm grant $pkg android.permission.$it") }
                // Sistem icazəsi — adətən üçüncü tərəf tətbiqə verilmir (xəta normaldır)
                sh("pm grant $pkg android.permission.CAPTURE_AUDIO_OUTPUT")

                // AppOps
                listOf(
                    "SYSTEM_ALERT_WINDOW", "RECORD_AUDIO", "RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND",
                    "SCHEDULE_EXACT_ALARM", "START_FOREGROUND"
                ).forEach { sh("appops set $pkg $it allow") }
                // MIUI: avtostart (10008) və arxa planda pəncərə açma (10021)
                sh("appops set $pkg 10008 allow")
                sh("appops set $pkg 10021 allow")

                // Batareya optimallaşdırmasından çıxar, aktiv bucket
                sh("dumpsys deviceidle whitelist +$pkg")
                sh("am set-standby-bucket $pkg active")

                // Əlçatımlılıq xidmətini aktiv et
                val comp = "$pkg/$pkg.CallAccessibilityService"
                val cur = try { d.shell("settings get secure enabled_accessibility_services").output.trim() } catch (e: Exception) { "" }
                val list = when {
                    cur.isEmpty() || cur == "null" -> comp
                    cur.contains(comp) -> cur
                    else -> "$cur:$comp"
                }
                sh("settings put secure enabled_accessibility_services $list")
                sh("settings put secure accessibility_enabled 1")

                log("\n✅ Bitdi. 'Quraşdırma' səhifəsində statusları yoxlayın.")
            }
        } catch (e: Exception) {
            log("❌ Qoşulmadı: ${e.message}\n\nKompüterdən bir dəfə işlədin:\n   adb tcpip $port\nsonra yenidən cəhd edin.")
        }
    }
}
