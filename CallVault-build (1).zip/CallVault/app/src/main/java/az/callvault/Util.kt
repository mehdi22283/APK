package az.callvault

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Fmt {
    private val df = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    fun dt(ms: Long): String = df.format(Date(ms))
    fun dur(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%02d:%02d".format(m, x)
    }
}

object P {
    private fun sp(c: Context) = c.getSharedPreferences("callvault", Context.MODE_PRIVATE)
    fun bool(c: Context, k: String, d: Boolean = true) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

object RecState {
    @Volatile var currentId = -1L
    @Volatile var up = false
    @Volatile var recording = false
}

object Notifs {
    const val CH_SVC = "svc"
    const val CH_SAVED = "saved"
    const val CH_REM = "rem"

    fun init(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SVC, "Xidmət", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SAVED, "Yazılmış zənglər", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_REM, "Xatırlatmalar", NotificationManager.IMPORTANCE_HIGH))
    }
}

object Contacts {
    fun name(c: Context, number: String?): String? {
        if (number.isNullOrBlank()) return null
        if (c.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0)
            }
        } catch (e: Exception) { Log.w("CallVault", "contact lookup", e) }
        return null
    }
}

object Svc {
    /** RecorderService-i işə salır / ona əmr göndərir. */
    fun send(c: Context, act: String? = null, extra: (Intent.() -> Unit)? = null) {
        val i = Intent(c, RecorderService::class.java)
        if (act != null) i.action = act
        extra?.invoke(i)
        try {
            c.startForegroundService(i)
        } catch (e: Exception) {
            try { c.startService(i) } catch (e2: Exception) { Log.e("CallVault", "service start failed", e2) }
        }
    }
}
