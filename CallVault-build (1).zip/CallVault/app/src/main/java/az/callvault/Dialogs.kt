package az.callvault

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.util.Calendar

object Dialogs {

    private fun box(ctx: Context) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), 0)
    }

    fun noteDialog(ctx: Context, recId: Long, existing: Note?, onDone: () -> Unit): AlertDialog {
        val db = Db.get(ctx)
        val v = box(ctx)
        val t = EditText(ctx).apply { hint = "Başlıq"; setText(existing?.title ?: "") }
        val b = EditText(ctx).apply {
            hint = "Qeyd"; minLines = 4; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(existing?.body ?: "")
        }
        v.addView(t); v.addView(b)
        val rid = existing?.recId ?: recId
        if (rid > 0) db.rec(rid)?.let {
            v.addView(TextView(ctx).apply { text = "📞 Əlaqəli zəng: ${it.label()} (${Fmt.dt(it.started)})"; setPadding(0, ctx.dp(8), 0, 0) })
        }
        val d = MaterialAlertDialogBuilder(ctx)
            .setTitle(if (existing == null) "Yeni qeyd" else "Qeydi redaktə et")
            .setView(v)
            .setPositiveButton("Yadda saxla") { _, _ ->
                val title = t.text.toString().trim()
                val body = b.text.toString().trim()
                if (title.isNotEmpty() || body.isNotEmpty()) {
                    db.saveNote(Note(existing?.id ?: 0, title, body, existing?.created ?: System.currentTimeMillis(), rid))
                    onDone()
                }
            }
            .setNegativeButton("Ləğv et", null)
            .create()
        d.show()
        return d
    }

    fun reminderDialog(ctx: Context, recId: Long, existing: Reminder?, onDone: () -> Unit): AlertDialog {
        val db = Db.get(ctx)
        val rid = existing?.recId ?: recId
        val cal = Calendar.getInstance().apply { timeInMillis = existing?.time ?: (System.currentTimeMillis() + 3_600_000) }
        val v = box(ctx)
        val defTitle = existing?.title ?: db.rec(rid)?.let { "Zəngə qayıt: " + it.label() } ?: ""
        val t = EditText(ctx).apply { hint = "Başlıq"; setText(defTitle) }
        val b = EditText(ctx).apply { hint = "Qeyd (ixtiyari)"; setText(existing?.body ?: "") }
        val pick = Button(ctx)
        fun upd() { pick.text = "🕒 " + Fmt.dt(cal.timeInMillis) }
        upd()
        pick.setOnClickListener {
            DatePickerDialog(ctx, { _, y, m, day ->
                cal.set(y, m, day)
                TimePickerDialog(ctx, { _, hh, mi ->
                    cal.set(Calendar.HOUR_OF_DAY, hh); cal.set(Calendar.MINUTE, mi); cal.set(Calendar.SECOND, 0)
                    upd()
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        v.addView(t); v.addView(b); v.addView(pick)

        val builder = MaterialAlertDialogBuilder(ctx)
            .setTitle(if (existing == null) "Yeni xatırlatma" else "Xatırlatmanı redaktə et")
            .setView(v)
            .setPositiveButton("Yadda saxla") { _, _ ->
                val title = t.text.toString().trim().ifEmpty { "Xatırlatma" }
                val r = Reminder(existing?.id ?: 0, title, b.text.toString().trim(), cal.timeInMillis, rid, false)
                val id = db.saveReminder(r)
                Reminders.schedule(ctx, r.copy(id = id))
                if (r.time <= System.currentTimeMillis()) Toast.makeText(ctx, "Vaxt keçmişdədir — həyəcan qurulmadı", Toast.LENGTH_LONG).show()
                onDone()
            }
            .setNegativeButton("Ləğv et", null)
        if (existing != null) {
            builder.setNeutralButton(if (existing.done) "Yenidən aç" else "Bitdi ✔") { _, _ ->
                db.setDone(existing.id, !existing.done)
                Reminders.schedule(ctx, existing.copy(done = !existing.done))
                onDone()
            }
        }
        val d = builder.create()
        d.show()
        return d
    }

    fun confirm(ctx: Context, msg: String, yes: () -> Unit) {
        MaterialAlertDialogBuilder(ctx).setMessage(msg)
            .setPositiveButton("Bəli") { _, _ -> yes() }
            .setNegativeButton("Xeyr", null).show()
    }
}

object RecordingDialog {

    fun show(act: Activity, id: Long, onChange: () -> Unit = {}) {
        val db = Db.get(act)
        val r = db.rec(id) ?: return
        val h = Handler(Looper.getMainLooper())
        var mp: MediaPlayer? = null

        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        }
        val dir = when (r.dir) { "in" -> "Gələn"; "out" -> "Gedən"; else -> "—" }
        val typeS = when (r.type) { "phone" -> "Telefon"; "whatsapp" -> "WhatsApp"; else -> "Əl ilə" }
        val info = TextView(act).apply {
            text = "${r.label()}\n${r.number ?: ""}\n$typeS · $dir · ${Fmt.dt(r.started)} · ${Fmt.dur(r.dur)}\nMənbə: ${r.source}" +
                if (r.status == "silent") "\n\n⚠ Yazı səssizdir: Android zəng zamanı mikrofonu blokladı. Quraşdırmada 'Avto-dinamik'i yandırın və ya mənbəni dəyişin." else ""
            textSize = 14f
        }
        val seek = SeekBar(act)
        val play = Button(act).apply { text = "▶ Dinlə" }
        play.setOnClickListener {
            try {
                if (mp == null) {
                    mp = MediaPlayer().apply {
                        setDataSource(r.path); prepare(); seek.max = duration
                        setOnCompletionListener { play.text = "▶ Dinlə"; seek.progress = 0 }
                    }
                }
                val p = mp!!
                if (p.isPlaying) { p.pause(); play.text = "▶ Davam" }
                else {
                    p.start(); play.text = "⏸ Pauza"
                    h.post(object : Runnable {
                        override fun run() {
                            val q = mp ?: return
                            if (q.isPlaying) { seek.progress = q.currentPosition; h.postDelayed(this, 300) }
                        }
                    })
                }
            } catch (e: Exception) { Toast.makeText(act, "Oxunmadı: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) mp?.seekTo(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val linked = TextView(act).apply {
            val ns = db.notes(id); val rs = db.reminders(id)
            val sb = StringBuilder()
            ns.forEach { sb.append("📝 ").append(it.title.ifBlank { it.body.take(40) }).append('\n') }
            rs.forEach { sb.append(if (it.done) "✔ " else "⏰ ").append(it.title).append(" — ").append(Fmt.dt(it.time)).append('\n') }
            text = sb.toString().trim()
            setPadding(0, act.dp(8), 0, act.dp(8))
        }
        root.addView(info); root.addView(play); root.addView(seek); root.addView(linked)

        lateinit var dlg: AlertDialog
        fun action(label: String, f: () -> Unit) {
            root.addView(Button(act).apply { text = label; setOnClickListener { f() } })
        }
        action("📝 Qeyd əlavə et") {
            dlg.dismiss(); Dialogs.noteDialog(act, id, null) { onChange(); show(act, id, onChange) }
        }
        action("⏰ Xatırlatma əlavə et") {
            dlg.dismiss(); Dialogs.reminderDialog(act, id, null) { onChange(); show(act, id, onChange) }
        }
        action("📤 Paylaş") {
            try {
                val uri = FileProvider.getUriForFile(act, act.packageName + ".fp", File(r.path))
                act.startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("audio/mp4").putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Paylaş"))
            } catch (e: Exception) { Toast.makeText(act, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        action("💾 Musiqi/CallVault qovluğuna köçür") { export(act, r) }
        action("🗑 Sil") {
            Dialogs.confirm(act, "Bu yazı silinsin?") { dlg.dismiss(); db.deleteRec(id); onChange() }
        }

        val scroll = android.widget.ScrollView(act).apply { addView(root) }
        dlg = MaterialAlertDialogBuilder(act).setTitle("Zəng yazısı").setView(scroll)
            .setPositiveButton("Bağla", null).create()
        dlg.setOnDismissListener { try { mp?.release() } catch (e: Exception) { }; mp = null; h.removeCallbacksAndMessages(null) }
        dlg.show()
    }

    private fun export(act: Activity, r: Rec) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, File(r.path).name)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/CallVault")
            }
            val uri = act.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv)!!
            act.contentResolver.openOutputStream(uri)!!.use { out -> File(r.path).inputStream().use { it.copyTo(out) } }
            Toast.makeText(act, "Köçürüldü: Music/CallVault", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(act, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() }
    }
}
