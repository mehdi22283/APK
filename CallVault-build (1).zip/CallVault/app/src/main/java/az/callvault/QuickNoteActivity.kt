package az.callvault

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** Zəng zamanı overlay-dən və ya bildirişdən açılan sürətli qeyd/xatırlatma pəncərəsi. */
class QuickNoteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rid = intent.getLongExtra("rec", -1).let { if (it > 0) it else RecState.currentId }
        val d = if (intent.getStringExtra("kind") == "reminder")
            Dialogs.reminderDialog(this, rid, null) {}
        else Dialogs.noteDialog(this, rid, null) {}
        d.setOnDismissListener { finish() }
    }
}
