package az.callvault

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

data class Rec(
    val id: Long, val path: String, val number: String?, val name: String?,
    val type: String, val dir: String, val started: Long, val dur: Long,
    val source: String, val status: String
) {
    fun label(): String =
        name?.takeIf { it.isNotBlank() } ?: number?.takeIf { it.isNotBlank() } ?: when (type) {
            "whatsapp" -> "WhatsApp zəngi"
            "manual" -> "Əl ilə yazı"
            else -> "Naməlum nömrə"
        }
}

data class Note(val id: Long, val title: String, val body: String, val created: Long, val recId: Long)
data class Reminder(val id: Long, val title: String, val body: String, val time: Long, val recId: Long, val done: Boolean)

class Db private constructor(c: Context) : SQLiteOpenHelper(c, "callvault.db", null, 1) {

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Db(c.applicationContext).also { inst = it }
        }
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE rec(id INTEGER PRIMARY KEY AUTOINCREMENT,path TEXT,number TEXT,name TEXT,type TEXT,dir TEXT,started INTEGER,dur INTEGER,source TEXT,status TEXT)")
        d.execSQL("CREATE TABLE note(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,created INTEGER,rec_id INTEGER)")
        d.execSQL("CREATE TABLE reminder(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,time INTEGER,rec_id INTEGER,done INTEGER)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    // ---------- Recordings ----------
    private val recCols = "id,path,number,name,type,dir,started,dur,source,status"

    private fun recOf(c: Cursor) = Rec(
        c.getLong(0), c.getString(1) ?: "", c.getString(2), c.getString(3),
        c.getString(4) ?: "", c.getString(5) ?: "unknown", c.getLong(6), c.getLong(7),
        c.getString(8) ?: "", c.getString(9) ?: ""
    )

    fun recs(): List<Rec> {
        val l = ArrayList<Rec>()
        readableDatabase.rawQuery("SELECT $recCols FROM rec ORDER BY started DESC", null).use {
            while (it.moveToNext()) l.add(recOf(it))
        }
        return l
    }

    fun rec(id: Long): Rec? {
        readableDatabase.rawQuery("SELECT $recCols FROM rec WHERE id=?", arrayOf(id.toString())).use {
            return if (it.moveToFirst()) recOf(it) else null
        }
    }

    fun insertRec(path: String, number: String?, name: String?, type: String, dir: String, started: Long, source: String): Long {
        val cv = ContentValues().apply {
            put("path", path); put("number", number); put("name", name); put("type", type)
            put("dir", dir); put("started", started); put("dur", 0); put("source", source)
            put("status", "recording")
        }
        return writableDatabase.insert("rec", null, cv)
    }

    fun updateRec(id: Long, cv: ContentValues) {
        writableDatabase.update("rec", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteRecRow(id: Long) {
        writableDatabase.delete("rec", "id=?", arrayOf(id.toString()))
    }

    fun deleteRec(id: Long) {
        rec(id)?.let { File(it.path).delete() }
        deleteRecRow(id)
    }

    // ---------- Notes ----------
    private fun noteOf(c: Cursor) = Note(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), c.getLong(4))

    fun notes(recId: Long = 0): List<Note> {
        val l = ArrayList<Note>()
        val q = if (recId > 0) "SELECT id,title,body,created,rec_id FROM note WHERE rec_id=$recId ORDER BY created DESC"
        else "SELECT id,title,body,created,rec_id FROM note ORDER BY created DESC"
        readableDatabase.rawQuery(q, null).use { while (it.moveToNext()) l.add(noteOf(it)) }
        return l
    }

    fun saveNote(n: Note): Long {
        val cv = ContentValues().apply {
            put("title", n.title); put("body", n.body); put("created", n.created); put("rec_id", n.recId)
        }
        return if (n.id > 0) { writableDatabase.update("note", cv, "id=?", arrayOf(n.id.toString())); n.id }
        else writableDatabase.insert("note", null, cv)
    }

    fun deleteNote(id: Long) { writableDatabase.delete("note", "id=?", arrayOf(id.toString())) }

    // ---------- Reminders ----------
    private fun remOf(c: Cursor) = Reminder(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), c.getLong(4), c.getInt(5) == 1)

    fun reminders(recId: Long = 0): List<Reminder> {
        val l = ArrayList<Reminder>()
        val q = if (recId > 0) "SELECT id,title,body,time,rec_id,done FROM reminder WHERE rec_id=$recId ORDER BY time ASC"
        else "SELECT id,title,body,time,rec_id,done FROM reminder ORDER BY done ASC, time ASC"
        readableDatabase.rawQuery(q, null).use { while (it.moveToNext()) l.add(remOf(it)) }
        return l
    }

    fun reminder(id: Long): Reminder? {
        readableDatabase.rawQuery("SELECT id,title,body,time,rec_id,done FROM reminder WHERE id=?", arrayOf(id.toString())).use {
            return if (it.moveToFirst()) remOf(it) else null
        }
    }

    fun saveReminder(r: Reminder): Long {
        val cv = ContentValues().apply {
            put("title", r.title); put("body", r.body); put("time", r.time)
            put("rec_id", r.recId); put("done", if (r.done) 1 else 0)
        }
        return if (r.id > 0) { writableDatabase.update("reminder", cv, "id=?", arrayOf(r.id.toString())); r.id }
        else writableDatabase.insert("reminder", null, cv)
    }

    fun setDone(id: Long, done: Boolean) {
        val cv = ContentValues().apply { put("done", if (done) 1 else 0) }
        writableDatabase.update("reminder", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteReminder(id: Long) { writableDatabase.delete("reminder", "id=?", arrayOf(id.toString())) }
}
