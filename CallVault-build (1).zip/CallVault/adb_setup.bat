
REM Kompüterdən (USB ilə) bütün icazələri vermək üçün alternativ yol.
set P=az.callvault
adb shell pm grant %P% android.permission.RECORD_AUDIO
adb shell pm grant %P% android.permission.READ_PHONE_STATE
adb shell pm grant %P% android.permission.READ_CALL_LOG
adb shell pm grant %P% android.permission.READ_CONTACTS
adb shell pm grant %P% android.permission.WRITE_SECURE_SETTINGS
adb shell appops set %P% SYSTEM_ALERT_WINDOW allow
adb shell appops set %P% RECORD_AUDIO allow
adb shell appops set %P% RUN_IN_BACKGROUND allow
adb shell appops set %P% RUN_ANY_IN_BACKGROUND allow
adb shell appops set %P% START_FOREGROUND allow
adb shell appops set %P% 10008 allow
adb shell appops set %P% 10021 allow
adb shell dumpsys deviceidle whitelist +%P%
adb shell am set-standby-bucket %P% active
adb shell settings put secure enabled_accessibility_services %P%/%P%.CallAccessibilityService
adb shell settings put secure accessibility_enabled 1
echo "Hazırdır. Lokal ADB üçün həmçinin:  adb tcpip 5555"
