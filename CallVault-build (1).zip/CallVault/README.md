# CallVault — Redmi Note 9 Pro (Android 12) lokal zəng yazıcı

Telefon + WhatsApp zəng yazıcı, zəngə bağlı qeyd/xatırlatma, ümumi qeyd və xatırlatma siyahıları,
yazı zamanı overlay göstəricisi, avtostart. Kompüter tələb olunmur.

## Kompüter olmadan build (yalnız telefon)
1. github.com-da hesab açın, "New repository" yaradın (Private ola bilər).
2. Repo-da "Add file → Upload files" ilə `CallVault-build.zip` faylını OLDUĞU KİMİ (açmadan) yükləyin → Commit.
3. "Add file → Create new file" → ad yerinə `.github/workflows/build.yml` yazın, `build.yml` faylının məzmununu yapışdırın → Commit.
4. "Actions" tabı → "Build APK" → Run workflow. 3-6 dəqiqə sonra yaşıl olur.
5. İşin səhifəsinin altındakı "CallVault-apk" artefaktını endirin, zip-i açın, `app-debug.apk`-ı quraşdırın
   ("Naməlum mənbələrdən quraşdırmaya icazə" verin).
   Build xətası olsa, loqun xəta sətrini mənə göndərin, düzəldim.

## Telefondan quraşdırma
Tətbiq → "Quraşdırma" tabı: İcazələr → Overlay → Əlçatımlılıq (CallVault aktiv) → Batareya →
MIUI Avtostart + son tətbiqlərdə 🔒 kilid.

## Məhdudiyyətlər (Android 12 / MIUI)
- Android 10+ üçüncü tərəf tətbiqlərə zəng səsini (VOICE_CALL) vermir. Tətbiq mikrofon mənbələrini
  ardıcıl yoxlayır; qarşı tərəfi eşitmək üçün "avto-dinamik" parametrini yandırın.
- Yazı səssiz çıxarsa siyahıda ⚠ səssiz işarəsi görünür.
- WhatsApp: əlçatımlılıq xidməti zəng ekranını aşkarlayır, yazı mikrofonla aparılır.
- Zəng yazmaq üçün qarşı tərəfin razılığı qanunla tələb oluna bilər.
