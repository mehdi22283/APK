# IPTVPlayer — Media3

Yeganə pleyer: **Media3 1.11.1** (ExoPlayer, OkHttp ilə; MediaCodec + **FFmpeg** dekoderləri). mpv və VLC silinib. Versiya: **1.31** (versionCode 31).

## Kanal açılışı
Kanal açılanda yeganə yoxlama OkHttp-dir: link birbaşa Media3-ə verilir, HTTP 4xx/5xx və ya qoşulma xətası alınarsa dərhal "Kanal İşləmir" göstərilir (ehtiyat yoda.az linki varsa o başlayır). Ayrıca ilkin server sorğusu, cəhd zənciri, vaxt aşımı sayğacı və geri sayım yoxdur.

## Çık-çık səs / donan görüntü: özü həll edir
`Media3Engine` səs underrun-larını və atılan video kadrları izləyir. Problem olarsa kanal addım-addım yenidən açılır: 1) səs FFmpeg (proqram) dekoderi ilə, video MediaCodec ilə; 2) kanalın bufer səviyyəsi +1; 3) səs və video FFmpeg dekoderləri. Ən çox 3 düzəliş edilir. Düzgün işləyən rejim kanal üzrə yadda saxlanır (`DecoderMemory`), növbəti dəfə kanal birbaşa o rejimlə açılır.

## Media3 + FFmpeg
- FFmpeg dekoderləri: `io.github.anilbeesetti:nextlib-media3ext:1.11.1-0.16.0` (NextLib, **GPL-3.0**). Versiya adı `<Media3>-<NextLib>` formatındadır, Media3 versiyası ilə eyni saxlanmalıdır.
  - Səs: Vorbis, Opus, FLAC, ALAC, MP3, AAC, AC3, EAC3, DTS, MLP, TrueHD, AMR-NB/WB, PCM a-law/mu-law.
  - Video: H.264, HEVC, VP8, VP9 (FFmpeg), AV1 (dav1d).
- `ModeRenderersFactory` dekoder rejiminə görə renderer-ləri qurur (NORMAL / AUDIO_FFMPEG / ALL_FFMPEG).
- Kotlin **2.2.21**: NextLib Kotlin 2.2 ilə yığılıb.
- Alt məlumat zolağında pleyer işarəsi: 💙 Media3.

## Əsas fayllar
- `Media3Engine.kt` — mühərrik (OkHttp, dekoder rejimləri, keyfiyyət nəzarəti).
- `Engines.kt` — `PlayerManager` (avtomatik bərpa, watchdog, ağıllı bufer).
- `DecoderMemory.kt` — kanal üzrə dekoder rejimi yaddaşı; `BufferMemory.kt` — kanal üzrə bufer səviyyəsi.

Ətraflı: `PLAYBACK_OPTIMIZATION.md`.

## 2 GB RAM TV box
Kiçik bufer (24 MB), `largeHeap`, universal APK (`armeabi-v7a` + `arm64-v8a`).

## Toolchain
- JDK 17, Gradle 8.14.3 (CI), AGP 8.11.1, Kotlin 2.2.21
- compileSdk 36, targetSdk 33, minSdk 24 (Android 7.0), core library desugaring
- OkHttp 4.12.0 (playlist/EPG və Media3 yayım sorğuları)

## Debug APK
```bash
gradle assembleDebug --no-daemon
```
Debug imza ilə qalır, amma `isDebuggable = false`.

## TV pultu: kanal paneli
Pultda yuxarı düymə ilə açılan kanal dəyişmə paneli avtomatik vaxt bitiminə görə bağlanmır. Panel geri düyməsi ilə, toxunuşla bağlandıqda və ya kanal seçildikdə bağlanır.

## Telefon / planşet idarəetməsi (toxunma)
- Videoya **tək toxunuş**: yuxarıda kanallar siyahısı, kanal zolağı və proqram cədvəli düymələri çıxır (4 s sonra gizlənir). Alt EPG zolağı kanal dəyişəndə çıxır və 4 s sonra gizlənir.
- **İki dəfə toxunuş**: pauza / davam.
- **Sağa/sola sürüşdür**: əvvəlki / növbəti kanal.
- **Sağ yarıda yuxarı/aşağı sürüşdür**: səs; **sol yarıda**: ekran parlaqlığı.
- Kanallar siyahısı və proqram cədvəlində sağ yuxarıda ✕ düyməsi var; sistem "geri" jesti də işləyir.
- TV pultu işləməyə davam edir (pult düyməsi basılanda toxunma düymələri gizlənir).

## Playlist mənbəsi
Yalnız `m3u8.mehdimyev.workers.dev` playlisti istifadə olunur (`Data.kt` → `PLAYLIST_URL`). Keş faylı `playlist_mehdimyev.m3u`-dur; köhnə mənbədən qalan `playlist.m3u` ilk açılışda silinir. Yükləmə alınmasa təkrar cəhdlər 8 s, 20 s, 45 s, 90 s, 180 s fasilə ilə aparılır.

## Son kanal
Son izlənən kanal link, ad, qrup və tvg-id ilə saxlanılır. Playlistdə linki dəyişsə də, tətbiq yenidən açılanda kanal ad/qrup və ya tvg-id ilə tapılıb açılır.

## Sabitlik
`App.kt`-dəki təhlükəsizlik toru tutulmayan Java/Kotlin xətasında tətbiqi avtomatik yenidən açır (15 s-də təkrar çökərsə açmır).

## EPG əl ilə əlaqələndirmə
`Epg.kt` → `EPG_ALIASES`: cbc-sport, ictimai-tv, muztv, kanal-7-hd-tr, show-hd-tr, star-tv-hd-tr, tv8-tr, tv85-tr, trt-1/2/3-hd, trt-avaz, trt-cocuk-tr, trt-haber-hd, trt-muzik-tr, trt-spor-yild-tr, trt-turk-tr, trt4k-tr, dmax-tr XML kanalları playlistdəki uyğun adlarla (hd/tr/boşluq/diakritikdən asılı olmayaraq) bağlanır. EPG-də proqram təsviri 160 simvolla məhduddur.

## Ehtiyat link (yoda.az)
Playlistdəki link açılmasa, tətbiq kanalın **yoda.az** səhifəsini gizli WebView-da açır, səhifənin pleyerinin göndərdiyi tokenli `.m3u8` linkini tutur və pleyerə verir (`Backup.kt`).
- Yalnız playlistdə **"Azərbaycan"** qrupunda olan 19 kanal üçün: AZTV, MƏDƏNİYYƏT TV, İDMAN TV, BİZNES TV, BAKU TV, APA TV, REAL TV, ARB 24 HD, ARB GÜNƏŞ HD, ARB, İCTİMAİ TV, SPACE TV, ATV, XƏZƏR TV HD, DÜNYA TV HD, NAXÇIVAN TV, KANAL 35, QAFQAZ TV, EL TV. Kanal adı normallaşdırılaraq (diakritik, boşluq, sondakı HD atılır) `Backup.PAGES` cədvəli ilə uyğunlaşdırılır; Türkiyə qrupundakı eyni adlı kanallara toxunulmur.
- Token IP və User-Agent-ə bağlıdır: link bu cihazda alınır, oynatma eyni User-Agent və Referer ilə aparılır (Media3: User-Agent və Referer başlıqları).
- Ardıcıllıq: playlist linki → (açılmasa) yoda.az-dan tokenli link. Ehtiyat link sonradan qırılsa (məs. token bitsə) link yenidən alınır (ardıcıl 3 cəhd; işləyəndə sayğac sıfırlanır).
- Ehtiyat linkdə `.m3u8` sorğusu tapılmasa 20 s sonra "Kanal İşləmir" göstərilir. Loglar: `adb logcat -s IPTV-BACKUP`.
- WebView yalnız lazım olanda yaradılır, şəkil yükləmə söndürülüb, iş bitən kimi yaddaşdan silinir; render prosesi ölərsə tətbiq çökmür.

### Apa TV: əvvəl yoda.az
Apa TV (`Backup.YODA_FIRST`) əksinə açılır: **yoda.az tokenli link**; link alınmasa və ya işləməsə **playlistdəki link** ehtiyat kimi açılır. yoda linki işləyib sonradan qırılsa (token bitsə) əvvəl yenilənir, alınmasa playlistə keçilir. Digər kanallar əvvəlki qaydadadır.

Loglar: `adb logcat -s IPTV-MEDIA3 IPTV-PLAYER`.

## Kanal nömrəsi (v1.26)
- **Ekran rəqəm paneli** (telefon/planşet): videoya toxun → yuxarıda `123` düyməsi → 0–9, ⌫ (sil), ✓ (aç). Nömrə yuxarı sağda göstərilir, 10 san hərəkətsizlikdən sonra panel bağlanır. Geri düyməsi/videoya toxunuş də bağlayır. Pult rəqəmləri əvvəlki kimi işləyir.

## Kanal axtarışı
- **Pult:** yayım ekranında **aşağı** düymə (və ya pultun axtarış düyməsi) axtarışı açır; ekranın yuxarı yarısında nəticələr, aşağıdan klaviatura açılır.
- **Toxunma:** videoya toxunanda yuxarıda 🔍 düyməsi.
- Hərf yazdıqca nəticələr dinamik yenilənir: əvvəl adı həmin hərflə başlayanlar (B → Beyaz TV, Bir TV), sonra sözü başlayanlar, sonra içində olanlar. Azərbaycan hərfləri (ə, ı, ö, ü, ş, ç, ğ) latın qarşılığı ilə də tapılır. Kanal nömrəsi yazmaq da işləyir.
- Klaviaturada "Axtar"/Enter birinci nəticəni açır; nəticəyə OK/toxunuş kanalı açır. Geri düyməsi klaviaturanı, sonra axtarışı bağlayır.
- Görüntü nisbəti dəyişdirmə funksiyası silindi (video əvvəlki kimi tam ekran uzanır).

## TCL 65C6K / Google TV uyğunlaşması (1.31)
TCL 65C6K: Google TV, MediaTek MT9653, 3 GB RAM, 4K@144 Hz, HDR10/HDR10+/HLG/Dolby Vision, Dolby Atmos/DTS. TV-nin şəkil mühərriki (AiPQ AI upscaling, MEMC, local dimming, Dolby Vision IQ) tətbiqdən idarə olunmur, TV özü tətbiq edir; tətbiq yalnız bu yolu bağlamır:
- Video `SurfaceView` + `MediaCodec` (hardware) ilə gedir. TV-də keyfiyyət problemində video heç vaxt FFmpeg (proqram) dekoderinə keçirilmir (`TvProfile`); yalnız dekoder tam açılmasa (`onPlayerError`) son çarə kimi keçir.
- `TvProfile`: TV aşkarlanması, RAM, maksimum yenilənmə tezliyi (Hz) və HDR növləri icra zamanı oxunur və `IPTV-TV` log teqi ilə yazılır. 3 GB-lı TV-də bufer həddi 48 MB (4K axınlar üçün).
- Kadr tezliyi uyğunlaşdırması: `ONLY_IF_SEAMLESS` (qara ekransız). TV ayarı: Display & Sound → Match content frame rate.
- Yayım başlığında video yolu etiketi: məs. `3840x2160 HDR10·HW` (HW = hardware dekoder, SW = proqram dekoder).
- Pult: Play, Pause, GUIDE (EPG), INFO düymələri əlavə edildi (CH+/CH-, rəqəmlər, Menu, Search, Play/Pause əvvəldən var idi).
- Manifest: `density|uiMode|colorMode|navigation|...` configChanges; TV ekran/HDR rejimini dəyişəndə Activity yenidən yaranmır, oynatma kəsilmir.
