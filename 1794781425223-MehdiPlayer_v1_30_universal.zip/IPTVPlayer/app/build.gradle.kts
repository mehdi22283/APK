import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "az.mehdi.iptvplayer"
    compileSdk = 36

    defaultConfig {
        applicationId = "az.mehdi.iptvplayer"
        minSdk = 24
        targetSdk = 33
        versionCode = 30
        versionName = "1.30"

        // Universal APK: 32-bit (armv7) və 64-bit (armv8/arm64) ARM. Cihaz öz ABI-sini avtomatik seçir.
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
    }

    buildTypes {
        // Debug imza ilə qalır, amma debuggable söndürülür: TV box-da ART tam optimallaşdırma ilə işləyir.
        debug {
            isDebuggable = false
        }
    }

    packaging {
        // libVLC, mpv və NextLib (FFmpeg) hər biri libc++_shared.so gətirir: biri seçilir.
        jniLibs { pickFirsts += "**/libc++_shared.so" }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Android 7.1 (API 25) üçün java.time və yeni Java API-lərini uyğunlaşdırır.
        isCoreLibraryDesugaringEnabled = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // java.time API-ləri API 26-dan aşağı Android versiyalarında da işləsin.
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // OkHttp: playlist/EPG yükləmə və kanalın serverinə ilkin sorğu üçün (pleyer deyil).
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Birinci pleyer: Media3 (ExoPlayer, yalnız http/https). Codec dəstəklənməyəndə əvvəl FFmpeg dekoderləri, sonra mpv.
    val media3 = "1.11.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-datasource-okhttp:$media3")

    // Media3 üçün FFmpeg (NextLib, GPL-3.0): səs (AAC, AC3, EAC3, DTS, TrueHD, MP3, Opus, Vorbis, FLAC, ALAC ...) və
    // video (H.264, HEVC, VP8, VP9, AV1) proqram dekoderləri. Versiya adı: <Media3 versiyası>-<NextLib versiyası>,
    // Media3 versiyası ilə eyni olmalıdır. Native kitabxanalar libavcodec.so/libavformat.so/libavutil.so/libswscale.so/
    // libswresample.so adları ilə gəlir; mpv-nin kitabxanaları toqquşmasın deyi libmv*/libmw* adlarına çevrilib (aşağıya bax).
    implementation("io.github.anilbeesetti:nextlib-media3ext:$media3-0.16.0")

    // Üçüncü ehtiyat pleyer: VLC (libVLC). Native kitabxanalar Maven-dən gəlir, abiFilters armeabi-v7a və arm64-v8a saxlayır. Versiya 3.7.7.
    implementation("org.videolan.android:libvlc-all:3.7.7")

    // İkinci ehtiyat pleyer: mpv. Native kitabxanalar (libmpv, libplayer, libmv*/libmw* = əvvəlki libav*/libsw*) app/src/main/jniLibs/{armeabi-v7a,arm64-v8a} içindədir,
    // JNI körpüsü: app/src/main/java/is/xyz/mpv/MPVLib.kt (mpv v0.41.0-1049-g0b7ed670f, Mpv.zip-dən).
}
