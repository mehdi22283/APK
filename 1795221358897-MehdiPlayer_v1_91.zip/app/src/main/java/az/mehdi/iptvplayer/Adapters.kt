package az.mehdi.iptvplayer

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.LayoutInflater
import android.view.View
import android.view.SurfaceView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.doOnNextLayout
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// MainActivity.kt-dən ayrılıb (v1.90): ümumi köməkçilər və RecyclerView adapterləri.
/** Arxa plan işlərində tutulmayan xəta tətbiqi çökdürməsin. */
val safeHandler = CoroutineExceptionHandler { _, t -> android.util.Log.w("IPTV", "arxa plan xətası", t) }
internal val CLOCK_FMT: java.time.format.DateTimeFormatter = java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")

/** Eyni mətn təkrar verilmir: hər setText layout tələb edir və video üstündə kadr düşməsi yarada bilir. */
fun TextView.setTextIfChanged(s: CharSequence) {
    if (text.toString() != s.toString()) text = s
}

/** Fokus alan element mavi rənglənmir, yerində böyüyüb qabarır. */
fun View.pop(has: Boolean, scale: Float = 1.07f) {
    animate().cancel()
    animate().scaleX(if (has) scale else 1f).scaleY(if (has) scale else 1f)
        .translationZ(if (has) resources.displayMetrics.density * 12f else 0f)
        .setDuration(120).start()
}

class ChannelAdapter(
    private val logos: LogoStore,
    private val epg: EpgStore,
    private val scope: CoroutineScope,
    private val layoutRes: Int = R.layout.item_channel,
    private val onFocusCh: ((Channel) -> Unit)? = null,
    /** true: siyahı sola və sağa sonsuz dövr edir (son kanaldan sonra yenə birincisi gəlir). */
    private val circular: Boolean = false,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    var items: List<Channel> = emptyList()
    var playingUrl: String? = null

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val epgTv: TextView = v.findViewById(R.id.epg)
        val epgNext: TextView? = v.findViewById(R.id.epgNext)
        val bar: ProgressBar? = v.findViewById(R.id.epgBar)
        val chGroup: TextView? = v.findViewById(R.id.chGroup)
        val chPos: TextView? = v.findViewById(R.id.chPos)
        var job: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))

    override fun getItemCount() = if (circular && items.size > 1) Int.MAX_VALUE else items.size

    /** Dövri siyahıda indeksin ortadakı nüsxəsinin mövqeyi (hər iki istiqamətdə sonsuz yer qalır). */
    fun basePosition(idx: Int): Int {
        if (!circular || items.size <= 1) return idx
        val mid = Int.MAX_VALUE / 2
        return mid - mid % items.size + idx
    }

    /** Oynayan kanal işarəsi yalnız görünən kartlarda yenilənir: kartlar yenidən bağlanmır, fokus və ölçü dəyişmir. */
    fun markPlaying(rv: RecyclerView, url: String?) {
        playingUrl = url
        for (i in 0 until rv.childCount) {
            val h = rv.getChildViewHolder(rv.getChildAt(i)) as? VH ?: continue
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) h.itemView.isActivated = urlAt(pos) == url
        }
    }

    private fun progText(p: Prog?): String = if (p == null) "" else "${hm(p.start)}  ${p.title}"

    /** Kartda indi gedən proqram: "20:00–21:00  Ad  · 25 dəq". */
    private fun nowText(p: Prog?): String {
        if (p == null) return ""
        val left = ((p.stop - System.currentTimeMillis() / 1000) / 60).toInt()
        val tail = if (left > 0) "  · $left dəq" else ""
        return "${hm(p.start)}–${hm(p.stop)}  ${p.title}$tail"
    }

    private fun urlAt(pos: Int): String? = if (pos < 0 || items.isEmpty()) null else items[pos % items.size].url

    override fun onBindViewHolder(h: VH, pos: Int) {
        val ch = items[pos % items.size]
        h.job?.cancel()
        // Qrup nişanı olan kartda ad təmiz göstərilir; nişansız (sətir) kartda nömrə adın önündədir.
        if (h.chGroup != null) {
            h.name.text = ch.name
            h.chGroup.text = ch.group
            h.chPos?.text = "${pos % items.size + 1}/${items.size}"
        } else {
            h.name.text = "${ch.number}.${ch.name}"
        }
        h.logo.setImageDrawable(null)
        val playing = ch.url == playingUrl
        h.itemView.isActivated = playing
        h.itemView.setOnClickListener { onClick(ch) }
        h.itemView.scaleX = if (h.itemView.isFocused) 1.07f else 1f
        h.itemView.scaleY = h.itemView.scaleX
        h.itemView.setOnFocusChangeListener { v, has -> v.pop(has); if (has) onFocusCh?.invoke(ch) }

        // Kart: logo / sıra və ad / indi gedən proqram / sonrakı proqram (aralarında boşluq yoxdur)
        val (now, nxt) = epg.nowNext(ch)
        val nxtStr = progText(nxt)
        val nxtTv = h.epgNext
        if (nxtTv != null) {
            // Kart: bütün kartlar eyni hündürlükdə qalsın deyə sətirlər INVISIBLE olur (GONE yox)
            val nowStr = nowText(now)
            h.epgTv.text = if (nowStr.isEmpty()) "EPG məlumatı yoxdur" else nowStr
            h.epgTv.alpha = if (nowStr.isEmpty()) 0.5f else 1f
            nxtTv.text = if (nxtStr.isEmpty()) " " else "▸ $nxtStr"
        } else {
            val nowStr = progText(now)
            // Tam ekran bölmədəki sətir: iki proqram bir mətndə
            val both = listOf(nowStr, nxtStr).filter { it.isNotEmpty() }.joinToString("\n")
            h.epgTv.text = both
            h.epgTv.visibility = if (both.isEmpty()) View.GONE else View.VISIBLE
        }
        h.bar?.let { b ->
            if (now != null && now.stop > now.start) {
                val t = System.currentTimeMillis() / 1000
                b.progress = (((t - now.start) * 100) / (now.stop - now.start)).toInt().coerceIn(0, 100)
                b.visibility = View.VISIBLE
            } else b.visibility = if (nxtTv != null) View.INVISIBLE else View.GONE
        }

        val cached = logos.peek(ch)
        if (cached != null) {
            h.logo.setImageBitmap(cached)
        } else {
            h.job = scope.launch(safeHandler) {
                val bmp = runCatching { logos.bitmapFor(ch) }.getOrNull()
                if (urlAt(h.bindingAdapterPosition) != ch.url) return@launch
                // Logo yoxdur/yüklənmədi: kanal adından avtomatik rəngli əvəzedici
                if (bmp != null && !bmp.isRecycled) h.logo.setImageBitmap(bmp)
                else h.logo.setImageDrawable(LogoPlaceholder(ch.name))
            }
        }
    }

    override fun onViewRecycled(h: VH) {
        h.job?.cancel()
    }
}

/** Tam ekran bölmədə sol tərəfdəki qruplar siyahısı. Fokus qrupa keçəndə sağda həmin qrupun kanalları göstərilir. */
class GroupAdapter(
    private val count: (String?) -> Int,
    private val onFocus: (String?) -> Unit,
    private val onPick: (String?) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {
    var items: List<String?> = emptyList()
    var selected: String? = null

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_group, p, false) as TextView)

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val g = items[pos]
        h.tv.text = "${g ?: "Hamısı"}  (${count(g)})"
        h.tv.isActivated = g == selected
        h.tv.setOnClickListener { onPick(g) }
        h.tv.setOnFocusChangeListener { v, has ->
            v.pop(has, 1.05f)
            if (has) {
                val old = items.indexOf(selected)
                selected = g
                // RecyclerView layout zamanı notify çağırmamaq üçün post ilə
                h.tv.post {
                    if (old >= 0) notifyItemChanged(old)
                    val ni = items.indexOf(g)
                    if (ni >= 0) notifyItemChanged(ni)
                }
                onFocus(g)
            }
        }
    }
}

/** Kanalın tam proqram cədvəli (OK-a iki dəfə basanda). */
class ProgAdapter : RecyclerView.Adapter<ProgAdapter.VH>() {
    var items: List<Prog> = emptyList()
    var nowStart: Long = -1L

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val time: TextView = v.findViewById(R.id.progTime)
        val title: TextView = v.findViewById(R.id.progTitle)
        val desc: TextView = v.findViewById(R.id.progDesc)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_prog, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        val now = p.start == nowStart
        val day = dayLabel(p.start)
        h.time.text = hm(p.start) + "–" + hm(p.stop) + (if (day.isEmpty()) "" else "\n$day")
        h.title.text = (if (now) "▶ " else "") + p.title
        h.desc.text = p.desc
        h.desc.visibility = if (p.desc.isBlank()) View.GONE else View.VISIBLE
        h.itemView.isActivated = now
    }
}
