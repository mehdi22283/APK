package az.mehdi.iptvplayer

import android.os.Handler
import android.os.Looper
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Əsas (playlist) linkin fonda yoxlanması: kanal ehtiyat linkdə oynayarkən əsas link [durationMs] ərzində yoxlanılır.
 * Pleyer və dekoder istifadə olunmur (zəif TV box-da ikinci dekoder açılmasın), yalnız OkHttp ilə şəbəkə yoxlaması:
 *  - HTTP 2xx cavab, HTML/xəta səhifəsi deyil;
 *  - düz axın (MPEG-TS və s.): müddət ərzində fasiləsiz və kifayət qədər bayt gəlir;
 *  - HLS: media playlist yenilənir (sequence artır) və son seqment yüklənir.
 * Nəticə əsas (UI) thread-də qaytarılır. Yalnız UI thread-indən çağırılır.
 */
class MainLinkProbe {
    private companion object {
        // Düz axında minimum bayt sürəti (~800 kbit/s): boş / boğulmuş / çox zəif axın "işləyir" sayılmır.
        const val MIN_BYTES_PER_SEC = 100_000L
        const val MAX_SEGMENT_BYTES = 6_000_000L
        // HLS: seqment yüklənməsi seqmentin öz müddətinin bu hissəsindən tez bitməlidir (real vaxtdan sürətli).
        const val MAX_SEGMENT_TIME_RATIO = 0.8
    }

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var generation = 0
    @Volatile private var call: Call? = null

    fun cancel() {
        generation++
        runCatching { call?.cancel() }
        call = null
    }

    fun check(url: String, ua: String?, ref: String?, durationMs: Long, done: (Boolean) -> Unit) {
        cancel()
        val gen = generation
        Thread {
            val ok = runCatching { probe(url, ua, ref, durationMs, gen) }.getOrDefault(false)
            ui.post { if (gen == generation) done(ok) }
        }.apply { isDaemon = true; name = "main-link-probe" }.start()
    }

    private fun alive(gen: Int) = gen == generation

    private fun request(url: String, ua: String?, ref: String?): Request {
        val b = Request.Builder().url(url).header("User-Agent", ua?.takeIf { it.isNotBlank() } ?: STREAM_DEFAULT_UA)
        ref?.takeIf { it.isNotBlank() }?.let { b.header("Referer", it) }
        return b.build()
    }

    private fun client(readMs: Long) = StreamHttp.client.newBuilder().readTimeout(readMs, TimeUnit.MILLISECONDS).build()

    private fun fetchText(url: String, ua: String?, ref: String?): String? {
        val c = client(4_000).newCall(request(url, ua, ref))
        call = c
        c.execute().use { r -> return if (r.isSuccessful) r.body?.string() else null }
    }

    private fun probe(url: String, ua: String?, ref: String?, durationMs: Long, gen: Int): Boolean {
        val start = System.currentTimeMillis()
        val c = client(4_000).newCall(request(url, ua, ref))
        call = c
        c.execute().use { r ->
            if (!r.isSuccessful) return false
            val type = r.header("Content-Type")?.lowercase().orEmpty()
            if (type.contains("text/html")) return false
            val body = r.body ?: return false
            val src = body.source()
            val isHls = url.lowercase().contains("m3u8") || type.contains("mpegurl") || (src.request(7) && src.peek().readUtf8(7) == "#EXTM3U")
            if (isHls) {
                val text = body.string()
                return probeHls(url, text, ua, ref, start, durationMs, gen)
            }
            // Düz axın: müddət boyu oxuyuruq.
            val buf = ByteArray(16 * 1024)
            var bytes = 0L
            val stream = body.byteStream()
            while (alive(gen) && System.currentTimeMillis() - start < durationMs) {
                val n = stream.read(buf)
                if (n < 0) break
                bytes += n
            }
            if (!alive(gen)) return false
            val secs = ((System.currentTimeMillis() - start).coerceAtLeast(1_000L)) / 1000
            return bytes >= MIN_BYTES_PER_SEC * minOf(secs, durationMs / 1000)
        }
    }

    private class Media(val sequence: Long, val lastSeg: String?, val segSeconds: Double)

    private fun parseMedia(base: String, text: String): Media? {
        var seq = 0L
        var dur = 0.0
        var last: String? = null
        for (raw in text.lineSequence()) {
            val l = raw.trim()
            if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
            else if (l.startsWith("#EXTINF:")) dur = l.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: 0.0
            else if (l.isNotEmpty() && !l.startsWith("#")) last = base.toHttpUrlOrNull()?.resolve(l)?.toString()
        }
        return if (last == null) null else Media(seq, last, dur)
    }

    private fun resolveMedia(url: String, text: String, ua: String?, ref: String?): Pair<String, String>? {
        var curUrl = url
        var curText = text
        repeat(2) {
            if (!curText.contains("#EXT-X-STREAM-INF")) return curUrl to curText
            val lines = curText.lines().map { it.trim() }
            val i = lines.indexOfFirst { it.startsWith("#EXT-X-STREAM-INF") }
            val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: return null
            curUrl = curUrl.toHttpUrlOrNull()?.resolve(uri)?.toString() ?: return null
            curText = fetchText(curUrl, ua, ref) ?: return null
        }
        return if (curText.contains("#EXTINF")) curUrl to curText else null
    }

    private fun downloadSegment(url: String, ua: String?, ref: String?): Long {
        val c = client(4_000).newCall(request(url, ua, ref))
        call = c
        c.execute().use { r ->
            if (!r.isSuccessful) return 0L
            val stream = (r.body ?: return 0L).byteStream()
            val buf = ByteArray(16 * 1024)
            var total = 0L
            while (total < MAX_SEGMENT_BYTES) { val n = stream.read(buf); if (n < 0) break; total += n }
            return total
        }
    }

    /** Seqmenti yükləyir; boşdursa və ya seqmentin müddətinin [MAX_SEGMENT_TIME_RATIO] hissəsindən yavaş gəlirsə false. */
    private fun segmentOk(url: String, ua: String?, ref: String?, segSeconds: Double): Boolean {
        val t0 = System.currentTimeMillis()
        if (downloadSegment(url, ua, ref) <= 0L) return false
        if (segSeconds <= 0.0) return true
        return System.currentTimeMillis() - t0 <= segSeconds * 1000.0 * MAX_SEGMENT_TIME_RATIO
    }

    private fun probeHls(url: String, text: String, ua: String?, ref: String?, start: Long, durationMs: Long, gen: Int): Boolean {
        val (mUrl, mText) = resolveMedia(url, text, ua, ref) ?: return false
        val m0 = parseMedia(mUrl, mText) ?: return false
        if (!segmentOk(m0.lastSeg!!, ua, ref, m0.segSeconds)) return false
        // Canlı yayım irəliləyirmi: playlist yenilənməsini gözləyirik (müddətin sonuna yaxın təkrar yoxlanır).
        val waitUntil = start + (durationMs * 8 / 10)
        while (alive(gen) && System.currentTimeMillis() < waitUntil) Thread.sleep(200)
        if (!alive(gen)) return false
        val t1 = fetchText(mUrl, ua, ref) ?: return false
        val m1 = parseMedia(mUrl, t1) ?: return false
        val advanced = m1.sequence > m0.sequence || m1.lastSeg != m0.lastSeg
        if (!advanced) return false
        return segmentOk(m1.lastSeg!!, ua, ref, m1.segSeconds)
    }
}
