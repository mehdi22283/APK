package az.mehdi.iptvplayer

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.LayoutInflater
import android.view.View
import android.view.SurfaceView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.doOnNextLayout
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Hər link üçün gözləmə müddəti: link (token) bu müddətdə alınmasa və ya oynamağa başlamasa növbəti linkə keçilir. */
private const val LINK_WAIT_MS = 5_000L
// canlitv.com-dan m3u8 tapılmasa (canlitv-first kanal) bu müddətdən sonra playlist → yoda.az növbəti linkinə keçilir
private const val CANLITV_RESOLVE_MS = 5_000L
// yoda.az tokeni 30 dəq yaşayır: oynayan yayım qırılmadan, linkin 28-ci dəqiqəsində fonda yeni token alınıb keçilir
private const val YODA_REFRESH_MS = 28 * 60_000L
private const val YODA_REFRESH_RETRY_MS = 30_000L
private const val YODA_REFRESH_MAX_FAILS = 3
// Əsas link problemli sayılıb ehtiyat linkdə oynayanda: əsas link fonda bu müddət (ms) yoxlanılır; uğursuzdursa aralıqla təkrarlanır.
private const val MAIN_PROBE_MS = 10_000L
private const val MAIN_PROBE_INTERVAL_MS = 60_000L
private const val MAIN_PROBE_MAX_INTERVAL_MS = 10 * 60_000L
// Əsas linkə qayıdandan sonra bu müddətdə yenə ehtiyata keçilərsə yoxlama aralığı ikiqat artır (ping-pong olmasın).
private const val MAIN_RETURN_FLAP_MS = 120_000L
// Əl ilə SW ↔ HW: pultda Geri düyməsini basıb saxlamaq / telefonda ekranın mərkəzini basıb saxlamaq.
// Geri düyməsi bu müddətdən (ms) uzun saxlanılanda rejim dəyişir.
private const val SW_BACK_HOLD_MS = 700L
// Telefonda "mərkəz": ekranın eni və hündürlüyünün ortadakı bu hissəsi (0.5 = ortadakı 50%).
private const val SW_CENTER_FRACTION = 0.5f

class MainActivity : AppCompatActivity() {
    private lateinit var engine: PlayerManager
    private lateinit var playerView: SurfaceView
    private lateinit var progress: View
    private lateinit var loadingBox: View
    private lateinit var loadingStatus: TextView
    private lateinit var status: TextView
    private val showSpinner = Runnable { loadingBox.visibility = View.VISIBLE }
    private lateinit var errorBox: View
    private lateinit var statsView: TextView
    private lateinit var clockView: TextView
    // Toxunma idarəetməsi (telefon/planşet)
    private lateinit var controls: View
    private lateinit var gestureHud: TextView
    private val hideHudRun = Runnable { gestureHud.visibility = View.GONE }
    private val hideControlsRun = Runnable { controls.visibility = View.GONE }
    private lateinit var videoCover: View
    // Video örtüyü ilk yeni kadr səthə çıxandan sonra (2 kadr gecikmə ilə) açılır: köhnə kadr bir anlıq belə görünməsin.
    private var coverPlaying = false
    private val hideCoverRun = Runnable { if (coverPlaying) videoCover.visibility = View.GONE }
    private lateinit var infoBar: LinearLayout
    private lateinit var infoLogo: ImageView
    private lateinit var infoName: TextView
    private val ping = PingMeter()
    private lateinit var infoEpg: TextView
    private lateinit var infoProg: ProgressBar
    private lateinit var infoNext: TextView
    private lateinit var detNow: TextView
    private lateinit var detNext: TextView
    private lateinit var detDesc: TextView
    private lateinit var panel: View
    private lateinit var panelBody: View
    private lateinit var groupTitle: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ChannelAdapter
    private lateinit var logos: LogoStore
    private lateinit var epgFull: View
    private lateinit var epgFullList: RecyclerView
    private lateinit var epgFullTitle: TextView
    private lateinit var epgFullLogo: ImageView
    private lateinit var epgFullEmpty: TextView
    private lateinit var progAdapter: ProgAdapter
    private var epgFullCh: Channel? = null
    private lateinit var epg: EpgStore
    private lateinit var browser: View
    private lateinit var groupsList: RecyclerView
    private lateinit var channelsList: RecyclerView
    private lateinit var browserTitle: TextView
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var rowAdapter: ChannelAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val hideInfoRun = Runnable { infoBar.visibility = View.GONE }
    private var lastInfoRefresh = 0L
    // Hər 0.5 s: bufer (🟢🟠🔴) + ölçü + endirmə sürəti (alt zolaqda).
    private val statsRun = object : Runnable {
        override fun run() {
            val s = engine.stats()
            // Tam saat (HH:mm:ss): alt zolaq görünəndə hər 0.5 s yenilənir.
            if (infoBar.visibility == View.VISIBLE) {
                clockView.setTextIfChanged(java.time.LocalTime.now().format(CLOCK_FMT)); clockView.visibility = View.VISIBLE
            } else clockView.visibility = View.INVISIBLE
            // Yalnız kanal dəyişəndə çıxan alt zolaq görünəndə göstərilir.
            if (s == null || infoBar.visibility != View.VISIBLE) { statsView.visibility = View.INVISIBLE }
            else {
                val nowMs = SystemClock.elapsedRealtime()
                if (nowMs - lastInfoRefresh > 20_000L) { lastInfoRefresh = nowMs; infoShown?.let { updateInfoExtras(it) } }
                // Sağ blok: sürət + pinq
                infoShown?.let { c -> infoName.setTextIfChanged(infoTitle(c, if (c.url == current?.url) s else null)) }
                statsView.setTextIfChanged(formatRes(s, ping.ms)); statsView.visibility = View.VISIBLE
            }
            handler.postDelayed(this, 500)
        }
    }

    /** Alt zolaq başlığı: "nömrə.ad ölçü [SW] bufer qrup" (məs. 1.AZTV HD 🟢 Hamısı; proqram dekoderdə: 1.AZTV SD SW 🟢 Hamısı). */
    private fun infoTitle(ch: Channel, s: PlayerStats?): String {
        val g = playGroup ?: "Hamısı"
        if (s == null) return "${ch.number}.${ch.name} $g"
        // Bütün hissələr arasında 1 boşluq.
        return listOf("${ch.number}.${ch.name}", resText(s), bufferDot(s), g).filter { it.isNotEmpty() }.joinToString(" ")
    }

    private var all: List<Channel> = emptyList()
    private var rawParsed: List<Channel> = emptyList()
    private var byGroup: Map<String, List<Channel>> = emptyMap()
    private var groupList: List<String?> = listOf(null) // null = "Hamısı"
    private var playGroup: String? = null
    private var browseGroup: String? = null
    private var browserGroup: String? = null
    private var current: Channel? = null
    // ---- ehtiyat link: playlistdəki link işləməsə yoda.az-dan tokenli link alınır ----
    private var resolver: YodaResolver? = null
    private var backupTries = 0
    private var backupResolving = false
    // yoda.az-dan başlayan kanallar (Apa TV): playlist linkinə keçilibmi / yoda linki bir dəfə işləyibmi
    private var playlistFallback = false
    private var yodaEverPlayed = false
    // 3-cü ehtiyat link: canlitv.com (playlist → yoda.az → canlitv.com)
    private var canlitvResolver: CanlitvResolver? = null
    private var canlitvStage = false
    private var canlitvTries = 0
    private var canlitvResolving = false
    // canlitv.com-dan başlayan kanallar (canlitv → yoda → playlist): canlitv linki bir dəfə işləyibmi
    private var canlitvEverPlayed = false
    // true: hazırda yoda.az linki oynadılır/gözlənir
    private var yodaStage = false
    // Fonda token yenilənməsi: ayrı gizli resolver (əsas resolver-ə toxunmur), yayım dayanmır
    private var refreshResolver: YodaResolver? = null
    private var linkRefreshing = false
    private var linkRefreshFails = 0
    private var linkRefreshKey = ""
    private val linkRefreshRun = Runnable { refreshYodaLinkSilently() }
    // Linkə verilən 5 s bitəndə kanal hələ oynamırsa növbəti linkə keçilir
    private val linkWatchRun = Runnable { onLinkWaitExpired() }
    // true: hazırda keşdəki (əvvəl tutulmuş) ehtiyat link oynadılır
    private var cachedLinkInUse = false
    // true: əsas (playlist) link problemlidir, kanal ehtiyat linkdə oynayır; əsas link fonda yoxlanılır və düzələndə ona qayıdılır
    private var mainBad = false
    private val mainProbe = MainLinkProbe()
    private var mainProbePending = false
    private var mainProbeIntervalMs = MAIN_PROBE_INTERVAL_MS
    private var mainReturnedAt = 0L
    private val mainProbeRun = Runnable { runMainProbe() }
    // SW ↔ HW: Geri düyməsi saxlanılanda rejim artıq dəyişibsə (düymə buraxılanda adi Geri işləməsin)
    private var backHoldFired = false
    private var switching = false
    private var previewCh: Channel? = null
    private var infoShown: Channel? = null
    private var focusedCh: Channel? = null
    private var lastFastStep = 0L

    // ---- rəqəm düymələri ilə kanal nömrəsi ----
    private lateinit var numInput: TextView
    private val numBuf = StringBuilder()
    private val numCommitRun = Runnable { commitNumber() }
    private val numHideRun = Runnable { numInput.visibility = View.GONE }

    private fun digitOf(code: Int): Int = when (code) {
        in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> code - KeyEvent.KEYCODE_0
        in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> code - KeyEvent.KEYCODE_NUMPAD_0
        else -> -1
    }

    /** Yığılan nömrə: uyğun kanal varsa "11.AzTV", yoxdursa yalnız rəqəmlər. */
    private fun numLabel(): String {
        val t = numBuf.toString()
        val n = t.toIntOrNull() ?: return t
        val ch = all.firstOrNull { it.number == n } ?: return t
        return "$n.${ch.name}"
    }

    private fun typeDigit(d: Int) {
        if (all.isEmpty()) return
        val maxLen = all.size.toString().length
        if (numBuf.length >= maxLen) numBuf.clear()
        numBuf.append(d)
        handler.removeCallbacks(numHideRun)
        numInput.text = numLabel()
        numInput.visibility = View.VISIBLE
        val n = numBuf.toString().toInt()
        // Daha uzun nömrə mümkün deyilsə tez aç, əks halda növbəti rəqəmi gözlə.
        val complete = n > 0 && (numBuf.length >= maxLen || n * 10 > all.size)
        handler.removeCallbacks(numCommitRun)
        handler.postDelayed(numCommitRun, if (complete) 250L else 1500L)
    }

    private fun commitNumber() {
        handler.removeCallbacks(numCommitRun)
        val n = numBuf.toString().toIntOrNull()
        numBuf.clear()
        if (n == null) { numInput.visibility = View.GONE; return }
        val ch = all.firstOrNull { it.number == n }
        if (ch == null) {
            numInput.text = "$n  ✗"
            handler.removeCallbacks(numHideRun)
            handler.postDelayed(numHideRun, 900)
            return
        }
        numInput.visibility = View.GONE
        previewCh = null
        handler.removeCallbacks(commitRun)
        if (panelShown()) setPanel(false)
        if (ch.url == current?.url) { showInfo(ch); return }
        // Kanal indiki qrupdadırsa qrup qalır, deyilsə "Hamısı".
        val grp = if (listFor(playGroup).any { it.url == ch.url }) playGroup else null
        play(ch, grp)
    }
    private val commitRun = Runnable { previewCh?.let { play(it, playGroup) }; previewCh = null }
    private val saveLastRun = Runnable { saveLast() }
    private val watchNextRun = Runnable { current?.let { WatchNext.publish(applicationContext, it, playGroup) } }

    // Watch Next kartından gələn kanal sorğusu (playlist hələ yüklənməyibsə gözləyir).
    private class PlayRequest(val url: String, val name: String?, val group: String?)
    private var pendingPlay: PlayRequest? = null

    private fun findRequested(r: PlayRequest): Channel? =
        all.firstOrNull { it.url == r.url }
            ?: all.firstOrNull { r.name != null && it.name == r.name && it.group == (r.group ?: it.group) }
            ?: all.firstOrNull { r.name != null && it.name == r.name }

    private fun groupFor(ch: Channel, g: String?): String? =
        g?.takeIf { it.isNotEmpty() && listFor(it).any { c -> c.url == ch.url } }

    // Səs axtarışı (Google Assistant): playlist hələ yüklənməyibsə sorğu gözləyir.
    private var pendingVoice: String? = null

    /** Assistant / axtarış intent-lərindən səs sorğusunu çıxarır (MEDIA_PLAY_FROM_SEARCH, SEARCH, SEARCH_ACTION). */
    private fun voiceQuery(i: Intent): String? {
        val a = i.action ?: return null
        if (a != "android.media.action.MEDIA_PLAY_FROM_SEARCH" && a != Intent.ACTION_SEARCH && a != "com.google.android.gms.actions.SEARCH_ACTION") return null
        return (i.getStringExtra(android.app.SearchManager.QUERY) ?: i.getStringExtra("android.intent.extra.title"))
            ?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun openSearchWith(q: String) {
        setSearch(true)
        searchInput.setText(VoiceSearch.clean(q))
    }

    private fun playVoice(q: String) = playVoiceAlts(listOf(q))

    /** Səs tanıma bir neçə variant qaytarır ("Xəzər TV", "Həzər TV" ...): ilk uyğun gələn kanal açılır. */
    private fun playVoiceAlts(alts: List<String>) {
        val q = alts.firstOrNull { it.isNotBlank() } ?: return
        if (all.isEmpty()) { pendingVoice = q; return }
        val ch = alts.firstNotNullOfOrNull { VoiceSearch.best(all, it) }
        if (ch == null) {
            showVoiceHud("🎤 $q — kanal tapılmadı", 2500)
            openSearchWith(q)
            return
        }
        showVoiceHud("🎤 $q  ▶  ${ch.name}", 2500)
        if (searchShown()) setSearch(false)
        if (ch.url == current?.url) return
        val g = playGroup?.takeIf { gr -> listFor(gr).any { it.url == ch.url } }
        play(ch, g)
    }

    // ---- tətbiqdaxili səs tanıma (Azərbaycan dili): mikrofon düyməsi / pultun Assistant düyməsi ----
    private var recognizer: android.speech.SpeechRecognizer? = null
    private var listening = false
    private var mutedForVoice = false
    // Sistem pəncərəsi (icazə / səs tanıma) açılanda onUserLeaveHint tətbiqi bağlamasın.
    private var leaveGuard = false

    private val micPermission = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startListening() else showVoiceHud("🎤 Mikrofon icazəsi verilmədi", 2500)
    }
    private val voiceFallback = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val l = r.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
        if (r.resultCode == RESULT_OK && !l.isNullOrEmpty()) playVoiceAlts(l)
    }

    private fun showVoiceHud(text: String, ms: Long) {
        gestureHud.text = text
        gestureHud.visibility = View.VISIBLE
        handler.removeCallbacks(hideHudRun)
        if (ms > 0) handler.postDelayed(hideHudRun, ms)
    }

    private fun muteForVoice(on: Boolean) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        runCatching {
            if (on) {
                if (!audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                    mutedForVoice = true
                }
            } else if (mutedForVoice) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                mutedForVoice = false
            }
        }
    }

    private fun startVoice() {
        if (listening) { stopListening(); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            leaveGuard = true
            micPermission.launch(android.Manifest.permission.RECORD_AUDIO)
            return
        }
        startListening()
    }

    private fun voiceIntent() = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "az-AZ")
        .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "az-AZ")
        .putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        .putExtra(android.speech.RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)

    private fun startListening() {
        if (!android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
            // Cihazda səs tanıma xidməti yoxdursa: sistemin öz səs pəncərəsi.
            leaveGuard = true
            runCatching { voiceFallback.launch(voiceIntent().putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Kanal adını deyin")) }
                .onFailure { showVoiceHud("🎤 Bu cihazda səs tanıma yoxdur", 2500) }
            return
        }
        val r = recognizer ?: android.speech.SpeechRecognizer.createSpeechRecognizer(this).also { recognizer = it }
        r.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { showVoiceHud("🎤 Danışın…  (məs. Xəzər TV)", 0) }
            override fun onBeginningOfSpeech() { showVoiceHud("🎤 Dinlənilir…", 0) }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { showVoiceHud("🎤 …", 0) }
            override fun onError(error: Int) {
                listening = false; muteForVoice(false)
                val msg = when (error) {
                    android.speech.SpeechRecognizer.ERROR_NO_MATCH, android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "🎤 Eşidilmədi, yenidən cəhd edin"
                    android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "🎤 Mikrofon icazəsi yoxdur"
                    android.speech.SpeechRecognizer.ERROR_NETWORK, android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "🎤 Şəbəkə xətası (səs tanıma internet tələb edir)"
                    else -> "🎤 Səs tanıma xətası ($error)"
                }
                showVoiceHud(msg, 2500)
            }
            override fun onResults(results: Bundle?) {
                listening = false; muteForVoice(false)
                val l = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                if (l.isNullOrEmpty()) showVoiceHud("🎤 Eşidilmədi, yenidən cəhd edin", 2500) else playVoiceAlts(l)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        listening = true
        muteForVoice(true)
        showVoiceHud("🎤 Danışın…  (məs. Xəzər TV)", 0)
        runCatching { r.startListening(voiceIntent()) }.onFailure {
            listening = false; muteForVoice(false)
            showVoiceHud("🎤 Səs tanıma başlamadı", 2500)
        }
    }

    private fun stopListening() {
        if (!listening) return
        listening = false
        muteForVoice(false)
        runCatching { recognizer?.cancel() }
        gestureHud.visibility = View.GONE
    }

    private fun handleLaunchIntent(i: Intent?) {
        if (i == null) return
        voiceQuery(i)?.let { q -> i.action = null; playVoice(q); return }
        if (i.action != WatchNext.ACTION_PLAY) return
        val url = i.getStringExtra(WatchNext.EXTRA_URL) ?: return
        i.action = null // bir dəfəlik: Activity yenidən yaranarsa təkrar işləməsin
        val req = PlayRequest(url, i.getStringExtra(WatchNext.EXTRA_NAME), i.getStringExtra(WatchNext.EXTRA_GROUP)?.ifEmpty { null })
        if (all.isEmpty()) { pendingPlay = req; return }
        findRequested(req)?.let { play(it, groupFor(it, req.group)) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }
    private fun saveLast() {
        val c = current ?: return
        getSharedPreferences("p", MODE_PRIVATE).edit()
            .putString("last", c.url).putString("group", playGroup ?: "")
            // Link dəyişsə də kanalı tapmaq üçün ad, qrup və tvg-id də saxlanılır.
            .putString("lastName", c.name).putString("lastChGroup", c.group)
            .putString("lastTvg", c.tvgId ?: "")
            .apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun listFor(g: String?): List<Channel> = if (g == null) all else byGroup[g].orEmpty()
    private fun panelShown() = panel.visibility == View.VISIBLE
    private fun browserShown() = browser.visibility == View.VISIBLE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        applyHdrMode()
        applyUhdOutput()
        playerView = findViewById(R.id.playerView)
        progress = findViewById(R.id.progress)
        loadingBox = findViewById(R.id.loadingBox)
        loadingStatus = findViewById(R.id.loadingStatus)
        status = findViewById(R.id.status)
        errorBox = findViewById(R.id.errorBox)
        statsView = findViewById(R.id.statsView)
        clockView = findViewById(R.id.clockView)
        numInput = findViewById(R.id.numInput)
        videoCover = findViewById(R.id.videoCover)
        infoBar = findViewById(R.id.infoBar)
        infoLogo = findViewById(R.id.infoLogo)
        infoName = findViewById(R.id.infoName)
        infoEpg = findViewById(R.id.infoEpg)
        infoProg = findViewById(R.id.infoBarProg)
        infoNext = findViewById(R.id.infoNext)
        panel = findViewById(R.id.panel)
        panelBody = findViewById(R.id.panelBody)
        groupTitle = findViewById(R.id.groupTitle)
        list = findViewById(R.id.list)
        detNow = findViewById(R.id.detNow)
        epgFull = findViewById(R.id.epgFull)
        epgFullList = findViewById(R.id.epgFullList)
        epgFullTitle = findViewById(R.id.epgFullTitle)
        epgFullLogo = findViewById(R.id.epgFullLogo)
        epgFullEmpty = findViewById(R.id.epgFullEmpty)
        progAdapter = ProgAdapter()
        epgFullList.layoutManager = LinearLayoutManager(this)
        epgFullList.adapter = progAdapter
        epgFullList.itemAnimator = null
        detNext = findViewById(R.id.detNext)
        detDesc = findViewById(R.id.detDesc)

        epg = EpgStore(applicationContext)
        logos = LogoStore(applicationContext, epg)
        adapter = ChannelAdapter(
            logos, epg, lifecycleScope, R.layout.item_channel,
            onFocusCh = { ch -> focusedCh = ch; renderDetail() },
            circular = false
        ) { ch ->
            // Oynayan kanalda ikinci OK: tam proqram cədvəli
            if (ch.url == current?.url) setEpgFull(true, ch)
            else { play(ch, browseGroup); setPanel(false) }
        }
        // Fokuslanan (qabarıq) kart həmişə ekranın ortasında qalır, siyahı onun altından sürüşür.
        list.layoutManager = object : LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false) {
            override fun requestChildRectangleOnScreen(
                parent: RecyclerView, child: View, rect: Rect, immediate: Boolean, focusedChildVisible: Boolean
            ): Boolean {
                val dx = child.left + child.width / 2 - parent.width / 2
                if (dx != 0) { if (immediate) parent.scrollBy(dx, 0) else parent.smoothScrollBy(dx, 0) }
                return true
            }
        }
        list.adapter = adapter
        list.itemAnimator = null

        browser = findViewById(R.id.browser)
        groupsList = findViewById(R.id.groupsList)
        channelsList = findViewById(R.id.channelsList)
        browserTitle = findViewById(R.id.browserTitle)
        groupAdapter = GroupAdapter(
            count = { g -> listFor(g).size },
            onFocus = { g ->
                if (g != browserGroup) {
                    browserGroup = g
                    showBrowserChannels()
                    channelsList.scrollToPosition(0)
                }
            },
            onPick = { g ->
                browserGroup = g
                showBrowserChannels()
                focusPos(channelsList, rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0))
            }
        )
        groupsList.layoutManager = LinearLayoutManager(this)
        groupsList.adapter = groupAdapter
        groupsList.itemAnimator = null
        rowAdapter = ChannelAdapter(logos, epg, lifecycleScope, R.layout.item_channel_row) { ch ->
            if (ch.url == current?.url) { setBrowser(false); setEpgFull(true, ch) }
            else { play(ch, browserGroup); setBrowser(false) }
        }
        val channelGrid = GridLayoutManager(this, 2, RecyclerView.VERTICAL, false)
        // Siyahının sonundakı "Kanalların Yerini Dəyiş" düyməsi bütün sətri tutur.
        channelGrid.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) = if (position >= rowAdapter.items.size) channelGrid.spanCount else 1
        }
        channelsList.layoutManager = channelGrid
        channelsList.adapter = ConcatAdapter(rowAdapter, FooterAdapter("⚙️ Kanalların Yerini Dəyiş") { openReorder() })
        channelsList.itemAnimator = null
        channelsList.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> adjustChannelColumns() }
        channelsList.post { adjustChannelColumns() }
        setupSearch()

        // Qısa buferləmədə göstərici gecikdirilir; kanalın ilkin açılışında isə status dərhal görünür.
        engine = PlayerManager(applicationContext, playerView, object : PlayerCallback {
            override fun onLoading() {
                coverPlaying = false
                videoCover.removeCallbacks(hideCoverRun)
                progress.removeCallbacks(showSpinner)
                statsView.visibility = View.INVISIBLE
                videoCover.visibility = View.VISIBLE
                setPlayerLoadingStatus("Yüklənir…")
                loadingBox.visibility = View.VISIBLE
                status.visibility = View.GONE
                errorBox.visibility = View.GONE
            }
            override fun onStatus(message: String) {
                setPlayerLoadingStatus(message)
                loadingBox.visibility = View.VISIBLE
                errorBox.visibility = View.GONE
            }
            override fun onPlaying() {
                handler.removeCallbacks(linkWatchRun)
                backupTries = 0
                canlitvTries = 0
                current?.let {
                    if (canlitvStage) canlitvEverPlayed = true
                    else if (yodaStage) yodaEverPlayed = true
                }
                // Ehtiyat linkdə oynayır, əsas link isə problemli sayılır: əsas link fonda yoxlanmağa başlayır.
                if (mainBad && (yodaStage || canlitvStage)) scheduleMainProbe(0L)
                progress.removeCallbacks(showSpinner)
                hidePlayerLoading()
                coverPlaying = true
                videoCover.removeCallbacks(hideCoverRun)
                videoCover.postDelayed(hideCoverRun, 60L)
                status.visibility = View.GONE
                errorBox.visibility = View.GONE
            }
            override fun onBuffering(active: Boolean) {
                progress.removeCallbacks(showSpinner)
                if (active) {
                    setPlayerLoadingStatus("Buferlənir…")
                    progress.postDelayed(showSpinner, 2_000L)
                } else {
                    hidePlayerLoading()
                }
            }
            override fun onFailed(message: String) {
                coverPlaying = false
                videoCover.removeCallbacks(hideCoverRun)
                progress.removeCallbacks(showSpinner)
                hidePlayerLoading()
                videoCover.visibility = View.VISIBLE
                status.visibility = View.GONE
                errorBox.visibility = View.VISIBLE // böyük qırmızı işarə + "Kanal İşləmir"
            }
            override fun onStreamFailed(isBackup: Boolean): Boolean {
                val ch = current
                val chUrl = ch?.url
                if (ch != null && canlitvStage) {
                    // canlitv linki qırıldı: əvvəl işləyibsə (token bitib) yenilənir, işləməyibsə təkrar cəhd edilmir
                    if (!Backup.canlitvFirst(ch)) return (canlitvEverPlayed || cachedLinkInUse) && startCanlitv(true)
                    // canlitv → playlist → yoda: link əvvəl işləyibsə (token bitib) yenilənir, işləməyibsə dərhal playlist linkinə keçilir
                    if (canlitvResolving) return true
                    if ((canlitvEverPlayed || cachedLinkInUse) && startCanlitv(true)) return true
                    handler.post { if (!isFinishing && !isDestroyed && current?.url == chUrl) advanceFromCanlitv() }
                    return true
                }
                if (ch != null && Backup.playlistLast(ch)) {
                    // playlist linki də açılmadı: canlitv-first kanalda son mərhələdir ("Kanal İşləmir"); yoda-first kanalda 3-cü ehtiyat canlitv.com
                    if (playlistFallback) {
                        if (!Backup.canlitvFirst(ch)) return startCanlitv(false)
                        // canlitv → playlist → yoda: playlist qırıldı → yoda.az (son mərhələ); yoda linki əvvəl işləyib qırılıbsa yenilənir
                        if (backupResolving) return true
                        if (isBackup) return (yodaEverPlayed || cachedLinkInUse) && startBackup(true)
                        return startBackup(false)
                    }
                    if (backupResolving) return true
                    // yoda linki əvvəl işləyib, sonra qırılıbsa (token bitib) yenilənir; heç işləməyibsə birbaşa playlist linki
                    if (isBackup && (yodaEverPlayed || cachedLinkInUse) && startBackup(true)) return true
                    handler.post { if (!isFinishing && !isDestroyed && current?.url == chUrl) fallbackToPlaylist() }
                    return true
                }
                // playlist → yoda.az → canlitv.com: yoda linki əvvəl işləyib qırılıbsa yenilənir, işləməyibsə dərhal canlitv.com
                val handled = if (isBackup) ((yodaEverPlayed || cachedLinkInUse) && startBackup(true)) || startCanlitv(false)
                else startBackup(false) || startCanlitv(false)
                if (handled) {
                    // Əsas link açılmadı və ehtiyat linkə keçildi: keşdə yadda saxlanır, əsas link fonda yoxlanacaq.
                    if (!isBackup && ch != null) markMainBad(ch)
                    return true
                }
                // Ehtiyat linklər bitdi, əsas link (bu açılışda) hələ sınanmayıbsa: ona qayıdılır.
                if (ch != null && mainBad && !playlistFallback) {
                    LinkCache.clearMainBad(this@MainActivity, ch.url)
                    mainBad = false
                    cancelMainProbe()
                    handler.post { if (!isFinishing && !isDestroyed && current?.url == chUrl) fallbackToPlaylist() }
                    return true
                }
                return false
            }

            // Statik / təkrarlanan görüntü: link xəta verməsə də dərhal ardıcıllıqdakı növbəti linkə keçilir.
            override fun onStaleStream(isBackup: Boolean): Boolean = advanceToNextLink(halt = false)
        })

        val root = findViewById<View>(R.id.root)
        root.isFocusable = false
        setupTouchControls(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Geri: açıq pəncərə varsa bağlanır. Video ekranında: birinci Geri alt məlumat zolağı,
                // zolaq açıq olarkən ikinci Geri ümumi kanal siyahısı (qruplar + kanallar).
                when {
                    searchShown() -> setSearch(false)
                    epgFullShown() -> setEpgFull(false)
                    browserShown() -> setBrowser(false)
                    numPadShown() -> setNumPad(false)
                    panelShown() -> setPanel(false)
                    listening -> stopListening()
                    else -> {
                        val c = current
                        if (c != null && !(infoBar.visibility == View.VISIBLE && infoShown?.url == c.url)) showInfo(c)
                        else setBrowser(true)
                    }
                }
            }
        })

        hideBars()
        handleLaunchIntent(intent) // Watch Next kartından açılıbsa: kanal playlist yüklənəndə oynadılır
        loadPlaylist() // keş dərhal açılır, playlist fonda yoxlanılır; dəyişiklik varsa keş yenilənir
    }


    // ---------- playlist ----------
    private var playlistFresh = false
    // Endirmə alınmasa (məs. TV box açılanda şəbəkə hələ hazır deyil) bu fasilələrlə təkrar yoxlanılır.
    private val playlistRetryMs = longArrayOf(8_000, 20_000, 45_000, 90_000, 180_000)

    private fun cacheAgeText(cache: File): String {
        if (!cache.exists()) return ""
        val h = (System.currentTimeMillis() - cache.lastModified()) / 3_600_000L
        return when {
            h >= 48 -> " (${h / 24} gün əvvəlki)"
            h >= 1 -> " ($h saat əvvəlki)"
            else -> ""
        }
    }

    private fun setPlayerLoadingStatus(message: String) {
        loadingStatus.text = message
    }

    private fun hidePlayerLoading() {
        loadingBox.visibility = View.GONE
    }

    private fun loadPlaylist() {
        if (all.isEmpty()) {
            status.text = "Playlist yüklənir…"
            status.visibility = View.VISIBLE
        }
        lifecycleScope.launch(safeHandler) {
            dropLegacyPlaylistCache(filesDir)
            val cache = File(filesDir, PLAYLIST_CACHE_NAME)
            // 1) Keş varsa dərhal açılır (gecikmə yoxdur).
            val cachedText = withContext(Dispatchers.IO) { runCatching { if (cache.exists()) cache.readText() else null }.getOrNull() }
            if (cachedText != null && all.isEmpty()) applyPlaylist(cachedText)
            // 2) Fonda playlist yoxlanılır; dəyişiklik varsa keş yenilənir və yeni playlist tətbiq olunur.
            var attempt = 0
            var lastError = "Naməlum bağlantı xətası"
            while (true) {
                val result = withContext(Dispatchers.IO) { runCatching { checkPlaylist(cache, 20000) } }
                val check = result.getOrNull()
                if (check != null) {
                    playlistFresh = true
                    if (check.changed || all.isEmpty()) applyPlaylist(check.text)
                    else status.visibility = View.GONE
                    return@launch
                }
                result.exceptionOrNull()?.let { e -> lastError = (e.message ?: e.javaClass.simpleName).take(120) }
                if (attempt >= playlistRetryMs.size) break
                if (all.isEmpty() && cachedText == null) {
                    status.text = "Playlist yüklənmədi, yenidən yoxlanılır…"
                    status.visibility = View.VISIBLE
                }
                delay(playlistRetryMs[attempt++])
            }
            // Bütün cəhdlər alınmadı.
            if (all.isEmpty()) {
                status.text = "Playlist yüklənmədi: $lastError"
                status.visibility = View.VISIBLE
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "Yenilənmədi, köhnə playlist açıqdır${cacheAgeText(cache)}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private suspend fun applyPlaylist(text: String) {
        val parsed = withContext(Dispatchers.Default) { parsePlaylist(text) }
        if (parsed.isEmpty()) return
        rawParsed = parsed
        val orderPrefs = ChannelOrder.prefs(applicationContext)
        // Playlistin qruplaşdırılması da arxa planda aparılır: böyük siyahı UI-ni dondurmasın.
        val prepared = withContext(Dispatchers.Default) {
            // İstifadəçinin saxladığı kanal sırası (hər qrup üçün) playlist yenilənəndə də tətbiq olunur.
            val groupedByName = parsed.groupBy { it.group }.mapValues { (g, l) -> ChannelOrder.applyTo(orderPrefs, g, l) }
            val order = parsed.map { it.group }.distinct()
            val grouped = order.asSequence()
                .flatMap { groupedByName[it].orEmpty().asSequence() }
                .mapIndexed { i, c -> c.copy(number = i + 1) }
                .toList()
            Triple(order, grouped, grouped.groupBy { it.group })
        }
        val order = prepared.first
        val grouped = prepared.second
        all = grouped
        byGroup = prepared.third
        groupList = listOf<String?>(null) + order
        if (playGroup != null && playGroup !in order) playGroup = null
        if (browseGroup != null && browseGroup !in order) browseGroup = null
        status.visibility = View.GONE

        val pend = pendingPlay
        val pendCh = if (pend != null && current == null) findRequested(pend) else null
        pendingPlay = null
        val pendVoice = pendingVoice
        pendingVoice = null
        val voiceCh = if (pendVoice != null && current == null) VoiceSearch.best(all, pendVoice) else null
        // Launcher kanal sətri (Android TV ana ekranı): kanallar kart kimi yazılır; dəyişiklik yoxdursa toxunulmur.
        ChannelRow.publish(applicationContext, all) { id ->
            runOnUiThread {
                if (!isFinishing && !isDestroyed) runCatching {
                    leaveGuard = true
                    startActivity(Intent("android.media.tv.action.REQUEST_CHANNEL_BROWSABLE").putExtra("android.media.tv.extra.CHANNEL_ID", id))
                }
            }
        }
        // Google TV ana səhifəsi: playlist sırası ilə ilk kanallar "Watch Next" cərgəsində də göstərilir.
        WatchNext.publishOrder(applicationContext, all)
        if (current == null && voiceCh != null) {
            play(voiceCh, null)
        } else if (current == null && pendCh != null) {
            play(pendCh, groupFor(pendCh, pend?.group))
        } else if (current == null) {
            val prefs = getSharedPreferences("p", MODE_PRIVATE)
            val lastUrl = prefs.getString("last", null)
            val lastGroup = prefs.getString("group", "")?.takeIf { it.isNotEmpty() && it in order }
            val lastName = prefs.getString("lastName", null)?.takeIf { it.isNotEmpty() }
            val lastChGroup = prefs.getString("lastChGroup", null)
            val lastTvg = prefs.getString("lastTvg", null)?.takeIf { it.isNotBlank() }
            // Kanalın linki dəyişibsə də, ad/qrup və ya tvg-id ilə tapılıb həmin kanalda qalınır.
            val ch = all.firstOrNull { it.url == lastUrl && (lastGroup == null || it.group == lastGroup) }
                ?: all.firstOrNull { it.url == lastUrl }
                ?: all.firstOrNull { lastName != null && it.name == lastName && it.group == lastChGroup }
                ?: lastTvg?.let { t -> all.firstOrNull { it.tvgId == t } }
                ?: all.firstOrNull { lastName != null && it.name == lastName }
                ?: byGroup[lastGroup]?.firstOrNull()
                ?: all.first()
            play(ch, if (lastGroup == null || ch.group == lastGroup) lastGroup else null)
        } else {
            // İzlənən kanalın linki yeni playlistdə dəyişibsə, yeni link açılır.
            val cur = current
            val updated = if (cur == null) null
                else all.firstOrNull { it.name == cur.name && it.group == cur.group && it.url != cur.url }
                    ?.takeIf { n -> all.none { it.url == cur.url } }
            if (updated != null) play(updated, playGroup)
            // Sıralama/qrup/kanal dəyişibsə açıq kanal siyahısı da yenilənir.
            if (panelShown()) loadBrowse()
        }
        // Səs sorğusuna uyğun kanal tapılmadı: axtarış paneli sorğu ilə açılır.
        if (pendVoice != null && voiceCh == null) openSearchWith(pendVoice)
        if (browserShown()) {
            if (browserGroup != null && browserGroup !in order) browserGroup = null
            groupAdapter.items = groupList
            groupAdapter.selected = browserGroup
            groupAdapter.notifyDataSetChanged()
            showBrowserChannels()
        }
        reloadEpg()
    }

    // ---------- playback ----------
    /** Kanalı açır (Media3). */
    private fun play(ch: Channel, group: String?, dir: Int = 0) {
        // Kanal dəyişir: örtük dərhal qapanır, köhnə kadr görünməsin.
        coverPlaying = false
        videoCover.removeCallbacks(hideCoverRun)
        videoCover.visibility = View.VISIBLE
        resolver?.cancel()
        canlitvResolver?.cancel()
        canlitvStage = false
        canlitvTries = 0
        canlitvResolving = false
        cachedLinkInUse = false
        backupResolving = false
        backupTries = 0
        playlistFallback = false
        yodaEverPlayed = false
        canlitvEverPlayed = false
        yodaStage = false
        cancelMainProbe()
        mainBad = false
        mainReturnedAt = 0L
        mainProbeIntervalMs = MAIN_PROBE_INTERVAL_MS
        cancelLinkRefresh()
        handler.removeCallbacks(linkWatchRun)
        current = ch
        playGroup = group
        // Diskə yazı kanal sürətlə dəyişəndə hər dəfə yox, sakitləşəndən sonra bir dəfə edilir.
        handler.removeCallbacks(saveLastRun)
        handler.postDelayed(saveLastRun, 1500)
        adapter.markPlaying(list, ch.url)
        showInfo(ch, dir)
        status.visibility = View.GONE
        errorBox.visibility = View.GONE
        if (Backup.canlitvFirst(ch)) {
            // canlitv səhifəsi olan Azərbaycan kanalları: canlitv.com → playlist → yoda.az
            engine.halt()
            if (!startCanlitv(false)) advanceFromCanlitv()
        } else if (Backup.yodaFirst(ch)) {
            // Mədəniyyət, Real, İdman, ARB Günəş, ARB, Space, MTV, APA, Biznes, Qafqaz, Naxçıvan, Kanal 35: yoda.az → playlist → canlitv.com
            engine.halt()
            if (!startBackup(false)) fallbackToPlaylist()
        } else if (LinkCache.isMainBad(this, ch.url) && startFromCachedBackup(ch)) {
            // Əsas link yaxın vaxtda problemli olub və keşdə ehtiyat link var: birbaşa ehtiyat linklə açılır, əsas link fonda yoxlanır
        } else {
            engine.play(ch.url, ch.ua, ch.referer)
            armLinkWatch()
        }
        ping.start(ch.url)
        // Kanal 20 s izlənəndən sonra Android TV ana ekranının "Watch Next" cərgəsinə yazılır.
        handler.removeCallbacks(watchNextRun)
        handler.postDelayed(watchNextRun, WatchNext.DELAY_MS)
        onChannelSwitched(ch)
    }

    // ---- yoda.az tokeninin fonda yenilənməsi (28-ci dəqiqə) ----
    private fun cancelLinkRefresh() {
        handler.removeCallbacks(linkRefreshRun)
        refreshResolver?.cancel()
        linkRefreshing = false
        linkRefreshFails = 0
        linkRefreshKey = ""
    }

    /** Yoda linki oynamağa başlayanda çağırılır: linkin yaşı 28 dəq olanda yenilənmə başlayır. */
    private fun scheduleLinkRefresh(cacheKey: String) {
        handler.removeCallbacks(linkRefreshRun)
        linkRefreshKey = cacheKey
        linkRefreshFails = 0
        val age = LinkCache.age(this, cacheKey).coerceAtLeast(0L)
        val delay = (YODA_REFRESH_MS - age).coerceAtLeast(3_000L)
        android.util.Log.i("IPTV-BACKUP", "yoda token yenilənməsi ${delay / 1000} s sonra (link yaşı ${age / 1000} s)")
        handler.postDelayed(linkRefreshRun, delay)
    }

    private fun refreshYodaLinkSilently() {
        if (isFinishing || isDestroyed) return
        val ch = current ?: return
        // yoda linki oynadılmırsa (başqa linkə keçilib / yenidən alınır) heç nə edilmir
        if (!yodaStage || backupResolving || linkRefreshing) return
        val page = Backup.pageFor(ch) ?: return
        val key = "yoda:$page"
        if (key != linkRefreshKey) return
        val chUrl = ch.url
        linkRefreshing = true
        android.util.Log.i("IPTV-BACKUP", "${ch.name}: yoda token fonda yenilənir → $page")
        val r = refreshResolver ?: YodaResolver(this, findViewById<ViewGroup>(R.id.root)).also { refreshResolver = it }
        r.resolve(page, YodaResolver.TIMEOUT_MS) { res ->
            linkRefreshing = false
            if (isFinishing || isDestroyed || current?.url != chUrl || !yodaStage) return@resolve
            if (res != null) {
                LinkCache.put(this, key, res)
                engine.swapLink(res.url, res.userAgent, res.referer)   // yayım dayanmır, sakit keçid
                scheduleLinkRefresh(key)                                // növbəti yenilənmə 28 dəq sonra
            } else if (++linkRefreshFails < YODA_REFRESH_MAX_FAILS) {
                // token hələ 2 dəq qüvvədədir: 30 s-dən bir təkrar; alınmasa qırılanda adi yenilənmə işləyir
                handler.postDelayed(linkRefreshRun, YODA_REFRESH_RETRY_MS)
            }
        }
    }

    /**
     * Pleyer playlistdəki linki aça bilmədi: kanalın yoda.az səhifəsi gizli WebView-da açılır,
     * tokenli yayım linki tutulur və pleyerə verilir. Link sonradan da qırılsa (məs. token bitsə) yenidən alınır (ən çox 3 cəhd).
     * true = proses başladı (xəta göstərilmir), false = ehtiyat link yoxdur / cəhdlər bitib.
     */
    private fun startBackup(isBackup: Boolean): Boolean {
        val ch = current ?: return false
        val page = Backup.pageFor(ch) ?: return false
        if (backupResolving) return true          // proses artıq gedir (köhnə pleyerin gec xətası)
        val cacheKey = "yoda:$page"
        if (isBackup) {
            LinkCache.remove(this, cacheKey)      // oynadılan link qırıldı: keş köhnədir, yenisi alınır
            cachedLinkInUse = false
        } else {
            val c = LinkCache.get(this, cacheKey, LinkCache.YODA_TTL)
            if (c != null) {
                android.util.Log.i("IPTV-BACKUP", "${ch.name}: yoda.az linki keşdən açılır")
                cachedLinkInUse = true
                progress.removeCallbacks(showSpinner)
                videoCover.visibility = View.VISIBLE
                errorBox.visibility = View.GONE
                status.visibility = View.GONE
                setPlayerLoadingStatus("Ehtiyat link keşdən açılır…")
                loadingBox.visibility = View.VISIBLE
                yodaStage = true
                engine.play(c.url, c.userAgent, c.referer, backup = true)
                armLinkWatch()
                scheduleLinkRefresh(cacheKey)   // tokenin real yaşına görə: keşdəki link köhnədirsə daha tez
                return true
            }
        }
        if (backupTries >= 3) return false        // cəhdlər bitdi → "Kanal İşləmir"
        backupTries++
        backupResolving = true
        val chUrl = ch.url
        android.util.Log.w("IPTV-BACKUP", "${ch.name}: ehtiyat link prosesi (cəhd $backupTries, yenilənmə=$isBackup) → $page")
        progress.removeCallbacks(showSpinner)
        videoCover.visibility = View.VISIBLE
        errorBox.visibility = View.GONE
        status.visibility = View.GONE
        setPlayerLoadingStatus(
            if (isBackup) "Link yenilənir (yoda.az)…"
            else if (Backup.playlistLast(ch)) "Link yoda.az-dan alınır…"
            else "Əsas link işləmir — ehtiyat link yoda.az-dan alınır…"
        )
        loadingBox.visibility = View.VISIBLE
        handler.removeCallbacks(linkWatchRun)
        val r = resolver ?: YodaResolver(this, findViewById<ViewGroup>(R.id.root)).also { resolver = it }
        r.resolve(page, 0L) { res -> // 0 = link alınana qədər gözləmə müddəti yoxdur
            backupResolving = false
            if (isFinishing || isDestroyed || current?.url != chUrl) return@resolve
            if (res != null) {
                LinkCache.put(this, cacheKey, res)
                cachedLinkInUse = false
                setPlayerLoadingStatus("Ehtiyat link tapıldı, açılır…")
                yodaStage = true
                engine.play(res.url, res.userAgent, res.referer, backup = true)
                armLinkWatch()
                scheduleLinkRefresh(cacheKey)
            } else if (!yodaEverPlayed) {
                // yoda.az-dan link 5 s-də alınmadı → növbəti link (playlist; yoxsa canlitv.com)
                if (Backup.canlitvFirst(ch)) showStreamFailed() else if (Backup.playlistLast(ch)) fallbackToPlaylist() else escalateFromYoda()
            } else {
                // yoda.az-dan link alınmadı: bir az gözləyib yenidən cəhd edilir
                handler.postDelayed({
                    if (!isFinishing && !isDestroyed && current?.url == chUrl && !backupResolving) {
                        if (!startBackup(isBackup)) escalateFromYoda()
                    }
                }, 2_000L)
            }
        }
        return true
    }

    /** yoda.az-dan başlayan kanal: yoda linki alınmadı/işləmədi → playlistdəki link açılır (ehtiyat). */
    private fun fallbackToPlaylist() {
        val ch = current ?: return
        if (playlistFallback) return
        playlistFallback = true
        yodaStage = false
        resolver?.cancel()
        backupResolving = false
        android.util.Log.w("IPTV-BACKUP", "${ch.name}: yoda.az işləmədi → playlist linki")
        setPlayerLoadingStatus("Playlistdəki link açılır…")
        loadingBox.visibility = View.VISIBLE
        errorBox.visibility = View.GONE
        engine.play(ch.url, ch.ua, ch.referer)
        armLinkWatch()
    }

    /** yoda.az cəhdləri bitdi: yoda-first kanal üçün əvvəl playlist, sonra (və ya birbaşa) canlitv.com; heç biri yoxdursa "Kanal İşləmir". */
    private fun escalateFromYoda() {
        val ch = current ?: return
        if (Backup.playlistLast(ch) && !playlistFallback) fallbackToPlaylist()
        else if (Backup.canlitvFirst(ch) || !startCanlitv(false)) showStreamFailed()
    }

    /** Ardıcıllıqda növbəti link varmı (yoxdursa 5 s gözləmə kəsilmir, yayım olduğu kimi qalır). */
    private fun nextLinkAvailable(): Boolean {
        val ch = current ?: return false
        if (canlitvStage) return Backup.canlitvFirst(ch)
        if (Backup.playlistLast(ch)) {
            if (!playlistFallback) return true
            if (Backup.canlitvFirst(ch)) return !yodaStage && Backup.pageFor(ch) != null
            return Backup.canlitvPageFor(this, ch) != null
        }
        if (yodaStage) return Backup.canlitvPageFor(this, ch) != null
        return Backup.pageFor(ch) != null || Backup.canlitvPageFor(this, ch) != null
    }

    /** Linkə 5 s verilir: bu müddətdə oynamasa (və növbəti link varsa) növbəti linkə keçilir. */
    private fun armLinkWatch() {
        handler.removeCallbacks(linkWatchRun)
        if (nextLinkAvailable()) handler.postDelayed(linkWatchRun, LINK_WAIT_MS)
    }

    private fun onLinkWaitExpired() {
        if (isFinishing || isDestroyed) return
        if (backupResolving || canlitvResolving || !nextLinkAvailable()) return
        val ch = current ?: return
        android.util.Log.w("IPTV-BACKUP", "${ch.name}: link ${LINK_WAIT_MS / 1000} s-də açılmadı → növbəti link")
        if (!advanceToNextLink(halt = true)) showStreamFailed()
    }

    /**
     * Cari linkdən ardıcıllıqdakı növbəti linkə keçir (canlitv → yoda → playlist, yoda → playlist (→ canlitv), playlist → yoda → canlitv).
     * halt=true: cari link oynamır, dayandırılır. false: görüntü statikdir, yeni link hazır olana qədər davam edir.
     * true = keçid başladı, false = növbəti link yoxdur.
     */
    private fun advanceToNextLink(halt: Boolean): Boolean {
        val ch = current ?: return false
        if (backupResolving || canlitvResolving || !nextLinkAvailable()) return false
        if (halt) engine.halt()
        if (canlitvStage) { advanceFromCanlitv(); return true }
        if (Backup.playlistLast(ch)) {
            if (!playlistFallback) { fallbackToPlaylist(); return true }
            return if (Backup.canlitvFirst(ch)) startBackup(false) else startCanlitv(false)
        }
        if (yodaStage) return startCanlitv(false)
        // playlist (əsas) → yoda.az → canlitv.com: əsas link problemlidir, keçid keşdə yadda saxlanır.
        val ok = startBackup(false) || startCanlitv(false)
        if (ok && !playlistFallback) markMainBad(ch)
        return ok
    }

    /** Əsas linkin problemli olduğu keşdə yazılır; kanal ehtiyat linkdə oynayanda əsas link fonda yoxlanacaq. */
    private fun markMainBad(ch: Channel) {
        val now = SystemClock.elapsedRealtime()
        // Əsas linkə qayıdıb tezliklə yenidən ehtiyata keçilib: yoxlama aralığı artırılır.
        if (mainReturnedAt != 0L && now - mainReturnedAt < MAIN_RETURN_FLAP_MS) {
            mainProbeIntervalMs = (mainProbeIntervalMs * 2).coerceAtMost(MAIN_PROBE_MAX_INTERVAL_MS)
        }
        mainReturnedAt = 0L
        mainBad = true
        LinkCache.markMainBad(this, ch.url)
        android.util.Log.i("IPTV-BACKUP", "${ch.name}: əsas link problemli → ehtiyat linkə keçildi (keşdə yazıldı)")
    }

    /** Əsas link keşdə problemli yazılıb: keşdəki yoda.az / canlitv.com linki varsa birbaşa onunla açılır. */
    private fun startFromCachedBackup(ch: Channel): Boolean {
        mainBad = true
        val yp = Backup.pageFor(ch)
        if (yp != null && LinkCache.get(this, "yoda:$yp", LinkCache.YODA_TTL) != null && startBackup(false)) return true
        val cp = Backup.canlitvPageFor(this, ch)
        if (cp != null && LinkCache.get(this, "canlitv:$cp", LinkCache.CANLITV_TTL) != null && startCanlitv(false)) return true
        mainBad = false
        return false
    }

    /** Əl ilə SW (FFmpeg) ↔ HW: kanal yeni rejimdə yenidən açılır, seçim kanal üzrə yadda saxlanır. */
    private fun toggleSoftwareDecoder() {
        val sw = engine.toggleSoftware() ?: return
        showHud(if (sw) "SW" else "HW")
        Toast.makeText(this, if (sw) "SW rejimi (proqram dekoder)" else "HW rejimi (hardware dekoder)", Toast.LENGTH_SHORT).show()
    }

    private fun cancelMainProbe() {
        handler.removeCallbacks(mainProbeRun)
        mainProbePending = false
        mainProbe.cancel()
    }

    private fun scheduleMainProbe(delayMs: Long) {
        if (mainProbePending || !mainBad) return
        mainProbePending = true
        handler.postDelayed(mainProbeRun, delayMs)
    }

    /** Əsas link fonda [MAIN_PROBE_MS] yoxlanılır: işləyirsə ona qayıdılır, yoxsa aralıqla təkrar yoxlanılır. */
    private fun runMainProbe() {
        mainProbePending = false
        val ch = current ?: return
        if (isFinishing || isDestroyed || !mainBad || !(yodaStage || canlitvStage)) return
        val chUrl = ch.url
        android.util.Log.i("IPTV-BACKUP", "${ch.name}: əsas link fonda yoxlanılır (${MAIN_PROBE_MS / 1000} s)")
        mainProbe.check(ch.url, ch.ua, ch.referer, MAIN_PROBE_MS) { ok ->
            if (isFinishing || isDestroyed || current?.url != chUrl || !mainBad) return@check
            if (ok) returnToMain(ch) else scheduleMainProbe(mainProbeIntervalMs)
        }
    }

    /** Əsas linkdə problem aradan qalxıb: yayım dayanmadan əsas linkə qayıdılır; açılmasa 5 s-dən sonra yenə ehtiyata keçilir. */
    private fun returnToMain(ch: Channel) {
        android.util.Log.i("IPTV-BACKUP", "${ch.name}: əsas link düzəlib → əsas linkə qayıdılır")
        LinkCache.clearMainBad(this, ch.url)
        mainBad = false
        mainReturnedAt = SystemClock.elapsedRealtime()
        resolver?.cancel()
        canlitvResolver?.cancel()
        backupResolving = false
        canlitvResolving = false
        yodaStage = false
        canlitvStage = false
        cachedLinkInUse = false
        playlistFallback = false
        backupTries = 0
        canlitvTries = 0
        cancelLinkRefresh()
        engine.swapLink(ch.url, ch.ua, ch.referer, backup = false)
        armLinkWatch()
    }

    /** canlitv-first kanal (ARB Günəş, ARB): canlitv.com linki yoxdur / alınmadı / işləmədi → playlistdəki link (sonra yoda.az). */
    private fun advanceFromCanlitv() {
        val ch = current ?: return
        canlitvResolver?.cancel()
        canlitvResolving = false
        canlitvStage = false
        cachedLinkInUse = false
        android.util.Log.w("IPTV-BACKUP", "${ch.name}: canlitv.com işləmədi → playlist linki")
        engine.halt()
        fallbackToPlaylist() // canlitv → playlist → yoda.az
    }

    /**
     * 3-cü ehtiyat link: kanalın canlitv.com səhifəsi (XezerTV məntiqi) gizli WebView-da açılır, .m3u8 tutulur.
     * true = proses başladı, false = canlitv linki yoxdur / cəhdlər (3) bitib.
     */
    private fun startCanlitv(isRefresh: Boolean): Boolean {
        val ch = current ?: return false
        val page = Backup.canlitvPageFor(this, ch) ?: run {
            android.util.Log.w("IPTV-BACKUP", "${ch.name}: canlitv səhifəsi tapılmadı (ad=${ch.name}, tvg=${ch.tvgName}, qrup=${ch.group})")
            return false
        }
        if (canlitvResolving) return true
        val cacheKey = "canlitv:$page"
        if (isRefresh) {
            LinkCache.remove(this, cacheKey)
            cachedLinkInUse = false
        } else {
            val c = LinkCache.get(this, cacheKey, LinkCache.CANLITV_TTL)
            if (c != null) {
                android.util.Log.i("IPTV-BACKUP", "${ch.name}: canlitv linki keşdən açılır")
                cachedLinkInUse = true
                canlitvStage = true
                resolver?.cancel()
                backupResolving = false
                progress.removeCallbacks(showSpinner)
                videoCover.visibility = View.VISIBLE
                errorBox.visibility = View.GONE
                status.visibility = View.GONE
                setPlayerLoadingStatus("Ehtiyat link keşdən açılır…")
                loadingBox.visibility = View.VISIBLE
                yodaStage = false
                engine.play(c.url, c.userAgent, c.referer, backup = true)
                armLinkWatch()
                return true
            }
        }
        if (canlitvTries >= 3) return false
        canlitvTries++
        canlitvStage = true
        canlitvResolving = true
        resolver?.cancel()
        backupResolving = false
        val chUrl = ch.url
        android.util.Log.w("IPTV-BACKUP", "${ch.name}: canlitv.com ehtiyat linki (cəhd $canlitvTries, yenilənmə=$isRefresh) → $page")
        progress.removeCallbacks(showSpinner)
        videoCover.visibility = View.VISIBLE
        errorBox.visibility = View.GONE
        status.visibility = View.GONE
        setPlayerLoadingStatus(
            if (isRefresh) "Link yenilənir (canlitv.com)…"
            else if (Backup.canlitvFirst(ch)) "Link canlitv.com-dan alınır…"
            else "Ehtiyat link canlitv.com-dan alınır…"
        )
        loadingBox.visibility = View.VISIBLE
        val r = canlitvResolver ?: CanlitvResolver(this, findViewById<ViewGroup>(R.id.root)).also { canlitvResolver = it }
        val first = Backup.canlitvFirst(ch)
        handler.removeCallbacks(linkWatchRun)
        r.resolve(page, if (first) CANLITV_RESOLVE_MS else CanlitvResolver.TIMEOUT_MS) { res -> // v1.68: canlitv-first: 5 s, son mərhələ: 20 s; m3u8 tapılmasa (player açılmasa) növbəti mənbəyə keçilir / "Kanal İşləmir"
            canlitvResolving = false
            if (isFinishing || isDestroyed || current?.url != chUrl) return@resolve
            if (res != null) {
                LinkCache.put(this, cacheKey, res)
                cachedLinkInUse = false
                setPlayerLoadingStatus("Link tapıldı, açılır…")
                yodaStage = false
                engine.play(res.url, res.userAgent, res.referer, backup = true)
                armLinkWatch()
            } else if (!canlitvEverPlayed) {
                // canlitv.com-dan link 5 s-də alınmadı → növbəti link (canlitv-first: yoda.az; digərlərində son mərhələ)
                if (first) advanceFromCanlitv() else showStreamFailed()
            } else {
                handler.postDelayed({
                    if (!isFinishing && !isDestroyed && current?.url == chUrl && !canlitvResolving) {
                        if (!startCanlitv(isRefresh)) { if (first) advanceFromCanlitv() else showStreamFailed() }
                    }
                }, 2_000L)
            }
        }
        return true
    }

    private fun showStreamFailed() {
        progress.removeCallbacks(showSpinner)
        hidePlayerLoading()
        videoCover.visibility = View.VISIBLE
        status.visibility = View.GONE
        errorBox.visibility = View.VISIBLE
    }

    private fun neighbor(base: Channel?, d: Int): Channel? {
        val l = listFor(playGroup).ifEmpty { all }
        if (l.isEmpty()) return null
        val i = l.indexOfFirst { it.url == base?.url }
        return l[((if (i < 0) 0 else i + d) + l.size) % l.size]
    }

    private fun step(d: Int) {
        previewCh = null
        handler.removeCallbacks(commitRun)
        neighbor(current, d)?.let { play(it, playGroup, d) }
    }

    /** Sol/sağ düyməni basıb saxlayanda kanallar sürətlə dəyişir; kanal düymə buraxılanda açılır. */
    private fun fastStep(d: Int) {
        val now = SystemClock.uptimeMillis()
        if (now - lastFastStep < 110) return
        lastFastStep = now
        val ch = neighbor(previewCh ?: current, d) ?: return
        previewCh = ch
        showInfo(ch, d)
        handler.removeCallbacks(commitRun)
        handler.postDelayed(commitRun, 450)
    }

    /** Kanal dəyişəndə/seçiləndə aşağıda məlumat yüngül animasiya ilə göstərilir, sonra silinir. */
    private fun showInfo(ch: Channel, dir: Int = 0) {
        infoShown = ch
        infoName.text = infoTitle(ch, if (ch.url == current?.url) engine.stats() else null)
        updateInfoExtras(ch)
        infoLogo.setImageDrawable(null)
        infoBar.animate().cancel()
        if (dir != 0) {
            infoBar.translationX = dp(48).toFloat() * dir
            infoBar.alpha = 0.3f
            infoBar.visibility = View.VISIBLE
            infoBar.animate().translationX(0f).alpha(1f).setDuration(120).start()
        } else {
            infoBar.translationX = 0f
            infoBar.alpha = 1f
            infoBar.visibility = View.VISIBLE
        }
        lifecycleScope.launch(safeHandler) {
            val bmp = logos.bitmapFor(ch)
            if (bmp != null && infoShown == ch) infoLogo.setImageBitmap(bmp)
        }
        handler.removeCallbacks(hideInfoRun)
        handler.postDelayed(hideInfoRun, 8_000L)
    }

    // ---------- channel panel ----------
    // ---------- tam ekran: qruplar (sol) + kanallar (sağ) ----------
    private fun showBrowserChannels() {
        val l = listFor(browserGroup)
        rowAdapter.items = l
        rowAdapter.playingUrl = current?.url
        rowAdapter.notifyDataSetChanged()
        browserTitle.text = "${browserGroup ?: "Hamısı"}  (${l.size})"
    }

    private fun adjustChannelColumns() {
        val layout = channelsList.layoutManager as? GridLayoutManager ?: return
        val available = channelsList.width
        if (available <= 0) return
        // Geniş ekranda daha çox kanal eyni anda görünür; kiçik ekranda sütun sayı azalır.
        val desired = (available.toFloat() / dp(270).coerceAtLeast(1)).roundToInt().coerceIn(2, 5)
        if (layout.spanCount != desired) layout.spanCount = desired
    }

    private fun focusPos(rv: RecyclerView, idx: Int) {
        val layout = rv.layoutManager as? LinearLayoutManager ?: return
        if (rv == list) centerListPadding()
        layout.scrollToPositionWithOffset(idx, if (rv == list) 0 else if (rv == channelsList) dp(24) else dp(120))
        rv.postDelayed({ rv.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 90)
    }

    // ---------- kanalların yerini dəyiş ----------
    private fun openReorder() {
        val g = browserGroup
        if (g != null) { showReorder(g); return }
        // "Hamısı" açıqdır: hansı qrupun sırası dəyişəcək?
        val names = groupList.filterNotNull()
        if (names.isEmpty()) return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Hansı qrupda kanalların yeri dəyişsin?")
            .setItems(names.map { "$it  (${byGroup[it]?.size ?: 0})" }.toTypedArray()) { _, i -> showReorder(names[i]) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun showReorder(g: String) {
        val l = byGroup[g].orEmpty()
        if (l.size < 2) { Toast.makeText(this, "Bu qrupda yerini dəyişmək üçün kifayət qədər kanal yoxdur", Toast.LENGTH_SHORT).show(); return }
        ReorderDialog(this, g, l,
            onSave = { ordered ->
                ChannelOrder.save(applicationContext, g, ordered)
                applyGroupOrder(g, ordered)
                Toast.makeText(this, "Kanalların sırası saxlanıldı", Toast.LENGTH_SHORT).show()
            },
            onReset = {
                ChannelOrder.clear(applicationContext, g)
                applyGroupOrder(g, rawParsed.filter { it.group == g })
                Toast.makeText(this, "İlkin sıra bərpa olundu", Toast.LENGTH_SHORT).show()
            }
        ).also { d ->
            d.setOnDismissListener {
                if (browserShown()) focusPos(channelsList, rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0))
            }
        }.show()
    }

    /** Bir qrupun yeni sırasını bütün siyahıya tətbiq edir, nömrələri yenidən verir və açıq siyahıları yeniləyir. */
    private fun applyGroupOrder(g: String, ordered: List<Channel>) {
        val flat = groupList.filterNotNull().flatMap { n -> if (n == g) ordered else byGroup[n].orEmpty() }
        val renum = flat.mapIndexed { i, c -> c.copy(number = i + 1) }
        all = renum
        byGroup = renum.groupBy { it.group }
        val cu = current
        if (cu != null) current = renum.firstOrNull { it.url == cu.url && it.group == cu.group } ?: cu
        groupAdapter.notifyDataSetChanged()
        showBrowserChannels()
        if (panelShown()) loadBrowse()
    }

    private fun setBrowser(show: Boolean) {
        if (show) setNumPad(false)
        if (!show) { browser.visibility = View.GONE; return }
        showControls(false)
        handler.removeCallbacks(hideInfoRun)
        setPanel(false)
        infoBar.visibility = View.GONE
        browserGroup = playGroup
        groupAdapter.items = groupList
        groupAdapter.selected = browserGroup
        groupAdapter.notifyDataSetChanged()
        showBrowserChannels()
        browser.visibility = View.VISIBLE
        groupsList.scrollToPosition(groupList.indexOf(browserGroup).coerceAtLeast(0))
        focusPos(channelsList, rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0))
    }

    /** Kanal şəbəkəsində verilmiş mövqeyə dərhal fokus verir (basıb saxlayanda gecikmə olmasın deyə postDelayed yoxdur). */
    private fun focusChannelNow(idx: Int) {
        val holder = channelsList.findViewHolderForAdapterPosition(idx)
        if (holder != null) {
            holder.itemView.requestFocus()
            // Görünən, amma kənara yaxın elementi ekrana gətir.
            channelsList.scrollToPosition(idx)
        } else {
            channelsList.scrollToPosition(idx)
            channelsList.doOnNextLayout {
                channelsList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus()
            }
        }
    }

    private fun handleBrowserKey(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> if (f != null) {
                    val channelItem = channelsList.findContainingItemView(f)
                    if (channelItem != null) {
                        val pos = channelsList.getChildAdapterPosition(channelItem)
                        val grid = channelsList.layoutManager as? GridLayoutManager
                        val size = rowAdapter.items.size
                        if (pos != RecyclerView.NO_POSITION && grid != null && (pos >= size || pos % grid.spanCount == 0)) {
                            if (e.repeatCount == 0) {
                                // Tək basış: sol kənardakı sütundan qruplara keç.
                                focusPos(groupsList, groupList.indexOf(browserGroup).coerceAtLeast(0))
                            } else if (size > 1 && pos < size) {
                                // Basıb saxlama: əvvəlki sətrin sonuna keç, siyahının əvvəlindən sonuna dövr et.
                                focusChannelNow((pos - 1 + size) % size)
                            }
                            return true
                        }
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (f != null) {
                    if (groupsList.findContainingItemView(f) != null) {
                        focusPos(channelsList, if (browserGroup == playGroup)
                            rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0) else 0)
                        return true
                    }
                    val channelItem = channelsList.findContainingItemView(f)
                    if (channelItem != null) {
                        val pos = channelsList.getChildAdapterPosition(channelItem)
                        val grid = channelsList.layoutManager as? GridLayoutManager
                        val size = rowAdapter.items.size
                        if (pos >= size) return true // sondakı "Yerini Dəyiş" düyməsi
                        // Sətrin sonunda (və ya sonuncu kanalda) dayanma: növbəti sətrə, ən sondan isə əvvələ keç.
                        if (pos != RecyclerView.NO_POSITION && grid != null && size > 1 &&
                            (pos % grid.spanCount == grid.spanCount - 1 || pos == size - 1)) {
                            focusChannelNow((pos + 1) % size)
                            return true
                        }
                    }
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun setPanel(show: Boolean) {
        if (show) setNumPad(false)
        if (show && ::controls.isInitialized) showControls(false)
        panel.animate().cancel()
        panelBody.animate().cancel()
        switching = false
        if (show) {
            handler.removeCallbacks(hideInfoRun)
            infoBar.visibility = View.GONE
            browseGroup = playGroup
            panelBody.translationY = 0f
            panelBody.alpha = 1f
            loadBrowse()
            panel.alpha = 0f
            panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).setDuration(150).start()
            focusedCh = current
            renderDetail()
            focusCurrent()
        } else {
            panel.visibility = View.GONE
        }
    }

    private fun loadBrowse() {
        val l = listFor(browseGroup)
        adapter.items = l
        adapter.playingUrl = current?.url
        adapter.notifyDataSetChanged()
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        groupTitle.text = "${browseGroup ?: "Hamısı"}  (${l.size})      ${gi + 1}/${groupList.size}"
    }

    /** Sol/sağ boşluq: birinci və sonuncu kart da ortaya gələ bilsin (kart eni 300dp + 2×6dp kənar). */
    private fun centerListPadding() {
        val w = if (list.width > 0) list.width else resources.displayMetrics.widthPixels
        val pad = ((w - dp(312)) / 2).coerceAtLeast(0)
        if (list.paddingLeft != pad || list.paddingRight != pad) list.setPadding(pad, list.paddingTop, pad, list.paddingBottom)
    }

    private fun focusCurrent() {
        val idx = adapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0)
        val pos = adapter.basePosition(idx)
        centerListPadding()
        (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(pos, 0)
        list.postDelayed({ list.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }, 70)
    }

    /** Yuxarı/aşağı: qonşu qrupa yüngül sürüşmə animasiyası ilə keçid. */
    private fun switchGroup(d: Int) {
        if (switching || groupList.size < 2) return
        switching = true
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        val next = groupList[(gi + d + groupList.size) % groupList.size]
        val dist = dp(56).toFloat() * d
        panelBody.animate().translationY(-dist).alpha(0f).setDuration(110).withEndAction {
            browseGroup = next
            loadBrowse()
            panelBody.translationY = dist
            panelBody.animate().translationY(0f).alpha(1f).setDuration(160)
                .withEndAction { switching = false }.start()
            focusCurrent()
        }.start()
    }

    // ---------- kanal axtarışı ----------
    private lateinit var searchBox: View
    private lateinit var searchInput: android.widget.EditText
    private lateinit var searchList: RecyclerView
    private lateinit var searchEmpty: TextView
    private lateinit var searchAdapter: ChannelAdapter
    private var searchIndexSrc: List<Channel>? = null
    private var searchIndex: List<Pair<Channel, String>> = emptyList()

    private fun searchShown() = ::searchBox.isInitialized && searchBox.visibility == View.VISIBLE

    /** Axtarış üçün sadələşdirmə: kiçik hərf, ə/ı/ö/ü/ş/ç/ğ → e/i/o/u/s/c/g, durğu işarələri atılır. */
    private fun foldSearch(s: String): String {
        var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
        t = java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        return t.trim()
    }

    /** Yazılan hərflərə görə kanallar: əvvəl adı həmin hərflə başlayanlar, sonra sözü başlayanlar, sonra içində olanlar. */
    private fun runSearch(raw: String) {
        val q = foldSearch(raw)
        if (searchIndexSrc !== all) {
            searchIndexSrc = all
            searchIndex = all.map { it to foldSearch(it.name) }
        }
        val res: List<Channel> = if (q.isEmpty()) emptyList() else {
            val seen = HashSet<String>()
            val scored = ArrayList<Pair<Int, Channel>>()
            for ((c, n) in searchIndex) {
                val tier = when {
                    n.startsWith(q) || c.number.toString() == q -> 0
                    n.split(' ').any { it.startsWith(q) } -> 1
                    n.contains(q) -> 2
                    else -> -1
                }
                if (tier < 0) continue
                if (seen.add(c.name + "|" + c.url)) scored.add(tier to c)
            }
            scored.sortedWith(compareBy<Pair<Int, Channel>>({ it.first }, { it.second.number })).map { it.second }.take(60)
        }
        searchAdapter.items = res
        searchAdapter.notifyDataSetChanged()
        searchList.scrollToPosition(0)
        val msg = when {
            q.isEmpty() -> "Kanal adını yazın"
            res.isEmpty() -> "Kanal tapılmadı"
            else -> ""
        }
        searchEmpty.text = msg
        searchEmpty.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun pickSearch(ch: Channel) {
        setSearch(false)
        if (ch.url == current?.url) return
        val g = playGroup?.takeIf { gr -> listFor(gr).any { it.url == ch.url } }
        play(ch, g)
    }

    private fun setSearch(show: Boolean) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        if (!show) {
            if (!searchShown()) return
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            searchBox.visibility = View.GONE
            searchInput.clearFocus()
            return
        }
        showControls(false)
        handler.removeCallbacks(hideInfoRun)
        setPanel(false)
        setBrowser(false)
        setNumPad(false)
        infoBar.visibility = View.GONE
        // Panel ekranın yuxarı yarısıdır: klaviatura aşağıdan açılanda nəticələri örtmür.
        val lp = searchBox.layoutParams
        lp.height = (findViewById<View>(R.id.root).height * 0.5f).roundToInt().coerceAtLeast(dp(260))
        searchBox.layoutParams = lp
        searchInput.setText("")
        runSearch("")
        searchBox.visibility = View.VISIBLE
        searchInput.requestFocus()
        searchInput.postDelayed({
            if (searchShown()) imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }, 150)
    }

    private fun setupSearch() {
        searchBox = findViewById(R.id.searchBox)
        searchInput = findViewById(R.id.searchInput)
        searchList = findViewById(R.id.searchList)
        searchEmpty = findViewById(R.id.searchEmpty)
        searchAdapter = ChannelAdapter(logos, epg, lifecycleScope, R.layout.item_channel_row) { ch -> pickSearch(ch) }
        val cols = if (resources.displayMetrics.widthPixels > dp(900)) 2 else 1
        searchList.layoutManager = GridLayoutManager(this, cols)
        searchList.adapter = searchAdapter
        searchList.itemAnimator = null
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { if (searchShown()) runSearch(s?.toString().orEmpty()) }
        })
        // Klaviaturada "Axtar" / Enter: birinci nəticəni açır.
        searchInput.setOnEditorActionListener { _, _, _ ->
            if (searchShown()) searchAdapter.items.firstOrNull()?.let { pickSearch(it) }
            true
        }
        findViewById<View>(R.id.searchClose).setOnClickListener { setSearch(false) }
    }

    // ---------- touch control (telefon / planşet) ----------
    private fun showControls(show: Boolean) {
        handler.removeCallbacks(hideControlsRun)
        if (!show) { controls.visibility = View.GONE; return }
        refreshControls()
        controls.visibility = View.VISIBLE
        handler.postDelayed(hideControlsRun, 4000)
    }

    private fun refreshControls() {
        current?.let { showInfo(it) } // kanal adı, proqram, ölçü, bufer, sürət, bitrate
    }

    private fun showHud(text: String) {
        gestureHud.text = text
        gestureHud.visibility = View.VISIBLE
        handler.removeCallbacks(hideHudRun)
        handler.postDelayed(hideHudRun, 900)
    }

    // ---- ekran rəqəm paneli (telefon/planşet): 123 düyməsi ilə açılır ----
    private lateinit var numPad: LinearLayout
    private val hideNumPadRun = Runnable { setNumPad(false) }
    private fun numPadShown() = ::numPad.isInitialized && numPad.visibility == View.VISIBLE

    private fun setNumPad(show: Boolean) {
        if (!::numPad.isInitialized) return
        handler.removeCallbacks(hideNumPadRun)
        numPad.visibility = if (show) View.VISIBLE else View.GONE
        // Nömrə göstəricisi panelin solunda qalsın.
        (numInput.layoutParams as FrameLayout.LayoutParams).let {
            it.marginEnd = if (show) dp(240) else dp(32)
            numInput.layoutParams = it
        }
        if (show) handler.postDelayed(hideNumPadRun, 10_000)
        else {
            handler.removeCallbacks(numCommitRun)
            numBuf.clear()
            numInput.visibility = View.GONE
        }
    }

    private fun padDigit(d: Int) {
        if (all.isEmpty()) return
        val maxLen = all.size.toString().length
        if (numBuf.length >= maxLen) numBuf.clear()
        numBuf.append(d)
        handler.removeCallbacks(numCommitRun)
        handler.removeCallbacks(numHideRun)
        numInput.text = numLabel()
        numInput.visibility = View.VISIBLE
        handler.removeCallbacks(hideNumPadRun)
        handler.postDelayed(hideNumPadRun, 10_000)
    }

    private fun padBack() {
        if (numBuf.isEmpty()) return
        numBuf.deleteCharAt(numBuf.length - 1)
        if (numBuf.isEmpty()) numInput.visibility = View.GONE else numInput.text = numLabel()
        handler.removeCallbacks(hideNumPadRun)
        handler.postDelayed(hideNumPadRun, 10_000)
    }

    private fun padOk() {
        val n = numBuf.toString().toIntOrNull() ?: return
        val found = all.any { it.number == n }
        commitNumber()
        if (found) setNumPad(false)
        else { handler.removeCallbacks(hideNumPadRun); handler.postDelayed(hideNumPadRun, 10_000) }
    }

    private fun buildNumPad(root: ViewGroup) {
        numPad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.round_bg)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isClickable = true // boşluğa toxunuş videoya keçməsin
            visibility = View.GONE
        }
        fun key(label: String, onTap: () -> Unit) = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 22f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setBackgroundResource(R.drawable.ctrl_bg)
            isClickable = true
            isFocusable = false
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
            setOnClickListener { onTap() }
        }
        val rows = listOf(
            listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "✓")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in r) row.addView(key(k) {
                when (k) { "⌫" -> padBack(); "✓" -> padOk(); else -> padDigit(k.toInt()) }
            })
            numPad.addView(row)
        }
        root.addView(numPad, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.END or Gravity.CENTER_VERTICAL
        ).apply { marginEnd = dp(16) })
    }

    // ---- HDR / Dolby Vision: pəncərə rəng rejimi (TCL 65C6K: HDR10/HDR10+/HLG/Dolby Vision) ----
    // TV HDR dəstəkləyirsə həmişə AÇIQDIR (düymə yoxdur): HDR axınları TV-yə HDR kimi çatır, SDR-ə endirilmir.
    // Kadr tezliyi uyğunlaşdırma (24/25/50/60 Hz, 144 Hz panel) və tunneled playback Media3Engine-də həmişə açıqdır.
    // AiPQ / MEMC / local dimming / Dolby Vision IQ TV-nin öz ayarlarıdır; tətbiq hardware dekoder → SurfaceView yolunu qoruyur.
    private fun hdrSupported(): Boolean = TvProfile.of(applicationContext).hdrTypes.isNotEmpty()

    /** Ekran çıxışı 4K-dan aşağıdırsa 4K rejim istənir ki, TV öz AI upscaling-i ilə videonu 4K-ya böyütsün. */
    private fun applyUhdOutput() {
        if (android.os.Build.VERSION.SDK_INT < 23 || !TvProfile.of(applicationContext).isTv) return
        val id = TvProfile.uhdModeId(applicationContext) ?: return
        runCatching { window.attributes = window.attributes.also { it.preferredDisplayModeId = id } }
    }

    private fun applyHdrMode() {
        if (android.os.Build.VERSION.SDK_INT < 26) return
        runCatching {
            window.colorMode = if (hdrSupported()) android.content.pm.ActivityInfo.COLOR_MODE_HDR
                               else android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT
        }
    }

    private fun setupTouchControls(root: View) {
        controls = findViewById(R.id.controls)
        gestureHud = findViewById(R.id.gestureHud)

        buildNumPad(root as ViewGroup)
        findViewById<View>(R.id.ctrlNum).setOnClickListener { showControls(false); setNumPad(true) }
        findViewById<View>(R.id.ctrlMic).setOnClickListener { showControls(false); startVoice() }
        findViewById<View>(R.id.ctrlList).setOnClickListener { showControls(false); setBrowser(true) }
        findViewById<View>(R.id.ctrlStrip).setOnClickListener { showControls(false); setPanel(true) }
        findViewById<View>(R.id.ctrlSearch).setOnClickListener { showControls(false); setSearch(true) }
        findViewById<View>(R.id.ctrlEpg).setOnClickListener {
            current?.let { showControls(false); setEpgFull(true, it) }
        }
        findViewById<View>(R.id.browserClose).setOnClickListener { setBrowser(false) }
        findViewById<View>(R.id.epgFullClose).setOnClickListener { setEpgFull(false) }

        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val slop = dp(14)
        // 0 = hələ təyin olunmayıb, 1 = üfüqi sürüşdürmə (kanal), 2 = səs (sağ yarı), 3 = parlaqlıq (sol yarı)
        var mode = 0
        var sx = 0f
        var sy = 0f
        var startVol = 0
        var startBright = 0.5f

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            // Tək toxunuş: açıq panel varsa bağlanır; yoxsa idarə düymələri göstərilir/gizlədilir.
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                when {
                    numPadShown() -> setNumPad(false)
                    panelShown() -> setPanel(false)
                    controls.visibility == View.VISIBLE -> { showControls(false); infoBar.visibility = View.GONE }
                    else -> showControls(true)
                }
                return true
            }
            // Ekranın mərkəzini basıb saxlamaq: SW ↔ HW (kanal oynayırsa).
            override fun onLongPress(e: MotionEvent) {
                if (current == null || mode != 0) return
                val w = root.width.toFloat()
                val h = root.height.toFloat()
                if (w <= 0f || h <= 0f) return
                val mx = w * (1f - SW_CENTER_FRACTION) / 2f
                val my = h * (1f - SW_CENTER_FRACTION) / 2f
                if (e.x < mx || e.x > w - mx || e.y < my || e.y > h - my) return
                root.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                if (engine.isPaused()) engine.togglePause()
                toggleSoftwareDecoder()
            }
            // İki dəfə toxunuş: pauza / davam.
            override fun onDoubleTap(e: MotionEvent): Boolean {
                engine.togglePause()
                showHud(if (engine.isPaused()) "⏸" else "▶")
                return true
            }
        })

        root.setOnTouchListener { v, ev ->
            detector.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    mode = 0; sx = ev.x; sy = ev.y
                    startVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    val wb = window.attributes.screenBrightness
                    startBright = if (wb >= 0f) wb else runCatching {
                        android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f
                    }.getOrDefault(0.5f)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.x - sx
                    val dy = ev.y - sy
                    if (mode == 0 && (abs(dx) > slop || abs(dy) > slop)) {
                        mode = if (abs(dx) > abs(dy)) 1 else if (sx < v.width / 2f) 3 else 2
                    }
                    val frac = -dy / (v.height * 0.8f)
                    when (mode) {
                        2 -> {
                            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            val vol = (startVol + frac * max).roundToInt().coerceIn(0, max)
                            runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0) }
                            showHud("🔊 ${if (max > 0) vol * 100 / max else 0}%")
                        }
                        3 -> {
                            val b = (startBright + frac).coerceIn(0.02f, 1f)
                            window.attributes = window.attributes.also { it.screenBrightness = b }
                            showHud("🔆 ${(b * 100).roundToInt()}%")
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    // Sola sürüşdür: növbəti kanal; sağa: əvvəlki kanal.
                    val dx = ev.x - sx
                    if (mode == 1 && abs(dx) > dp(80)) {
                        step(if (dx < 0) 1 else -1)
                    }
                }
            }
            true
        }
    }

    // ---------- remote control ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        // Pultun mikrofon / Assistant düyməsi (sistem tətbiqə ötürərsə): tətbiqdaxili səs axtarışı.
        if (e.keyCode == KeyEvent.KEYCODE_VOICE_ASSIST || e.keyCode == KeyEvent.KEYCODE_ASSIST) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) startVoice()
            return true
        }
        // Geri düyməsini basıb saxlamaq: oynayan kanal SW ↔ HW. Düymə buraxılanda adi Geri işləmir.
        if (e.keyCode == KeyEvent.KEYCODE_BACK) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                if (e.repeatCount == 0) backHoldFired = false
                else if (!backHoldFired && e.eventTime - e.downTime >= SW_BACK_HOLD_MS && current != null && !searchShown()) {
                    backHoldFired = true
                    if (browserShown()) setBrowser(false)
                    toggleSoftwareDecoder()
                    return true
                }
                if (backHoldFired) return true
            } else if (e.action == KeyEvent.ACTION_UP && backHoldFired) {
                backHoldFired = false
                return true
            }
        }
        if (epgFullShown()) return super.dispatchKeyEvent(e)
        if (browserShown()) return handleBrowserKey(e)
        // Axtarış açıqdır: düymələr (hərflər, rəqəmlər, sol/sağ/aşağı) yazı xanasına və nəticələr siyahısına gedir.
        if (searchShown()) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN && controls.visibility == View.VISIBLE) showControls(false)
        if (e.action == KeyEvent.ACTION_UP && previewCh != null) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CHANNEL_UP,
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    handler.removeCallbacks(commitRun); commitRun.run(); return true
                }
            }
        }
        if (e.action == KeyEvent.ACTION_DOWN) {
            val dg = digitOf(e.keyCode)
            if (dg >= 0) { if (e.repeatCount == 0) typeDigit(dg); return true }
            if (numBuf.isNotEmpty()) when (e.keyCode) {
                // Nömrə yığılarkən OK: gözləmədən kanalı aç.
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    if (e.repeatCount == 0) commitNumber(); return true
                }
            }
            if (panelShown()) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (e.repeatCount == 0) switchGroup(-1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { if (e.repeatCount == 0) switchGroup(1); return true }
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        // Siyahı dövr edir, amma görüntü yerində qalır: sonuncudan sonra birinciyə, birincidən əvvəl sonuncuya keçid.
                        val dir = if (e.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1
                        val n = adapter.items.size
                        val fc = list.focusedChild
                        val pos = if (fc != null) list.getChildAdapterPosition(fc) else RecyclerView.NO_POSITION
                        if (n > 1 && pos != RecyclerView.NO_POSITION && ((dir > 0 && pos == n - 1) || (dir < 0 && pos == 0))) {
                            if (e.repeatCount == 0) focusPos(list, if (dir > 0) 0 else n - 1)
                            return true
                        }
                    }
                }
                return super.dispatchKeyEvent(e) // sol/sağ/OK: kanal seçimi
            }
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MENU -> {
                    if (e.repeatCount == 0) setPanel(true); return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    // OK: birbaşa ümumi kanal siyahısı (qruplar + kanallar).
                    if (e.repeatCount == 0 && current != null) setBrowser(true)
                    return true
                }
                // Aşağı düymə (və ya pultun axtarış düyməsi): kanal axtarışı + klaviatura.
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_SEARCH -> {
                    if (e.repeatCount == 0) setSearch(true); return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (e.repeatCount == 0) step(-1) else fastStep(-1); return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (e.repeatCount == 0) step(1) else fastStep(1); return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    engine.togglePause()
                    return true
                }
                // Google TV / TCL pultu və HDMI-CEC: ayrıca Play / Pause düymələri.
                KeyEvent.KEYCODE_MEDIA_PLAY -> {
                    if (e.repeatCount == 0 && engine.isPaused()) { engine.togglePause(); showHud("▶") }
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    if (e.repeatCount == 0 && !engine.isPaused()) { engine.togglePause(); showHud("⏸") }
                    return true
                }
                // GUIDE: cari kanalın proqram cədvəli (EPG); INFO: kanal məlumatı paneli.
                KeyEvent.KEYCODE_GUIDE -> {
                    if (e.repeatCount == 0) current?.let { setEpgFull(true, it) }
                    return true
                }
                KeyEvent.KEYCODE_INFO -> {
                    if (e.repeatCount == 0) current?.let { showInfo(it) }
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------- EPG + resolution ----------
    private fun reloadEpg() {
        val chs = all
        if (chs.isEmpty()) return
        lifecycleScope.launch(safeHandler) {
            logos.beginBatch() // loqolar tam yenilənənə qədər kartlar tək-tək endirməsin
            try {
                // 1) telefondakı EPG dərhal; 2) mənbədə yenilik varsa tam endirilib bir anda əvəz olunur
                if (epg.loadCached(chs)) refreshEpgUi()
                if (epg.loadExtCached(chs)) refreshEpgUi()   // kanala xas əlavə EPG (telefondakı nüsxə)
                if (epg.update(chs, true)) refreshEpgUi() // açılışda mənbədə yenilik məcburi yoxlanılır
                if (epg.updateExt(chs, true)) refreshEpgUi() // azepg.ddns.net faylları
                // 3) loqolar: hamısı paralel endirilir, tam bitəndən sonra birdən dəyişir
                val n = logos.refreshAll(all, epg.consumeSourceUpdated())
                if (n > 0) refreshEpgUi()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (t: Throwable) {
                // şəbəkə/yaddaş xətası tətbiqi çökdürməsin: köhnə EPG/loqolar qalır
            } finally {
                logos.endBatch()
            }
            refreshEpgUi() // gözləyən kartlar yeni loqonu göstərsin
        }
    }

    /**
     * Kanal dəyişəndə şəbəkədən EPG yoxlanılmır (EPG mənbəyi əsasən açılışda yoxlanılır). Yalnız bu kanalın proqramı
     * köhnəlibsə telefondakı EPG faylından yenilənir; kanalın loqosu mənbədə dəyişibsə yalnız o halda əvəz olunur.
     */
    private var switchedJob: Job? = null
    private fun onChannelSwitched(ch: Channel) {
        // Sürətli dəyişmədə köhnə yoxlamalar ləğv olunur, yalnız son kanal üçün icra edilir.
        switchedJob?.cancel()
        switchedJob = lifecycleScope.launch(safeHandler) {
            kotlinx.coroutines.delay(700)
            if (epg.refreshChannel(ch, all)) refreshEpgUi()
            if (epg.refreshExtChannel(ch, all)) refreshEpgUi()
            if (logos.refreshChannel(ch)) {
                if (infoShown == ch) logos.bitmapFor(ch)?.let { infoLogo.setImageBitmap(it) }
                adapter.notifyDataSetChanged(); rowAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun epgFullShown() = epgFull.visibility == View.VISIBLE

    private fun setEpgFull(show: Boolean, ch: Channel? = null) {
        if (!show) { epgFull.visibility = View.GONE; epgFullCh = null; return }
        if (ch == null) return
        showControls(false)
        handler.removeCallbacks(hideInfoRun)
        setPanel(false)
        infoBar.visibility = View.GONE
        epgFullCh = ch
        epgFullTitle.text = "${ch.number}.${ch.name}"
        epgFullLogo.setImageDrawable(null)
        lifecycleScope.launch(safeHandler) {
            val b = logos.bitmapFor(ch)
            if (b != null && epgFullCh == ch) epgFullLogo.setImageBitmap(b)
        }
        val list = epg.programs(ch)
        val nowStart = epg.nowNext(ch).first?.start ?: -1L
        progAdapter.items = list
        progAdapter.nowStart = nowStart
        progAdapter.notifyDataSetChanged()
        epgFullEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        epgFull.visibility = View.VISIBLE
        val idx = list.indexOfFirst { it.start == nowStart }.coerceAtLeast(0)
        (epgFullList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(40))
        epgFullList.postDelayed({ epgFullList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 90)
    }

    private fun refreshEpgUi() {
        adapter.notifyDataSetChanged(); rowAdapter.notifyDataSetChanged()
        renderDetail()
        current?.let { updateInfoExtras(it) }
    }

    /** Alt zolaqda kanal adının altında: indi gedən proqram, onun altında növbəti proqram. */
    private fun updateInfoExtras(ch: Channel) {
        if (infoShown != ch) return
        val (n, x) = epg.nowNext(ch)
        if (n != null) {
            infoEpg.text = hm(n.start) + "–" + hm(n.stop) + "  " + n.title
            infoEpg.visibility = View.VISIBLE
            if (n.stop > n.start) {
                val t = System.currentTimeMillis() / 1000
                infoProg.progress = (((t - n.start) * 100) / (n.stop - n.start)).toInt().coerceIn(0, 100)
                infoProg.visibility = View.VISIBLE
            } else infoProg.visibility = View.INVISIBLE
        } else {
            infoEpg.text = ""
            infoEpg.visibility = View.INVISIBLE
            infoProg.visibility = View.INVISIBLE
        }
        if (x != null) {
            infoNext.text = "Sonra:  " + hm(x.start) + "  " + x.title
            infoNext.visibility = View.VISIBLE
        } else {
            infoNext.text = ""
            infoNext.visibility = View.INVISIBLE
        }
    }

    /** OK ilə açılan bölmədə fokuslanan kanalın ətraflı məlumatı. */
    private fun renderDetail() {
        if (!panelShown()) return
        val ch = focusedCh ?: current ?: return
        val (n, x) = epg.nowNext(ch)
        detNow.text = if (n != null) "Hazırda:  ${hm(n.start)}–${hm(n.stop)}  ${n.title}" else "Proqram məlumatı yoxdur"
        detNext.text = if (x != null) "Sonra:  ${hm(x.start)}  ${x.title}" else ""

        detDesc.text = n?.desc.orEmpty()
    }

    // ---------- lifecycle ----------
    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onStart() {
        super.onStart()
        engine.attach()
        // yoda.az linki gözlənərkən fona keçilibsə (yayım yoxdur): proses yenidən başladılır.
        current?.let { c ->
            if (!engine.hasUrl()) {
                if (Backup.canlitvFirst(c)) { if (!startCanlitv(false)) advanceFromCanlitv() }
                else if (Backup.yodaFirst(c)) { if (!startBackup(false)) fallbackToPlaylist() }
            }
        }
        handler.removeCallbacks(statsRun); handler.post(statsRun)
    }

    override fun onResume() {
        super.onResume()
        leaveGuard = false
    }

    override fun onStop() {
        super.onStop()
        stopListening()
        showControls(false)
        handler.removeCallbacks(statsRun); statsView.visibility = View.INVISIBLE; clockView.visibility = View.INVISIBLE
        handler.removeCallbacks(saveLastRun); saveLast()
        // Yayım dayandırılır; Activity geri qayıdanda eyni kanal yenidən açılır.
        ping.stop()
        // Fonda ehtiyat link prosesi dayandırılır; Activity qayıdanda kanal yenidən açılır və lazım olsa proses təkrar başlayır.
        resolver?.cancel()
        canlitvResolver?.cancel()
        canlitvStage = false
        canlitvTries = 0
        canlitvResolving = false
        canlitvEverPlayed = false
        yodaStage = false
        cancelLinkRefresh()
        handler.removeCallbacks(linkWatchRun)
        cachedLinkInUse = false
        backupResolving = false
        backupTries = 0
        playlistFallback = false
        yodaEverPlayed = false
        cancelMainProbe()
        progress.removeCallbacks(showSpinner)
        hidePlayerLoading()
        engine.stopForBackground()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // 10 = TRIM_MEMORY_RUNNING_LOW: yaddaş azdır, loqo keşi boşaldılır (lazım olanda diskdən yenidən oxunur).
        if (level >= 10) logos.trim()
    }

    // Ev (Home) düyməsi: tətbiq fonda qalmır, tam bağlanır (tapşırıq siyahısından da silinir, proses sonlandırılır).
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (leaveGuard) return // mikrofon icazəsi / səs pəncərəsi / ana ekran sətri sorğusu: bağlanmır
        runCatching { saveLast() }
        finishAndRemoveTask()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        progress.removeCallbacks(showSpinner)
        ping.stop()
        resolver?.cancel()
        resolver = null
        refreshResolver?.cancel()
        refreshResolver = null
        canlitvResolver?.cancel()
        canlitvResolver = null
        runCatching { recognizer?.destroy() }
        recognizer = null
        engine.release()
        super.onDestroy()
        // Ev düyməsi ilə bağlananda proses də ölür: pleyer RAM-da qalmır (konfiqurasiya dəyişikliyi deyilsə).
        if (isFinishing && !isChangingConfigurations) {
            android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}

