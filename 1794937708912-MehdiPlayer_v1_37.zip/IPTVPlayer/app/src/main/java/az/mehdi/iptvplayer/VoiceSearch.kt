package az.mehdi.iptvplayer

import java.text.Normalizer

/**
 * Səs axtarışı (Google Assistant: "Xəzər TV aç"): gələn mətnə ən uyğun kanalı tapır.
 * Mətn sadələşdirilir (ə/ı/ö/ü/ş/ç/ğ → e/i/o/u/s/c/g), "aç / oynat / göstər / kanalı" kimi əmr sözləri atılır.
 */
object VoiceSearch {
    private val COMMAND_WORDS = setOf(
        "ac", "acin", "oynat", "oynadin", "goster", "gosterin", "ver", "qos", "qosun", "izle", "bax",
        "kanal", "kanali", "kanalini", "kanalina", "et", "zehmet", "olmasa", "zehmet olmasa",
        "play", "open", "watch", "show", "channel", "tune", "to", "the", "in", "on", "mehdi", "player", "playerde", "playerda"
    )

    fun fold(s: String): String {
        var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        return t.trim()
    }

    /** Əmr sözləri atılmış, sadələşdirilmiş sorğu. Hamısı əmr sözüdürsə ilkin sadələşdirilmiş mətn qaytarılır. */
    fun clean(raw: String): String {
        val folded = fold(raw)
        val kept = folded.split(' ').filter { it.isNotEmpty() && it !in COMMAND_WORDS }
        return if (kept.isEmpty()) folded else kept.joinToString(" ")
    }

    /** Ən yaxşı uyğun kanal; tapılmazsa null. */
    fun best(channels: List<Channel>, raw: String): Channel? {
        val q = clean(raw)
        if (q.isEmpty()) return null
        val qTokens = q.split(' ')
        var bestCh: Channel? = null
        var bestTier = Int.MAX_VALUE
        var bestLen = Int.MAX_VALUE
        var bestNum = Int.MAX_VALUE
        for (c in channels) {
            val n = fold(c.name)
            if (n.isEmpty()) continue
            val nTokens = n.split(' ')
            val tier = when {
                n == q -> 0
                n.startsWith("$q ") -> 1
                n.length >= 3 && q.startsWith("$n ") -> 2
                qTokens.all { t -> nTokens.any { it.startsWith(t) } } -> 3
                n.contains(q) -> 4
                else -> -1
            }
            if (tier < 0) continue
            // Eyni səviyyədə daha qısa ad (məs. "Xəzər TV" > "Xəzər TV HD"), sonra kiçik nömrə.
            val better = tier < bestTier ||
                (tier == bestTier && (n.length < bestLen || (n.length == bestLen && c.number < bestNum)))
            if (better) { bestCh = c; bestTier = tier; bestLen = n.length; bestNum = c.number }
        }
        return bestCh
    }
}
