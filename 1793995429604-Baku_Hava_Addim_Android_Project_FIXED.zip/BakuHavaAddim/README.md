# Bakı Hava + Addım

Android tətbiqi və ana ekran widgeti: Bakı üzrə hava proqnozu, yağış ehtimalı, saatlıq dəyişikliklər, təhlükəli hava bildirişləri və telefondakı hardware addım sensoru.

## Funksiyalar

- Bakı üçün cari hava: temperatur, hiss olunan temperatur, rütubət, külək və külək şiddəti.
- 7 günlük proqnoz: hər günün minimum/maksimum temperaturu, yağış ehtimalı, yağıntı, qar və maksimum külək.
- Saatlıq proqnoz: növbəti 18 saatın dəyişiklikləri və ən yaxın əhəmiyyətli hadisə (məsələn, 3 saat sonra yağış).
- Bildirişlər: yağış, qar, fırtına/ildırım və güclü külək üçün xəbərdarlıqlar.
- Android ana ekran widgeti: cari hava + növbəti saatların qısa xülasəsi + 7 günlük yağış ehtimalı + addım və kilometr.
- Addımölçən: Android `TYPE_STEP_COUNTER` sensoru ilə arxa fonda izləmə.
- Boy/çəki parametrləri: ilkin dəyərlər 180 sm və 78 kq; addım məsafəsi boydan, təxmini kalori çəkidən hesablanır.

## Texniki məlumat

- Package: `az.mehdi.bakuhavaaddim`
- Min SDK: 26 (Android 8.0)
- Target SDK: 35
- Compile SDK: 35
- Java: 17
- Kotlin: 2.0.21
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Hava API: Open-Meteo Forecast API, Bakı koordinatları 40.4093, 49.8671, `Asia/Baku` saat qurşağı.
- Hava məlumatları 30 dəqiqəlik WorkManager işi ilə yenilənir. Android enerji optimizasiyası fon işini gecikdirə bilər.

## Addımölçən barədə vacib qeyd

İlk dəfə addım izləməni aktiv etdikdə Android fiziki aktivlik icazəsi istəyir. İzləmə üçün tətbiq foreground service işlədir və status sətrində davamlı bildiriş göstərir. Xidmət aktiv olduqdan sonra addımlar arxa fonda sayılır. İlk aktivləşdirmədən əvvəl həmin gün atılmış addımlar geriyə dönük hesaba əlavə edilmir. Telefon yenidən başladıqdan sonra sensorun sayğacı sıfırlana bilər; tətbiq bunu aşkarlayıb yeni baza yaradır. Bəzi Xiaomi/HyperOS enerji qənaəti parametrləri xidməti dayandıra bilər; belə halda tətbiq üçün batareya məhdudiyyətini aradan qaldırın və izləməni yenidən başladın.

Bir addımın uzunluğu təxmini olaraq `boy × 0.415` düsturu ilə götürülür. 180 sm üçün təxminən 74.7 sm-dir. Məsafə və kalori tibbi/peşəkar dəqiqlikdə ölçü deyil.

## Bildiriş və yenilənmə məhdudiyyətləri

Bildirişlər üçün Android 13+ sistemində `POST_NOTIFICATIONS` icazəsi verilməlidir. Hava xəbərdarlıqları internet bağlantısı və fon işinin icrasından asılıdır. WorkManager yenilənməni dəqiq dəqiqədə icra etməyə zəmanət vermir; batareya qənaəti və sistem yükü gecikmə yarada bilər. Proqnoz xəbərdarlıqdır, rəsmi fövqəladə xəbərdarlıq xidməti deyil.

## Ana ekran widgetini əlavə etmək

1. Tətbiqi quraşdırın və bir dəfə açın.
2. Telefonun ana ekranında boş sahəyə uzun basın.
3. **Widgetlər** bölməsini açın.
4. **Bakı Hava + Addım** widgetini seçib ana ekrana yerləşdirin.
5. Widgeti böyüdərək 7 günlük sətirlərin hamısının görünməsini təmin edin.
6. Widgetdəki `↻` düyməsi hava məlumatını yeniləyir; widgetin əsas hissəsinə toxunmaq tətbiqi açır.

## APK yaratmaq

### GitHub Actions ilə (kompütersiz)

1. Bu ZIP arxivinin içindəkiləri GitHub repozitoriyasının kök qovluğuna yükləyin (ZIP-in özünü deyil, faylları açaraq yükləyin).
2. Repozitoriyada **Actions** bölməsini açın.
3. **Build Baku Hava Addim APK** workflow-unu seçin və **Run workflow** düyməsinə toxunun.
4. İş tamamlandıqda **Artifacts** hissəsindən `Baku-Hava-Addim-debug-apk` faylını endirin.
5. ZIP-i açın və `app-debug.apk` faylını Android telefonunuza quraşdırın. Lazım gələrsə, Android-də həmin mənbədən tətbiq quraşdırma icazəsi verin.

Workflow Java 17, Android SDK 35 və Gradle 8.9 ilə debug APK yaradır.

### Android Studio ilə

Layihənin kök qovluğunu Android Studio-da açın, Gradle sync tamamlandıqdan sonra **Build > Build APK(s)** seçin. APK yolu: `app/build/outputs/apk/debug/app-debug.apk`.

## Məlumat mənbəyi və atribusiya

Hava məlumatı [Open-Meteo](https://open-meteo.com/) API-dən alınır. Open-Meteo məlumatlarının atribusiyası tətbiqdə və bu README-də göstərilib. API-nin istifadə şərtləri və kommersiya istifadəsi üçün aktual qaydalar Open-Meteo saytında yoxlanmalıdır.
