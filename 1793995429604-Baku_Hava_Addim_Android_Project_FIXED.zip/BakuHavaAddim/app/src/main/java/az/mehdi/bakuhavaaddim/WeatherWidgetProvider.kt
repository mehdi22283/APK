package az.mehdi.bakuhavaaddim

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

class WeatherWidgetProvider : AppWidgetProvider() {
    companion object {
        const val ACTION_REFRESH = "az.mehdi.bakuhavaaddim.WIDGET_REFRESH"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, WeatherWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            for (id in ids) updateOne(context, manager, id)
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_weather)
            val openIntent = Intent(context, MainActivity::class.java)
            val openPending = PendingIntent.getActivity(
                context, widgetId, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openPending)

            val refreshIntent = Intent(context, WeatherWidgetProvider::class.java).setAction(ACTION_REFRESH)
            val refreshPending = PendingIntent.getBroadcast(
                context, widgetId + 5000, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPending)

            val data = WeatherRepository.cached(context)
            if (data == null) {
                views.setTextViewText(R.id.widget_current, "Hava məlumatı yüklənir...")
                views.setTextViewText(R.id.widget_current_meta, "İnternet bağlantısını yoxlayın")
                views.setTextViewText(R.id.widget_next_change, "Proqnoz ilk yenilənmədən sonra görünəcək")
                views.setTextViewText(R.id.widget_hourly, "↻ düyməsinə toxunaraq yeniləyin")
                views.removeAllViews(R.id.widget_days_container)
            } else {
                val current = data.current
                views.setTextViewText(
                    R.id.widget_current,
                    "${current.temperature.roundToInt()}°  ${WeatherText.emoji(current.code)} ${WeatherText.description(current.code)}"
                )
                views.setTextViewText(
                    R.id.widget_current_meta,
                    "Hiss olunur ${current.feelsLike.roundToInt()}° · Külək ${current.wind.roundToInt()} km/s · Rütubət ${current.humidity}%"
                )
                val warning = WeatherLogic.currentWarning(current)
                views.setTextViewText(R.id.widget_next_change, warning ?: WeatherLogic.nextChange(data))
                views.setTextViewText(R.id.widget_hourly, WeatherLogic.hourlyShort(data, 4))
                views.removeAllViews(R.id.widget_days_container)
                for (day in data.daily.take(7)) {
                    val row = RemoteViews(context.packageName, R.layout.widget_day_row)
                    row.setTextViewText(R.id.day_name, WeatherText.dayLabel(day.date))
                    row.setTextViewText(R.id.day_weather, WeatherText.description(day.code))
                    row.setTextViewText(
                        R.id.day_temp,
                        "${day.maximum.roundToInt()}°/${day.minimum.roundToInt()}°"
                    )
                    row.setTextViewText(R.id.day_rain, "☂ ${day.rainProbability}%")
                    views.addView(R.id.widget_days_container, row)
                }
            }

            val stats = StepStats.snapshot(context)
            val stepLine = if (stats.tracking) {
                "👟 ${stats.steps} addım · ${"%.2f".format(Locale.US, stats.kilometers)} km · ~${stats.calories} kkal"
            } else {
                "Addımölçəni tətbiqdən aktiv edin"
            }
            views.setTextViewText(R.id.widget_steps, stepLine)
            views.setTextViewText(R.id.widget_updated, "Weather data by Open-Meteo.com · ${WeatherRepository.lastUpdated(context)}")
            val sourceIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://open-meteo.com/"))
            val sourcePending = PendingIntent.getActivity(
                context, widgetId + 9000, sourceIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_updated, sourcePending)
            manager.updateAppWidget(widgetId, views)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAll(context)
        WeatherWork.refreshNow(context)
        WeatherWork.schedule(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WeatherWork.refreshNow(context)
            updateAll(context)
        }
    }
}
