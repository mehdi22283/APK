package az.mehdi.bakuhavaaddim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.ceil
import kotlin.math.roundToInt

private val BAKU_ZONE: ZoneId = ZoneId.of("Asia/Baku")
private val AZ_LOCALE: Locale = Locale("az", "AZ")

object AppPrefs {
    const val FILE = "baku_hava_addim"
    fun get(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}

data class CurrentWeather(
    val time: String,
    val temperature: Double,
    val feelsLike: Double,
    val humidity: Int,
    val precipitation: Double,
    val rain: Double,
    val snowfall: Double,
    val code: Int,
    val wind: Double,
    val gust: Double,
    val cloud: Int
)

data class HourlyWeather(
    val time: String,
    val temperature: Double,
    val feelsLike: Double,
    val rainProbability: Int,
    val precipitation: Double,
    val snowfall: Double,
    val code: Int,
    val wind: Double,
    val gust: Double,
    val thunderProbability: Int
)

data class DailyWeather(
    val date: String,
    val code: Int,
    val maximum: Double,
    val minimum: Double,
    val rainProbability: Int,
    val precipitation: Double,
    val snowfall: Double,
    val windMaximum: Double,
    val gustMaximum: Double
)

data class WeatherData(
    val current: CurrentWeather,
    val hourly: List<HourlyWeather>,
    val daily: List<DailyWeather>
)

object WeatherRepository {
    private const val WEATHER_URL =
        "https://api.open-meteo.com/v1/forecast" +
            "?latitude=40.4093&longitude=49.8671" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,snowfall,weather_code,cloud_cover,wind_speed_10m,wind_gusts_10m" +
            "&hourly=temperature_2m,apparent_temperature,precipitation_probability,precipitation,snowfall,weather_code,wind_speed_10m,wind_gusts_10m,thunderstorm_probability" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,snowfall_sum,wind_speed_10m_max,wind_gusts_10m_max" +
            "&timezone=Asia%2FBaku&forecast_days=7&wind_speed_unit=kmh"

    fun fetchAndSave(context: Context): WeatherData {
        val connection = (URL(WEATHER_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "BakuHavaAddim/1.0")
        }
        val raw = try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("Hava serveri HTTP $code qaytardı")
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
        val parsed = parse(raw)
        AppPrefs.get(context).edit()
            .putString("weather_json", raw)
            .putString("weather_updated", LocalDateTime.now(BAKU_ZONE).toString())
            .apply()
        WeatherAlerts.check(context, parsed)
        WeatherWidgetProvider.updateAll(context)
        return parsed
    }

    fun cached(context: Context): WeatherData? {
        val raw = AppPrefs.get(context).getString("weather_json", null) ?: return null
        return try {
            parse(raw)
        } catch (_: Exception) {
            null
        }
    }

    fun lastUpdated(context: Context): String {
        val value = AppPrefs.get(context).getString("weather_updated", null) ?: return "Hələ yenilənməyib"
        return try {
            val dateTime = LocalDateTime.parse(value)
            "Yenilənib: " + dateTime.format(DateTimeFormatter.ofPattern("dd.MM · HH:mm", AZ_LOCALE))
        } catch (_: Exception) {
            "Son yenilənmə: $value"
        }
    }

    private fun parse(raw: String): WeatherData {
        val json = JSONObject(raw)
        val currentJson = json.getJSONObject("current")
        val current = CurrentWeather(
            time = currentJson.optString("time"),
            temperature = currentJson.optDouble("temperature_2m", 0.0),
            feelsLike = currentJson.optDouble("apparent_temperature", currentJson.optDouble("temperature_2m", 0.0)),
            humidity = currentJson.optDouble("relative_humidity_2m", 0.0).roundToInt(),
            precipitation = currentJson.optDouble("precipitation", 0.0),
            rain = currentJson.optDouble("rain", 0.0),
            snowfall = currentJson.optDouble("snowfall", 0.0),
            code = currentJson.optInt("weather_code", 0),
            wind = currentJson.optDouble("wind_speed_10m", 0.0),
            gust = currentJson.optDouble("wind_gusts_10m", 0.0),
            cloud = currentJson.optInt("cloud_cover", 0)
        )

        val hourlyJson = json.getJSONObject("hourly")
        val times = hourlyJson.getJSONArray("time")
        val hourly = ArrayList<HourlyWeather>(times.length())
        for (i in 0 until times.length()) {
            hourly.add(
                HourlyWeather(
                    time = times.optString(i),
                    temperature = hourlyJson.optJSONArray("temperature_2m")?.optDouble(i, 0.0) ?: 0.0,
                    feelsLike = hourlyJson.optJSONArray("apparent_temperature")?.optDouble(i, 0.0) ?: 0.0,
                    rainProbability = hourlyJson.optJSONArray("precipitation_probability")?.optInt(i, 0) ?: 0,
                    precipitation = hourlyJson.optJSONArray("precipitation")?.optDouble(i, 0.0) ?: 0.0,
                    snowfall = hourlyJson.optJSONArray("snowfall")?.optDouble(i, 0.0) ?: 0.0,
                    code = hourlyJson.optJSONArray("weather_code")?.optInt(i, 0) ?: 0,
                    wind = hourlyJson.optJSONArray("wind_speed_10m")?.optDouble(i, 0.0) ?: 0.0,
                    gust = hourlyJson.optJSONArray("wind_gusts_10m")?.optDouble(i, 0.0) ?: 0.0,
                    thunderProbability = hourlyJson.optJSONArray("thunderstorm_probability")?.optInt(i, 0) ?: 0
                )
            )
        }

        val dailyJson = json.getJSONObject("daily")
        val dates = dailyJson.getJSONArray("time")
        val daily = ArrayList<DailyWeather>(dates.length())
        for (i in 0 until dates.length()) {
            daily.add(
                DailyWeather(
                    date = dates.optString(i),
                    code = dailyJson.optJSONArray("weather_code")?.optInt(i, 0) ?: 0,
                    maximum = dailyJson.optJSONArray("temperature_2m_max")?.optDouble(i, 0.0) ?: 0.0,
                    minimum = dailyJson.optJSONArray("temperature_2m_min")?.optDouble(i, 0.0) ?: 0.0,
                    rainProbability = dailyJson.optJSONArray("precipitation_probability_max")?.optInt(i, 0) ?: 0,
                    precipitation = dailyJson.optJSONArray("precipitation_sum")?.optDouble(i, 0.0) ?: 0.0,
                    snowfall = dailyJson.optJSONArray("snowfall_sum")?.optDouble(i, 0.0) ?: 0.0,
                    windMaximum = dailyJson.optJSONArray("wind_speed_10m_max")?.optDouble(i, 0.0) ?: 0.0,
                    gustMaximum = dailyJson.optJSONArray("wind_gusts_10m_max")?.optDouble(i, 0.0) ?: 0.0
                )
            )
        }
        return WeatherData(current, hourly, daily)
    }
}

object WeatherText {
    fun description(code: Int): String = when (code) {
        0 -> "Açıq hava"
        1 -> "Əsasən açıq"
        2 -> "Az buludlu"
        3 -> "Buludlu"
        45, 48 -> "Dumanlı"
        51 -> "Zəif çiskin"
        53 -> "Çiskin"
        55 -> "Güclü çiskin"
        56, 57 -> "Buzlu çiskin"
        61 -> "Zəif yağış"
        63 -> "Yağış"
        65 -> "Güclü yağış"
        66, 67 -> "Buzlu yağış"
        71 -> "Zəif qar"
        73 -> "Qar yağışı"
        75 -> "Güclü qar"
        77 -> "Dənəvər qar"
        80 -> "Zəif leysan"
        81 -> "Leysan"
        82 -> "Güclü leysan"
        85, 86 -> "Qar leysanı"
        95 -> "İldırımlı fırtına"
        96, 99 -> "Dolu ilə fırtına"
        else -> "Dəyişkən hava"
    }

    fun emoji(code: Int): String = when {
        code == 0 -> "☀️"
        code in 1..2 -> "🌤️"
        code == 3 -> "☁️"
        code == 45 || code == 48 -> "🌫️"
        code in 51..67 || code in 80..82 -> "🌧️"
        code in 71..77 || code in 85..86 -> "❄️"
        code in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    fun isRain(code: Int): Boolean = code in 51..67 || code in 80..82
    fun isSnow(code: Int): Boolean = code in 71..77 || code in 85..86
    fun isStorm(code: Int): Boolean = code in 95..99

    fun dayLabel(dateString: String): String {
        return try {
            val date = LocalDate.parse(dateString)
            when (date) {
                LocalDate.now(BAKU_ZONE) -> "Bu gün"
                LocalDate.now(BAKU_ZONE).plusDays(1) -> "Sabah"
                else -> date.format(DateTimeFormatter.ofPattern("EEE, dd.MM", AZ_LOCALE))
                    .replaceFirstChar { if (it.isLowerCase()) it.titlecase(AZ_LOCALE) else it.toString() }
            }
        } catch (_: Exception) {
            dateString
        }
    }

    fun hourLabel(time: String): String = try {
        LocalDateTime.parse(time).format(DateTimeFormatter.ofPattern("HH:mm", AZ_LOCALE))
    } catch (_: Exception) {
        time.takeLast(5)
    }
}

object WeatherLogic {
    fun hoursAhead(time: String): Int {
        return try {
            val target = LocalDateTime.parse(time)
            val mins = Duration.between(LocalDateTime.now(BAKU_ZONE), target).toMinutes()
            ceil(mins.coerceAtLeast(1) / 60.0).toInt().coerceAtLeast(1)
        } catch (_: Exception) {
            1
        }
    }

    fun eventType(point: HourlyWeather): String? {
        return when {
            WeatherText.isStorm(point.code) || point.thunderProbability >= 35 -> "storm"
            WeatherText.isSnow(point.code) || point.snowfall >= 0.1 -> "snow"
            point.wind >= 55.0 || point.gust >= 75.0 -> "wind"
            WeatherText.isRain(point.code) || point.rainProbability >= 60 || point.precipitation >= 0.2 -> "rain"
            else -> null
        }
    }

    fun eventDescription(type: String, point: HourlyWeather): String {
        val hours = hoursAhead(point.time)
        return when (type) {
            "storm" -> "$hours saat sonra ildırımlı fırtına riski var${if (point.thunderProbability > 0) " (${point.thunderProbability}%)" else ""}."
            "snow" -> "$hours saat sonra qar yağışı gözlənilir."
            "wind" -> "$hours saat sonra güclü külək: ${point.wind.roundToInt()} km/saat, külək şiddəti ${point.gust.roundToInt()} km/saat."
            else -> "$hours saat sonra yağış ehtimalı ${point.rainProbability}%."
        }
    }

    fun nextChange(data: WeatherData): String {
        val now = LocalDateTime.now(BAKU_ZONE)
        val candidate = data.hourly.firstOrNull { point ->
            val pointTime = try { LocalDateTime.parse(point.time) } catch (_: Exception) { null }
            pointTime != null && !pointTime.isBefore(now) &&
                Duration.between(now, pointTime).toHours() <= 18 && eventType(point) != null
        }
        if (candidate != null) return eventDescription(eventType(candidate)!!, candidate)

        val change = data.hourly.firstOrNull { point ->
            val pointTime = try { LocalDateTime.parse(point.time) } catch (_: Exception) { null }
            pointTime != null && !pointTime.isBefore(now) &&
                Duration.between(now, pointTime).toHours() <= 6 && point.code != data.current.code
        }
        if (change != null) {
            return "${hoursAhead(change.time)} saat sonra hava: ${WeatherText.description(change.code).lowercase(AZ_LOCALE)}."
        }
        return "Yaxın saatlarda kəskin hava dəyişikliyi görünmür."
    }

    fun hourlyShort(data: WeatherData, count: Int = 6): String {
        val now = LocalDateTime.now(BAKU_ZONE)
        val next = data.hourly.filter {
            try { !LocalDateTime.parse(it.time).isBefore(now) } catch (_: Exception) { false }
        }.take(count)
        if (next.isEmpty()) return "Saatlıq proqnoz mövcud deyil."
        return next.joinToString("  ·  ") { point ->
            val hour = hoursAhead(point.time)
            val type = eventType(point)
            val desc = when (type) {
                "storm" -> "Fırtına"
                "snow" -> "Qar ${point.snowfall.roundToInt()}"
                "wind" -> "Külək ${point.wind.roundToInt()}"
                "rain" -> "Yağış ${point.rainProbability}%"
                else -> "${point.temperature.roundToInt()}° ${WeatherText.description(point.code)}"
            }
            "$hour s: $desc"
        }
    }

    fun currentWarning(current: CurrentWeather): String? = when {
        WeatherText.isStorm(current.code) -> "Hazırda ildırımlı fırtına müşahidə olunur. Açıq ərazilərdə ehtiyatlı olun."
        WeatherText.isSnow(current.code) -> "Hazırda qar yağır. Sürüşkən yollara diqqət edin."
        current.wind >= 55 || current.gust >= 75 -> "Hazırda güclü külək var: ${current.wind.roundToInt()} km/saat."
        WeatherText.isRain(current.code) && current.rain > 0 -> "Hazırda yağış yağır."
        else -> null
    }
}

object WeatherAlerts {
    private const val CHANNEL_ID = "weather_alerts"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hava xəbərdarlıqları",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Bakı üzrə yağış, qar, fırtına və güclü külək xəbərdarlıqları"
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun check(context: Context, data: WeatherData) {
        ensureChannel(context)
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val now = LocalDateTime.now(BAKU_ZONE)
        val currentType = when {
            WeatherText.isStorm(data.current.code) -> "storm"
            WeatherText.isSnow(data.current.code) || data.current.snowfall >= 0.1 -> "snow"
            data.current.wind >= 55.0 || data.current.gust >= 75.0 -> "wind"
            WeatherText.isRain(data.current.code) && data.current.rain > 0.0 -> "rain"
            else -> null
        }
        if (currentType != null) {
            val currentKey = "alert_current_${LocalDate.now(BAKU_ZONE)}_$currentType"
            if (!prefs.getBoolean(currentKey, false)) {
                val message = when (currentType) {
                    "storm" -> "Hazırda Bakıda ildırımlı fırtına müşahidə olunur. Açıq ərazilərdə ehtiyatlı olun."
                    "snow" -> "Hazırda Bakıda qar yağır. Sürüşkən yollara diqqət edin."
                    "wind" -> "Hazırda Bakıda güclü külək var: ${data.current.wind.roundToInt()} km/saat."
                    else -> "Hazırda Bakıda yağış yağır."
                }
                show(context, currentType, message)
                prefs.edit().putBoolean(currentKey, true).apply()
            }
        }

        val future = data.hourly.filter { point ->
            try {
                val dt = LocalDateTime.parse(point.time)
                !dt.isBefore(now) && Duration.between(now, dt).toHours() <= 24
            } catch (_: Exception) { false }
        }
        val sentToday = HashSet<String>()
        val prefs = AppPrefs.get(context)
        for (point in future) {
            val type = WeatherLogic.eventType(point) ?: continue
            val date = try { LocalDateTime.parse(point.time).toLocalDate().toString() } catch (_: Exception) { LocalDate.now(BAKU_ZONE).toString() }
            val key = "alert_${date}_$type"
            if (prefs.getBoolean(key, false) || !sentToday.add(key)) continue
            show(context, type, WeatherLogic.eventDescription(type, point))
            prefs.edit().putBoolean(key, true).apply()
        }
    }

    private fun show(context: Context, type: String, message: String) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val title = when (type) {
            "storm" -> "Bakı: Fırtına xəbərdarlığı"
            "snow" -> "Bakı: Qar xəbərdarlığı"
            "wind" -> "Bakı: Güclü külək xəbərdarlığı"
            else -> "Bakı: Yağış xəbərdarlığı"
        }
        val pending = android.app.PendingIntent.getActivity(
            context, 200, android.content.Intent(context, MainActivity::class.java),
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            Notification.Builder(context).setPriority(Notification.PRIORITY_HIGH)
        }
            .setSmallIcon(R.drawable.ic_weather)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        manager.notify(("weather_$type").hashCode(), notification)
    }
}

class WeatherRefreshWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return try {
            WeatherRepository.fetchAndSave(applicationContext)
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

object WeatherWork {
    fun schedule(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<WeatherRefreshWorker>(30, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "baku_weather_refresh",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    fun refreshNow(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = androidx.work.OneTimeWorkRequestBuilder<WeatherRefreshWorker>()
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueue(request)
    }
}
