package az.mehdi.bakuhavaaddim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import java.time.LocalDate
import kotlin.math.roundToInt

object StepStats {
    data class Snapshot(val steps: Long, val kilometers: Double, val calories: Int, val tracking: Boolean)

    fun snapshot(context: Context): Snapshot {
        val prefs = AppPrefs.get(context)
        val today = LocalDate.now().toString()
        if (prefs.getString("step_date", "") != today) {
            prefs.edit().putString("step_date", today).putLong("today_steps", 0L).apply()
        }
        val steps = prefs.getLong("today_steps", 0L).coerceAtLeast(0L)
        val height = prefs.getInt("height_cm", 180).coerceIn(100, 230)
        val weight = prefs.getInt("weight_kg", 78).coerceIn(25, 250)
        val strideMeters = height * 0.415 / 100.0
        val km = steps * strideMeters / 1000.0
        val calories = (weight * km * 0.5).roundToInt()
        return Snapshot(steps, km, calories, prefs.getBoolean("tracking_enabled", false))
    }

    fun start(context: Context) {
        AppPrefs.get(context).edit().putBoolean("tracking_enabled", true).apply()
        val intent = Intent(context, StepTrackingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
        else context.startService(intent)
    }

    fun stop(context: Context) {
        AppPrefs.get(context).edit().putBoolean("tracking_enabled", false).apply()
        context.startService(Intent(context, StepTrackingService::class.java).setAction(StepTrackingService.ACTION_STOP))
    }
}

class StepTrackingService : Service(), SensorEventListener {
    companion object {
        const val ACTION_STOP = "az.mehdi.bakuhavaaddim.STOP_STEP_TRACKING"
        const val ACTION_STEPS_CHANGED = "az.mehdi.bakuhavaaddim.STEPS_CHANGED"
        private const val CHANNEL_ID = "step_tracking"
        private const val NOTIFICATION_ID = 4102
    }

    private var sensorManager: SensorManager? = null
    private var stepSensor: Sensor? = null
    private var lastWidgetSteps: Long = -1L

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            AppPrefs.get(this).edit().putBoolean("tracking_enabled", false).apply()
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }

        if (stepSensor == null) {
            AppPrefs.get(this).edit().putBoolean("tracking_enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            sensorManager?.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
            broadcastStepsChanged()
        } catch (_: SecurityException) {
            AppPrefs.get(this).edit().putBoolean("tracking_enabled", false).apply()
            stopSelf()
        }
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_STEP_COUNTER || event.values.isEmpty()) return
        val sensorTotal = event.values[0].toLong().coerceAtLeast(0L)
        val prefs = AppPrefs.get(this)
        val today = LocalDate.now().toString()
        val storedDate = prefs.getString("step_date", "")
        var todaySteps = prefs.getLong("today_steps", 0L)
        if (storedDate != today) {
            todaySteps = 0L
            prefs.edit().putString("step_date", today).putLong("today_steps", 0L).apply()
        }

        val lastSensorTotal = prefs.getLong("last_sensor_total", -1L)
        if (lastSensorTotal < 0L || sensorTotal < lastSensorTotal) {
            // İlk aktivasiya və ya telefon yenidən başladıqdan sonra sensor sıfırlanıb.
            prefs.edit().putLong("last_sensor_total", sensorTotal).apply()
        } else if (sensorTotal > lastSensorTotal) {
            todaySteps += sensorTotal - lastSensorTotal
            prefs.edit()
                .putLong("last_sensor_total", sensorTotal)
                .putLong("today_steps", todaySteps)
                .apply()
        }

        val current = StepStats.snapshot(this)
        if (current.steps != lastWidgetSteps && (current.steps % 5L == 0L || lastWidgetSteps < 0L)) {
            lastWidgetSteps = current.steps
            val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (notificationsAllowed) {
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(NOTIFICATION_ID, buildNotification())
            }
            WeatherWidgetProvider.updateAll(this)
            broadcastStepsChanged()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        sensorManager?.unregisterListener(this)
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Addımölçən izləməsi",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Addım sayını və məsafəni arxa fonda izləyir" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stats = StepStats.snapshot(this)
        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 4102, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = "${stats.steps} addım · ${"%.2f".format(stats.kilometers)} km"
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this).setPriority(Notification.PRIORITY_LOW)
        }
        return builder
            .setSmallIcon(R.drawable.ic_weather)
            .setContentTitle("Addımölçən aktivdir")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pending)
            .build()
    }

    private fun broadcastStepsChanged() {
        sendBroadcast(Intent(ACTION_STEPS_CHANGED).setPackage(packageName))
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = AppPrefs.get(context)
        if (!prefs.getBoolean("tracking_enabled", false)) return
        if (Build.VERSION.SDK_INT >= 29 &&
            context.checkSelfPermission(android.Manifest.permission.ACTIVITY_RECOGNITION) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val serviceIntent = Intent(context, StepTrackingService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent)
            else context.startService(serviceIntent)
        } catch (_: Exception) {
            // Bəzi istehsalçıların enerji siyasəti açılışdan sonra xidməti gecikdirə bilər.
        }
    }
}
