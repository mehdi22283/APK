package az.mehdi.bakuhavaaddim

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var currentTitle: TextView
    private lateinit var currentDetails: TextView
    private lateinit var currentWarning: TextView
    private lateinit var nextChange: TextView
    private lateinit var hourlyContainer: LinearLayout
    private lateinit var dailyContainer: LinearLayout
    private lateinit var stepSummary: TextView
    private lateinit var stepStatus: TextView
    private lateinit var bodyHeight: EditText
    private lateinit var bodyWeight: EditText
    private lateinit var refreshButton: Button
    private lateinit var stepButton: Button
    private var pendingStartSteps = false
    private var receiverRegistered = false

    private val stepReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            renderSteps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 18, 32)
        window.navigationBarColor = android.graphics.Color.rgb(11, 18, 32)
        setContentView(createScreen())

        WeatherAlerts.ensureChannel(this)
        createStepChannel()
        WeatherWork.schedule(this)
        registerStepReceiver()

        renderWeather(WeatherRepository.cached(this))
        renderSteps()
        refreshWeather(showToast = false)
        askNotificationPermissionOnce()
    }

    override fun onResume() {
        super.onResume()
        renderSteps()
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(stepReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        executor.shutdown()
        super.onDestroy()
    }

    private fun createScreen(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(color("#0B1220"))
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(26))
        }
        scroll.addView(content)

        content.addView(text("BAKI HAVA + ADDIM", 23f, "#F4F7FB", true))
        content.addView(text("7 günlük proqnoz · Saatlıq dəyişiklik · Addımölçən", 12f, "#A9B8CC", false).apply {
            setPadding(0, dp(4), 0, dp(12))
        })

        refreshButton = actionButton("Hava məlumatını yenilə") {
            refreshWeather(showToast = true)
        }
        content.addView(refreshButton, matchWrap())

        val weatherCard = card()
        weatherCard.addView(sectionHeading("İNDİ · BAKI"))
        currentTitle = text("Hava məlumatı yüklənir...", 25f, "#F4F7FB", true)
        weatherCard.addView(currentTitle)
        currentDetails = text("", 13f, "#C2D1E1", false).apply { setPadding(0, dp(5), 0, 0) }
        weatherCard.addView(currentDetails)
        currentWarning = text("", 12f, "#FFE08A", true).apply {
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = rounded("#3A3322", 10)
            visibility = View.GONE
        }
        val warningParams = matchWrap().apply { topMargin = dp(10) }
        weatherCard.addView(currentWarning, warningParams)
        nextChange = text("Növbəti saatların proqnozu gözlənilir...", 13f, "#FFE08A", true).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded("#1B3854", 10)
        }
        val nextParams = matchWrap().apply { topMargin = dp(10) }
        weatherCard.addView(nextChange, nextParams)
        content.addView(weatherCard, matchWrap().apply { topMargin = dp(14) })

        val hourlyCard = card()
        hourlyCard.addView(sectionHeading("YAXIN 24 SAAT · SAATLIQ DƏYİŞİKLİK"))
        hourlyContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hourlyCard.addView(hourlyContainer)
        content.addView(hourlyCard, matchWrap().apply { topMargin = dp(12) })

        val dailyCard = card()
        dailyCard.addView(sectionHeading("7 GÜNLÜK HAVA PROQNOZU"))
        dailyCard.addView(text("Hər gün üçün yağış ehtimalı, temperatur və maksimum külək", 11f, "#A9B8CC", false).apply {
            setPadding(0, 0, 0, dp(8))
        })
        dailyContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dailyCard.addView(dailyContainer)
        content.addView(dailyCard, matchWrap().apply { topMargin = dp(12) })

        val stepCard = card()
        stepCard.addView(sectionHeading("ADDIMÖLÇƏN"))
        stepSummary = text("0 addım", 24f, "#F4F7FB", true)
        stepCard.addView(stepSummary)
        stepStatus = text("Gündəlik məsafə və təxmini kalori", 12f, "#A9B8CC", false).apply {
            setPadding(0, dp(4), 0, dp(12))
        }
        stepCard.addView(stepStatus)

        val bodyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bodyHeight = numericInput("Boy (sm)")
        bodyWeight = numericInput("Çəki (kq)")
        bodyHeight.setText(AppPrefs.get(this).getInt("height_cm", 180).toString())
        bodyWeight.setText(AppPrefs.get(this).getInt("weight_kg", 78).toString())
        bodyRow.addView(bodyHeight, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        bodyRow.addView(bodyWeight, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        stepCard.addView(bodyRow)
        val saveBody = actionButton("Boy və çəkini yadda saxla") { saveBodySettings() }
        stepCard.addView(saveBody, matchWrap().apply { topMargin = dp(8) })

        stepButton = actionButton("Addımölçəni aktiv et") { toggleStepTracking() }
        stepCard.addView(stepButton, matchWrap().apply { topMargin = dp(8) })
        val notificationSettings = actionButton("Hava bildirişlərinin icazəsi") { openNotificationSettings() }
        stepCard.addView(notificationSettings, matchWrap().apply { topMargin = dp(8) })
        content.addView(stepCard, matchWrap().apply { topMargin = dp(12) })

        val attribution = text(
            "Weather data by Open-Meteo.com · Külək km/saatla. Addım məsafəsi və kalori təxminidir.",
            10f, "#8296AE", false
        ).apply {
            setPadding(dp(3), dp(12), dp(3), 0)
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://open-meteo.com/"))) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "open-meteo.com", Toast.LENGTH_SHORT).show() }
            }
        }
        content.addView(attribution)

        return scroll
    }

    private fun renderWeather(data: WeatherData?) {
        if (data == null) {
            currentTitle.text = "Hava məlumatı hələ yoxdur"
            currentDetails.text = "İnternetə qoşulub yeniləmə düyməsinə toxunun."
            nextChange.text = "Saatlıq və 7 günlük proqnoz yüklənəcək."
            hourlyContainer.removeAllViews()
            dailyContainer.removeAllViews()
            hourlyContainer.addView(text("Proqnoz gözlənilir...", 12f, "#A9B8CC", false))
            dailyContainer.addView(text("Proqnoz gözlənilir...", 12f, "#A9B8CC", false))
            return
        }

        val now = data.current
        currentTitle.text = "${now.temperature.roundToInt()}°  ${WeatherText.emoji(now.code)} ${WeatherText.description(now.code)}"
        currentDetails.text = "Hiss olunan ${now.feelsLike.roundToInt()}°  ·  Rütubət ${now.humidity}%\n" +
            "Külək ${now.wind.roundToInt()} km/saat  ·  Şiddət ${now.gust.roundToInt()} km/saat  ·  Bulud ${now.cloud}%"
        val activeWarning = WeatherLogic.currentWarning(now)
        if (activeWarning.isNullOrBlank()) {
            currentWarning.visibility = View.GONE
        } else {
            currentWarning.visibility = View.VISIBLE
            currentWarning.text = "⚠ $activeWarning"
        }
        nextChange.text = "YAXIN DƏYİŞİKLİK\n${WeatherLogic.nextChange(data)}\n\n${WeatherLogic.hourlyShort(data, 6)}"

        hourlyContainer.removeAllViews()
        val future = data.hourly.filter {
            try { !LocalDateTime.parse(it.time).isBefore(LocalDateTime.now(ZoneId.of("Asia/Baku"))) }
            catch (_: Exception) { false }
        }.take(24)
        if (future.isEmpty()) {
            hourlyContainer.addView(text("Saatlıq proqnoz mövcud deyil.", 12f, "#A9B8CC", false))
        } else {
            future.forEachIndexed { index, point ->
                val event = WeatherLogic.eventType(point)
                val detail = when (event) {
                    "storm" -> "⛈ Fırtına · ildırım ${point.thunderProbability}%"
                    "snow" -> "❄ Qar · ${point.snowfall} sm"
                    "wind" -> "💨 Güclü külək · ${point.wind.roundToInt()} km/s"
                    "rain" -> "🌧 Yağış ehtimalı ${point.rainProbability}%"
                    else -> "${WeatherText.emoji(point.code)} ${WeatherText.description(point.code)} · Yağış ${point.rainProbability}%"
                }
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                line.addView(text(WeatherText.hourLabel(point.time), 12f, "#65C8F2", true),
                    LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.WRAP_CONTENT))
                val info = text(
                    "${point.temperature.roundToInt()}°  $detail",
                    11f,
                    if (event != null) "#FFE08A" else "#D5E3F1",
                    event != null
                )
                line.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                hourlyContainer.addView(line)
                if (index != future.lastIndex) hourlyContainer.addView(divider())
            }
        }

        dailyContainer.removeAllViews()
        data.daily.take(7).forEachIndexed { index, day ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            top.addView(text(WeatherText.dayLabel(day.date), 13f, "#F4F7FB", true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(text("${WeatherText.emoji(day.code)} ${WeatherText.description(day.code)}", 11f, "#D5E3F1", false))
            row.addView(top)
            row.addView(text(
                "${day.minimum.roundToInt()}° – ${day.maximum.roundToInt()}°   ·   Yağış: ${day.rainProbability}%   ·   Külək: ${day.windMaximum.roundToInt()} km/saat" +
                    if (day.snowfall > 0.0) "   ·   Qar: ${day.snowfall} sm" else "",
                11f, "#A9B8CC", false
            ).apply { setPadding(0, dp(5), 0, 0) })
            dailyContainer.addView(row)
            if (index != data.daily.take(7).lastIndex) dailyContainer.addView(divider())
        }
    }

    private fun renderSteps() {
        if (!::stepSummary.isInitialized) return
        val stats = StepStats.snapshot(this)
        stepSummary.text = "${String.format(Locale.US, "%,d", stats.steps)} addım"
        stepStatus.text = "${String.format(Locale.US, "%.2f", stats.kilometers)} km  ·  Təxminən ${stats.calories} kkal\n" +
            "Boy: ${AppPrefs.get(this).getInt("height_cm", 180)} sm  ·  Çəki: ${AppPrefs.get(this).getInt("weight_kg", 78)} kq"
        stepButton.text = if (stats.tracking) "Addımölçəni dayandır" else "Addımölçəni aktiv et"
    }

    private fun refreshWeather(showToast: Boolean) {
        refreshButton.isEnabled = false
        refreshButton.text = "Yenilənir..."
        executor.execute {
            try {
                val data = WeatherRepository.fetchAndSave(this)
                mainHandler.post {
                    renderWeather(data)
                    refreshButton.isEnabled = true
                    refreshButton.text = "Hava məlumatını yenilə"
                    renderSteps()
                    if (showToast) Toast.makeText(this, "Bakı hava məlumatı yeniləndi", Toast.LENGTH_SHORT).show()
                }
            } catch (error: Exception) {
                mainHandler.post {
                    refreshButton.isEnabled = true
                    refreshButton.text = "Yenidən cəhd et"
                    if (showToast) Toast.makeText(this, "Yenilənmə alınmadı: ${error.localizedMessage ?: "internet xətası"}", Toast.LENGTH_LONG).show()
                    if (WeatherRepository.cached(this) == null) {
                        currentDetails.text = "İnternet bağlantısını yoxlayın və yenidən cəhd edin."
                    }
                }
            }
        }
    }

    private fun toggleStepTracking() {
        val stats = StepStats.snapshot(this)
        if (stats.tracking) {
            StepStats.stop(this)
            renderSteps()
            WeatherWidgetProvider.updateAll(this)
            return
        }

        val sensorManager = getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
        if (sensorManager.getDefaultSensor(android.hardware.Sensor.TYPE_STEP_COUNTER) == null) {
            Toast.makeText(this, "Bu telefonda hardware addım sensoru tapılmadı.", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            pendingStartSteps = true
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 102)
            return
        }
        startStepTracking()
    }

    private fun startStepTracking() {
        try {
            StepStats.start(this)
            renderSteps()
            Toast.makeText(this, "Addımölçən aktiv edildi. İlk sayım sensor məlumatı gələndən sonra başlayacaq.", Toast.LENGTH_LONG).show()
        } catch (error: Exception) {
            AppPrefs.get(this).edit().putBoolean("tracking_enabled", false).apply()
            Toast.makeText(this, "Addımölçən başlatmaq olmadı: ${error.localizedMessage}", Toast.LENGTH_LONG).show()
            renderSteps()
        }
    }

    private fun saveBodySettings() {
        val height = bodyHeight.text.toString().toIntOrNull()
        val weight = bodyWeight.text.toString().toIntOrNull()
        if (height == null || height !in 100..230 || weight == null || weight !in 25..250) {
            Toast.makeText(this, "Boy 100–230 sm, çəki 25–250 kq aralığında olmalıdır.", Toast.LENGTH_LONG).show()
            return
        }
        AppPrefs.get(this).edit().putInt("height_cm", height).putInt("weight_kg", weight).apply()
        renderSteps()
        WeatherWidgetProvider.updateAll(this)
        Toast.makeText(this, "Boy və çəki yadda saxlanıldı", Toast.LENGTH_SHORT).show()
    }

    private fun askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        val prefs = AppPrefs.get(this)
        if (!prefs.getBoolean("asked_notification", false) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            prefs.edit().putBoolean("asked_notification", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun openNotificationSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= 26) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Telefon parametrlərində tətbiqin bildirişlərini aktiv edin.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android API, kept for compatibility with minSdk 23")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            101 -> {
                if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                    WeatherRepository.cached(this)?.let { WeatherAlerts.check(this, it) }
                } else {
                    Toast.makeText(this, "Hava xəbərdarlıqları üçün bildiriş icazəsini Parametrlərdən aça bilərsiniz.", Toast.LENGTH_LONG).show()
                }
            }
            102 -> {
                if (pendingStartSteps && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startStepTracking()
                else Toast.makeText(this, "Addımölçən üçün fiziki aktivlik icazəsi lazımdır.", Toast.LENGTH_LONG).show()
                pendingStartSteps = false
            }
        }
    }

    private fun registerStepReceiver() {
        val filter = IntentFilter(StepTrackingService.ACTION_STEPS_CHANGED)
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(stepReceiver, filter, RECEIVER_NOT_EXPORTED)
            else registerReceiver(stepReceiver, filter)
            receiverRegistered = true
        } catch (_: Exception) {
            receiverRegistered = false
        }
    }

    private fun createStepChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = android.app.NotificationChannel(
                "step_tracking", "Addımölçən izləməsi", android.app.NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun numericInput(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        textSize = 14f
        setTextColor(color("#F4F7FB"))
        setHintTextColor(color("#879CB5"))
        setPadding(dp(12), 0, dp(12), 0)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        background = rounded("#1B2D46", 10)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded("#142238", 18)
    }

    private fun sectionHeading(value: String): TextView = text(value, 12f, "#65C8F2", true).apply {
        setPadding(0, 0, 0, dp(10))
    }

    private fun text(value: String, size: Float, hex: String, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color(hex))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(color("#071421"))
        isAllCaps = false
        background = rounded("#65C8F2", 12)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(color("#2B4665"))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    }

    private fun rounded(hex: String, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color(hex))
        cornerRadius = dp(radius).toFloat()
    }

    private fun color(hex: String): Int = android.graphics.Color.parseColor(hex)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
