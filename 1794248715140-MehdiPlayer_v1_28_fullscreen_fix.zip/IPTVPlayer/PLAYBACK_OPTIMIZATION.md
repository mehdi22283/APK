# Oynatma konfiqurasiyası (2 GB RAM TV box) — v1.25, Media3 → mpv

## Açılış ardıcıllığı
Əvvəl serverə sorğu göndərilir (5 s); xəta cavabı (404/403/5xx, qoşulmur) alınarsa pleyerlər yoxlanmır. Ehtiyat (yoda.az tokenli) linkdə sorğu göndərilmir.

| Vəziyyət | Ardıcıllıq |
|---|---|
| Yeni kanal (http/https) | **Media3 × 1 cəhd (5 s)** → uğursuz olarsa mpv × 3 cəhd (hər biri 5 s) |
| **Codec/format dəstəklənmir** | **gözləmədən dərhal mpv** (Media3-ün 5 s-i gözlənmir) |
| rtsp / rtmp / udp / srt və s. | birbaşa mpv |
| İşləyən kanal qırılıb/donub | işləyən mühərriklə 2 cəhd (dərhal); Media3 açmasa mpv |
| Hamısı açmasa | ehtiyat link (yoda.az) və ya "Kanal İşləmir" |
| Əvvəl işləmiş kanal, hamısı açmasa | xəta göstərilmir, hər 2 s-dən bir avtomatik təkrar yoxlanılır |

Codec dəstəklənmir sayılan hallar (`Media3Engine`): video və ya səs qrupunda dekodlana bilən trek yoxdur (`onTracksChanged`);
`DECODER_INIT_FAILED`, `DECODER_QUERY_FAILED`, `DECODING_FAILED`, `DECODING_FORMAT_EXCEEDS_CAPABILITIES`, `DECODING_FORMAT_UNSUPPORTED`,
`AUDIO_TRACK_INIT_FAILED`, `PARSING_CONTAINER_MALFORMED/UNSUPPORTED`, `PARSING_MANIFEST_UNSUPPORTED`. Yayım ortasında də eyni xətalar mpv-yə keçirir.

Video səthini eyni anda yalnız bir mühərrik tutur: Media3-ə keçəndə mpv səthi buraxır (`releaseSurface`), mpv-yə keçəndə Media3 dekoderi/səthi azad edilir.

## Media3 codec-ləri
- **Mühərrik:** `NextRenderersFactory` (`io.github.anilbeesetti:nextlib-media3ext`), `EXTENSION_RENDERER_MODE_ON`: əvvəl cihazın MediaCodec-i, açılmasa FFmpeg proqram dekoderi.
- **Video:** MediaCodec (H.264, HEVC, VP9, AV1, MPEG-2 ... cihazdan asılı) + FFmpeg: H.264, HEVC, VP8, VP9. Bunlarda da olmayan codec (AV1, MPEG-2 və s.) → dərhal mpv.
- **Səs:** MediaCodec + FFmpeg: Vorbis, Opus, FLAC, ALAC, MP3, AAC, AC3, E-AC3, DTS, MLP, TrueHD, AMR, PCM a/mu-law.
- **MPEG-TS:** `FLAG_DETECT_ACCESS_UNITS`, `FLAG_ALLOW_NON_IDR_KEYFRAMES`, `FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS` (HLS və düz .ts).

## Kanal üzrə pleyer yaddaşı (`PlayerMemory`)
Kanal hansı pleyerlə oynayıbsa (link → Media3/mpv) `player_memory_v4`-də saxlanır. mpv ilə açılmış kanal növbəti dəfə Media3-ü atlayıb birbaşa mpv ilə başlayır. Hər iki qeyd daimidir (müddəti yoxdur); kanal digər pleyerlə uğurla oynayanda qeyd yenilənir. Ehtiyat (yoda.az) linkləri saxlanmır.

Sabitlər: `Engines.kt` → `PlayerManager` (`EXO_TIMEOUT_MS`, `MPV_TIMEOUT_MS`, `NEW_ATTEMPTS`, `RECOVER_ATTEMPTS`).
Pleyer işarəsi: 💙 = Media3, 💜 = mpv, 🧡 = VLC (üçüncü ehtiyat: mpv bitəndən sonra 1 cəhd, `VLC_ATTEMPTS`; hər pleyerdə 1 cəhd, `VLC_TIMEOUT_MS` = 6 s).

## mpv seçimləri (`MpvEngine.initMpv`)
- **Video:** `vo=gpu`, `gpu-context=android`, `opengl-es=yes`, `profile=fast`, `keepaspect=no` (həmişə stretch — ekranı tam doldurur).
- **Dekoder:** `hwdec=mediacodec,mediacodec-copy` (`hwdec-codecs=h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1`); açılmasa proqram (FFmpeg) dekoderi; `vd-lavc-threads` ən çox 4.
- **Səs:** `ao=audiotrack,opensles`.
- **Bufer:** `cache=yes`, `cache-secs=20`, `demuxer-readahead-secs=20`, `demuxer-max-bytes=24 MB`, `demuxer-max-back-bytes=4 MB`, `cache-pause=yes`, `cache-pause-wait=2.5`.
- **Şəbəkə:** `network-timeout=8`, `tls-verify=no` (vaxtı keçmiş/özü imzalı sertifikatlı IPTV serverləri üçün), `stream-lavf-o=reconnect=1,reconnect_streamed=1,reconnect_delay_max=2`.
- **User-Agent:** standart `VLC/3.0.20 LibVLC/3.0.20`; kanalın öz User-Agent və Referer-i varsa o işlədilir (`user-agent`, `referrer`).
- **Digər:** altyazı söndürülüb (`sid=no`, `sub-auto=no`), `ytdl=no`, `idle=yes`.

## Hadisələr və vəziyyət
- "Oynayır" = `START_FILE` + `PLAYBACK_RESTART` hadisələri gəlib və `core-idle=false`.
- Bufer göstəricisi: `paused-for-cache`.
- Yayım bitdi/açılmadı: `idle-active=true` (yalnız həmin kanalın `START_FILE`-ından sonra).
- Ölçü: `video-params/w`, `video-params/h`; bufer: `demuxer-cache-duration`; bitrate: `video-bitrate` + `audio-bitrate`; mövqe: `time-pos`.
- Əsas thread mpv-dən property oxumur, hamısı `observeProperty` ilə keşlənir.

## Avtomatik bərpa (davamlı izləmə)
- Yayım işləyərkən qırılsa (xəta, yayım bitdi) kanal gözləmədən (0 s) yenidən qoşulur.
- Bufer 5 s dolmursa və ya mövqe (`time-pos`) 5 s dəyişmirsə yenidən qoşulur; "oynayır" deyir, amma vaxt 10 s gəlmirsə də yenilənir.
- Watchdog hər 1 s yoxlayır; istifadəçi pauza edibsə bərpa işləmir.
- Əvvəl işləmiş kanalın bərpasında yükləmə paneli dərhal çıxmır (son kadr ekranda qalır); yalnız 3.5 s-dən uzun çəkərsə görünür.

## Yaddaş (2 GB RAM)
- `largeHeap=true`, ABI yalnız `armeabi-v7a`.
- Bir video səthi (`mpvView`).
- **Loqo keşi:** bitmap keşi 3–8 MB, eyni anda 2 dekod / 2 endirmə. `onTrimMemory ≥ 10`-da loqo keşi təmizlənir.
- **EPG:** proqram təsviri 160 simvol.
- **Ehtiyat link WebView:** yalnız lazım olanda yaradılır, şəkil yükləmə söndürülüb, iş bitəndə silinir.

## Stabillik qeydləri
- `loadfile` / `stop` / `pause` tək `mpv-ctl` thread-ində; köhnəlmiş əmrlər generation ilə atlanır.
- Video səthi hazır olmadan `loadfile` verilmir; səth `surfaceChanged`-dən sonra hazır sayılır. Fona keçəndə `vo=null` + `detachSurface`, qayıdanda `attachSurface` + `vo=gpu`.
- **yoda.az WebView:** `onRenderProcessGone` ilə render prosesi ölərsə tətbiq çökmür.
- **İlkin server sorğusu:** gözlənilməz xəta nəticəsiz sayılır, mpv yoxlayır; kanal dəyişəndə köhnə sorğunun nəticəsi ignor edilir.
- **Təhlükəsizlik toru (`App.kt`):** tutulmayan Java/Kotlin xətasında tətbiq yenidən açılır (15 s-də təkrar çökərsə açılmır). Native çökmələr bununla tutulmur.

## Stream linkləri
http/https (m3u8, ts, mp4, mpd və genişlənməsiz linklər), rtsp, rtmp, udp, srt və s. — mpv (FFmpeg) bütün bu protokolları özü açır.

## Playlist linki dəyişəndə
İzlənən kanalın linki yeni playlistdə dəyişibsə, kanal yeni linklə avtomatik yenidən açılır. Son kanal link, ad, qrup və tvg-id ilə saxlanılır.

## Pleyer işarəsi
EPG-nin sağında üstdə 💜 (mpv), yanında ölçü, altında bufer (🟢🟡🔴) • endirmə sürəti • bitrate yazılır.
