package az.mehdi.iptvplayer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * Üçüncü (son ehtiyat) mühərrik: VLC (libVLC). Media3 və mpv açmayanda növbə buna çatır.
 *
 * Qaydalar:
 *  1) LibVLC və MediaPlayer ilk istifadədə (lazy) yaradılır: Media3/mpv ilə işləyən kanallarda RAM tutulmur.
 *  2) Video səthi eyni anda yalnız bir mühərrikdədir: VLC səthi YALNIZ özü oynayanda qoşur ([attach]),
 *     başqa mühərrikə keçəndə [releaseSurface] ilə ayırır.
 *  3) Hadisələr (libVLC thread-i) UI thread-inə ötürülür; köhnəlmiş hadisələr "generation" ilə ignor edilir.
 *  4) Video həmişə ekranı tam doldurur (SURFACE_FILL = stretch).
 *  5) Ağır native boşaltma (release) ayrıca thread-də gedir, UI bloklanmır.
 */
class VlcEngine(
    context: Context,
    private val view: SurfaceView,
    private val callback: PlayerCallback
) {
    companion object {
        private const val TAG = "IPTV-VLC"
        private const val DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"
        // 2 GB RAM: kiçik bufer (ms). Canlı yayım üçün 2.5 s kifayətdir.
        private const val NETWORK_CACHING_MS = 2_500
    }

    private val appContext = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())
    private val workerThread = HandlerThread("vlc-ctl").apply { start() }
    private val worker = Handler(workerThread.looper)

    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var attached = false
    private var released = false
    private var generation = 0
    private var url: String? = null
    private var timeoutMs = 5_000L
    private var openTimeout: Runnable? = null
    private var playing = false
    private var buffering = false
    private var lastBufferingAt = 0L
    private var pausedByUser = false
    private var voutCount = 0
    private var sawPlaying = false
    private var lastTime = -1L
    private val speed = SpeedMeter()

    private val holderCb = object : SurfaceHolder.Callback {
        override fun surfaceCreated(holder: SurfaceHolder) {}
        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            if (attached) runCatching { player?.vlcVout?.setWindowSize(width, height) }
        }
        override fun surfaceDestroyed(holder: SurfaceHolder) { releaseSurface() }
    }

    init { view.holder.addCallback(holderCb) }

    // ---------- yaradılma ----------
    private fun ensurePlayer(): MediaPlayer? {
        player?.let { return it }
        if (released) return null
        return try {
            val opts = arrayListOf(
                "--network-caching=$NETWORK_CACHING_MS",
                "--live-caching=$NETWORK_CACHING_MS",
                "--http-reconnect",
                "--no-sub-autodetect-file",
                "--no-osd",
                "--no-stats",
                "--drop-late-frames",
                "--skip-frames",
                "--audio-time-stretch"
            )
            val lib = LibVLC(appContext, opts)
            val mp = MediaPlayer(lib)
            mp.setEventListener { ev -> onVlcEvent(ev) }
            libVlc = lib
            player = mp
            mp
        } catch (t: Throwable) {
            Log.e(TAG, "VLC başladılmadı", t)
            null
        }
    }

    // ---------- səth ----------
    private fun attach(mp: MediaPlayer): Boolean {
        if (attached) return true
        return runCatching {
            val vout = mp.vlcVout
            vout.setVideoView(view)
            if (view.width > 0 && view.height > 0) vout.setWindowSize(view.width, view.height)
            vout.attachViews()
            mp.videoScale = MediaPlayer.ScaleType.SURFACE_FILL
            attached = true
        }.onFailure { Log.e(TAG, "VLC video səthi qoşula bilmədi", it) }.isSuccess
    }

    /** Səthi VLC-dən ayırır (Media3/mpv götürməzdən əvvəl; fona keçəndə). Əsas thread-də. */
    fun releaseSurface() {
        stop()
        if (!attached) return
        attached = false
        val mp = player ?: return
        runCatching { mp.vlcVout.detachViews() }
    }

    // ---------- hadisələr (UI thread-ə ötürülür) ----------
    private fun onVlcEvent(ev: MediaPlayer.Event) {
        val g = generation
        val type = ev.type
        val buf = ev.buffering
        val vout = ev.voutCount
        val time = ev.timeChanged
        ui.post {
            if (released || g != generation || url == null) return@post
            when (type) {
                MediaPlayer.Event.Playing -> { sawPlaying = true; pausedByUser = false }
                MediaPlayer.Event.Vout -> { voutCount = vout.toInt(); if (voutCount > 0) markPlaying() }
                MediaPlayer.Event.TimeChanged -> {
                    lastTime = time
                    // Yalnız səsli kanallarda (radio) Vout gəlmir: vaxt irəliləyirsə oynayır sayılır.
                    if (time > 0 && sawPlaying) markPlaying()
                }
                MediaPlayer.Event.Buffering -> {
                    if (!playing) return@post
                    val active = buf < 100f
                    if (active == buffering) return@post
                    buffering = active
                    if (active) lastBufferingAt = SystemClock.elapsedRealtime()
                    callback.onBuffering(active)
                }
                MediaPlayer.Event.EncounteredError -> failNow(g, "VLC yayımı aça bilmədi")
                MediaPlayer.Event.EndReached -> failNow(g, if (playing) "Yayım bitdi" else "VLC yayımı aça bilmədi")
            }
        }
    }

    private fun markPlaying() {
        if (playing || url == null) return
        playing = true
        cancelTimeout()
        callback.onPlaying()
    }

    private fun failNow(g: Int, message: String) {
        if (released || g != generation || url == null) return
        playing = false
        cancelTimeout()
        callback.onFailed(message)
    }

    private fun cancelTimeout() {
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
    }

    private fun armTimeout(g: Int) {
        cancelTimeout()
        val r = Runnable {
            openTimeout = null
            if (released || g != generation || url == null || playing) return@Runnable
            failNow(g, "VLC ${timeoutMs / 1000} saniyədə açmadı")
        }
        openTimeout = r
        ui.postDelayed(r, timeoutMs)
    }

    // ---------- oynatma ----------
    fun play(newUrl: String, ua: String?, ref: String?, timeoutMs: Long) {
        if (released) return
        val g = ++generation
        cancelTimeout()
        url = newUrl
        this.timeoutMs = timeoutMs
        playing = false
        buffering = false
        pausedByUser = false
        sawPlaying = false
        voutCount = 0
        lastTime = -1L
        speed.reset()
        val mp = ensurePlayer()
        if (mp == null) { failNow(g, "VLC işə düşmədi"); return }
        if (!attach(mp)) { failNow(g, "VLC video səthi qoşula bilmədi"); return }
        armTimeout(g)
        try {
            val lib = libVlc ?: run { failNow(g, "VLC işə düşmədi"); return }
            val media = Media(lib, Uri.parse(newUrl))
            // Əvvəl cihazın MediaCodec-i, açılmasa VLC özü proqram dekoderinə keçir (force=false).
            media.setHWDecoderEnabled(true, false)
            media.addOption(":network-caching=$NETWORK_CACHING_MS")
            media.addOption(":http-user-agent=" + (ua?.takeIf { it.isNotBlank() } ?: DEFAULT_UA))
            ref?.takeIf { it.isNotBlank() }?.let { media.addOption(":http-referrer=$it") }
            mp.media = media
            media.release()
            mp.play()
        } catch (t: Throwable) {
            Log.e(TAG, "Yayım açıla bilmədi", t)
            failNow(g, "VLC yayımı aça bilmədi")
        }
    }

    fun stop() {
        generation++
        cancelTimeout()
        url = null
        playing = false
        buffering = false
        pausedByUser = false
        val mp = player ?: return
        runCatching { mp.stop() }
    }

    fun stopForBackground() = releaseSurface()

    fun togglePause() {
        val mp = player ?: return
        if (released || !playing) return
        pausedByUser = !pausedByUser
        runCatching { if (pausedByUser) mp.pause() else mp.play() }
    }

    /** Oynatma mövqeyi (ms); yayım donanda dəyişmir. Naməlum: -1. */
    fun position(): Long {
        val mp = player ?: return -1L
        if (released || !playing) return -1L
        val t = runCatching { mp.time }.getOrDefault(-1L)
        return if (t < 0) -1L else t
    }

    fun stats(): PlayerStats? {
        val mp = player ?: return null
        if (released || !playing) return null
        val now = SystemClock.elapsedRealtime()
        val level = when {
            buffering -> 2
            now - lastBufferingAt < 12_000L -> 1
            else -> 0
        }
        val bps = speed.sample(uidRxBytes(), now)
        var w = 0; var h = 0
        runCatching {
            val vt = mp.currentVideoTrack
            if (vt != null) { w = vt.width; h = vt.height }
        }
        return PlayerStats(w, h, -1L, level, bps, "", bps)
    }

    fun release() {
        if (released) return
        released = true
        generation++
        cancelTimeout()
        url = null
        runCatching { view.holder.removeCallback(holderCb) }
        val mp = player
        val lib = libVlc
        player = null
        libVlc = null
        if (mp != null || lib != null) {
            // Native boşaltma ayrıca thread-də: əsas thread bloklanmır.
            worker.post {
                runCatching { mp?.setEventListener(null) }
                runCatching { mp?.stop() }
                runCatching { mp?.vlcVout?.detachViews() }
                runCatching { mp?.release() }
                runCatching { lib?.release() }
                workerThread.quitSafely()
            }
        } else {
            workerThread.quitSafely()
        }
    }
}
