package az.mehdi.iptvplayer

import android.content.Context
import java.security.MessageDigest

/**
 * Kanalın hansı pleyerlə uğurla açıldığını yadda saxlayır (kanal linki → Media3 / mpv / VLC).
 * Növbəti açılışda birbaşa o pleyerlə başlanır: mpv-yə keçən kanallarda Media3-ün cəhdi (5 s) itirilmir.
 *
 * - "e" = Media3 açıb, "m" = mpv açıb, "v" = VLC açıb. Hər iki qeyd daimidir (müddəti yoxdur).
 *   Kanal sonradan digər pleyerlə uğurla oynayanda qeyd yenilənir (məs. mpv-də qalan kanalın qeydi dəyişmir,
 *   çünki Media3 heç yoxlanmır; Media3 qeydli kanal mpv-yə düşüb orada oynasa qeyd "m" olur).
 *   Köhnə "m:<vaxt>" formatı da mpv sayılır.
 * Yalnız UI thread-i. Açar linkin qısa MD5-idir; ehtiyat (yoda.az tokenli) linklər saxlanmır.
 */
class PlayerMemory(context: Context) {
    private companion object {
        const val PREFS = "player_memory_v4"
        const val MAX_ENTRIES = 4_000
    }

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val cache = HashMap<String, String>()

    init {
        runCatching {
            for ((k, v) in prefs.all) if (v is String) cache[k] = v
            if (cache.size > MAX_ENTRIES) { cache.clear(); prefs.edit().clear().apply() }
        }
    }

    private fun key(url: String): String {
        val d = MessageDigest.getInstance("MD5").digest(url.trim().toByteArray())
        val sb = StringBuilder(16)
        for (i in 0 until 8) sb.append(String.format("%02x", d[i]))
        return sb.toString()
    }

    /** Kanalın son uğurlu pleyeri: 'e' = Media3, 'm' = mpv, 'v' = VLC; qeyd yoxdursa null (qeyd daimidir). */
    fun preferred(url: String): Char? = cache[key(url)]?.firstOrNull()?.takeIf { it == 'e' || it == 'm' || it == 'v' }

    /** Kanal bu pleyerlə uğurla oynadı ('e' / 'm' / 'v'). */
    fun remember(url: String, code: Char) {
        val k = key(url)
        val nv = code.toString()
        val old = cache[k]
        if (old != null && old.startsWith(nv)) return // eyni qeyd, diskə təkrar yazılmır
        cache[k] = nv
        runCatching { prefs.edit().putString(k, nv).apply() }
    }
}
