package com.mehdi.calc

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext

class CalcActivity : Activity() {

    // Gizli kod: bunu yığıb "=" basanda Fake GPS paneli açılır
    private val SECRET = "1997"

    private lateinit var display: TextView
    private lateinit var history: TextView
    private var expr = ""
    private var done = false
    private val ops = "+−×÷"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(12), dp(24), dp(12), dp(16))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.2f)
            setPadding(dp(12), 0, dp(12), dp(8))
        }
        history = TextView(this).apply {
            setTextColor(0xFF8E8E93.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            gravity = Gravity.END
            maxLines = 1
        }
        display = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            text = "0"
            setAutoSizeTextTypeUniformWithConfiguration(28, 72, 2, TypedValue.COMPLEX_UNIT_SP)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(96))
        }
        top.addView(history, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        top.addView(display)
        root.addView(top)

        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3f)
        }
        val rows = listOf(
            listOf("C", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("00", "0", ".", "=")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            for (t in r) {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                lp.setMargins(dp(5), dp(5), dp(5), dp(5))
                row.addView(makeBtn(t), lp)
            }
            pad.addView(row)
        }
        root.addView(pad)
        setContentView(root)
    }

    private fun makeBtn(t: String): Button = Button(this).apply {
        text = t
        isAllCaps = false
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        val bg: Int
        val fg: Int
        if (t == "C" || t == "⌫" || t == "%") {
            bg = 0xFFA5A5A5.toInt(); fg = Color.BLACK
        } else if (t == "÷" || t == "×" || t == "−" || t == "+" || t == "=") {
            bg = 0xFFFF9F0A.toInt(); fg = Color.WHITE
        } else {
            bg = 0xFF333333.toInt(); fg = Color.WHITE
        }
        setTextColor(fg)
        background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(60).toFloat()
        }
        stateListAnimator = null
        setOnClickListener { press(t) }
    }

    private fun press(t: String) {
        when (t) {
            "C" -> { expr = ""; history.text = ""; done = false }
            "⌫" -> {
                if (done) { expr = ""; history.text = ""; done = false } else expr = expr.dropLast(1)
            }
            "=" -> { equals(); return }
            "+", "−", "×", "÷" -> {
                if (expr.isEmpty()) {
                    if (t == "−") expr = "−"
                } else if (expr == "−") {
                    // heç nə
                } else if (ops.contains(expr.last())) {
                    expr = expr.dropLast(1) + t
                } else {
                    expr += t
                }
                if (done) { history.text = ""; done = false }
            }
            else -> {
                if (done && t != "%") { expr = ""; history.text = ""; done = false }
                expr += t
            }
        }
        display.text = if (expr.isEmpty()) "0" else expr
    }

    private fun equals() {
        if (expr == SECRET) {
            expr = ""
            display.text = "0"
            startActivity(Intent(this, GpsActivity::class.java))
            return
        }
        if (expr.isEmpty()) return
        try {
            val r = Parser(expr).parse()
            val s = fmt(r)
            history.text = "$expr ="
            expr = s
            done = true
            display.text = s
        } catch (e: Exception) {
            history.text = ""
            expr = ""
            done = false
            display.text = "Xəta"
        }
    }

    private fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) throw ArithmeticException()
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return BigDecimal(v).round(MathContext(10)).stripTrailingZeros().toPlainString()
    }
}

private class Parser(val s: String) {
    var i = 0

    fun parse(): Double {
        val v = expr()
        if (i != s.length) throw IllegalArgumentException()
        return v
    }

    private fun expr(): Double {
        var v = term()
        while (i < s.length && (s[i] == '+' || s[i] == '−')) {
            val op = s[i++]
            val r = term()
            v = if (op == '+') v + r else v - r
        }
        return v
    }

    private fun term(): Double {
        var v = factor()
        while (i < s.length && (s[i] == '×' || s[i] == '÷')) {
            val op = s[i++]
            val r = factor()
            if (op == '×') v *= r else {
                if (r == 0.0) throw ArithmeticException()
                v /= r
            }
        }
        return v
    }

    private fun factor(): Double {
        var neg = false
        if (i < s.length && s[i] == '−') { neg = true; i++ }
        val st = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (st == i) throw IllegalArgumentException()
        var v = s.substring(st, i).toDouble()
        while (i < s.length && s[i] == '%') { v /= 100; i++ }
        return if (neg) -v else v
    }
}
