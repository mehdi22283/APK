package com.mehdi.calc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock

class MockService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var error: String? = null
        @Volatile var lat = 0.0
        @Volatile var lng = 0.0
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var lm: LocationManager
    private val active = ArrayList<String>()

    private val tick = object : Runnable {
        override fun run() {
            push()
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null) {
            lat = intent.getDoubleExtra("lat", lat)
            lng = intent.getDoubleExtra("lng", lng)
        }
        startFg()
        if (!running) {
            try {
                setup()
                error = null
                running = true
                h.post(tick)
            } catch (e: SecurityException) {
                error = "Developer settings → \"Select mock location app\" → Kalkulyator seçin"
                stopSelf()
            } catch (e: Exception) {
                error = e.message ?: "Xəta"
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("calc", "Kalkulyator", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "calc")
            .setContentTitle("Kalkulyator")
            .setContentText("Aktivdir")
            .setSmallIcon(R.drawable.ic_notif)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(1, n)
        }
    }

    private fun setup() {
        active.clear()
        // GPS məcburidir (SecurityException buradan çıxır)
        addProvider(LocationManager.GPS_PROVIDER)
        active.add(LocationManager.GPS_PROVIDER)
        // Network ixtiyaridir
        try {
            addProvider(LocationManager.NETWORK_PROVIDER)
            active.add(LocationManager.NETWORK_PROVIDER)
        } catch (e: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun addProvider(p: String) {
        try { lm.removeTestProvider(p) } catch (e: Exception) { }
        lm.addTestProvider(p, false, false, false, false, true, true, true, Criteria.POWER_LOW, Criteria.ACCURACY_FINE)
        lm.setTestProviderEnabled(p, true)
    }

    private fun push() {
        for (p in active) {
            try {
                val l = Location(p)
                l.latitude = lat
                l.longitude = lng
                l.altitude = 10.0
                l.accuracy = 3f
                l.speed = 0f
                l.bearing = 0f
                l.time = System.currentTimeMillis()
                l.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
                lm.setTestProviderLocation(p, l)
            } catch (e: Exception) {
                error = "Mock location app seçilməyib: Developer settings-dən seçin"
                stopSelf()
                return
            }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        for (p in active) {
            try { lm.removeTestProvider(p) } catch (e: Exception) { }
        }
        active.clear()
        running = false
        super.onDestroy()
    }
}
