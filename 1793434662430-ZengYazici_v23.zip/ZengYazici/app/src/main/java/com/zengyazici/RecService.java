package com.zengyazici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import io.github.muntashirakon.adb.AdbStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import android.media.AudioManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.IBinder;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.provider.CallLog;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;

public class RecService extends Service {
    public static final String CH_FG = "fg", CH_EV = "ev", CH_CALL = "call";
    private boolean shownRec, recordedAny, waCall;
    /** Xidmət yalnız zəng zamanı yaşayır; zəng yoxdursa bu aralıqla özünü söndürür. */
    static final long IDLE_GUARD_MS = 30 * 1000L;
    public static volatile boolean running;
    /** WhatsApp zəng bildirişi var (WaListener qoyur). */
    public static volatile boolean waActive;
    public static volatile String waDir = "out", waName = "";
    private boolean waWatch;
    public static volatile android.content.Context appCtx;
    public static final StringBuilder LOG = new StringBuilder();

    public static void log(String s) {
        synchronized (LOG) {
            LOG.append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())).append(' ').append(s).append('\n');
            if (LOG.length() > 20000) LOG.delete(0, 5000);
        }
    }

    private NotificationManager nm;
    private TelephonyManager tm;
    private Object cb;
    private boolean listening, ringing, stopping;
    private volatile boolean rec;
    private String app = "", dir = "in", num = "";
    private long t0;
    private File file;
    private Recorder recorder;
    private AdbMgr mgr;
    private ServerSocket ss;
    private AdbStream st;
    private Thread wt;
    private volatile java.util.concurrent.Future<?> connF;
    private final ExecutorService connEx = idleExecutor();
    private boolean lastFail;
    private volatile boolean connecting;
    private final ExecutorService ex = idleExecutor();
    private boolean permLogged;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private volatile boolean micOnly;
    private AudioManager am;
    private int lastMode = -1, endTicks;
    private volatile boolean pollRec;
    /** Zəngin bitdiyi an (rejim/vəziyyət dəyişəndə); bundan sonra gələn səs kəsilir. 0 = zəng davam edir. */
    private volatile long endMark;
    private Object modeCb;
    // Xidmət yalnız zəng zamanı işlədiyi üçün bu sorğu da yalnız zəng ərzində gedir.
    private final Runnable modePoll = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { pollMode(); } catch (Throwable e) { log("Rejim: " + e); }
            boolean busy = rec || stopping || ringing || lastMode != AudioManager.MODE_NORMAL;
            if (busy) h.postDelayed(this, 300);
            else if (Build.VERSION.SDK_INT < 31 || modeCb == null) h.postDelayed(this, 3000);
        }
    };

    @android.annotation.TargetApi(31)
    private class ModeCb implements AudioManager.OnModeChangedListener {
        @Override public void onModeChanged(int mode) { h.removeCallbacks(modePoll); h.post(modePoll); }
    }

    private void registerModeListener() {
        if (Build.VERSION.SDK_INT < 31 || modeCb != null) return;
        try {
            if (am == null) am = (AudioManager) getSystemService(AUDIO_SERVICE);
            ModeCb m = new ModeCb();
            am.addOnModeChangedListener(getMainExecutor(), m);
            modeCb = m;
        } catch (Throwable e) { log("Rejim dinləyicisi: " + e); }
    }

    private void unregisterModeListener() {
        try {
            if (Build.VERSION.SDK_INT >= 31 && modeCb != null && am != null) am.removeOnModeChangedListener((AudioManager.OnModeChangedListener) modeCb);
        } catch (Throwable e) { }
        modeCb = null;
    }
    private WindowManager wm;
    private TextView ov;
    private GradientDrawable ovBg;
    private final Runnable ovTick = new Runnable() {
        @Override public void run() {
            if (ov == null) return;
            if (rec) {
                int sec = (int) ((System.currentTimeMillis() - t0) / 1000);
                ov.setText("🔴 Zəng yazılır · " + fmt(sec));
                if (ovBg != null) ovBg.setColor(0xE6D32F2F);
            } else {
                ov.setText("⚪ Zəng yazılmır" + (waWatch ? " — dinamiki açın" : ""));
                if (ovBg != null) ovBg.setColor(0xE6616161);
            }
            h.postDelayed(this, 1000);
        }
    };
    private String fgText = "Zəng gözlənilir";
    /** Zəng yoxdursa (və yazı getmirsə) xidməti söndürür — arxa fonda qalmasın. */
    private final Runnable idleGuard = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (!rec && !stopping && !ringing && !waActive && lastMode <= AudioManager.MODE_NORMAL) { shutdown(); return; }
            h.postDelayed(this, IDLE_GUARD_MS);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        appCtx = getApplicationContext();
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_FG, "Xidmət", NotificationManager.IMPORTANCE_LOW));
        // Zəng zamanı vəziyyət bildirişi: ekranın üstündə çıxır (səssiz), yazı vəziyyəti dəyişəndə yenidən çıxır.
        NotificationChannel cc = new NotificationChannel(CH_CALL, "Zəng yazısı vəziyyəti", NotificationManager.IMPORTANCE_HIGH);
        cc.setSound(null, null);
        cc.enableVibration(false);
        nm.createNotificationChannel(cc);
        nm.createNotificationChannel(new NotificationChannel(CH_EV, "Zəng yazıları", NotificationManager.IMPORTANCE_HIGH));
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "wa".equals(i.getAction())) {
            waWatch = true;
            if (!rec) { app = "WhatsApp"; dir = waDir; num = waName; }
        }
        if (!running) {
            running = true;
            startFg(waWatch ? label() + " · yazmaq üçün dinamiki açın" : "Zəng gözlənilir · hələ yazılmır");
            listen();
            connF = connEx.submit(this::tryConnect);
            registerModeListener();
            h.post(modePoll);
            if (waWatch) showOverlay();
        } else if (waWatch) {
            updateFg(label() + " · yazmaq üçün dinamiki açın");
            showOverlay();
        }
        // Xidmət həmişə işləyir: sistem öldürsə özü yenidən qalxır.
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        restartLater(1500);
        super.onTaskRemoved(rootIntent);
    }

    /** Xidmət öldürülsə/tətbiq tapşırıqlardan silinsə alarm vasitəsilə yenidən qaldırır. */
    private void restartLater(long ms) {
        try {
            android.app.AlarmManager am2 = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
            PendingIntent pi = PendingIntent.getForegroundService(getApplicationContext(), 77,
                    new Intent(getApplicationContext(), RecService.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            am2.set(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + ms, pi);
        } catch (Throwable e) { log("restart: " + e); }
    }

    @Override
    public void onDestroy() {
        if (!rec) restartLater(2000);
        running = false;
        h.removeCallbacks(idleGuard);
        h.removeCallbacks(modePoll);
        h.removeCallbacks(ovTick);
        unregisterModeListener();
        try { if (ov != null && wm != null) wm.removeView(ov); } catch (Throwable e) { }
        ov = null;
        release();
        try {
            if (cb != null && tm != null) {
                if (Build.VERSION.SDK_INT >= 31) tm.unregisterTelephonyCallback((TelephonyCallback) cb);
                else tm.listen((PhoneStateListener) cb, PhoneStateListener.LISTEN_NONE);
            }
        } catch (Throwable e) { }
        ex.shutdown();
        connEx.shutdown();
        super.onDestroy();
    }

    // ---------- bildirişlər ----------
    private PendingIntent openApp() {
        return PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification fgNotif(String text) {
        boolean changed = rec != shownRec;
        shownRec = rec;
        return new Notification.Builder(this, CH_CALL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(rec ? "🔴 Zəng yazılır" : "⚪ Zəng yazılmır")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(!changed)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(openApp())
                .build();
    }

    private void startFg(String text) {
        fgText = text;
        Notification n = fgNotif(text);
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void disconnectAdb() {
        final AdbMgr m = AdbMgr.peek();
        if (m == null) return;
        Thread t = new Thread(() -> { try { m.disconnect(); } catch (Throwable e) { } });
        t.setDaemon(true);
        t.start();
    }

    /** Zəng bitib: ön plan bildirişini, ADB bağlantısını və xidmətin özünü bağlayır. */
    private void shutdown() {
        if (rec || stopping) return;
        if (waWatch && waCall && !recordedAny) notifyEv(5, "⚪ Zəng yazılmadı", "WhatsApp · dinamik açılmadığı üçün yazılmadı", false);
        h.removeCallbacks(idleGuard);
        hideOverlay();
        // Xidmət dayanmır: növbəti zəngi gözləməyə qayıdır (ADB bağlantısı açıq qalır).
        waWatch = false; waCall = false; recordedAny = false; ringing = false;
        updateFg("Zəng gözlənilir · hələ yazılmır");
    }

    private void updateFg(String text) { fgText = text; nm.notify(1, fgNotif(text)); }

    private void notifyEv(int id, String title, String text, boolean ongoing) {
        nm.notify(id, new Notification.Builder(this, CH_EV)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .setCategory(Notification.CATEGORY_STATUS)
                .setContentIntent(openApp())
                .build());
    }

    // ---------- tətbiqlərin üstündə göstərici ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void showOverlay() {
        h.post(() -> {
            try {
                if (ov != null) return;
                if (!Settings.canDrawOverlays(this)) { log("Üstündə göstərmə icazəsi yoxdur — göstərici açılmadı"); return; }
                wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                TextView t = new TextView(this);
                t.setTextColor(Color.WHITE); t.setTextSize(13); t.setTypeface(null, Typeface.BOLD);
                t.setPadding(dp(14), dp(7), dp(14), dp(7));
                GradientDrawable g = new GradientDrawable();
                g.setColor(0xE6616161); g.setCornerRadius(dp(20));
                t.setBackground(g);
                ovBg = g;
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                lp.y = dp(36);
                wm.addView(t, lp);
                ov = t;
                h.removeCallbacks(ovTick);
                h.post(ovTick);
            } catch (Throwable e) {
                log("Göstərici: " + e);
                ov = null;
            }
        });
    }

    private void hideOverlay() {
        h.post(() -> {
            h.removeCallbacks(ovTick);
            try { if (ov != null && wm != null) wm.removeView(ov); } catch (Throwable e) { }
            ov = null;
        });
    }

    // ---------- ADB ----------
    private void ensureConnected() throws Exception {
        if (mgr == null) mgr = AdbMgr.get(this);
        try {
            Conn.ensureLocal(this); // bir dəfə açılmış 5555: Wi-Fi/Wireless olmadan da işləyir
        } catch (Throwable e) {
            if (!Conn.hasWifi(this)) {
                log("Lokal ADB yoxdur, Wi-Fi də yoxdur — yalnız mikrofon. Wi-Fi + Wireless debugging açıb Menyu → Qoşul basın.");
                throw e;
            }
            Conn.ensure(this); // Wi-Fi varsa Wireless ilə qoşulub lokala keçir (özünü bərpa)
        }
    }

    /** Dinamik (hoparlor) açıqdırmı — WhatsApp zəngində yazı bununla başlayır. */
    private boolean speakerOn() {
        try {
            if (am == null) am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (Build.VERSION.SDK_INT >= 31) {
                android.media.AudioDeviceInfo d = am.getCommunicationDevice();
                if (d != null) return d.getType() == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER;
            }
            return am.isSpeakerphoneOn();
        } catch (Throwable e) { return false; }
    }

    private static String modeName(int m) {
        return m == 0 ? "NORMAL" : m == 1 ? "RINGTONE" : m == 2 ? "IN_CALL" : m == 3 ? "IN_COMMUNICATION" : String.valueOf(m);
    }

    /** Zəngi telefonun audio rejimindən də tanıyır (zəng callback-i işləməsə belə). */
    private void pollMode() {
        if (am == null) am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int m = am.getMode();
        if (m != lastMode) { log("Audio rejimi: " + modeName(m)); lastMode = m; }
        if (m == AudioManager.MODE_RINGTONE) ringing = true;
        if (m == AudioManager.MODE_IN_COMMUNICATION && waWatch) waCall = true;
        if (m == AudioManager.MODE_IN_COMMUNICATION && waWatch && !rec && !stopping && speakerOn()) {
            startRec("WhatsApp", waDir, waName);
            if (rec) pollRec = true;
        }
        boolean waRec = m == AudioManager.MODE_IN_COMMUNICATION && "WhatsApp".equals(app) && (rec || stopping);
        if (m == AudioManager.MODE_IN_CALL || waRec) {
            endTicks = 0;
            if (!stopping) endMark = 0;
            if (m == AudioManager.MODE_IN_CALL && !rec && !stopping) { startRec("Telefon", ringing ? "in" : "out", ""); if (rec) pollRec = true; }
        } else {
            if (rec && (pollRec || "Telefon".equals(app)) && !stopping) {
                if (endTicks == 0) endMark = System.currentTimeMillis();
                if (++endTicks >= (pollRec ? 4 : 5)) { endTicks = 0; stopRec(); }
            } else {
                endTicks = 0;
            }
            if (m == AudioManager.MODE_NORMAL && !rec) ringing = false;
        }
    }

    /** Zəng başlayanda bir dəfə qoşulur; təkrar cəhd və arxa fon yoxlaması yoxdur. */
    private void tryConnect() {
        if (connecting) return;
        connecting = true;
        try {
            ensureConnected();
            if (lastFail) log("ADB yenidən qoşuldu");
            lastFail = false;
            if (!rec) updateFg("ADB qoşulub (" + Conn.mode + ") · zəng yoxlanılır");
            AdbPerms.apply(this, false);
        } catch (Throwable e) {
            if (!lastFail) log("ADB: " + e);
            lastFail = true;
        } finally {
            connecting = false;
        }
    }

    // ---------- zəng izləmə ----------
    private void listen() {
        if (listening) return;
        if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            if (!permLogged) { log("READ_PHONE_STATE icazəsi yoxdur — zənglər tanınmır"); permLogged = true; }
            updateFg("Telefon icazəsi verilməyib: Menyu → İcazələr");
            h.postDelayed(this::shutdown, 5000);
            return;
        }
        try {
            tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (Build.VERSION.SDK_INT >= 31) {
                cb = new Cb31();
                tm.registerTelephonyCallback(getMainExecutor(), (TelephonyCallback) cb);
            } else {
                PhoneStateListener l = new PhoneStateListener() {
                    @Override public void onCallStateChanged(int s, String n) { onState(s); }
                };
                cb = l;
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE);
            }
            listening = true;
            log("Zəng dinləyicisi aktiv");
        } catch (Throwable e) {
            log("Dinləyici: " + e);
        }
    }

    @android.annotation.TargetApi(31)
    private class Cb31 extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        @Override public void onCallStateChanged(int s) { onState(s); }
    }

    private void onState(int s) {
        log("Zəng vəziyyəti: " + (s == 0 ? "IDLE" : s == 1 ? "RINGING" : "OFFHOOK"));
        if (s == TelephonyManager.CALL_STATE_RINGING) {
            ringing = true;
            if (!connecting) connF = connEx.submit(this::tryConnect);
            updateFg(waWatch ? label() + " · yazmaq üçün dinamiki açın" : "Zəng gəlir · hələ yazılmır");
            showOverlay();
        } else if (s == TelephonyManager.CALL_STATE_OFFHOOK) {
            if (!rec) showOverlay();
            if (!rec) startRec("Telefon", ringing ? "in" : "out", "");
        } else if (s == TelephonyManager.CALL_STATE_IDLE) {
            ringing = false;
            if (rec && "Telefon".equals(app)) { if (endMark == 0) endMark = System.currentTimeMillis(); stopRec(); }
            else if (!rec && !stopping && !waWatch) h.postDelayed(this::shutdown, 1500);
        }
    }

    // ---------- yazı ----------
    private String label() {
        return app + " · " + ("out".equals(dir) ? "gedən" : "gələn") + (num.isEmpty() ? "" : " · " + num);
    }

    private static String fmt(int s) { return String.format(Locale.US, "%d:%02d", s / 60, s % 60); }

    private void startRec(String a, String d, String n) {
        if (rec) return;
        rec = true;
        recordedAny = true;
        endMark = 0;
        micOnly = false;
        fallbackOn = false;
        app = a;
        dir = d == null || d.isEmpty() ? "in" : d;
        num = n == null ? "" : n;
        t0 = System.currentTimeMillis();
        try {
            if (wl == null) wl = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zengyazici:rec");
            wl.acquire(4 * 60 * 60 * 1000L);
        } catch (Throwable e) { }
        h.post(this::micForeground);
        ex.execute(() -> {
            try {
                File dirF = new File(getFilesDir(), "rec");
                dirF.mkdirs();
                final File f = new File(dirF, "rec_" + t0 + ".wav");
                file = f;
                boolean adbOk = false;
                try {
                    mgr = AdbMgr.get(this);
                    if (!mgr.isConnected()) {
                        java.util.concurrent.Future<?> cf = connF;
                        if (cf != null) { try { cf.get(4, java.util.concurrent.TimeUnit.SECONDS); } catch (Throwable e) { } }
                    }
                    adbOk = mgr.isConnected();
                } catch (Throwable e) { log("ADB: " + e); }
                if (adbOk) {
                    try {
                        startAdbRec(f);
                    } catch (Throwable e) {
                        log("ADB yazısı açılmadı, mikrofona keçilir: " + e);
                        adbOk = false;
                        closeAdb();
                    }
                }
                if (!adbOk) {
                    Recorder r = new Recorder(f, (src, far) -> micOnly = !far);
                    recorder = r;
                    r.start();
                }
                showOverlay();
            } catch (Throwable e) {
                log("Yazı başlamadı: " + e);
                rec = false;
                release();
                hideOverlay();
                notifyEv(4, "Zəng yazıla bilmədi", String.valueOf(e.getMessage()), false);
            }
        });
    }

    /** ADB shell (uid 2000) vasitəsilə sistem mənbələrindən (4/3) qarşı tərəfin səsini də yazır. */
    private void startAdbRec(final File f) throws Exception {
        final ServerSocket sk = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
        ss = sk;
        sk.setSoTimeout(20000);
        String src = "WhatsApp".equals(app) ? "6;1;7" : "4;3+2;3+1;8+1;2+3;7;1";
        final AdbStream stream = mgr.openStream("shell:CLASSPATH=" + getPackageCodePath()
                + " app_process /system/bin com.zengyazici.Rec " + sk.getLocalPort() + " '" + src + "'");
        st = stream;
        Thread rt = new Thread(() -> {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(stream.openInputStream()))) {
                String l;
                while ((l = br.readLine()) != null) {
                    log("rec: " + l);
                    if (l.contains("Hec bir audio menbeyi acilmadi")) fallbackMic();
                    if (l.contains("FAR=none")) {
                        micOnly = true;
                    }
                    if (l.contains("FAR=ok")) micOnly = false;
                }
            } catch (Exception e) { }
        });
        rt.setDaemon(true);
        rt.start();
        wt = new Thread(() -> pump(sk, f));
        wt.setDaemon(true);
        wt.start();
        log("Yazı ADB ilə başladı");
    }

    private volatile boolean fallbackOn;

    /** ADB mənbələri heç açılmayanda (məs. Note 9 Pro) tətbiqin öz mikrofonuna keçir. */
    private void fallbackMic() {
        ex.execute(() -> {
            try {
                if (!rec || stopping || recorder != null || file == null) return;
                fallbackOn = true;
                log("ADB mənbəsi açılmadı — tətbiq daxili yazıya keçildi");
                try { if (ss != null) ss.close(); } catch (Throwable e) { }
                Recorder r = new Recorder(file, (src, far) -> micOnly = !far);
                recorder = r;
                r.start();
            } catch (Throwable e) { log("Ehtiyat yazı: " + e); }
        });
    }

    private void closeAdb() {
        try { if (st != null) st.close(); } catch (Throwable e) { }
        try { if (ss != null) ss.close(); } catch (Throwable e) { }
        try { if (wt != null) wt.join(5000); } catch (Throwable e) { }
        st = null; ss = null; wt = null;
    }

    private void pump(ServerSocket s, File f) {
        long total = 0;
        try (RandomAccessFile r = new RandomAccessFile(f, "rw")) {
            r.write(new byte[44]);
            try {
                Socket c = s.accept();
                InputStream in = c.getInputStream();
                int src = in.read();
                log("Audio planı #" + src);
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) { r.write(b, 0, n); total += n; }
            } catch (Exception e) {
                log("Audio axını: " + e);
            }
            if (total > 0 || !fallbackOn) header(r, total);
        } catch (Exception e) {
            log("Fayl: " + e);
        }
    }

    /** Mikrofon yazısı üçün xidməti mikrofon tipli ön plan xidmətinə yüksəldir (Android 14). */
    private void micForeground() {
        updateFg(label());
        try {
            if (Build.VERSION.SDK_INT < 30) return;
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
            startForeground(1, fgNotif(label()),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } catch (Throwable e) {
            log("Mikrofon xidməti: " + e);
        }
    }

    /** Başqa komponentlərdən (əlçatımlılıq, alarm) xidməti qaldırır. */
    public static void ensure(android.content.Context c) { ensure(c, new Intent(c, RecService.class)); }

    public static void ensure(android.content.Context c, Intent i) {
        if (running) return;
        try {
            c.startForegroundService(i);
        } catch (Throwable e) {
            try { c.startService(i); } catch (Throwable e2) { log("ensure: " + e2); }
        }
    }

    /** Boşda işləməyən axın: 30 san sonra thread-i də bağlanır (RAM). */
    private static ExecutorService idleExecutor() {
        java.util.concurrent.ThreadPoolExecutor t = new java.util.concurrent.ThreadPoolExecutor(1, 1, 30, java.util.concurrent.TimeUnit.SECONDS,
                new java.util.concurrent.LinkedBlockingQueue<Runnable>());
        t.allowCoreThreadTimeOut(true);
        return t;
    }

    private void release() {
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable e) { }
    }

    static void header(RandomAccessFile r, long n) throws Exception {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt((int) (36 + n)).put("WAVE".getBytes()).put("fmt ".getBytes())
                .putInt(16).putShort((short) 1).putShort((short) 1).putInt(16000).putInt(32000)
                .putShort((short) 2).putShort((short) 16).put("data".getBytes()).putInt((int) n);
        r.seek(0);
        r.write(b.array());
    }

    private void stopRec() {
        if (!rec || stopping) return;
        stopping = true;
        ex.execute(() -> {
            try {
                final long stopAt = System.currentTimeMillis();
                final long endAt = endMark;
                try { if (recorder != null) recorder.stopAndJoin(); } catch (Throwable e) { }
                recorder = null;
                closeAdb();
                nm.cancel(2);
                File f = file;
                long realEnd = endAt > t0 && endAt < stopAt ? endAt : stopAt;
                if (f != null && realEnd < stopAt) trimTail(f, stopAt - realEnd);
                int dur = (int) ((realEnd - t0) / 1000);
                if (f != null && f.length() > 8000) {
                    resolve();
                    Db.Item it = new Db.Item();
                    it.path = f.getAbsolutePath();
                    it.num = num;
                    it.app = app;
                    it.dir = dir;
                    it.ts = t0;
                    it.dur = dur;
                    it.note = !micOnly || !"Telefon".equals(app) ? "" : "Yalnız mikrofon: qarşı tərəfin səsi tutulmadı";
                    Db.add(this, it);
                    notifyEv(3, "✅ Zəng yazıldı", label() + " · " + fmt(dur), false);
                } else {
                    if (f != null) f.delete();
                    notifyEv(4, "Zəng yazıla bilmədi", "Audio alınmadı — Log-a baxın", false);
                }
            } catch (Throwable e) {
                log("Yazını bitirmə xətası: " + e);
            } finally {
                rec = false;
                stopping = false;
                pollRec = false;
                endMark = 0;
                hideOverlay();
                release();
                if (running) h.postDelayed(this::shutdown, 800);
            }
        });
    }

    /** Zəng bitəndən sonra yazılmış sonluq hissəni (ms) WAV faylından kəsir (16 kHz, 16 bit, mono = 32 bayt/ms). */
    private void trimTail(File f, long ms) {
        try (RandomAccessFile r = new RandomAccessFile(f, "rw")) {
            long len = r.length();
            long cut = (ms * 32) & ~1L;
            long data = len - 44 - cut;
            if (data < 3200) return; // çox qısa qalacaqsa toxunma
            r.setLength(44 + data);
            header(r, data);
        } catch (Throwable e) {
            log("Sonluq kəsilmədi: " + e);
        }
    }

    /** Nömrə/ad və istiqaməti zəng jurnalından dəqiqləşdirir. */
    private void resolve() {
        if ("WhatsApp".equals(app)) { if (num.isEmpty()) num = "Naməlum"; return; }
        try { Thread.sleep(1200); } catch (Exception e) { }
        try {
            Bundle b = new Bundle();
            b.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            b.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{CallLog.Calls.DATE});
            b.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
            Cursor c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                    new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE}, b, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        String nu = c.getString(0), na = c.getString(1);
                        int ty = c.getInt(2);
                        if (na != null && !na.isEmpty()) num = na;
                        else if (nu != null && !nu.isEmpty()) num = nu;
                        if (ty == CallLog.Calls.OUTGOING_TYPE) dir = "out";
                        else if (ty == CallLog.Calls.INCOMING_TYPE) dir = "in";
                    }
                } finally { c.close(); }
            }
        } catch (Throwable e) {
            log("Zəng jurnalı: " + e);
        }
        if (num.isEmpty()) num = "Naməlum";
    }
}
