package az.mehdi.xezertv

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.ui.PlayerView
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Channel(val name: String, val pageUrl: String) {
    val id: String get() = Integer.toHexString(pageUrl.hashCode())
}

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    companion object {
        const val TIMEOUT_MS = 30_000L
        const val SCAN_EVERY_MS = 400L
        const val MAX_RETRY = 5

        const val SITE = "https://canlitv.com/"

        // JS: səhifədəki bütün resurs adlarını + DOM mətnini qaytarır
        const val SCAN_JS = """(function(){var r=[];try{performance.getEntriesByType('resource').forEach(function(e){r.push(e.name)})}catch(e){}
try{document.querySelectorAll('video,source,iframe,script').forEach(function(e){if(e.src)r.push(e.src)})}catch(e){}
r.push(document.documentElement.outerHTML);return r.join('\n');})()"""
    }

    private val blockExt = setOf("png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "css",
        "woff", "woff2", "ttf", "otf", "eot", "mp4", "webm")
    private val blockHosts = listOf("doubleclick", "googlesyndication", "google-analytics",
        "googletagmanager", "googleadservices", "adservice", "facebook.net", "facebook.com",
        "yandex", "adsystem", "adnxs", "taboola", "outbrain", "histats")

    private fun shouldBlock(u: String): Boolean {
        if (u.contains(".m3u8", true)) return false
        val noQuery = u.substringBefore('?').substringBefore('#')
        val ext = noQuery.substringAfterLast('.', "").lowercase()
        if (ext in blockExt) return true
        val host = android.net.Uri.parse(u).host ?: return false
        return blockHosts.any { host.contains(it) }
    }

    private val ui = Handler(Looper.getMainLooper())
    private val m3u8Regex = Regex("""https?://[^\s"'<>\\]+?\.m3u8[^\s"'<>\\]*""")

    private lateinit var playerView: PlayerView
    private lateinit var statusView: TextView
    private lateinit var linkView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var webContainer: FrameLayout
    private lateinit var btnChannel: Button
    private var channels: List<Channel> = emptyList()

    private var player: ExoPlayer? = null
    private var webView: WebView? = null
    private var channel: Channel = Channel("-", SITE)
    private var done = false
    private var candidate: String? = null
    private var attempt = 0
    private var currentUrl: String? = null
    private var playHeaders: Map<String, String> = emptyMap()
    private var userAgent: String = ""
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val prefs get() = getSharedPreferences("xezer", MODE_PRIVATE)

    private val scanRunnable = object : Runnable {
        override fun run() {
            val wv = webView ?: return
            if (done) return
            wv.evaluateJavascript(SCAN_JS) { raw -> onScanResult(raw) }
            ui.postDelayed(this, SCAN_EVERY_MS)
        }
    }

    private val timeoutRunnable = Runnable {
        if (done) return@Runnable
        val c = candidate
        if (c != null) {
            log("⏱ Vaxt bitdi, namizəd link istifadə olunur")
            accept(c, "namizəd")
        } else {
            log("✖ 30 saniyədə m3u8 tapılmadı")
            setStatus("Link tapılmadı — 🔄 Yenilə düyməsini bas")
            stopFetch()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.playerView)
        statusView = findViewById(R.id.statusView)
        linkView = findViewById(R.id.linkView)
        logView = findViewById(R.id.logView)
        logScroll = findViewById(R.id.logScroll)
        webContainer = findViewById(R.id.webContainer)
        btnChannel = findViewById(R.id.btnChannel)

        userAgent = WebSettings.getDefaultUserAgent(this)

        channels = loadChannels()
        log("Kanal siyahısı: ${channels.size} kanal")
        btnChannel.setOnClickListener { showPicker() }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { step(-1) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { step(1) }

        findViewById<Button>(R.id.btnRefresh).setOnClickListener {
            attempt = 0
            startFetch()
        }
        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val u = currentUrl
            if (u == null) {
                Toast.makeText(this, "Hələ link yoxdur", Toast.LENGTH_SHORT).show()
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("m3u8", u))
                Toast.makeText(this, "Link kopyalandı", Toast.LENGTH_SHORT).show()
            }
        }

        initPlayer()
        if (channels.isNotEmpty()) {
            val last = prefs.getString("last", null)
            selectChannel(
                channels.firstOrNull { it.id == last }
                    ?: channels.firstOrNull { it.pageUrl.contains("xezer-tv") }
                    ?: channels[0]
            )
        }
    }

    private fun loadChannels(): List<Channel> =
        assets.open("channels.txt").bufferedReader(Charsets.UTF_8).readLines()
            .mapNotNull { line ->
                val parts = line.split("|", limit = 2)
                if (parts.size < 2) null
                else Channel(parts[0].trim(), parts[1].trim()).takeIf { it.pageUrl.startsWith("http") }
            }

    private fun step(d: Int) {
        if (channels.isEmpty()) return
        val i = channels.indexOfFirst { it.id == channel.id }.let { if (it < 0) 0 else it }
        selectChannel(channels[(i + d + channels.size) % channels.size])
    }

    private fun showPicker() {
        val et = EditText(this)
        et.hint = "Axtar..."
        et.setSingleLine()
        val lv = ListView(this)
        val shown = channels.toMutableList()
        val names = shown.map { it.name }.toMutableList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        lv.adapter = adapter
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(et)
        root.addView(lv)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Kanal seç (${channels.size})")
            .setView(root)
            .setNegativeButton("Bağla", null)
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            selectChannel(shown[pos])
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty()
                shown.clear()
                shown.addAll(channels.filter { it.name.lowercase(Locale.ROOT).contains(q) })
                names.clear()
                names.addAll(shown.map { it.name })
                adapter.notifyDataSetChanged()
            }
        })
        dlg.show()
    }

    private fun selectChannel(ch: Channel) {
        stopFetch()
        player?.stop()
        channel = ch
        attempt = 0
        done = false
        currentUrl = null
        linkView.text = ""
        prefs.edit().putString("last", ch.id).apply()
        btnChannel.text = "📺 ${ch.name}"
        log("═══ Kanal: ${ch.name} ═══")

        val cached = prefs.getString("${ch.id}_url", null)
        if (cached != null) {
            log("⚡ Keşdəki link ilə dərhal oynadılır (xəta olarsa avtomatik yenilənəcək)")
            val ref = prefs.getString("${ch.id}_ref", SITE) ?: SITE
            val org = prefs.getString("${ch.id}_org", SITE.trimEnd('/')) ?: SITE.trimEnd('/')
            playHeaders = mapOf("Referer" to ref, "Origin" to org)
            currentUrl = cached
            linkView.text = cached
            play(cached)
        } else {
            startFetch()
        }
    }

    private fun initPlayer() {
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 800, 1_500)
            .build()
        val p = ExoPlayer.Builder(this).setLoadControl(lc).build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> setStatus("Yüklənir...")
                    Player.STATE_READY -> {
                        attempt = 0
                        setStatus("▶ ${channel.name} — canlı yayım gedir")
                        log("▶ Oynadılır")
                    }
                    else -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                log("✖ Player xətası: ${error.errorCodeName} — ${error.cause?.message ?: error.message}")
                if (attempt < MAX_RETRY) {
                    log("↻ Token köhnələ bilər, link yenidən çəkilir...")
                    startFetch()
                } else {
                    setStatus("Oynatma alınmadı — 🔄 Yenilə düyməsini bas")
                }
            }
        })
        playerView.player = p
        player = p
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun startFetch() {
        stopFetch()
        done = false
        candidate = null
        attempt++
        log("━━━ Cəhd #$attempt ━━━")
        log("1) Gizli WebView açılır: ${channel.pageUrl}")
        setStatus("Link axtarılır...")

        val wv = WebView(this)
        webView = wv
        webContainer.addView(wv, ViewGroup.LayoutParams(1, 1))
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = userAgent
            loadsImagesAutomatically = false
            blockNetworkImage = true
        }
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url.toString()
                if (shouldBlock(u)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                if (u.contains(".m3u8", ignoreCase = true)) {
                    val h = request.requestHeaders
                    ui.post { onUrlSeen(u, "şəbəkə sorğusu (JS player sorğusu)", h) }
                }
                return null
            }

            override fun onPageFinished(view: WebView, url: String) {
                log("2) Səhifə yükləndi")
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                if (request.isForMainFrame) log("✖ Səhifə xətası: ${error.description}")
            }
        }
        wv.loadUrl(channel.pageUrl, mapOf("Referer" to SITE))
        ui.postDelayed(timeoutRunnable, TIMEOUT_MS)
        ui.postDelayed(scanRunnable, 300)
    }

    private fun stopFetch() {
        ui.removeCallbacks(scanRunnable)
        ui.removeCallbacks(timeoutRunnable)
        webView?.let {
            it.stopLoading()
            webContainer.removeView(it)
            it.destroy()
        }
        webView = null
    }

    private fun onScanResult(raw: String?) {
        if (done || raw == null || raw == "null") return
        val text = (JSONTokener(raw).nextValue() as? String) ?: return
        val norm = normalize(text)
        for (m in m3u8Regex.findAll(norm)) {
            onUrlSeen(m.value, "səhifə JS/DOM mətni", emptyMap())
            if (done) return
        }
    }

    private fun normalize(s: String): String = s
        .replace("\\/", "/")
        .replace("\\u0026", "&")
        .replace("\\u003d", "=")
        .replace("&amp;", "&")

    private fun clean(u: String): String =
        normalize(u).trimEnd(')', ']', ';', ',', '}')

    private fun onUrlSeen(raw: String, source: String, headers: Map<String, String>) {
        if (done) return
        val u = clean(raw)
        accept(u, source, headers)
    }

    private fun accept(url: String, source: String, headers: Map<String, String> = emptyMap()) {
        if (done) return
        done = true
        val keep = setOf("referer", "origin", "user-agent", "cookie")
        val h = headers.filterKeys { it.lowercase() in keep }
        playHeaders = if (h.isEmpty())
            mapOf("Referer" to SITE, "Origin" to SITE.trimEnd('/'))
        else h
        log("3) ✔ m3u8 TAPILDI — mənbə: $source")
        log("   $url")
        log("   Header-lər: $playHeaders")
        currentUrl = url
        linkView.text = url
        val ref = playHeaders.entries.firstOrNull { it.key.equals("referer", true) }?.value ?: SITE
        val org = playHeaders.entries.firstOrNull { it.key.equals("origin", true) }?.value ?: SITE.trimEnd('/')
        prefs.edit()
            .putString("${channel.id}_url", url)
            .putString("${channel.id}_ref", ref)
            .putString("${channel.id}_org", org)
            .apply()
        stopFetch()
        play(url)
    }

    private fun play(url: String) {
        val p = player ?: return
        val ua = playHeaders.entries.firstOrNull { it.key.equals("user-agent", true) }?.value ?: userAgent
        val props = playHeaders.filterKeys { !it.equals("user-agent", true) }
        val dsf = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(props)
        val src = HlsMediaSource.Factory(dsf).createMediaSource(MediaItem.fromUri(url))
        p.setMediaSource(src)
        p.prepare()
        p.playWhenReady = true
        log("4) ExoPlayer HLS ilə oynatma başladı")
    }

    private fun setStatus(s: String) {
        statusView.text = s
    }

    private fun log(s: String) {
        val line = "[${timeFmt.format(Date())}] $s\n"
        runOnUiThread {
            logView.append(line)
            logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        stopFetch()
        player?.release()
        player = null
        super.onDestroy()
    }
}
