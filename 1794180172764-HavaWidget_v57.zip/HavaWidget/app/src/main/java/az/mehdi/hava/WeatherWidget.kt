package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.RemoteViews
import kotlin.math.roundToInt

class WeatherWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        Scheduler.start(context)
        Midnight.schedule(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Scheduler.start(context)
        Midnight.schedule(context)
        refresh(context)
        if (WeatherApi.ageMin(context) > 10) Scheduler.now(context)
    }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return
            m.updateAppWidget(ids, build(c))
        }


        /** Şarj göstəricisini rv-ə yazır və son göstərilən mətni yadda saxlayır */
        private fun applyCharge(c: Context, rv: RemoteViews): String {
            val rem = Battery.remainingMs(c)
            val txt = when {
                rem == null -> ""
                rem > 0 -> "⚡ ${(rem / 60000).coerceAtLeast(1)}"
                else -> "⚡ …"
            }
            rv.setTextViewText(R.id.w_chg, txt)
            rv.setViewVisibility(R.id.w_chg, if (rem == null) View.GONE else View.VISIBLE)
            c.getSharedPreferences("home", Context.MODE_PRIVATE).edit().putString("chg_txt", txt).apply()
            return txt
        }

        /**
         * Dəqiqəlik yeniləmə üçün yüngül yol: bütün vidceti yenidən çəkmir, yalnız ⚡ mətnini dəyişir.
         * Göstərilən mətn dəyişməyibsə heç nə göndərmir.
         */
        fun refreshCharge(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return
            val last = c.getSharedPreferences("home", Context.MODE_PRIVATE).getString("chg_txt", null)
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val txt = applyCharge(c, rv)
            if (txt == last) return
            m.partiallyUpdateAppWidget(ids, rv)
        }

        private val INFO_IDS = intArrayOf(R.id.w_i1, R.id.w_i2, R.id.w_i3, R.id.w_i4, R.id.w_i5, R.id.w_i6)

        private val T_IDS = intArrayOf(R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5, R.id.w_t6,
            R.id.w_t7, R.id.w_t8)

        /** Saatlıq xana mətni: saat / temperatur / yağış % (ikon yuxarıda, ayrıca) */
        private fun hourText(time: String, temp: Int, prob: Int, mm: Double, snow: Double): CharSequence {
            val sb = SpannableStringBuilder()
            fun add(t: String, size: Float, color: Int, bold: Boolean) {
                val s = sb.length
                sb.append(t)
                val f = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                sb.setSpan(RelativeSizeSpan(size), s, sb.length, f)
                sb.setSpan(ForegroundColorSpan(color), s, sb.length, f)
                if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, f)
            }
            add(time, 1.0f, Color.parseColor("#CFD8DC"), false)
            sb.append("\n")
            add("$temp°", 1.2f, Color.WHITE, true)
            sb.append("\n")
            add("$prob%", 0.9f, Color.parseColor("#4FC3F7"), true)
            sb.append("\n")
            add(fmtPrecip(mm, snow), 0.8f, Color.parseColor("#81D4FA"), false)
            sb.append("\n")
            add(precipShort(mm, snow), 0.75f, Color.parseColor("#B3E5FC"), false)
            return sb
        }

        /** Mətnin solunda ikon göstərir (sol ikon: ad + ölçü) */
        private fun left(c: Context, rv: RemoteViews, id: Int, text: CharSequence, icon: String, size: String) {
            rv.setTextViewText(id, text)
            rv.setTextViewCompoundDrawables(id, Ic.id(c, icon, size), 0, 0, 0)
            rv.setViewVisibility(id, View.VISIBLE)
        }

        private fun build(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val w = WeatherApi.cached(c)
            val n = w?.nowIndex() ?: -1
            rv.setTextViewText(R.id.w_dm, T.dayMonth())
            rv.setTextViewText(R.id.w_wd, T.weekday())
            applyCharge(c, rv)
            left(c, rv, R.id.w_word, Daily.word(c), "bulb", "s")
            left(c, rv, R.id.w_proverb, Daily.proverb(c), "book", "s")
            rv.removeAllViews(R.id.w_days)
            INFO_IDS.forEach { rv.setViewVisibility(it, View.GONE) }
            rv.setViewVisibility(R.id.w_wear, View.GONE)
            if (w == null || n < 0) {
                rv.setTextViewText(R.id.w_title, "Yenilənir…")
                rv.setTextViewCompoundDrawables(R.id.w_title, 0, 0, 0, 0)
                rv.setTextViewText(R.id.w_outlook, "İnternet bağlantısı olanda məlumat yüklənəcək")
                rv.setTextViewCompoundDrawables(R.id.w_outlook, 0, 0, 0, 0)
            } else {
                val h = w.hours[n]
                left(c, rv, R.id.w_title, "${h.temp.roundToInt()}°  ${T.desc(h.code)}", T.iconName(h.code), "xl")
                val o = w.outlook()
                left(c, rv, R.id.w_outlook, o?.text ?: "", T.kindIcon(o?.kind), "")
                // geyim: yalnız üst, alt, ayaqqabı — hər biri qısa, hamısı bir sətirdə
                val wear = Wear.now(w, n).lines.take(3).joinToString(" · ") { l ->
                    val t = l.second
                    val body = t.substringAfter(": ").substringBefore(",").substringBefore(";").substringBefore(" və ").trim()
                    t.substringBefore(": ") + ": " + body
                }
                left(c, rv, R.id.w_wear, wear, "shirt", "s")
                w.widgetInfo(n).forEachIndexed { r, row ->
                    row.take(3).forEachIndexed { i, p ->
                        left(c, rv, INFO_IDS[r * 3 + i], p.second, p.first, "s")
                        val sec = when (p.first) { "thermo" -> "wear"; "sunrise", "sunset" -> "sky"; "wind", "clear", "leaf" -> p.first; else -> "top" }
                        rv.setOnClickPendingIntent(INFO_IDS[r * 3 + i], Notif.openSection(c, sec))
                    }
                }
                // növbəti 8 saat: tək sətirdə
                for (j in 1..8) {
                    val idx = n + j
                    if (idx >= w.hours.size) break
                    val hh = w.hours[idx]
                    val id = T_IDS[j - 1]
                    rv.setTextViewText(id, hourText(hh.time.substring(11, 16), hh.temp.roundToInt(), hh.prob, hh.mm, hh.snow))
                    rv.setTextViewCompoundDrawables(id, 0, Ic.id(c, T.iconName(hh.code), "l"), 0, 0)
                    rv.setOnClickPendingIntent(id, Notif.openSection(c, "hours"))
                }
                w.upcomingDays().forEachIndexed { i, d ->
                    val r = RemoteViews(c.packageName, R.layout.widget_day)
                    r.setTextViewText(R.id.d_name, if (i == 0) "Bu gün" else T.dayName(d.date))
                    r.setImageViewResource(R.id.d_icon, Ic.id(c, T.iconName(d.code), "xl"))
                    r.setTextViewText(R.id.d_max, "${d.max.roundToInt()}°")
                    r.setTextViewText(R.id.d_min, "${d.min.roundToInt()}°")
                    r.setTextViewText(R.id.d_rain, "${d.prob}%")
                    r.setTextViewCompoundDrawables(R.id.d_rain, Ic.id(c, "drop", "s"), 0, 0, 0)
                    r.setTextViewText(R.id.d_mm, fmtPrecip(d.mm, d.snow) + "\n" + precipShort(d.mm, d.snow))
                    r.setTextViewText(R.id.d_hours, "${w.precipHours(d)} saat")
                    r.setTextViewCompoundDrawables(R.id.d_hours, Ic.id(c, "clock", "s"), 0, 0, 0)
                    val frame = when (d.frameKind()) {
                        "qar" -> R.drawable.frame_snow
                        "yağış" -> R.drawable.frame_rain
                        "külək" -> R.drawable.frame_wind
                        else -> R.drawable.frame_none
                    }
                    r.setInt(R.id.d_box, "setBackgroundResource", frame)
                    r.setOnClickPendingIntent(R.id.d_box, Notif.openSection(c, "days"))
                    rv.addView(R.id.w_days, r)
                }
            }
            left(c, rv, R.id.w_steps, Steps.stepsText(c), "steps", "")
            left(c, rv, R.id.w_km, Steps.kmText(c), "ruler", "")
            val hr = Heart.last(c)
            rv.setTextViewText(R.id.w_heart, if (hr == null) "❤️ Ölç" else "❤️ ${hr.second}")
            rv.setOnClickPendingIntent(R.id.w_root, Notif.open(c))
            rv.setOnClickPendingIntent(R.id.w_title, Notif.openSection(c, "top"))
            rv.setOnClickPendingIntent(R.id.w_outlook, Notif.openSection(c, "outlook"))
            rv.setOnClickPendingIntent(R.id.w_wear, Notif.openSection(c, "wear"))
            rv.setOnClickPendingIntent(R.id.w_steps, Notif.openSection(c, "steps"))
            rv.setOnClickPendingIntent(R.id.w_km, Notif.openSection(c, "steps"))
            rv.setOnClickPendingIntent(R.id.w_heart, Heart.open(c))
            return rv
        }
    }
}
