package az.mehdi.hava

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import kotlin.math.roundToInt

/** Şarj vəziyyəti: şarjda olub-olmama və 100%-ə qalan vaxt */
object Battery {
    /** Telefon hazırda şarja taxılıdır? */
    fun charging(c: Context): Boolean = try {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i != null && (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 ||
            i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING)
    } catch (e: Exception) { false }

    /**
     * Vidcetdəki şarj göstəricisi üçün:
     *  null  — göstərmə (şarjda deyil və ya artıq 100%)
     *  -1    — şarjdadır, amma qalan vaxt hələ bilinmir
     *  > 0   — 100%-ə qalan millisaniyə (Androidin computeChargeTimeRemaining dəyəri)
     */
    fun remainingMs(c: Context): Long? {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return null
            val pct = (level * 100f / scale).roundToInt()
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            when {
                status == BatteryManager.BATTERY_STATUS_FULL || (plugged && pct >= 100) -> null
                status == BatteryManager.BATTERY_STATUS_CHARGING || plugged -> {
                    val bm = c.getSystemService(BatteryManager::class.java)
                    var ms = -1L
                    if (Build.VERSION.SDK_INT >= 28) ms = bm.computeChargeTimeRemaining()
                    // yalnız Androidin öz təxmini; vermirsə (-1) vidcetdə "⚡ …" göstərilir
                    if (ms > 0) ms.coerceAtLeast(60_000L) else -1L
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }
}
