package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceView
import androidx.media3.common.util.UnstableApi
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** Mühərriklərin (Media3 / mpv / VLC) geri çağırışları. */
interface PlayerCallback {
    fun onLoading()
    /** Yüklənmə/keçid mesajı və həmin cəhd üçün təxmini taymer. */
    fun onStatus(message: String, countdownMs: Long = 0L) {}
    fun onPlaying()
    fun onBuffering(active: Boolean)
    fun onFailed(message: String)
    /** Media3 codec/formatı dekodlaya bilmir: PlayerManager dərhal mpv-yə keçir (MainActivity-yə çatmır). */
    fun onCodecUnsupported(message: String) {}
    /**
     * mpv yayımı aça bilmədi. true qaytarılırsa ehtiyat link prosesi (yoda.az) başladılıb,
     * pleyer xəta göstərmir; isBackup = oynadılan link artıq yoda.az-dan alınmış linkdir.
     */
    fun onStreamFailed(isBackup: Boolean): Boolean = false
}

/**
 * Kanal linkinin serverinə ilkin sorğu (pleyerlərdən əvvəl).
 * false = server xəta qaytardı (HTTP 4xx/5xx) və ya qoşulmadı (DNS/refused/SSL) → kanal işləmir;
 * true = server normal cavab verdi; null = nəticəsiz (vaxt aşımı və ya yanlış link) → pleyerlər yoxlayır.
 */
private object Preflight {
    private val client: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val b = OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .callTimeout(5, TimeUnit.SECONDS)
            .protocols(listOf(Protocol.HTTP_1_1))
            .followRedirects(true)
            .followSslRedirects(true)
            .hostnameVerifier { _, _ -> true }
        runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            b.sslSocketFactory(ctx.socketFactory, trustAll)
        }
        b.build()
    }

    fun check(url: String, ua: String?, ref: String?): Boolean? {
        return try {
            val rb = okhttp3.Request.Builder().url(url)
                .header("User-Agent", ua?.takeIf { it.isNotBlank() } ?: "VLC/3.0.20 LibVLC/3.0.20")
            ref?.takeIf { it.isNotBlank() }?.let { rb.header("Referer", it) }
            // Yalnız başlıqlar oxunur, yayımın gövdəsi endirilmir (use bağlantını bağlayır).
            client.newCall(rb.build()).execute().use { r -> r.code < 400 }
        } catch (e: java.net.SocketTimeoutException) {
            null
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: java.io.IOException) {
            false
        } catch (e: Throwable) {
            // Ayrıca thread-də tutulmayan istənilən xəta bütün tətbiqi çökdürür: nəticəsiz sayılır, pleyerlər yoxlayır.
            null
        }
    }
}

/**
 * Pleyer meneceri: ƏVVƏL Media3 (yalnız http/https; MediaCodec + FFmpeg dekoderləri), codec/format dəstəklənmirsə DƏRHAL mpv.
 *
 * Yeni kanal: Media3 × 1 → mpv × 1 → VLC × 1 (hər biri 1 cəhd).
 * Codec dəstəklənmir (video/səs treki dekodlanmır, dekoder açılmır, format tanınmır) → gözləmədən mpv.
 * rtsp/rtmp/udp/srt və s. → birbaşa mpv. Kanalın son uğurlu pleyeri yadda saxlanır ([PlayerMemory]): mpv ilə açılmış kanal növbəti dəfə birbaşa mpv ilə başlayır. İşləyən kanal qırılsa/donsa avtomatik yenidən qoşulur (2 cəhd).
 * Hamısı uğursuz olarsa ehtiyat link (yoda.az) və ya "Kanal İşləmir".
 */
@androidx.annotation.OptIn(UnstableApi::class)
class PlayerManager(
    context: Context,
    private val view: SurfaceView,
    private val cb: PlayerCallback
) {
    private enum class Eng { EXO, MPV, VLC }

    private companion object {
        // Bir cəhdin açılış vaxt aşımı və cəhd sayı. Yeni kanal: Media3 1 + mpv 3; işləmiş kanalın bərpası: mpv 2.
        const val EXO_TIMEOUT_MS = 5_000L
        const val MPV_TIMEOUT_MS = 5_000L
        const val VLC_TIMEOUT_MS = 6_000L
        const val NEW_ATTEMPTS = 1
        const val RECOVER_ATTEMPTS = 1
        // Üçüncü ehtiyat pleyer (VLC): mpv-nin bütün cəhdləri bitəndən sonra.
        const val VLC_ATTEMPTS = 1
        const val PREFLIGHT_MS = 5_000L
        // Avtomatik bərpa: görüntü/vaxt (bufer göstərilmədən) 5 s donursa kanal yenidən qoşulur.
        // Buferlənmə zamanı pleyer ÖZÜ qaldığı yerdən davam edir (yenidən qoşulma canlı yayımın sonuna tullandırardı):
        // yalnız bufer 30 s-dən uzun dolmursa kanal yenidən qoşulur.
        const val STALL_BUFFERING_MS = 30_000L
        const val STALL_FREEZE_MS = 5_000L
        // Pleyer "oynayır" deyir, amma vaxt göstəricisi heç gəlmirsə (qara ekran/boş yayım).
        const val NO_TIME_MS = 10_000L
        const val WATCHDOG_MS = 1_000L
        const val RECONNECT_DELAY_MS = 0L
        // Əvvəl işləmiş kanalın bərpası bu müddətdən uzun çəksə yüklənmə göstəricisi çıxır; qısa bərpa görünmür.
        const val SILENT_RECOVERY_MS = 3_500L
        const val RETRY_ALL_DELAY_MS = 2_000L
        // Ağıllı bufer: 2 dəqiqədə 3 buferlənmə → səviyyə +1; 20 dəqiqə buferlənmə yoxdursa → səviyyə -1.
        const val STALL_WINDOW_MS = 120_000L
        const val STALLS_TO_RAISE = 3
        const val CALM_LOWER_MS = 20 * 60_000L
        // Qonşu kanalların server adı əvvəlcədən həll edilir; eyni ad bu müddətdə təkrar həll edilmir.
        const val WARM_TTL_MS = 60_000L
        const val ICON_MEDIA3 = "\uD83D\uDC99" // 💙
        const val ICON_MPV = "\uD83D\uDC9C"    // 💜
        const val ICON_VLC = "\uD83E\uDDE1"    // 🧡
    }

    private val ui = Handler(Looper.getMainLooper())
    private var url: String? = null
    private var ua: String? = null
    private var ref: String? = null
    // true: oynadılan link yoda.az ehtiyat linkidir (tokenlidir)
    private var usingBackup = false
    private var resume = false
    private var released = false
    private var playedOk = false
    private var everPlayed = false
    private var reconnecting = false
    private var userPaused = false
    private var bufferingSince = 0L
    private var lastPos = -1L
    private var lastPosAt = 0L
    // Cari mühərrik; cari cəhd nömrəsi (yalnız mpv üçün sayılır) / icazə verilən cəhd sayı.
    private var cur = Eng.MPV
    private var attempt = 0
    private var maxAttempts = NEW_ATTEMPTS
    // İlkin server sorğusunun nömrəsi: kanal dəyişəndə/dayandırılanda köhnə nəticə ignor edilir.
    private var preflightGen = 0
    // Kanal başına ağıllı bufer.
    private val bufMemory = BufferMemory(context)
    private var bufLevel = 0
    private val stallTimes = ArrayDeque<Long>()
    private var lastStallAt = 0L
    private val warmedAt = HashMap<String, Long>()

    private fun pos(): Long = when (cur) {
        Eng.EXO -> exo.position()
        Eng.MPV -> mpv.position()
        Eng.VLC -> vlc.position()
    }

    private val watchdogRun: Runnable = object : Runnable {
        override fun run() {
            if (released || url == null || !playedOk) return
            val now = SystemClock.elapsedRealtime()
            var stalled = false
            // Uzun müddət buferlənmədən işləyən kanalın bufer səviyyəsi bir pillə azalır (növbəti açılışdan tətbiq olunur).
            if (bufLevel > 0 && bufferingSince == 0L && now - lastStallAt >= CALM_LOWER_MS) {
                lastStallAt = now
                setBufLevel(bufLevel - 1)
            }
            if (!userPaused) {
                if (bufferingSince != 0L) {
                    // Buferlənmə gedir: vaxtın donması normaldır, yenidən qoşulmur; pleyer qaldığı yerdən davam edəcək.
                    lastPosAt = now
                    if (now - bufferingSince >= STALL_BUFFERING_MS) stalled = true
                } else {
                    val p = pos()
                    if (p > 0) {
                        if (p != lastPos) { lastPos = p; lastPosAt = now }
                        else if (now - lastPosAt >= STALL_FREEZE_MS) stalled = true
                    } else if (now - lastPosAt > NO_TIME_MS) {
                        // "Oynayır" dedi, amma vaxt heç irəliləmir: yenidən qoşulur.
                        stalled = true
                    }
                }
            }
            if (stalled) { reconnect("Yayım donub"); return }
            ui.postDelayed(this, WATCHDOG_MS)
        }
    }
    private val slowRecoveryRun: Runnable = Runnable { if (!released && url != null && reconnecting) cb.onLoading() }
    private val restartRun: Runnable = Runnable {
        if (released || url == null) return@Runnable
        reconnecting = false
        startEngine(retry = true)
    }
    private val retryAllRun: Runnable = Runnable {
        if (released || url == null) return@Runnable
        attempt = 0
        maxAttempts = NEW_ATTEMPTS
        reconnecting = false
        begin()
    }

    /** Buferlənmə başladı: tez-tez təkrarlanırsa kanalın bufer səviyyəsi qalxır. */
    private fun noteStall() {
        val now = SystemClock.elapsedRealtime()
        lastStallAt = now
        stallTimes.addLast(now)
        while (stallTimes.isNotEmpty() && now - stallTimes.first() > STALL_WINDOW_MS) stallTimes.removeFirst()
        if (stallTimes.size >= STALLS_TO_RAISE && bufLevel < BufferProfile.MAX_LEVEL) {
            stallTimes.clear()
            setBufLevel(bufLevel + 1)
        }
    }

    /** Bufer səviyyəsini dəyişir və yadda saxlayır. mpv-də dərhal, Media3/VLC-də növbəti (təkrar) açılışdan tətbiq olunur. */
    private fun setBufLevel(level: Int) {
        val l = level.coerceIn(0, BufferProfile.MAX_LEVEL)
        if (l == bufLevel) return
        android.util.Log.i("IPTV-PLAYER", "Bufer səviyyəsi $bufLevel → $l")
        bufLevel = l
        if (!usingBackup) url?.let { bufMemory.set(it, l) }
        if (cur == Eng.MPV) mpv.setBufferLevel(l)
    }

    /** Qonşu kanalların server adlarını əvvəlcədən həll edir: kanal dəyişəndə DNS gözləmək lazım olmur. */
    fun warm(urls: List<String>) {
        if (released) return
        val now = SystemClock.elapsedRealtime()
        if (warmedAt.size > 200) warmedAt.clear()
        val hosts = urls.mapNotNull { u ->
            val sch = u.substringBefore("://", "").lowercase()
            if (sch != "http" && sch != "https") null else runCatching { java.net.URI(u).host }.getOrNull()
        }.distinct().filter { h -> now - (warmedAt[h] ?: 0L) > WARM_TTL_MS }.take(4)
        if (hosts.isEmpty()) return
        for (h in hosts) warmedAt[h] = now
        Thread {
            for (h in hosts) runCatching { java.net.InetAddress.getAllByName(h) }
        }.apply { isDaemon = true }.start()
    }

    /** Hər mühərrik üçün ayrıca geri çağırış: o an aktiv olmayan mühərrikin gecikmiş hadisələri ignor edilir. */
    private fun makeCb(tag: Eng): PlayerCallback = object : PlayerCallback {
        override fun onLoading() {}
        override fun onPlaying() {
            if (released || url == null || cur != tag) return
            playedOk = true
            everPlayed = true
            reconnecting = false
            // Uğurlu pleyer yadda saxlanır (ehtiyat yoda.az linki tokenlidir, saxlanmır).
            if (!usingBackup) url?.let { memory.remember(it, when (tag) { Eng.EXO -> 'e'; Eng.MPV -> 'm'; Eng.VLC -> 'v' }) }
            bufferingSince = 0L
            lastPos = -1L
            lastPosAt = SystemClock.elapsedRealtime()
            ui.removeCallbacks(watchdogRun)
            ui.postDelayed(watchdogRun, WATCHDOG_MS)
            cb.onPlaying()
        }
        override fun onBuffering(active: Boolean) {
            if (released || url == null || cur != tag) return
            if (active) {
                if (bufferingSince == 0L) { bufferingSince = SystemClock.elapsedRealtime(); noteStall() }
            } else bufferingSince = 0L
            cb.onBuffering(active)
        }
        override fun onFailed(message: String) {
            if (released || url == null || reconnecting || cur != tag) return
            // Yayım əvvəl işləyibsə (sonra qırılıbsa) yenidən qoşulur; ilk açılışda isə növbəti cəhd / mpv.
            if (playedOk) reconnect(message) else fallback(message)
        }
        override fun onCodecUnsupported(message: String) {
            if (released || url == null || reconnecting || cur != tag || tag != Eng.EXO) return
            // Codec dəstəklənmir: heç bir cəhd/gözləmə yoxdur, dərhal mpv.
            switchToMpv(message, codec = true)
        }
    }

    // Kanal → son uğurlu pleyer (növbəti açılış tez olsun).
    private val memory = PlayerMemory(context)

    private val mpv: MpvEngine = MpvEngine(context, view, makeCb(Eng.MPV))
    private val exo: Media3Engine = Media3Engine(context, view, makeCb(Eng.EXO))
    // Üçüncü ehtiyat: VLC (libVLC ilk istifadədə yaradılır, əvvəl RAM tutmur).
    private val vlc: VlcEngine = VlcEngine(context, view, makeCb(Eng.VLC))

    /** Media3 yalnız http/https açır; qalan sxemlər (rtsp, rtmp, udp, srt ...) birbaşa mpv-yə verilir. */
    private fun exoEligible(u: String): Boolean {
        val scheme = u.substringBefore("://", "").lowercase()
        return scheme == "http" || scheme == "https"
    }

    private fun startEngine(retry: Boolean = false) {
        when (cur) {
            Eng.EXO -> startExo(retry)
            Eng.MPV -> startMpv(retry)
            Eng.VLC -> startVlc(retry)
        }
    }

    private fun startExo(retry: Boolean = false) {
        val u = url ?: return
        val isRetry = retry || reconnecting || attempt > 0
        if (!(retry && everPlayed)) cb.onStatus(
            if (isRetry) "Təkrar cəhd edilir (Media3 Player)" else "Yüklənir (Media3 Player)",
            EXO_TIMEOUT_MS
        )
        playedOk = false
        // Eyni video səthini yalnız bir mühərrik tuta bilər: əvvəl mpv və VLC ayrılır.
        vlc.releaseSurface()
        mpv.stop()
        mpv.releaseSurface()
        exo.play(u, ua, ref, EXO_TIMEOUT_MS, bufLevel)
    }

    private fun startMpv(retry: Boolean = false, message: String? = null) {
        val u = url ?: return
        val isRetry = retry || reconnecting || attempt > 0
        // Əvvəl işləmiş kanalın təkrar cəhdində yükləmə paneli dərhal çıxmır: son kadr ekranda qalır, bərpa fonda gedir.
        if (!(retry && everPlayed)) cb.onStatus(
            message ?: if (isRetry) "Təkrar cəhd edilir (mpv Player)" else "Yüklənir (mpv Player)",
            MPV_TIMEOUT_MS
        )
        playedOk = false
        // Media3 və VLC səthi tam azad edilir (mpv hwdec/səth götürəcək).
        vlc.releaseSurface()
        exo.releaseSurface()
        mpv.play(u, ua, ref, MPV_TIMEOUT_MS, bufLevel)
    }

    private fun startVlc(retry: Boolean = false, message: String? = null) {
        val u = url ?: return
        val isRetry = retry || reconnecting || attempt > 0
        if (!(retry && everPlayed)) cb.onStatus(
            message ?: if (isRetry) "Təkrar cəhd edilir (VLC Player)" else "Yüklənir (VLC Player)",
            VLC_TIMEOUT_MS
        )
        playedOk = false
        // Səthi yalnız bir mühərrik tutur: Media3 və mpv tam ayrılır.
        exo.releaseSurface()
        mpv.stop()
        mpv.releaseSurface()
        vlc.play(u, ua, ref, VLC_TIMEOUT_MS, bufLevel)
    }

    /** mpv-nin bütün cəhdləri bitdi: üçüncü ehtiyat pleyer VLC-yə keçid. */
    private fun switchToVlc(reason: String) {
        if (released || url == null) return
        android.util.Log.w("IPTV-PLAYER", "mpv → VLC: $reason")
        cur = Eng.VLC
        attempt = 0
        maxAttempts = VLC_ATTEMPTS
        playedOk = false
        bufferingSince = 0L
        ui.removeCallbacks(watchdogRun)
        startVlc(retry = true, message = "mpv açmadı — VLC Player")
    }

    /** Media3-dən mpv-yə keçid: cəhd sayğacı sıfırlanır, mpv-nin tam cəhd sayı qalır. */
    private fun switchToMpv(reason: String, codec: Boolean) {
        if (released || url == null) return
        android.util.Log.w("IPTV-PLAYER", "Media3 → mpv (${if (codec) "codec" else "xəta"}): $reason")
        cur = Eng.MPV
        attempt = 0
        playedOk = false
        bufferingSince = 0L
        ui.removeCallbacks(watchdogRun)
        startMpv(
            retry = true,
            message = if (codec) "Codec dəstəklənmir — mpv Player" else "Media3 açmadı — mpv Player"
        )
    }

    fun play(newUrl: String, newUa: String? = null, newRef: String? = null, backup: Boolean = false) {
        if (released) return
        url = newUrl; ua = newUa; ref = newRef
        usingBackup = backup
        resume = false
        attempt = 0
        maxAttempts = NEW_ATTEMPTS
        playedOk = false
        everPlayed = false
        reconnecting = false
        userPaused = false
        bufferingSince = 0L
        // Kanalın yadda saxlanmış bufer səviyyəsi (ehtiyat tokenli link üçün həmişə 0).
        bufLevel = if (backup) 0 else bufMemory.level(newUrl)
        stallTimes.clear()
        lastStallAt = SystemClock.elapsedRealtime()
        cancelRecovery()
        stopEngines()
        cb.onLoading()
        begin()
    }

    private fun stopEngines() {
        exo.stop()
        mpv.stop()
        vlc.stop()
    }

    /**
     * Açılış ardıcıllığı: əvvəl serverə qısa sorğu, sonra Media3 (1 cəhd), uğursuz/codec olarsa mpv (3 cəhd),
     * mpv də açmasa VLC (2 cəhd, üçüncü ehtiyat).
     * Hamısı uğursuz olarsa ehtiyat link (yoda.az) və ya "Kanal İşləmir".
     */
    private fun begin() {
        val u = url ?: return
        // Əvvəl mpv/VLC ilə açılmış kanal birbaşa həmin pleyerlə başlayır (əvvəlki pleyerlərin cəhdi atlanır).
        val pref = if (usingBackup) null else memory.preferred(u)
        cur = when {
            pref == 'v' -> Eng.VLC
            pref == 'm' -> Eng.MPV
            exoEligible(u) -> Eng.EXO
            else -> Eng.MPV
        }
        if (cur == Eng.VLC) maxAttempts = VLC_ATTEMPTS
        val scheme = u.substringBefore("://", "").lowercase()
        // Əvvəl kanalın serverinə sorğu: xəta cavabı (404/403/5xx, qoşulmur) alınırsa kanal işləmir, pleyerlər yoxlanmır.
        // Ehtiyat (yoda.az tokenli) linkdə sorğu göndərilmir.
        if (!usingBackup && (scheme == "http" || scheme == "https")) {
            // Server yoxlaması pleyerin açılması ilə PARALEL gedir (əvvəl ardıcıl idi və kanal dəyişmə 1-5 s gec açılırdı).
            // Server xəta qaytarsa və pleyer hələ oynamırsa kanal işləmir sayılır; pleyer artıq oynayırsa cavab nəzərə alınmır.
            val g = ++preflightGen
            val pu = u; val pua = ua; val pref = ref
            Thread {
                val r = Preflight.check(pu, pua, pref)
                ui.post {
                    if (released || g != preflightGen || url != pu || playedOk) return@post
                    if (r == false) {
                        android.util.Log.w("IPTV-PLAYER", "Server xəta qaytardı/qoşulmadı → kanal işləmir: $pu")
                        failAll()
                    }
                }
            }.start()
        }
        startEngine()
    }

    private fun fallback(message: String) {
        // Media3 açmadı (codec xətası olmayan səbəblə): mpv ikinci rəy kimi yoxlanır.
        if (cur == Eng.EXO) { switchToMpv(message, codec = false); return }
        android.util.Log.w("IPTV-PLAYER", "Cəhd ${attempt + 1}/$maxAttempts uğursuz (${cur.name}): $message")
        attempt++
        if (attempt >= maxAttempts) {
            // mpv bitdi → VLC (üçüncü ehtiyat); VLC də bitdisə kanal işləmir.
            if (cur == Eng.MPV) switchToVlc(message) else failAll()
            return
        }
        if (cur == Eng.VLC) startVlc(retry = true) else startMpv(retry = true)
    }

    private fun failAll() {
        preflightGen++ // gözləyən server yoxlaması ikinci dəfə xəta çağırmasın
        stopEngines()
        // Əsas link işləmir: ehtiyat link (yoda.az) prosesi başladılırsa xəta göstərilmir.
        if (!released && url != null && cb.onStreamFailed(usingBackup)) return
        if (everPlayed) {
            // Kanal əvvəl işləyib: server müvəqqəti düşübsə, avtomatik təkrar yoxlanılır.
            cb.onLoading()
            cb.onStatus("Kanal cavab vermir — yenidən yoxlanılır", RETRY_ALL_DELAY_MS)
            ui.removeCallbacks(retryAllRun)
            ui.postDelayed(retryAllRun, RETRY_ALL_DELAY_MS)
        } else {
            cb.onFailed("Kanal İşləmir")
        }
    }

    private fun cancelRecovery() {
        preflightGen++
        ui.removeCallbacks(watchdogRun)
        ui.removeCallbacks(restartRun)
        ui.removeCallbacks(retryAllRun)
        ui.removeCallbacks(slowRecoveryRun)
    }

    /** Yayım işləyərkən qırılıb/donub: kanalı avtomatik yenidən qoşur (eyni mühərriklə; o da açmasa mpv). */
    private fun reconnect(reason: String) {
        if (released || url == null || reconnecting) return
        android.util.Log.w("IPTV-PLAYER", "Yenidən qoşulma: $reason")
        if (!everPlayed) cb.onStatus("Təkrar cəhd edilir", MPV_TIMEOUT_MS)
        reconnecting = true
        playedOk = false
        bufferingSince = 0L
        attempt = 0
        maxAttempts = RECOVER_ATTEMPTS
        ui.removeCallbacks(watchdogRun)
        // Əvvəl oynamış kanalın bərpası sakit gedir: son kadr ekranda qalır, yüklənmə yalnız uzun çəkəndə görünür.
        ui.removeCallbacks(slowRecoveryRun)
        if (everPlayed) ui.postDelayed(slowRecoveryRun, SILENT_RECOVERY_MS) else cb.onLoading()
        // Heç nə gözlənmir: təkrar cəhd dərhal (eyni döngədə) başlayır.
        ui.removeCallbacks(restartRun)
        if (RECONNECT_DELAY_MS <= 0L) ui.post(restartRun) else ui.postDelayed(restartRun, RECONNECT_DELAY_MS)
    }

    fun attach() {
        if (released) return
        val u = url
        if (resume && u != null) play(u, ua, ref, usingBackup)
    }

    /** Yayımı tam dayandırır (yoda.az linki gözlənərkən köhnə kanal səsi/şəkli qalmasın). */
    fun halt() {
        if (released) return
        cancelRecovery()
        stopEngines()
        url = null
        resume = false
        playedOk = false
        everPlayed = false
        reconnecting = false
    }

    fun stopForBackground() {
        if (released) return
        resume = url != null
        cancelRecovery()
        exo.stopForBackground()
        mpv.stopForBackground()
        vlc.stopForBackground()
    }

    fun isPaused(): Boolean = userPaused

    fun hasUrl(): Boolean = url != null

    fun togglePause() {
        userPaused = !userPaused
        if (userPaused) ui.removeCallbacks(watchdogRun)
        else { lastPosAt = SystemClock.elapsedRealtime(); lastPos = -1L; bufferingSince = 0L; if (playedOk) ui.postDelayed(watchdogRun, WATCHDOG_MS) }
        when (cur) {
            Eng.EXO -> exo.togglePause()
            Eng.MPV -> mpv.togglePause()
            Eng.VLC -> vlc.togglePause()
        }
    }

    fun stats(): PlayerStats? {
        val s = when (cur) {
            Eng.EXO -> exo.stats()
            Eng.MPV -> mpv.stats()
            Eng.VLC -> vlc.stats()
        } ?: return null
        // Pleyer işarəsi: 💙 = Media3, 💜 = mpv, 🧡 = VLC
        val icon = when (cur) { Eng.EXO -> ICON_MEDIA3; Eng.MPV -> ICON_MPV; Eng.VLC -> ICON_VLC }
        return PlayerStats(s.width, s.height, s.bufferMs, s.level, s.bps, icon, s.bitrate)
    }

    fun release() {
        if (released) return
        released = true
        cancelRecovery()
        exo.release()
        mpv.release()
        vlc.release()
    }
}
