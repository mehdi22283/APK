package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import kotlin.math.roundToInt

class WeatherWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        Scheduler.start(context)
        Midnight.schedule(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Scheduler.start(context)
        Midnight.schedule(context)
        refresh(context)
        if (WeatherApi.ageMin(context) > 10) Scheduler.now(context)
    }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return
            m.updateAppWidget(ids, build(c))
        }

        private fun build(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val w = WeatherApi.cached(c)
            val n = w?.nowIndex() ?: -1
            rv.setTextViewText(R.id.w_date, T.dateLine())
            rv.removeAllViews(R.id.w_days)
            if (w == null || n < 0) {
                rv.setTextViewText(R.id.w_title, "Yenilənir…")
                rv.setTextViewText(R.id.w_outlook, "İnternet bağlantısı olanda məlumat yüklənəcək")
                rv.setTextViewText(R.id.w_hours, "")
                rv.setTextViewText(R.id.w_info, "")
            } else {
                val h = w.hours[n]
                rv.setTextViewText(R.id.w_title, "${T.icon(h.code)} ${h.temp.roundToInt()}°  ${T.desc(h.code)}")
                rv.setTextViewText(R.id.w_outlook, w.outlook()?.text ?: "")
                rv.setTextViewText(R.id.w_hours, w.hourLine(n))
                rv.setTextViewText(R.id.w_info, w.widgetInfo(n))
                w.upcomingDays().forEachIndexed { i, d ->
                    val r = RemoteViews(c.packageName, R.layout.widget_day)
                    r.setTextViewText(R.id.d_name, if (i == 0) "Bu gün" else T.dayName(d.date))
                    r.setTextViewText(R.id.d_icon, T.icon(d.code))
                    r.setTextViewText(R.id.d_max, "${d.max.roundToInt()}°")
                    r.setTextViewText(R.id.d_min, "${d.min.roundToInt()}°")
                    r.setTextViewText(R.id.d_rain, "💧${d.prob}%")
                    rv.addView(R.id.w_days, r)
                }
            }
            rv.setTextViewText(R.id.w_steps, "🚶 ${Steps.stepsText(c)}")
            rv.setTextViewText(R.id.w_km, "📏 ${Steps.kmText(c)}")
            val hr = Heart.last(c)
            rv.setTextViewText(R.id.w_heart, if (hr == null) "❤️\nÖlç" else "❤️ ${hr.second}\n${Heart.timeText(hr.first)}")
            rv.setOnClickPendingIntent(R.id.w_root, Notif.open(c))
            rv.setOnClickPendingIntent(R.id.w_heart, Heart.open(c))
            return rv
        }
    }
}
