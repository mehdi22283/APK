package az.mehdi.hava

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Range
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Arxa kamera + flaş ilə ürək döyüntüsü ölçmə (fotoplətizmoqrafiya).
 * Kamera ən yüksək kadr sürətində işləyir; nəticə sabitləşən kimi ölçmə dayanır.
 * Bu təxmini ölçmədir, tibbi cihaz deyil.
 */
class HeartActivity : Activity() {
    private val BG = Color.parseColor("#0F1B2A")
    private val CARD = Color.parseColor("#1B2B3F")
    private val GREY = Color.parseColor("#90A4AE")
    private val RED = Color.parseColor("#FF8A80")

    private val SETTLE = 1.5       // saniyə: sabitlənmə
    private val MIN_MEASURE = 6.0  // saniyə: bundan tez nəticə verilmir
    private val MAX_MEASURE = 15.0 // saniyə: bundan sonra son nəticə

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var statusView: TextView
    private lateinit var bpmView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var wave: WaveView
    private lateinit var btn: Button
    private lateinit var histBox: LinearLayout

    private var cam: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private var reqBuilder: CaptureRequest.Builder? = null

    @Volatile private var running = false
    private var t0 = -1L
    private var locked = false
    private var frame = 0
    private var lastWave = 0.0
    private var lastCheck = 0.0
    private val recent = ArrayList<Int>()
    private val ts = ArrayList<Double>()
    private val vs = ArrayList<Double>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        sv.addView(root)
        setContentView(sv)

        fun text(s: String, sp: Float, col: Int, bold: Boolean = false): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = sp
            t.setTextColor(col)
            if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
            root.addView(t)
            return t
        }

        text("❤️ Ürək döyüntüsü", 22f, Color.WHITE, true)
        statusView = text("Barmağınızı arxa kameranın və flaşın üzərinə yüngülcə qoyun.", 14f, GREY)
        statusView.setPadding(0, dp(8), 0, dp(8))

        bpmView = text("--", 64f, RED, true)
        bpmView.gravity = Gravity.CENTER
        val unit = text("döyüntü / dəq", 14f, GREY)
        unit.gravity = Gravity.CENTER

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        wave = WaveView(this)
        root.addView(wave, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110)).apply { topMargin = dp(12) })

        btn = Button(this)
        btn.text = "▶ Ölç"
        btn.setOnClickListener { if (running) stopAll("Dayandırıldı.") else start() }
        root.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        val hint = text("Barmağı kameranı və flaşı tam örtəcək şəkildə, çox basmadan sabit tutun. Nəticə sabitləşən kimi ölçmə dayanır (adətən 8–12 saniyə). Flaş bir az qızır, bu normaldır.", 12f, GREY)
        hint.setPadding(0, dp(12), 0, 0)
        val warn = text("Bu təxmini ölçmədir, tibbi cihaz deyil. Özünüzü pis hiss edirsinizsə həkimə müraciət edin.", 12f, GREY)
        warn.setPadding(0, dp(6), 0, dp(12))

        text("Son ölçmələr", 14f, GREY, true)
        histBox = LinearLayout(this)
        histBox.orientation = LinearLayout.VERTICAL
        val bgd = android.graphics.drawable.GradientDrawable()
        bgd.setColor(CARD)
        bgd.cornerRadius = dp(16).toFloat()
        histBox.background = bgd
        histBox.setPadding(dp(14), dp(10), dp(14), dp(10))
        root.addView(histBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        renderHistory()

        // widget-dən ürəyə basılıbsa dərhal başla
        if (intent?.getBooleanExtra("auto", false) == true) ui.post { if (!running) start() }
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        if (i.getBooleanExtra("auto", false) && !running) start()
    }

    override fun onPause() {
        if (running) stopAll("Dayandırıldı.")
        super.onPause()
    }

    override fun onDestroy() {
        running = false
        closeCamera()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun renderHistory() {
        histBox.removeAllViews()
        val h = Heart.history(this)
        if (h.isEmpty()) {
            val t = TextView(this)
            t.text = "Hələ ölçmə yoxdur"
            t.setTextColor(GREY)
            histBox.addView(t)
            return
        }
        h.forEach {
            val t = TextView(this)
            t.text = "❤️ ${it.second} d/dəq   ·   ${Heart.timeText(it.first)}"
            t.setTextColor(Color.WHITE)
            t.textSize = 14f
            t.setPadding(0, dp(3), 0, dp(3))
            histBox.addView(t)
        }
    }

    // ---------- Ölçmənin idarəsi ----------
    private fun start() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 10)
            return
        }
        t0 = -1L
        locked = false
        frame = 0
        lastWave = 0.0
        lastCheck = 0.0
        recent.clear()
        ts.clear()
        vs.clear()
        bpmView.text = "--"
        progress.progress = 0
        wave.data = DoubleArray(0)
        wave.invalidate()
        statusView.text = "Kamera açılır…"
        btn.text = "■ Dayandır"
        running = true
        openCamera()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 10) {
            if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) start()
            else statusView.text = "Kamera icazəsi verilmədi. Ürək döyüntüsünü ölçmək üçün icazə lazımdır."
        }
    }

    private fun stopAll(msg: String) {
        running = false
        closeCamera()
        btn.text = "▶ Ölç"
        statusView.text = msg
    }

    private fun fail(msg: String) {
        ui.post { stopAll(msg) }
    }

    private fun placeMsg(): String = "Barmağınızı kameranın və flaşın üzərinə qoyun (yüngül basın)"

    // ---------- Kamera ----------
    private fun openCamera() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val ch = cm.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK &&
                    ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                fail("Flaşlı arxa kamera tapılmadı.")
                return
            }
            val map = cm.getCameraCharacteristics(id).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.YUV_420_888)
            if (sizes == null || sizes.isEmpty()) {
                fail("Kamera formatı dəstəklənmir.")
                return
            }
            val size = sizes.filter { it.width >= 160 }.minByOrNull { it.width * it.height }
                ?: sizes.minByOrNull { it.width * it.height }!!

            val th = HandlerThread("heart-cam")
            th.start()
            thread = th
            val h = Handler(th.looper)
            bg = h

            val rd = ImageReader.newInstance(size.width, size.height, ImageFormat.YUV_420_888, 3)
            rd.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    try {
                        if (running) onFrame(img)
                    } catch (e: Exception) {
                    } finally {
                        try { img.close() } catch (e: Exception) {}
                    }
                }
            }, h)
            reader = rd

            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) {
                    cam = c
                    createSession(c, cm, id)
                }

                override fun onDisconnected(c: CameraDevice) {
                    c.close()
                    cam = null
                    if (running) fail("Kamera ilə əlaqə kəsildi.")
                }

                override fun onError(c: CameraDevice, e: Int) {
                    c.close()
                    cam = null
                    fail("Kamera açılmadı (xəta $e). Başqa tətbiq kameranı işlədirsə, onu bağlayın.")
                }
            }, h)
        } catch (e: SecurityException) {
            fail("Kamera icazəsi yoxdur.")
        } catch (e: Exception) {
            fail("Kamera açılmadı.")
        }
    }

    private fun createSession(c: CameraDevice, cm: CameraManager, id: String) {
        try {
            val surface = reader!!.surface
            val b = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(surface)
            b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)
            // ən yüksək kadr sürəti (60-a qədər)
            val ranges = cm.getCameraCharacteristics(id).get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val best = ranges?.filter { it.upper <= 60 }?.maxWithOrNull(compareBy<Range<Int>>({ it.upper }, { it.lower }))
            if (best != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, best)
            reqBuilder = b
            @Suppress("DEPRECATION")
            c.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        s.setRepeatingRequest(b.build(), null, bg)
                        ui.post { if (running) statusView.text = placeMsg() }
                    } catch (e: Exception) {
                        fail("Kamera başladıla bilmədi.")
                    }
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    fail("Kamera qurula bilmədi.")
                }
            }, bg)
        } catch (e: Exception) {
            fail("Kamera qurula bilmədi.")
        }
    }

    /** Parlaqlıq və rəng avtomatik dəyişməsin deyə kilidlə (yoxsa döyüntü siqnalı silinir). */
    private fun lockExposure() {
        val b = reqBuilder ?: return
        val s = session ?: return
        try {
            b.set(CaptureRequest.CONTROL_AE_LOCK, true)
            b.set(CaptureRequest.CONTROL_AWB_LOCK, true)
            s.setRepeatingRequest(b.build(), null, bg)
        } catch (e: Exception) {
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (e: Exception) {}
        try { cam?.close() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { thread?.quitSafely() } catch (e: Exception) {}
        session = null
        cam = null
        reader = null
        thread = null
        bg = null
        reqBuilder = null
    }

    // ---------- Kadr emalı ----------
    private fun onFrame(img: Image) {
        val t = img.timestamp
        val c = rgbMean(img)
        val ok = c[0] > 80 && c[0] > 1.5 * c[1]
        frame++
        if (!ok) {
            if (t0 >= 0) {
                t0 = -1L
                locked = false
                lastWave = 0.0
                lastCheck = 0.0
                recent.clear()
                ts.clear()
                vs.clear()
            }
            if (frame % 8 == 0) ui.post {
                if (running) {
                    statusView.text = placeMsg()
                    progress.progress = 0
                    bpmView.text = "--"
                }
            }
            return
        }
        if (t0 < 0) t0 = t
        val el = (t - t0) / 1e9
        if (!locked && el >= 0.8) {
            locked = true
            lockExposure()
        }
        if (el < SETTLE) {
            if (frame % 8 == 0) ui.post { if (running) statusView.text = "Sabitlənir… tərpətməyin" }
            return
        }
        ts.add(el)
        vs.add(c[0])
        val n = ts.size
        val measured = el - SETTLE

        // dalğa və irəliləyiş (≈ 7 dəfə / saniyə)
        if (el - lastWave >= 0.14) {
            lastWave = el
            val from = maxOf(0, n - 200)
            val tt = ts.subList(from, n)
            val dur = tt.last() - tt.first()
            val fps = if (dur > 0) (tt.size - 1) / dur else 30.0
            val f = bandpass(vs.subList(from, n).toDoubleArray(), fps)
            val pct = ((measured / MAX_MEASURE) * 100).toInt().coerceIn(0, 99)
            ui.post {
                if (running) {
                    wave.data = f
                    wave.invalidate()
                    progress.progress = pct
                    statusView.text = "Ölçülür… tərpətməyin"
                }
            }
        }

        // yarım saniyədən bir qiymətləndir; sabitləşibsə dərhal bitir
        if (measured >= MIN_MEASURE - 2.0 && el - lastCheck >= 0.5) {
            lastCheck = el
            val e = estimate(ts, vs)
            if (e != null) {
                recent.add(e)
                ui.post { if (running) bpmView.text = "≈ $e" }
            } else {
                recent.clear()
            }
            val stable = recent.size >= 4 &&
                recent.takeLast(4).let { (it.maxOrNull() ?: 0) - (it.minOrNull() ?: 0) <= 2 }
            if (measured >= MIN_MEASURE && stable) {
                running = false
                val result = recent.last()
                ui.post { onResult(result) }
                return
            }
        }

        if (measured >= MAX_MEASURE) {
            running = false
            val result = estimate(ts, vs)
            ui.post { onResult(result) }
        }
    }

    private fun onResult(bpm: Int?) {
        closeCamera()
        btn.text = "▶ Yenidən ölç"
        progress.progress = 100
        if (bpm == null) {
            bpmView.text = "--"
            statusView.text = "Dəqiq ölçülmədi. Barmağı sabit və yüngül tutub təkrar yoxlayın."
        } else {
            bpmView.text = bpm.toString()
            statusView.text = "Ölçmə tamamlandı ✅"
            Heart.save(this, bpm)
            WeatherWidget.refresh(this)
            renderHistory()
        }
    }

    /** Mərkəzi bölgənin orta R, G, B qiymətləri (YUV -> RGB). */
    private fun rgbMean(img: Image): DoubleArray {
        val w = img.width
        val h = img.height
        val yP = img.planes[0]
        val uP = img.planes[1]
        val vP = img.planes[2]
        val yB = yP.buffer
        val uB = uP.buffer
        val vB = vP.buffer
        var sr = 0.0
        var sg = 0.0
        var sb = 0.0
        var cnt = 0
        var y = h / 4
        while (y < h * 3 / 4) {
            var x = w / 4
            while (x < w * 3 / 4) {
                val yy = yB.get(y * yP.rowStride + x * yP.pixelStride).toInt() and 0xFF
                val u = (uB.get((y / 2) * uP.rowStride + (x / 2) * uP.pixelStride).toInt() and 0xFF) - 128
                val v = (vB.get((y / 2) * vP.rowStride + (x / 2) * vP.pixelStride).toInt() and 0xFF) - 128
                sr += (yy + 1.402 * v).coerceIn(0.0, 255.0)
                sg += (yy - 0.344 * u - 0.714 * v).coerceIn(0.0, 255.0)
                sb += (yy + 1.772 * u).coerceIn(0.0, 255.0)
                cnt++
                x += 2
            }
            y += 2
        }
        if (cnt == 0) return doubleArrayOf(0.0, 0.0, 0.0)
        return doubleArrayOf(sr / cnt, sg / cnt, sb / cnt)
    }

    // ---------- Siqnal emalı ----------
    private fun movingAvg(v: DoubleArray, half: Int): DoubleArray {
        val n = v.size
        val ps = DoubleArray(n + 1)
        for (i in 0 until n) ps[i + 1] = ps[i] + v[i]
        return DoubleArray(n) {
            val a = maxOf(0, it - half)
            val b = minOf(n - 1, it + half)
            (ps[b + 1] - ps[a]) / (b - a + 1)
        }
    }

    /** Yavaş sürüşməni at, kiçik səs-küyü hamarla. */
    private fun bandpass(v: DoubleArray, fps: Double): DoubleArray {
        if (v.size < 5) return v
        val slow = movingAvg(v, maxOf(3, (fps * 0.75).toInt()))
        val hp = DoubleArray(v.size) { v[it] - slow[it] }
        return movingAvg(hp, maxOf(1, (fps * 0.07).roundToInt()))
    }

    private fun peaks(f: DoubleArray, fps: Double): List<Int> {
        val sd = sqrt(f.sumOf { it * it } / f.size)
        if (sd < 1e-6) return emptyList()
        val minDist = maxOf(2, (fps * 0.33).toInt())
        val k = (fps * 0.06).roundToInt().coerceIn(2, 5)
        val res = ArrayList<Int>()
        for (i in k until f.size - k) {
            var isMax = true
            for (j in 1..k) {
                if (f[i] <= f[i - j] || f[i] < f[i + j]) {
                    isMax = false
                    break
                }
            }
            if (!isMax || f[i] < 0.3 * sd) continue
            if (res.isNotEmpty() && i - res.last() < minDist) {
                if (f[i] > f[res.last()]) res[res.size - 1] = i
                continue
            }
            res.add(i)
        }
        return res
    }

    /** Döyüntülər arası məsafələrdən dəq-də döyüntü sayı; etibarlı deyilsə null. */
    private fun estimate(tt: List<Double>, vv: List<Double>): Int? {
        val n = vv.size
        if (n < 60) return null
        val dur = tt.last() - tt.first()
        if (dur < 4.0) return null
        val fps = (n - 1) / dur
        val f = bandpass(vv.toDoubleArray(), fps)
        val pk = peaks(f, fps)
        if (pk.size < 5) return null
        val iv = ArrayList<Double>()
        for (i in 1 until pk.size) {
            val d = tt[pk[i]] - tt[pk[i - 1]]
            if (d in 0.33..1.5) iv.add(d)
        }
        if (iv.size < 4) return null
        val med = iv.sorted()[iv.size / 2]
        val good = iv.filter { abs(it - med) <= 0.25 * med }
        if (good.size < iv.size * 0.6) return null
        val bpm = (60.0 / good.average()).roundToInt()
        return if (bpm in 40..180) bpm else null
    }
}

/** Ölçmə zamanı siqnalı çəkən kiçik dalğa görünüşü. */
class WaveView(ctx: Context) : View(ctx) {
    var data: DoubleArray = DoubleArray(0)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF8A80")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val bg = Paint().apply { color = Color.parseColor("#1B2B3F") }

    override fun onDraw(c: Canvas) {
        c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 24f, 24f, bg)
        if (data.size < 2) return
        var mn = Double.MAX_VALUE
        var mx = -Double.MAX_VALUE
        for (d in data) {
            if (d < mn) mn = d
            if (d > mx) mx = d
        }
        val range = if (mx - mn < 1e-6) 1.0 else mx - mn
        val pad = 12f
        val path = Path()
        for (i in data.indices) {
            val x = pad + (width - 2 * pad) * i / (data.size - 1)
            val y = (height - pad - (height - 2 * pad) * ((data[i] - mn) / range)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, line)
    }
}
