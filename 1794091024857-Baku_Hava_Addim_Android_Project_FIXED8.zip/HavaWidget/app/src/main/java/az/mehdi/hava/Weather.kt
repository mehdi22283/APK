package az.mehdi.hava

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.roundToInt

val BAKU: ZoneId = ZoneId.of("Asia/Baku")
private val HOUR_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH")

data class Hour(val time: String, val temp: Double, val code: Int, val prob: Int, val wind: Double, val feels: Double = Double.NaN, val uv: Double = Double.NaN)
data class Day(val date: String, val code: Int, val max: Double, val min: Double, val prob: Int, val wind: Double, val sunrise: String = "", val sunset: String = "", val uvMax: Double = Double.NaN)
data class Aqi(val us: Int, val pm25: Double, val pm10: Double)
data class Outlook(val text: String, val kind: String?, val inHours: Int, val ongoing: Boolean, val key: String)

data class Weather(val hours: List<Hour>, val days: List<Day>, val aqi: Aqi? = null) {

    fun nowIndex(): Int {
        val k = LocalDateTime.now(BAKU).format(HOUR_FMT)
        return hours.indexOfFirst { it.time.startsWith(k) }
    }

    fun upcomingDays(): List<Day> {
        val t = LocalDate.now(BAKU).toString()
        return days.filter { it.date >= t }.take(8)
    }

    /** yağış / qar / tufan / külək — yoxdursa null */
    fun kindOf(h: Hour, lenient: Boolean): String? = when {
        h.code >= 95 -> "tufan"
        h.code in 71..77 || h.code == 85 || h.code == 86 -> "qar"
        h.code in 51..67 || h.code in 80..82 -> "yağış"
        lenient && h.prob >= 70 -> "yağış"
        h.wind >= 40 -> "külək"
        else -> null
    }

    /** "saat 14:00" (sabahdırsa "sabah saat 02:00"); cap=true olanda cümlə əvvəli üçün böyük hərflə */
    private fun at(i: Int, cap: Boolean = false): String {
        val t = hours[i].time
        val tomorrow = t.take(10) != LocalDate.now(BAKU).toString()
        val hhmm = t.substring(11, 16)
        val pre = if (tomorrow) (if (cap) "Sabah saat" else "sabah saat") else (if (cap) "Saat" else "saat")
        return "$pre $hhmm"
    }

    private fun tempNote(n: Int): String {
        if (n + 3 >= hours.size) return ""
        val d = (hours[n + 3].temp - hours[n].temp).roundToInt()
        if (abs(d) < 3) return ""
        val sign = if (d > 0) "+" else ""
        return " ${at(n + 3, true)}-da hava ${if (d > 0) "isinəcək" else "soyuyacaq"}: ${hours[n + 3].temp.roundToInt()}° ($sign$d°)."
    }

    fun outlook(): Outlook? {
        val n = nowIndex()
        if (n < 0) return null
        val limit = minOf(24, hours.size - 1 - n)
        val cur = kindOf(hours[n], false)
        val note = tempNote(n)
        if (cur != null) {
            val k = (1..limit).firstOrNull { kindOf(hours[n + it], false) != cur }
            val t = if (k != null) "${T.now(cur)}, ${at(n + k)}-da ${T.end(cur)}." else "${T.now(cur)}, növbəti 24 saat davam edəcək."
            val tm = hours[n].time
            return Outlook(t + note, cur, 0, true, "$cur@now@${tm.take(10)}-${tm.substring(11, 13).toInt() / 6}")
        }
        val k = (1..limit).firstOrNull { kindOf(hours[n + it], true) != null }
        if (k != null) {
            val kd = kindOf(hours[n + k], true)!!
            val e = (k + 1..limit).firstOrNull { kindOf(hours[n + it], true) != kd }
            val endTxt = if (e != null) ", ${at(n + e)}-da ${T.end(kd)}" else ""
            return Outlook("${at(n + k, true)}-da ${T.future(kd)}$endTxt.$note", kd, k, false, "$kd@${hours[n + k].time}")
        }
        return Outlook("Növbəti 24 saat ərzində yağış, qar və tufan gözlənilmir ✅.$note", null, 99, false, "none")
    }

    /** Tətbiq üçün: [hiss + külək, UV, AQI, günəş çıxma/batma] */
    fun infoParts(n: Int): List<String> {
        val h = hours[n]
        val a = ArrayList<String>()
        if (!h.feels.isNaN()) a.add("🌡️ Hiss ${h.feels.roundToInt()}°")
        a.add("💨 ${h.wind.roundToInt()} km/saat")
        val out = arrayListOf(a.joinToString("   "))
        if (!h.uv.isNaN()) {
            val mx = days.firstOrNull { it.date == LocalDate.now(BAKU).toString() }?.uvMax
            val tail = if (mx != null && !mx.isNaN()) " · bu gün maks. ${mx.roundToInt()}" else ""
            out.add("☀️ UV ${h.uv.roundToInt()} (${T.uvLevel(h.uv)})$tail")
        }
        aqi?.let { out.add("😷 Hava keyfiyyəti: ${T.aqiLevel(it.us)}") }
        out.add(sunLine())
        return out.filter { it.isNotEmpty() }
    }

    private fun sunLine(): String {
        val d = days.firstOrNull { it.date == LocalDate.now(BAKU).toString() }
        val sun = ArrayList<String>()
        if (d != null && d.sunrise.length >= 16) sun.add("🌅 ${d.sunrise.substring(11, 16)}")
        if (d != null && d.sunset.length >= 16) sun.add("🌇 ${d.sunset.substring(11, 16)}")
        return sun.joinToString("   ")
    }

    /** Widget üçün yığcam 2 sətir */
    fun widgetInfo(n: Int): String {
        val h = hours[n]
        val l1 = ArrayList<String>()
        if (!h.feels.isNaN()) l1.add("🌡️ ${h.feels.roundToInt()}°")
        l1.add("💨 ${h.wind.roundToInt()}")
        if (!h.uv.isNaN()) l1.add("☀️ UV ${h.uv.roundToInt()}")
        val l2 = ArrayList<String>()
        val sl = sunLine()
        if (sl.isNotEmpty()) l2.add(sl)
        aqi?.let { l2.add("😷 ${T.aqiLevel(it.us)}") }
        return listOf(l1.joinToString("  "), l2.joinToString("  ")).filter { it.isNotEmpty() }.joinToString("\n")
    }

    fun hourLine(n: Int): String =
        listOf(3, 6, 9, 12).filter { n + it < hours.size }.joinToString("   ") {
            val h = hours[n + it]
            "${h.time.substring(11, 16)}\u00A0${T.icon(h.code)}${h.temp.roundToInt()}°"
        }
}

object T {
    private val AY = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr", "oktyabr", "noyabr", "dekabr")
    private val GUN = listOf("bazar ertəsi", "çərşənbə axşamı", "çərşənbə", "cümə axşamı", "cümə", "şənbə", "bazar")

    /** məs: 7 noyabr 2026, şənbə */
    fun dateLine(): String {
        val d = LocalDate.now(BAKU)
        return "${d.dayOfMonth} ${AY[d.monthValue - 1]} ${d.year}, ${GUN[d.dayOfWeek.value - 1]}"
    }

    fun desc(c: Int): String = when (c) {
        0 -> "Aydın"
        1 -> "Əsasən aydın"
        2 -> "Az buludlu"
        3 -> "Buludlu"
        45, 48 -> "Dumanlı"
        51, 53, 55 -> "Çiskin"
        56, 57 -> "Dondurucu çiskin"
        61 -> "Yüngül yağış"
        63 -> "Yağış"
        65 -> "Güclü yağış"
        66, 67 -> "Dondurucu yağış"
        71 -> "Yüngül qar"
        73 -> "Qar"
        75 -> "Güclü qar"
        77 -> "Qar dənələri"
        80 -> "Yüngül leysan"
        81 -> "Leysan"
        82 -> "Güclü leysan"
        85, 86 -> "Qar leysanı"
        95 -> "Tufan"
        in 96..99 -> "Dolulu tufan"
        else -> "—"
    }

    fun icon(c: Int): String = when (c) {
        0 -> "☀️"
        1 -> "🌤️"
        2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67 -> "🌧️"
        in 71..77 -> "🌨️"
        in 80..82 -> "🌧️"
        85, 86 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    fun uvLevel(v: Double): String = when {
        v < 3 -> "aşağı"
        v < 6 -> "orta"
        v < 8 -> "yüksək"
        v < 11 -> "çox yüksək"
        else -> "həddindən artıq"
    }

    fun aqiLevel(v: Int): String = when {
        v <= 50 -> "yaxşı"
        v <= 100 -> "orta"
        v <= 150 -> "zəif"
        v <= 200 -> "pis"
        v <= 300 -> "çox pis"
        else -> "təhlükəli"
    }

    fun dayName(date: String): String =
        listOf("B.e.", "Ç.a.", "Çər", "C.a.", "Cümə", "Şən", "Baz")[LocalDate.parse(date).dayOfWeek.value - 1]

    fun now(k: String): String = when (k) {
        "yağış" -> "Hazırda yağış yağır 🌧️"
        "qar" -> "Hazırda qar yağır ❄️"
        "tufan" -> "Hazırda tufan var ⛈️"
        else -> "Hazırda güclü külək əsir 💨"
    }

    fun end(k: String): String = when (k) {
        "yağış" -> "yağış kəsiləcək"
        "qar" -> "qar kəsiləcək"
        "tufan" -> "tufan keçəcək"
        else -> "külək səngiyəcək"
    }

    fun future(k: String): String = when (k) {
        "yağış" -> "yağış yağacaq 🌧️"
        "qar" -> "qar yağacaq ❄️"
        "tufan" -> "tufan olacaq ⛈️"
        else -> "güclü külək əsəcək 💨"
    }
}

object WeatherApi {
    // Koordinat: 40.427565, 49.822425 — Open-Meteo (pulsuz, API açarı lazım deyil)
    private const val URL_STR =
        "https://api.open-meteo.com/v1/forecast?latitude=40.427565&longitude=49.822425" +
        "&hourly=temperature_2m,weather_code,precipitation_probability,wind_speed_10m,apparent_temperature,uv_index" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset,uv_index_max" +
        "&timezone=Asia%2FBaku&forecast_days=8&wind_speed_unit=kmh"

    private const val AQI_URL =
        "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=40.427565&longitude=49.822425" +
        "&current=us_aqi,pm2_5,pm10&timezone=Asia%2FBaku"

    private fun download(u: String = URL_STR): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun parse(s: String): Weather {
        val o = JSONObject(s)
        val h = o.getJSONObject("hourly")
        val t = h.getJSONArray("time")
        val tt = h.getJSONArray("temperature_2m")
        val tc = h.getJSONArray("weather_code")
        val tp = h.getJSONArray("precipitation_probability")
        val tw = h.getJSONArray("wind_speed_10m")
        val ta = h.optJSONArray("apparent_temperature")
        val tu = h.optJSONArray("uv_index")
        val hours = (0 until t.length()).map {
            Hour(t.getString(it), tt.optDouble(it, 0.0), tc.optInt(it), tp.optInt(it), tw.optDouble(it, 0.0),
                ta?.optDouble(it, Double.NaN) ?: Double.NaN,
                tu?.optDouble(it, Double.NaN) ?: Double.NaN)
        }
        val d = o.getJSONObject("daily")
        val dt = d.getJSONArray("time")
        val dc = d.getJSONArray("weather_code")
        val dmax = d.getJSONArray("temperature_2m_max")
        val dmin = d.getJSONArray("temperature_2m_min")
        val dp = d.getJSONArray("precipitation_probability_max")
        val dw = d.getJSONArray("wind_speed_10m_max")
        val dsr = d.optJSONArray("sunrise")
        val dss = d.optJSONArray("sunset")
        val dum = d.optJSONArray("uv_index_max")
        val days = (0 until dt.length()).map {
            Day(dt.getString(it), dc.optInt(it), dmax.optDouble(it, 0.0), dmin.optDouble(it, 0.0), dp.optInt(it), dw.optDouble(it, 0.0),
                dsr?.optString(it, "") ?: "", dss?.optString(it, "") ?: "",
                dum?.optDouble(it, Double.NaN) ?: Double.NaN)
        }
        return Weather(hours, days)
    }

    private fun prefs(c: Context) = c.getSharedPreferences("hava", Context.MODE_PRIVATE)

    fun parseAqi(s: String): Aqi? = try {
        val cur = JSONObject(s).getJSONObject("current")
        if (cur.isNull("us_aqi")) null
        else Aqi(cur.getInt("us_aqi"), cur.optDouble("pm2_5", 0.0), cur.optDouble("pm10", 0.0))
    } catch (e: Exception) {
        null
    }

    fun refresh(c: Context): Weather? = try {
        val s = download()
        var w = parse(s)
        prefs(c).edit().putString("json", s).putLong("ts", System.currentTimeMillis()).apply()
        // AQI ayrıca yüklənir; alınmasa köhnə dəyər qalır, hava yenilənməsi pozulmur
        try {
            val a = download(AQI_URL)
            if (parseAqi(a) != null) prefs(c).edit().putString("aqi", a).apply()
        } catch (e: Exception) {
        }
        w = w.copy(aqi = prefs(c).getString("aqi", null)?.let { parseAqi(it) })
        w
    } catch (e: Exception) {
        null
    }

    fun cached(c: Context): Weather? =
        prefs(c).getString("json", null)?.let {
            try { parse(it).copy(aqi = prefs(c).getString("aqi", null)?.let { a -> parseAqi(a) }) } catch (e: Exception) { null }
        }

    fun ageMin(c: Context): Long {
        val ts = prefs(c).getLong("ts", 0L)
        return if (ts == 0L) Long.MAX_VALUE else (System.currentTimeMillis() - ts) / 60000
    }
}
