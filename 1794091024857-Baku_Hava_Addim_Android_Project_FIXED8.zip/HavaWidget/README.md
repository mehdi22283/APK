# Bakı Hava (HavaWidget)
- Bakı: bu gün + 7 gün, hər gün üçün yağış ehtimalı (Open-Meteo, API açarı lazım deyil)
- "3 saat sonra yağış yağacaq" tipli proqnoz — tətbiqdə, widgetdə və bildirişdə
- Yağış / qar / tufan / güclü külək xəbərdarlığı (bildiriş), səhər proqnozu
- UV indeksi (indiki + günün maksimumu) və hava keyfiyyəti AQI + PM2.5 (Open-Meteo Air Quality, açar lazım deyil); koordinat 40.427565, 49.822425
- Addımölçən + km (boyunuza görə), widgetdə də görünür
- Widget: ana ekran → uzun bas → Widgetlər → Bakı Hava (və ya tətbiqdəki "widget əlavə et" düyməsi)

Build: layihəni GitHub-a yükləyin → Actions → "Build APK" → artifact: HavaWidget-apk
