package az.mehdi.hava

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.*
import android.os.*
import java.text.SimpleDateFormat
import java.util.*

class StepService : Service(), SensorEventListener {
    private val h = Handler(Looper.getMainLooper())
    private var lastUi = 0L

    private val loop = object : Runnable {
        override fun run() {
            val c = applicationContext
            Thread {
                try {
                    val j = Weather.refresh(c)
                    if (j != null) { Notifs.check(c, j); WidgetUpdater.update(c) }
                } catch (e: Exception) {}
            }.start()
            h.postDelayed(this, 30 * 60 * 1000L)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        Notifs.channels(this)
        try {
            if (Build.VERSION.SDK_INT >= 30)
                startForeground(1, Notifs.fg(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
            else startForeground(1, Notifs.fg(this))
        } catch (e: Exception) {
            try { startForeground(1, Notifs.fg(this)) } catch (e2: Exception) { stopSelf(); return }
        }
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        h.post(loop)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val total = e.values[0]
        val p = Weather.prefs(this)
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        var base = p.getFloat("base", -1f)
        val last = p.getFloat("last", -1f)
        var steps = p.getInt("steps", 0)
        if (p.getString("day", "") != day) { base = total; steps = 0 }
        else if (base < 0f || total < last) base = total - steps
        steps = (total - base).toInt().coerceAtLeast(0)
        p.edit().putString("day", day).putFloat("base", base).putFloat("last", total).putInt("steps", steps).apply()
        val now = System.currentTimeMillis()
        if (now - lastUi > 30000) {
            lastUi = now
            WidgetUpdater.update(this); Notifs.updateFg(this)
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onDestroy() {
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(this)
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        fun startIfAllowed(c: Context) {
            try {
                if (c.checkSelfPermission("android.permission.ACTIVITY_RECOGNITION") != PackageManager.PERMISSION_GRANTED) return
                val i = Intent(c, StepService::class.java)
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {}
        }
    }
}
