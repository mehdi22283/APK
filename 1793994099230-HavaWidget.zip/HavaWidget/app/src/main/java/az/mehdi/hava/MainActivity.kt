package az.mehdi.hava

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        info = TextView(this).apply { textSize = 16f }
        val height = EditText(this).apply {
            hint = "Boyunuz (sm)"; inputType = 2
            setText(Weather.prefs(this@MainActivity).getInt("height", 180).toString())
        }
        val save = Button(this).apply {
            text = "Boyu yadda saxla (km hesabı üçün)"
            setOnClickListener {
                val hgt = height.text.toString().toIntOrNull() ?: 170
                Weather.prefs(this@MainActivity).edit().putInt("height", hgt).apply()
                WidgetUpdater.update(this@MainActivity); show()
            }
        }
        val start = Button(this).apply { text = "İcazələri ver və başlat"; setOnClickListener { askPerms() } }
        val hint = TextView(this).apply {
            textSize = 12f
            text = "Xiaomi: Parametrlər → Tətbiqlər → Hava Widget → Avtostart AÇIQ, Batareya → Məhdudiyyət yoxdur. Sonra ana ekrana widget əlavə edin."
        }
        listOf(info, height, save, start, hint).forEach { l.addView(it) }
        setContentView(ScrollView(this).apply { addView(l) })
    }

    override fun onResume() {
        super.onResume()
        show()
        StepService.startIfAllowed(this)
        Thread {
            try {
                val j = Weather.refresh(this)
                if (j != null) { Notifs.check(this, j); WidgetUpdater.update(this) }
                runOnUiThread { show() }
            } catch (e: Exception) {}
        }.start()
    }

    private fun show() {
        val p = Weather.prefs(this)
        val j = Weather.cached(this)
        val o = j?.let { try { Weather.outlook(it) } catch (e: Exception) { null } }
        info.text = "🚶 ${p.getInt("steps", 0)} addım\n📏 ${WidgetUpdater.km(this)} km\n\n" +
            (o?.alert ?: "Hava yüklənir…") + "\n" + (o?.hours ?: "") + (if (o != null && o.warn.isNotEmpty()) "\n\n" + o.warn else "")
    }

    private fun askPerms() {
        val perms = mutableListOf("android.permission.ACTIVITY_RECOGNITION")
        if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        StepService.startIfAllowed(this)
    }
}
