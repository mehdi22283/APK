package az.mehdi.hava

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class Outlook(val alert: String, val hours: String, val warn: String, val notifKey: String?, val notifText: String?)

object Weather {
    private const val API = "https://api.open-meteo.com/v1/forecast?latitude=40.4093&longitude=49.8671" +
        "&current=temperature_2m,weather_code,wind_speed_10m,wind_gusts_10m" +
        "&hourly=temperature_2m,precipitation_probability,weather_code,wind_gusts_10m" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_gusts_10m_max" +
        "&timezone=Asia%2FBaku&forecast_days=8"

    fun prefs(c: Context) = c.getSharedPreferences("hava", 0)

    fun cached(c: Context): JSONObject? =
        prefs(c).getString("json", null)?.let { try { JSONObject(it) } catch (e: Exception) { null } }

    fun refresh(c: Context): JSONObject? = try {
        val con = URL(API).openConnection() as HttpURLConnection
        con.connectTimeout = 15000; con.readTimeout = 15000
        val s = con.inputStream.bufferedReader().use { it.readText() }
        val j = JSONObject(s)
        prefs(c).edit().putString("json", s).putLong("ts", System.currentTimeMillis()).apply()
        j
    } catch (e: Exception) { cached(c) }

    fun isRain(code: Int) = code in 51..67 || code in 80..82 || code in 95..99

    fun icon(code: Int) = when (code) {
        0 -> "☀️"; 1, 2 -> "🌤"; 3 -> "☁️"; 45, 48 -> "🌫"
        in 51..57 -> "🌦"; in 61..67 -> "🌧"; in 71..77 -> "❄️"
        in 80..82 -> "🌧"; 85, 86 -> "❄️"; in 95..99 -> "⛈"; else -> "☁️"
    }

    fun desc(code: Int) = when (code) {
        0 -> "Açıq"; 1, 2 -> "Az buludlu"; 3 -> "Buludlu"; 45, 48 -> "Dumanlı"
        in 51..57 -> "Çiskin"; in 61..67 -> "Yağışlı"; in 71..77, 85, 86 -> "Qar"
        in 80..82 -> "Leysan"; in 95..99 -> "Tufan"; else -> "Buludlu"
    }

    fun dayName(date: String, idx: Int): String {
        if (idx == 1) return "Sabah " + date.substring(8, 10) + "." + date.substring(5, 7)
        val cal = Calendar.getInstance()
        cal.time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!
        val n = arrayOf("Bazar", "B.ertəsi", "Ç.axşamı", "Çərşənbə", "C.axşamı", "Cümə", "Şənbə")
        return n[cal.get(Calendar.DAY_OF_WEEK) - 1] + " " + date.substring(8, 10) + "." + date.substring(5, 7)
    }

    fun outlook(j: JSONObject): Outlook {
        val cur = j.getJSONObject("current"); val h = j.getJSONObject("hourly")
        val tm = h.getJSONArray("time"); val t = h.getJSONArray("temperature_2m")
        val p = h.getJSONArray("precipitation_probability"); val c = h.getJSONArray("weather_code")
        val key = cur.getString("time").substring(0, 13)
        var i = 0
        while (i < tm.length() && !tm.getString(i).startsWith(key)) i++
        if (i >= tm.length() - 13) i = 0
        fun rain(k: Int) = p.optInt(k) >= 50 || isRain(c.optInt(k))
        val nowRain = isRain(cur.getInt("weather_code"))
        val alert: String
        var nk: String? = null; var nt: String? = null
        if (nowRain) {
            var k = 1
            while (k <= 12 && rain(i + k)) k++
            alert = if (k <= 12) "☔ $k saat sonra yağış dayanacaq" else "☔ Yağış ən azı 12 saat davam edəcək"
        } else {
            var k = 1
            while (k <= 12 && !rain(i + k)) k++
            if (k <= 12) {
                alert = "☔ $k saat sonra yağış yağacaq (${p.optInt(i + k)}%)"
                if (k <= 3) { nk = "rain:" + tm.getString(i + k); nt = alert.removePrefix("☔ ") }
            } else alert = "🌤 Növbəti 12 saatda yağış gözlənilmir"
        }
        val g = h.getJSONArray("wind_gusts_10m")
        val warns = mutableListOf<String>(); val seen = mutableSetOf<String>()
        var sk: String? = null; var st: String? = null
        for (k in 0..12) {
            val code = if (k == 0) cur.getInt("weather_code") else c.optInt(i + k)
            val gust = g.optDouble(i + k)
            val w = if (k == 0) "İndi" else "$k saat sonra"
            val items = mutableListOf<Pair<String, String>>()
            if (code in 95..99) items.add("storm" to "⛈ $w tufan/ildırım")
            if (code in 71..77 || code == 85 || code == 86) items.add("snow" to "❄️ $w qar")
            if (gust >= 60) items.add("wind" to "💨 $w güclü külək (${Math.round(gust)} km/s)")
            for ((type, txt) in items) if (seen.add(type)) {
                warns.add(txt)
                if (k <= 6 && sk == null) { sk = "$type:" + tm.getString(i + k).substring(0, 10); st = txt }
            }
        }
        if (sk != null) { nk = sk; nt = st }
        fun d(k: Int) = Math.round(t.optDouble(i + k) - t.optDouble(i)).toInt()
        fun tt(k: Int): String {
            val dd = d(k); val s = if (dd > 0) "+$dd" else "$dd"
            return "$k saat: ${Math.round(t.optDouble(i + k))}°($s) 💧${p.optInt(i + k)}%"
        }
        val d3 = d(3)
        if (nk == null && Math.abs(d3) >= 6) {
            nk = "temp:$key"
            nt = "3 saat sonra hava " + (if (d3 < 0) "soyuyacaq" else "isinəcək") + ": ${Math.round(t.optDouble(i + 3))}° ($d3°)"
        }
        return Outlook(alert, listOf(3, 6, 12).joinToString("  │  ") { tt(it) }, warns.joinToString("\n"), nk, nt)
    }
}
