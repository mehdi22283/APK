package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

class WeatherWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        try {
            WidgetUpdater.update(c)
            Thread {
                try {
                    val j = Weather.refresh(c)
                    if (j != null) { Notifs.check(c, j); WidgetUpdater.update(c) }
                } catch (e: Exception) {}
            }.start()
            StepService.startIfAllowed(c)
        } catch (e: Exception) {}
    }
}
