package az.mehdi.iptvplayer

import android.content.Context
import java.security.MessageDigest

/**
 * Bufer səviyyələri (kanal başına). 0 = ən sürətli açılış (0,5 s), 1 = normal (1 s, köhnə səviyyə 0), 2 = orta, 3 = böyük.
 * Kanal 2 dəqiqədə 3 dəfə buferlənərsə səviyyə bir pillə qalxır; 20 dəqiqə buferlənmədən işləyərsə bir pillə düşür.
 */
object BufferProfile {
    const val MAX_LEVEL = 3
    /** Ehtiyat (yoda.az/canlitv tokenli) linklər həmişə bu səviyyədən (köhnə 0 = 1 s) başlayır. */
    const val BACKUP_LEVEL = 1
    /** Yayımın başlaması üçün lazım olan bufer (ms). */
    fun startMs(level: Int): Int = when (level) { 0 -> 500; 1 -> 1_000; 2 -> 2_000; else -> 3_000 }
    /** Buferlənmədən sonra davam etmək üçün lazım olan bufer (ms). */
    fun rebufferMs(level: Int): Int = when (level) { 0 -> 2_000; 1 -> 2_500; 2 -> 6_000; else -> 12_000 }
}

/**
 * Kanalın bufer səviyyəsini yadda saxlayır (kanal linki → 0..3). Yalnız UI thread-i.
 * Açar linkin qısa MD5-idir; ehtiyat (yoda.az tokenli) linklər saxlanmır.
 */
class BufferMemory(context: Context) {
    private companion object {
        const val PREFS = "buffer_memory_v2"
        const val OLD_PREFS = "buffer_memory_v1"   // v1: səviyyələr 0..2; yeni sistemdə hamısı +1 (0 = yeni sürətli səviyyə)
        const val MAX_ENTRIES = 4_000
    }

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val cache = HashMap<String, Int>()

    init {
        runCatching {
            // Köhnə (v1) yaddaş bir dəfə köçürülür: 1→2, 2→3. Heç vaxt problem olmayan kanallar (v1-də 0) yeni 0 səviyyəsinə düşür.
            val old = context.applicationContext.getSharedPreferences(OLD_PREFS, Context.MODE_PRIVATE)
            if (old.all.isNotEmpty()) {
                val e = prefs.edit()
                for ((k, v) in old.all) if (v is Int && v > 0 && !prefs.contains(k)) e.putInt(k, (v + 1).coerceAtMost(BufferProfile.MAX_LEVEL))
                e.apply()
                old.edit().clear().apply()
            }
        }
        runCatching {
            for ((k, v) in prefs.all) if (v is Int) cache[k] = v
            if (cache.size > MAX_ENTRIES) { cache.clear(); prefs.edit().clear().apply() }
        }
    }

    private fun key(url: String): String {
        val d = MessageDigest.getInstance("MD5").digest(url.trim().toByteArray())
        val sb = StringBuilder(16)
        for (i in 0 until 8) sb.append(String.format("%02x", d[i]))
        return sb.toString()
    }

    fun level(url: String): Int = (cache[key(url)] ?: 0).coerceIn(0, BufferProfile.MAX_LEVEL)

    fun set(url: String, level: Int) {
        val k = key(url)
        val l = level.coerceIn(0, BufferProfile.MAX_LEVEL)
        if (l == 0) {
            if (cache.remove(k) != null) runCatching { prefs.edit().remove(k).apply() }
            return
        }
        if (cache[k] == l) return
        cache[k] = l
        runCatching { prefs.edit().putInt(k, l).apply() }
    }
}
