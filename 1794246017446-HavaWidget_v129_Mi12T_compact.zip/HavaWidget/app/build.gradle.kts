plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "az.mehdi.hava"
    compileSdk = 34
    defaultConfig {
        applicationId = "az.mehdi.hava"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.osmdroid:osmdroid-android:6.1.18")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
