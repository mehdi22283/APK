package az.yvok.app;

import android.content.Context;

import org.json.JSONArray;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Bələdiyyə bazasına (data.db + edits.db) yazan əməliyyatlar. MainActivity (WhatsApp göndərəndə) və
 * BazaActivity («Dəyişikliklər»də təsdiq düyməsi) eyni kodu işlədir.
 */
public class BazaOps {
    private final Context ctx;
    public BazaOps(Context c) { this.ctx = c.getApplicationContext(); }

    private boolean bazaIsLive() { return new File(ctx.getFilesDir(), "data.db").exists(); }

    /** Bələdiyyə bazasının işlək (redaktələrlə) nüsxəsi; baza hələ açılmayıbsa quraşdırılmış nüsxənin oxu üçün kopyası */
    public File bazaFile() throws Exception {
        File f = new File(ctx.getFilesDir(), "data.db");
        if (f.exists()) return f;
        File lf = new File(ctx.getCacheDir(), "lookup.db");
        long upd = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).lastUpdateTime;
        if (!lf.exists() || lf.lastModified() < upd) {
            try (InputStream in = ctx.getAssets().open("data.db"); OutputStream out = new java.io.FileOutputStream(lf)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
        }
        return lf;
    }

    private static String foldAz(String s) {
        if (s == null) return "";
        String t = s.replace('İ', 'i').replace('I', 'ı').toLowerCase(Locale.ROOT);
        t = t.replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u').replace('ş', 's').replace('ç', 'c').replace('ğ', 'g');
        return t.trim().replaceAll("\\s+", " ");
    }

    /** true - nömrə əlavə edildi. Nömrə bazada artıq varsa (hər hansı sətirdə) heç nə dəyişmir. */
    public boolean addPhoneToBazaImpl(String code, String phone) throws Exception {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        String digits = phone == null ? "" : phone.replaceAll("\\D", "");
        if (c.length() != 7 || digits.length() < 9) return false;
        String last9 = digits.substring(digits.length() - 9);
        String full = "10011" + c;
        boolean live = bazaIsLive();
        File f = bazaFile();
        android.database.sqlite.SQLiteDatabase d = android.database.sqlite.SQLiteDatabase.openDatabase(
            f.getPath(), null, live ? android.database.sqlite.SQLiteDatabase.OPEN_READWRITE : android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        try {
            long rowId = -1; int ord = 0; String sheet = "", fileName = ""; JSONArray cells = null; int ni = -1;
            android.database.Cursor cur = d.rawQuery(
                "SELECT r.id, r.ord, r.cells, b.headers, b.sheet, f.name FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.cells LIKE ? ORDER BY r.id LIMIT 30",
                new String[]{"%" + c + "\"%"});
            try {
                while (cur.moveToNext()) {
                    JSONArray arr = new JSONArray(cur.getString(2));
                    boolean ok = false;
                    for (int i = 0; i < arr.length(); i++) {
                        String v = arr.optString(i, "").trim().toUpperCase();
                        if (v.equals(full) || v.equals(c)) { ok = true; break; }
                    }
                    if (!ok) continue;
                    JSONArray hs = new JSONArray(cur.getString(3));
                    int idx = -1;
                    for (int i = 0; i < hs.length(); i++) if (foldAz(hs.optString(i, "")).startsWith("nomre")) { idx = i; break; }
                    if (idx < 0) continue;
                    rowId = cur.getLong(0); ord = cur.getInt(1); cells = arr; ni = idx;
                    sheet = cur.getString(4) == null ? "" : cur.getString(4);
                    fileName = cur.getString(5);
                    break;
                }
            } finally { cur.close(); }
            if (rowId < 0 || cells == null) return false;

            String existing = ni < cells.length() ? cells.optString(ni, "").trim() : "";
            // nömrə yalnız həmin YVÖK-ün sətrində yoxdursa əlavə olunur (başqa mənzildə olması maneə deyil)
            if (existing.replaceAll("\\D", "").contains(last9)) return false;
            String merged = existing.isEmpty() ? phone : existing.replaceAll("[;,/|\\s]+$", "") + "; " + phone;
            while (cells.length() <= ni) cells.put("");
            cells.put(ni, merged);
            if (live) {
                d.execSQL("UPDATE rows SET cells = ?, nomre_d = ? WHERE id = ?", new Object[]{cells.toString(), merged.replaceAll("\\D", ""), rowId});
            }
            // redaktə qeydi: baza yenilənəndə də itməsin (Bələdiyyə bazasının öz «Nömrə əlavə et» qaydası ilə eyni)
            android.database.sqlite.SQLiteDatabase e = ctx.openOrCreateDatabase("edits.db", android.content.Context.MODE_PRIVATE, null);
            try {
                e.execSQL("CREATE TABLE IF NOT EXISTS edits(file TEXT, sheet TEXT, ord INTEGER, col INTEGER, value TEXT, PRIMARY KEY(file, sheet, ord, col))");
                java.util.HashMap<String, java.util.HashSet<String>> clb = az.axtaris.baza.ChangeLog.snapshot(e, d);
                e.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", new Object[]{fileName, sheet, ord, ni, merged});
                az.axtaris.baza.ChangeLog.record(e, "📞 Nömrə əlavə olundu (mesaj): " + sheet + " · " + full + "\n" + phone, clb, d);
            } finally { e.close(); }
            return true;
        } finally { d.close(); }
    }

    private static final java.util.Set<String> STREET_NOISE = new java.util.HashSet<>(
        java.util.Arrays.asList("kucesi", "kuc", "prospekti", "pr", "ks", "pros", "bina", "binasi", "bin"));

    private static java.util.List<String> streetWordsJ(String s) {
        java.util.ArrayList<String> r = new java.util.ArrayList<>();
        for (String w : foldAz(s).split("[^a-z0-9]+")) if (!w.isEmpty() && !STREET_NOISE.contains(w)) r.add(w);
        return r;
    }

    private static boolean coverNameJ(java.util.List<String> a, java.util.List<String> b) {
        String sn = b.get(b.size() - 1);
        int i = a.lastIndexOf(sn);
        if (i < 0) return false;
        if (b.size() >= 2 && i > 0) {
            char ini = b.get(0).charAt(0);
            boolean any = false;
            for (int k = 0; k < i; k++) if (a.get(k).charAt(0) == ini) any = true;
            if (!any) return false;
        }
        return true;
    }

    /** "Həmzə Babaşov bina" = "H.BABAŞOV": bazadakı soyad adın içindədir, ad yazılıbsa baş hərf uyğundur (index.html ilə eyni qayda) */
    private static boolean sameStreetNameJ(String a, String b) {
        java.util.List<String> x = streetWordsJ(a), y = streetWordsJ(b);
        if (x.isEmpty() || y.isEmpty()) return false;
        return coverNameJ(x, y) || coverNameJ(y, x);
    }

    /** "Həmzə Babaşov 20" -> {"Həmzə Babaşov", "20"} */
    private static String[] splitNumJ(String s) {
        String t = s == null ? "" : s.trim();
        java.util.regex.Matcher m = Pattern.compile("^(.*?)[\\s\\-]*(\\d.*)$").matcher(t);
        if (m.find()) return new String[]{m.group(1).trim(), m.group(2).trim()};
        return new String[]{t, ""};
    }

    private static String firstNumJ(String s) {
        java.util.regex.Matcher m = Pattern.compile("\\d+").matcher(s == null ? "" : s);
        return m.find() ? m.group() : "";
    }

    private static long scalarLongJ(android.database.sqlite.SQLiteDatabase d, String sql, String... a) {
        long r = -1;
        android.database.Cursor c = d.rawQuery(sql, a);
        try { if (c.moveToFirst() && !c.isNull(0)) r = c.getLong(0); } finally { c.close(); }
        return r;
    }

    /** «Rüstəm Rüstəmov» / «R.Rüstəmov» -> «R.RÜSTƏMOV»; tək söz olarsa «RÜSTƏMOV» */
    private static String abbrevStreetJ(String name) {
        java.util.ArrayList<String> w = new java.util.ArrayList<>();
        for (String t : (name == null ? "" : name).split("[\\s.]+")) {
            if (!t.isEmpty() && !STREET_NOISE.contains(foldAz(t))) w.add(t);
        }
        if (w.isEmpty()) return "";
        java.util.Locale az = new java.util.Locale("az");
        String last = w.get(w.size() - 1).toUpperCase(az);
        if (w.size() == 1) return last;
        return w.get(0).substring(0, 1).toUpperCase(az) + "." + last;
    }

    /** Yeni fayl (kateqoriya) əlifba sırasına uyğun yerə düşür; «⭐» qrupu həmişə üstdə qalır (Bələdiyyə bazasının öz qaydası) */
    private static long fileSlotOrdJ(android.database.sqlite.SQLiteDatabase d, String name) {
        java.text.Collator col = java.text.Collator.getInstance(new java.util.Locale("az"));
        long next = scalarLongJ(d, "SELECT COALESCE(MAX(ord), -1) + 1 FROM files");
        android.database.Cursor c = d.rawQuery("SELECT name, ord FROM files ORDER BY ord", null);
        long hit = -1;
        try {
            while (c.moveToNext()) {
                String n = c.getString(0) == null ? "" : c.getString(0);
                if (n.startsWith("⭐")) continue;
                if (col.compare(name, n) < 0) { hit = c.getLong(1); break; }
            }
        } finally { c.close(); }
        if (hit < 0) return next;
        d.execSQL("UPDATE files SET ord = ord + 1 WHERE ord >= ?", new Object[]{hit});
        return hit;
    }

    private static class Place { long bId = -1; String fileName, sheet, hdrJson; }

    /** Yazılan küçə adına (soyad + bina nömrəsi) uyğun mövcud bina; yoxdursa «🆕 Yeni əlavələr»də yeni küçə/bina yaradılır */
    private Place resolvePlace(android.database.sqlite.SQLiteDatabase d, android.database.sqlite.SQLiteDatabase e, boolean live,
                               String st, String[] sp, String defName, String newFile) throws Exception {
        Place pl = new Place();
            long bId = -1; String fileName = null, sheet = null, hdrJson = null;
            if (!st.isEmpty() && !firstNumJ(sp[1]).isEmpty() && !sp[0].isEmpty()) {
                android.database.Cursor bc = d.rawQuery("SELECT b.id, b.name, b.sheet, b.headers, f.name FROM buildings b JOIN files f ON f.id = b.file_id ORDER BY f.ord, b.ord", null);
                try {
                    while (bc.moveToNext()) {
                        String[] bs = splitNumJ(bc.getString(1));
                        if (!firstNumJ(bs[1]).equals(firstNumJ(sp[1]))) continue;
                        if (!sameStreetNameJ(sp[0], bs[0])) continue;
                        bId = bc.getLong(0); sheet = bc.getString(2) == null ? "" : bc.getString(2);
                        hdrJson = bc.getString(3); fileName = bc.getString(4);
                        break;
                    }
                } finally { bc.close(); }
            }

            // 2b) uyğun bina yoxdur, amma eyni soyadlı küçə bazada var (məs. H.BABAŞOV): bina həmin küçənin öz faylında,
            //     digər binalar kimi «H.BABAŞOV 22» adı ilə nömrə sırasına uyğun yerdə yaradılır («🆕 Yeni əlavələr»də yox)
            boolean placed = false;
            if (bId < 0 && !st.isEmpty() && !sp[0].isEmpty() && !firstNumJ(sp[1]).isEmpty()) {
                long sid0 = -1, fid0 = -1; String sName0 = null, fName0 = null;
                android.database.Cursor sc = d.rawQuery("SELECT s.id, s.name, f.id, f.name FROM streets s JOIN files f ON f.id = s.file_id ORDER BY f.ord, s.ord", null);
                try {
                    while (sc.moveToNext()) {
                        String fn = sc.getString(3) == null ? "" : sc.getString(3);
                        if (fn.startsWith("⭐") || fn.startsWith("🆕")) continue;
                        if (sc.getString(1) != null && sameStreetNameJ(sp[0], sc.getString(1))) {
                            sid0 = sc.getLong(0); sName0 = sc.getString(1); fid0 = sc.getLong(2); fName0 = fn;
                            break;
                        }
                    }
                } finally { sc.close(); }
                if (sid0 >= 0) {
                    placed = true;
                    String bName0 = sName0.trim() + " " + sp[1].trim();
                    fileName = fName0; sheet = bName0;
                    hdrJson = new JSONArray(java.util.Arrays.asList("Mənzil", "Soyad, Ad, Atasının adı", "YVÖK", "Borc", "Nömrə",
                        "Ümumi sahəsi", "Otaqların sayı", "Vergidən azad olunanlar")).toString();
                    if (live) {
                        long ex = scalarLongJ(d, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", String.valueOf(fid0), bName0);
                        if (ex >= 0) {
                            bId = ex;
                        } else {
                            long newNum = 0;
                            try { newNum = Long.parseLong(firstNumJ(sp[1])); } catch (Exception ignore) { }
                            long ordB = -1, lastOrd = -1;
                            android.database.Cursor bq = d.rawQuery("SELECT name, ord FROM buildings WHERE street_id = ? ORDER BY ord", new String[]{String.valueOf(sid0)});
                            try {
                                while (bq.moveToNext()) {
                                    lastOrd = bq.getLong(1);
                                    String[] bn = splitNumJ(bq.getString(0) == null ? "" : bq.getString(0));
                                    String dg = firstNumJ(bn[1]);
                                    if (ordB < 0 && !dg.isEmpty()) {
                                        long v = Long.MAX_VALUE;
                                        try { v = Long.parseLong(dg); } catch (Exception ignore) { }
                                        if (v > newNum) ordB = bq.getLong(1);
                                    }
                                }
                            } finally { bq.close(); }
                            if (ordB < 0) ordB = lastOrd >= 0 ? lastOrd + 1 : scalarLongJ(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM buildings WHERE file_id = ?", String.valueOf(fid0));
                            d.execSQL("UPDATE buildings SET ord = ord + 1 WHERE file_id = ? AND ord >= ?", new Object[]{fid0, ordB});
                            android.content.ContentValues cv = new android.content.ContentValues();
                            cv.put("street_id", sid0); cv.put("file_id", fid0); cv.put("name", bName0); cv.put("name_n", foldAz(bName0));
                            cv.put("title", ""); cv.put("sheet", bName0); cv.put("headers", hdrJson); cv.put("ord", ordB);
                            bId = d.insert("buildings", null, cv);
                        }
                    }
                    // bazanın öz «yeni bina» qeydi: baza yenilənəndə bərpa olunsun
                    e.execSQL("INSERT OR REPLACE INTO added VALUES('b', ?, ?, ?)", new Object[]{fName0, sName0, bName0});
                }
            }

            // 3) uyğun bina və uyğun küçə yoxdur: yeni kateqoriya / küçə / bina
            if (bId < 0 && !placed) {
                String useFile = newFile;
                String sName = sp[0].isEmpty() ? defName : sp[0];
                String bName = st.isEmpty() ? defName : st;
                // küçə adı və bina nömrəsi yazılıbsa: «R.RÜSTƏMOV» adlı yeni fayl, içində eyni adlı küçə və «R.RÜSTƏMOV 46» binası
                if (!st.isEmpty() && !sp[0].isEmpty() && !firstNumJ(sp[1]).isEmpty()) {
                    String ab = abbrevStreetJ(sp[0]);
                    if (!ab.isEmpty()) { useFile = ab; sName = ab; bName = ab + " " + sp[1].trim(); }
                }
                fileName = useFile; sheet = bName;
                hdrJson = new JSONArray(java.util.Arrays.asList("Mənzil", "Soyad, Ad, Atasının adı", "YVÖK", "Borc", "Nömrə",
                    "Ümumi sahəsi", "Otaqların sayı", "Vergidən azad olunanlar")).toString();
                long fid = scalarLongJ(d, "SELECT id FROM files WHERE name = ?", useFile);
                if (live) {
                    android.content.ContentValues cv = new android.content.ContentValues();
                    if (fid < 0) {
                        cv.put("name", useFile);
                        cv.put("ord", fileSlotOrdJ(d, useFile));
                        fid = d.insert("files", null, cv);
                    }
                    long sid = scalarLongJ(d, "SELECT id FROM streets WHERE file_id = ? AND name = ?", String.valueOf(fid), sName);
                    if (sid < 0) {
                        cv = new android.content.ContentValues();
                        cv.put("file_id", fid); cv.put("name", sName); cv.put("name_n", foldAz(sName));
                        cv.put("ord", scalarLongJ(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM streets WHERE file_id = ?", String.valueOf(fid)));
                        sid = d.insert("streets", null, cv);
                    }
                    bId = scalarLongJ(d, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", String.valueOf(fid), bName);
                    if (bId < 0) {
                        cv = new android.content.ContentValues();
                        cv.put("street_id", sid); cv.put("file_id", fid); cv.put("name", bName); cv.put("name_n", foldAz(bName));
                        cv.put("title", ""); cv.put("sheet", bName); cv.put("headers", hdrJson);
                        cv.put("ord", scalarLongJ(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM buildings WHERE file_id = ?", String.valueOf(fid)));
                        bId = d.insert("buildings", null, cv);
                    }
                }
                // bazanın öz «yeni kateqoriya/küçə/bina» qeydləri: baza yenilənəndə bərpa olunsun
                e.execSQL("INSERT OR REPLACE INTO added VALUES('f', '', '', ?)", new Object[]{useFile});
                e.execSQL("INSERT OR REPLACE INTO added VALUES('s', ?, '', ?)", new Object[]{useFile, sName});
                e.execSQL("INSERT OR REPLACE INTO added VALUES('b', ?, ?, ?)", new Object[]{useFile, sName, bName});
            }
        pl.bId = bId; pl.fileName = fileName; pl.sheet = sheet; pl.hdrJson = hdrJson;
        return pl;
    }

    /**
     * YVÖK bazada artıq varsa: yazılan küçə adının soyadı və ya bina nömrəsi bazadakı binadan fərqlidirsə
     * sətir uyğun binaya (yoxdursa «🆕 Yeni əlavələr»də yeni binaya) köçürülür. «H.BABAŞOV BİNA 20» = «Həmzə Babaşov bina 20»
     * eyni sayılır, dəyişiklik deyil. true - köçürüldü.
     */
    public boolean relocateExistingImpl(String code, String street) throws Exception {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        if (c.length() != 7) return false;
        String full = "10011" + c;
        String st = street == null ? "" : street.replaceAll("\\s+", " ").trim();
        String[] sp = splitNumJ(st);
        if (st.isEmpty() || sp[0].isEmpty() || firstNumJ(sp[1]).isEmpty()) return false;   // soyad və bina nömrəsi yoxdursa toxunulmur
        boolean live = bazaIsLive();
        File dbf = bazaFile();
        android.database.sqlite.SQLiteDatabase d = android.database.sqlite.SQLiteDatabase.openDatabase(
            dbf.getPath(), null, live ? android.database.sqlite.SQLiteDatabase.OPEN_READWRITE : android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        android.database.sqlite.SQLiteDatabase e = null;
        try {
            long rowId = -1, oldOrd = 0, oldB = -1; String oldBName = "", oldSheet = "", oldHdr = "[]", oldFile = ""; JSONArray src = null;
            android.database.Cursor q = d.rawQuery(
                "SELECT r.id, r.ord, r.cells, b.id, b.name, b.sheet, b.headers, f.name FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.cells LIKE ? ORDER BY r.id LIMIT 30", new String[]{"%" + c + "\"%"});
            try {
                while (q.moveToNext() && rowId < 0) {
                    JSONArray arr = new JSONArray(q.getString(2));
                    for (int i = 0; i < arr.length(); i++) {
                        String v = arr.optString(i, "").trim().toUpperCase();
                        if (v.equals(full) || v.equals(c)) {
                            rowId = q.getLong(0); oldOrd = q.getLong(1); src = arr; oldB = q.getLong(3);
                            oldBName = q.getString(4) == null ? "" : q.getString(4);
                            oldSheet = q.getString(5) == null ? "" : q.getString(5);
                            oldHdr = q.getString(6) == null ? "[]" : q.getString(6);
                            oldFile = q.getString(7);
                            break;
                        }
                    }
                }
            } finally { q.close(); }
            if (rowId < 0 || src == null) return false;

            // soyad + bina nömrəsi müqayisəsi
            String[] bs = splitNumJ(oldBName);
            if (bs[0].isEmpty() || firstNumJ(bs[1]).isEmpty()) return false;               // bazadakı bina adı müqayisə üçün yararsızdır
            if (firstNumJ(bs[1]).equals(firstNumJ(sp[1])) && sameStreetNameJ(sp[0], bs[0])) return false;   // dəyişiklik yoxdur

            e = ctx.openOrCreateDatabase("edits.db", android.content.Context.MODE_PRIVATE, null);
            e.execSQL("CREATE TABLE IF NOT EXISTS edits(file TEXT, sheet TEXT, ord INTEGER, col INTEGER, value TEXT, PRIMARY KEY(file, sheet, ord, col))");
            e.execSQL("CREATE TABLE IF NOT EXISTS added(kind TEXT, a TEXT, b TEXT, name TEXT, PRIMARY KEY(kind, a, b, name))");
            e.execSQL("CREATE TABLE IF NOT EXISTS added_rows(file TEXT, sheet TEXT, ord INTEGER, cells TEXT, PRIMARY KEY(file, sheet, ord))");
            e.execSQL("CREATE TABLE IF NOT EXISTS deleted_rows(file TEXT, sheet TEXT, ord INTEGER, PRIMARY KEY(file, sheet, ord))");

            java.util.HashMap<String, java.util.HashSet<String>> clb = az.axtaris.baza.ChangeLog.snapshot(e, d);
            Place pl = resolvePlace(d, e, live, st, sp, "Küçə adı yazılmayıb", "🆕 Yeni əlavələr");
            if ((live && pl.bId == oldB) || (pl.fileName.equals(oldFile) && pl.sheet.equals(oldSheet))) return false;

            // köhnə sətrin telefonda edilmiş xanaları (məs. əlavə olunan nömrə) yeni sətrə keçsin
            android.database.Cursor ec = e.rawQuery("SELECT col, value FROM edits WHERE file = ? AND sheet = ? AND ord = ?",
                new String[]{oldFile, oldSheet, String.valueOf(oldOrd)});
            try {
                while (ec.moveToNext()) {
                    int col = ec.getInt(0);
                    while (src.length() <= col) src.put("");
                    src.put(col, ec.getString(1) == null ? "" : ec.getString(1));
                }
            } finally { ec.close(); }

            // xanalar yeni binanın başlıqlarına görə düzülür
            JSONArray sh = new JSONArray(oldHdr), dh = new JSONArray(pl.hdrJson);
            JSONArray cells = new JSONArray();
            for (int i = 0; i < dh.length(); i++) {
                String key = foldAz(dh.optString(i, ""));
                String v = "";
                for (int j = 0; j < sh.length(); j++) {
                    if (foldAz(sh.optString(j, "")).equals(key)) { v = j < src.length() ? src.optString(j, "") : ""; break; }
                }
                cells.put(v);
            }

            long ord = 1;
            if (live && pl.bId >= 0) ord = scalarLongJ(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM rows WHERE building_id = ?", String.valueOf(pl.bId));
            long delMax = scalarLongJ(e, "SELECT COALESCE(MAX(ord), 0) FROM deleted_rows WHERE file = ? AND sheet = ?", pl.fileName, pl.sheet);
            if (delMax + 1 > ord) ord = delMax + 1;
            long addMax = scalarLongJ(e, "SELECT COALESCE(MAX(ord), 0) FROM added_rows WHERE file = ? AND sheet = ?", pl.fileName, pl.sheet);
            if (addMax + 1 > ord) ord = addMax + 1;

            if (live) {
                int mi = -1, ni = -1, bi = -1, pi = -1;
                for (int i = 0; i < dh.length(); i++) {
                    String h = foldAz(dh.optString(i, ""));
                    if (h.startsWith("menzil")) mi = i;
                    else if (h.startsWith("soyad") || h.startsWith("ad, soyad") || h.startsWith("ad,soyad")) ni = i;
                    else if (h.equals("borc")) bi = i;
                    else if (h.startsWith("nomre")) pi = i;
                }
                String mz = mi >= 0 ? cells.optString(mi, "") : "";
                String nm = ni >= 0 ? cells.optString(ni, "").trim() : "";
                String ph = pi >= 0 ? cells.optString(pi, "") : "";
                String[] toks = nm.isEmpty() ? new String[0] : nm.split("\\s+");
                String so = toks.length > 0 ? toks[0] : "", ad = toks.length > 1 ? toks[1] : "";
                StringBuilder at = new StringBuilder();
                for (int i = 2; i < toks.length; i++) { if (at.length() > 0) at.append(' '); at.append(toks[i]); }
                double bv = 0;
                try { if (bi >= 0) bv = Double.parseDouble(cells.optString(bi, "").replace("\u00A0", "").replace(" ", "").replace(',', '.')); } catch (Exception ignore) { }
                android.content.ContentValues rv = new android.content.ContentValues();
                rv.put("building_id", pl.bId); rv.put("ord", ord);
                rv.put("menzil", mz); rv.put("menzil_n", foldAz(mz));
                rv.put("soyad", so); rv.put("ad", ad); rv.put("ata", at.toString());
                rv.put("soyad_n", foldAz(so)); rv.put("ad_n", foldAz(ad)); rv.put("ata_n", foldAz(at.toString()));
                rv.put("nomre_d", ph.replaceAll("\\D", "")); rv.put("cells", cells.toString()); rv.put("borc", bv);
                d.insert("rows", null, rv);
                d.execSQL("DELETE FROM rows WHERE id = ?", new Object[]{rowId});
            }
            e.execSQL("INSERT OR REPLACE INTO added_rows VALUES(?, ?, ?, ?)", new Object[]{pl.fileName, pl.sheet, ord, cells.toString()});
            // köhnə sətir silinmiş sayılır (Bələdiyyə bazasının öz «Sil» qaydası ilə eyni)
            e.execSQL("INSERT OR REPLACE INTO deleted_rows VALUES(?, ?, ?)", new Object[]{oldFile, oldSheet, oldOrd});
            e.execSQL("DELETE FROM edits WHERE file = ? AND sheet = ? AND ord = ?", new Object[]{oldFile, oldSheet, oldOrd});
            e.execSQL("DELETE FROM added_rows WHERE file = ? AND sheet = ? AND ord = ?", new Object[]{oldFile, oldSheet, oldOrd});
            az.axtaris.baza.ChangeLog.record(e, "🔀 YVÖK köçürüldü (WhatsApp): " + full + "\n" + oldBName + " → " + pl.sheet, clb, d);
            return true;
        } finally {
            if (e != null) try { e.close(); } catch (Throwable ignore) { }
            d.close();
        }
    }

    /**
     * YVÖK bazada yoxdursa yeni sətir əlavə edir. Qaytarır: 1 - əlavə edildi, 2 - YVÖK bazada artıq var, 0 - heç nə.
     * Yer: yazılan küçə adı bazadakı bir binaya uyğundursa (soyad + bina nömrəsi) həmin binaya, yoxdursa
     * «🆕 Yeni əlavələr» kateqoriyasında yeni küçə/bina yaradılıb ora.
     */
    public int addNewToBazaImpl(String code, String phone, String name, String borc, String street, String menzil) throws Exception {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        if (c.length() != 7) return 0;
        String full = "10011" + c;
        boolean live = bazaIsLive();
        File dbf = bazaFile();
        android.database.sqlite.SQLiteDatabase d = android.database.sqlite.SQLiteDatabase.openDatabase(
            dbf.getPath(), null, live ? android.database.sqlite.SQLiteDatabase.OPEN_READWRITE : android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        android.database.sqlite.SQLiteDatabase e = null;
        try {
            // 1) YVÖK bazada varmı
            android.database.Cursor q = d.rawQuery("SELECT cells FROM rows WHERE cells LIKE ? LIMIT 30", new String[]{"%" + c + "\"%"});
            try {
                while (q.moveToNext()) {
                    JSONArray arr = new JSONArray(q.getString(0));
                    for (int i = 0; i < arr.length(); i++) {
                        String v = arr.optString(i, "").trim().toUpperCase();
                        if (v.equals(full) || v.equals(c)) return 2;
                    }
                }
            } finally { q.close(); }

            // saytdan ad gəlməyibsə (səhv/tapılmayan YVÖK) bazaya yeni sətir yazılmır
            if (name == null || name.trim().isEmpty()) return 0;

            String st = street == null ? "" : street.replaceAll("\\s+", " ").trim();
            String[] sp = splitNumJ(st);
            String defName = "Küçə adı yazılmayıb";
            String newFile = "🆕 Yeni əlavələr";

            e = ctx.openOrCreateDatabase("edits.db", android.content.Context.MODE_PRIVATE, null);
            e.execSQL("CREATE TABLE IF NOT EXISTS added(kind TEXT, a TEXT, b TEXT, name TEXT, PRIMARY KEY(kind, a, b, name))");
            e.execSQL("CREATE TABLE IF NOT EXISTS added_rows(file TEXT, sheet TEXT, ord INTEGER, cells TEXT, PRIMARY KEY(file, sheet, ord))");
            e.execSQL("CREATE TABLE IF NOT EXISTS deleted_rows(file TEXT, sheet TEXT, ord INTEGER, PRIMARY KEY(file, sheet, ord))");

            java.util.HashMap<String, java.util.HashSet<String>> clb = az.axtaris.baza.ChangeLog.snapshot(e, d);
            // 2-3) yer: uyğun mövcud bina, yoxdursa yeni kateqoriya / küçə / bina
            Place pl = resolvePlace(d, e, live, st, sp, defName, newFile);
            long bId = pl.bId; String fileName = pl.fileName, sheet = pl.sheet, hdrJson = pl.hdrJson;

            // 4) sətrin xanaları: başlıqlara görə
            JSONArray hs = new JSONArray(hdrJson);
            String nm = name == null ? "" : name.replaceAll("\\s+", " ").trim().toUpperCase(new Locale("az"));
            String bc2 = borc == null ? "" : borc.trim();
            String ph = phone == null ? "" : phone.trim();
            String mz = menzil == null ? "" : menzil.trim();
            JSONArray cells = new JSONArray();
            int mi = -1, ni = -1, bi = -1, si = -1, pi = -1;
            for (int i = 0; i < hs.length(); i++) {
                String h = foldAz(hs.optString(i, ""));
                String v = "";
                if (h.startsWith("menzil")) { v = mz; mi = i; }
                else if (h.startsWith("soyad") || h.startsWith("ad, soyad") || h.startsWith("ad,soyad")) { v = nm; ni = i; }
                else if (h.startsWith("yvok")) { v = full; }
                else if (h.equals("borc")) { v = bc2; bi = i; }
                else if (h.startsWith("nomre")) { v = ph; pi = i; }
                cells.put(v);
            }

            // 5) sətrin sırası
            long ord = 1;
            if (bId >= 0) ord = scalarLongJ(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM rows WHERE building_id = ?", String.valueOf(bId));
            long delMax = scalarLongJ(e, "SELECT COALESCE(MAX(ord), 0) FROM deleted_rows WHERE file = ? AND sheet = ?", fileName, sheet);
            if (delMax + 1 > ord) ord = delMax + 1;
            long addMax = scalarLongJ(e, "SELECT COALESCE(MAX(ord), 0) FROM added_rows WHERE file = ? AND sheet = ?", fileName, sheet);
            if (addMax + 1 > ord) ord = addMax + 1;

            if (live && bId >= 0) {
                String[] toks = nm.isEmpty() ? new String[0] : nm.split("\\s+");
                String so = toks.length > 0 ? toks[0] : "", ad = toks.length > 1 ? toks[1] : "";
                StringBuilder at = new StringBuilder();
                for (int i = 2; i < toks.length; i++) { if (at.length() > 0) at.append(' '); at.append(toks[i]); }
                double bv = 0;
                try { bv = Double.parseDouble(bc2.replace("\u00A0", "").replace(" ", "").replace(',', '.')); } catch (Exception ignore) { }
                android.content.ContentValues rv = new android.content.ContentValues();
                rv.put("building_id", bId); rv.put("ord", ord);
                rv.put("menzil", mz); rv.put("menzil_n", foldAz(mz));
                rv.put("soyad", so); rv.put("ad", ad); rv.put("ata", at.toString());
                rv.put("soyad_n", foldAz(so)); rv.put("ad_n", foldAz(ad)); rv.put("ata_n", foldAz(at.toString()));
                rv.put("nomre_d", ph.replaceAll("\\D", "")); rv.put("cells", cells.toString()); rv.put("borc", bv);
                d.insert("rows", null, rv);
            }
            e.execSQL("INSERT OR REPLACE INTO added_rows VALUES(?, ?, ?, ?)", new Object[]{fileName, sheet, ord, cells.toString()});
            az.axtaris.baza.ChangeLog.record(e, "➕ Yeni YVÖK bazaya əlavə olundu (WhatsApp): " + sheet + " · " + nm + " · " + full, clb, d);
            return 1;
        } finally {
            if (e != null) try { e.close(); } catch (Throwable ignore) { }
            d.close();
        }
    }

    // =====================================================================
    //  Avtomatik qalan əməliyyat: bazadakı sahibin adı köhnədirsə yenilənir
    // =====================================================================

    private static final java.util.Set<String> NAME_NOISE = new java.util.HashSet<>(
        java.util.Arrays.asList("oglu", "qizi", "kisi", "ogli"));

    private static java.util.Set<String> nameTokens(String s) {
        java.util.HashSet<String> r = new java.util.HashSet<>();
        for (String w : foldAz(s).split("[^a-z0-9]+")) if (w.length() > 1 && !NAME_NOISE.contains(w)) r.add(w);
        return r;
    }

    /** Eyni şəxsdir (sıra/hərf böyüklüyü fərqi, «oğlu/qızı» əlavəsi sayılmır): ≥2 ortaq söz və ya biri digərinin içindədir */
    static boolean sameOwner(String a, String b) {
        java.util.Set<String> x = nameTokens(a), y = nameTokens(b);
        if (x.isEmpty() || y.isEmpty()) return false;
        int common = 0;
        for (String t : x) if (y.contains(t)) common++;
        return common >= 2 || common == x.size() || common == y.size();
    }

    /** true - bazadakı köhnə ad saytdan gələn yeni adla əvəz olundu. Ad eynidirsə və ya YVÖK bazada yoxdursa heç nə dəyişmir. */
    public boolean updateNameImpl(String code, String name) throws Exception {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        String nm = name == null ? "" : name.replaceAll("\\s+", " ").trim().toUpperCase(new Locale("az"));
        if (c.length() != 7 || nameTokens(nm).isEmpty()) return false;
        String full = "10011" + c;
        boolean live = bazaIsLive();
        File f = bazaFile();
        android.database.sqlite.SQLiteDatabase d = android.database.sqlite.SQLiteDatabase.openDatabase(
            f.getPath(), null, live ? android.database.sqlite.SQLiteDatabase.OPEN_READWRITE : android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        try {
            long rowId = -1; int ord = 0, idx = -1; String sheet = "", fileName = ""; JSONArray cells = null;
            android.database.Cursor cur = d.rawQuery(
                "SELECT r.id, r.ord, r.cells, b.headers, b.sheet, f.name FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.cells LIKE ? ORDER BY r.id LIMIT 30",
                new String[]{"%" + c + "\"%"});
            try {
                while (cur.moveToNext()) {
                    JSONArray arr = new JSONArray(cur.getString(2));
                    boolean ok = false;
                    for (int i = 0; i < arr.length(); i++) {
                        String v = arr.optString(i, "").trim().toUpperCase();
                        if (v.equals(full) || v.equals(c)) { ok = true; break; }
                    }
                    if (!ok) continue;
                    JSONArray hs = new JSONArray(cur.getString(3));
                    int hi = -1;
                    for (int i = 0; i < hs.length(); i++) {
                        String h = foldAz(hs.optString(i, ""));
                        if (h.startsWith("soyad") || h.startsWith("ad, soyad") || h.startsWith("ad,soyad")) { hi = i; break; }
                    }
                    if (hi < 0) continue;
                    rowId = cur.getLong(0); ord = cur.getInt(1); cells = arr; idx = hi;
                    sheet = cur.getString(4) == null ? "" : cur.getString(4);
                    fileName = cur.getString(5);
                    break;
                }
            } finally { cur.close(); }
            if (rowId < 0 || cells == null) return false;

            String old = idx < cells.length() ? cells.optString(idx, "").trim() : "";
            if (!old.isEmpty() && sameOwner(old, nm)) return false;
            while (cells.length() <= idx) cells.put("");
            cells.put(idx, nm);
            if (live) {
                String[] toks = nm.split("\\s+");
                String so = toks.length > 0 ? toks[0] : "", ad = toks.length > 1 ? toks[1] : "";
                StringBuilder at = new StringBuilder();
                for (int i = 2; i < toks.length; i++) { if (at.length() > 0) at.append(' '); at.append(toks[i]); }
                d.execSQL("UPDATE rows SET cells = ?, soyad = ?, ad = ?, ata = ?, soyad_n = ?, ad_n = ?, ata_n = ? WHERE id = ?",
                    new Object[]{cells.toString(), so, ad, at.toString(), foldAz(so), foldAz(ad), foldAz(at.toString()), rowId});
            }
            android.database.sqlite.SQLiteDatabase e = ctx.openOrCreateDatabase("edits.db", android.content.Context.MODE_PRIVATE, null);
            try {
                e.execSQL("CREATE TABLE IF NOT EXISTS edits(file TEXT, sheet TEXT, ord INTEGER, col INTEGER, value TEXT, PRIMARY KEY(file, sheet, ord, col))");
                java.util.HashMap<String, java.util.HashSet<String>> clb = az.axtaris.baza.ChangeLog.snapshot(e, d);
                e.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", new Object[]{fileName, sheet, ord, idx, nm});
                // Ad/soyad dəyişikliyi "Dəyişikliklər" jurnalına daxil edilmir, amma digər cihazlara sinxronizasiya olunur.
                az.axtaris.baza.PendingChanges.syncSoon();
            } finally { e.close(); }
            return true;
        } finally { d.close(); }
    }

    /** true - bazadakı mənzil nömrəsi mesajdakı (əllə dəyişdirilmiş) ilə əvəz olundu. Eynidirsə və ya YVÖK bazada yoxdursa heç nə dəyişmir. */
    public boolean updateMenzilImpl(String code, String menzil) throws Exception {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        String mz = menzil == null ? "" : menzil.replaceAll("\\s+", " ").trim();
        if (c.length() != 7 || mz.isEmpty()) return false;
        String full = "10011" + c;
        boolean live = bazaIsLive();
        File f = bazaFile();
        android.database.sqlite.SQLiteDatabase d = android.database.sqlite.SQLiteDatabase.openDatabase(
            f.getPath(), null, live ? android.database.sqlite.SQLiteDatabase.OPEN_READWRITE : android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        try {
            long rowId = -1; int ord = 0, idx = -1; String sheet = "", fileName = ""; JSONArray cells = null;
            android.database.Cursor cur = d.rawQuery(
                "SELECT r.id, r.ord, r.cells, b.headers, b.sheet, f.name FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.cells LIKE ? ORDER BY r.id LIMIT 30",
                new String[]{"%" + c + "\""});
            try {
                while (cur.moveToNext()) {
                    JSONArray arr = new JSONArray(cur.getString(2));
                    if (!rowHasCode(arr, full, c)) continue;
                    JSONArray hs = new JSONArray(cur.getString(3));
                    int hi = -1;
                    for (int i = 0; i < hs.length(); i++) if (foldAz(hs.optString(i, "")).startsWith("menzil")) { hi = i; break; }
                    if (hi < 0) continue;
                    rowId = cur.getLong(0); ord = cur.getInt(1); cells = arr; idx = hi;
                    sheet = cur.getString(4) == null ? "" : cur.getString(4);
                    fileName = cur.getString(5);
                    break;
                }
            } finally { cur.close(); }
            if (rowId < 0 || cells == null) return false;

            String old = idx < cells.length() ? cells.optString(idx, "").replaceAll("\\s+", " ").trim() : "";
            if (foldAz(old).equals(foldAz(mz))) return false;
            // sahədə yalnız rəqəm göstərilir (12A -> 12): baza dəyərinin rəqəm hissəsi eynidirsə dəyişiklik sayılmır
            if (mz.matches("\\d+") && old.replaceAll("\\D", "").equals(mz)) return false;
            while (cells.length() <= idx) cells.put("");
            cells.put(idx, mz);
            if (live) {
                d.execSQL("UPDATE rows SET cells = ?, menzil = ?, menzil_n = ? WHERE id = ?",
                    new Object[]{cells.toString(), mz, foldAz(mz), rowId});
            }
            android.database.sqlite.SQLiteDatabase e = ctx.openOrCreateDatabase("edits.db", android.content.Context.MODE_PRIVATE, null);
            try {
                e.execSQL("CREATE TABLE IF NOT EXISTS edits(file TEXT, sheet TEXT, ord INTEGER, col INTEGER, value TEXT, PRIMARY KEY(file, sheet, ord, col))");
                java.util.HashMap<String, java.util.HashSet<String>> clb = az.axtaris.baza.ChangeLog.snapshot(e, d);
                e.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", new Object[]{fileName, sheet, ord, idx, mz});
                az.axtaris.baza.ChangeLog.record(e, "🏠 Mənzil yeniləndi (mesaj): " + sheet + " · " + full + "\n" + (old.isEmpty() ? "—" : old) + " → " + mz, clb, d);
            } finally { e.close(); }
            return true;
        } finally { d.close(); }
    }

    // =====================================================================
    //  «Dəyişikliklər»ə düşən təkliflər: bazaya toxunmadan yoxlama (yalnız oxuma)
    // =====================================================================

    private android.database.sqlite.SQLiteDatabase openRead() throws Exception {
        return android.database.sqlite.SQLiteDatabase.openDatabase(bazaFile().getPath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
    }

    private static boolean rowHasCode(JSONArray arr, String full, String c) {
        for (int i = 0; i < arr.length(); i++) {
            String v = arr.optString(i, "").trim().toUpperCase();
            if (v.equals(full) || v.equals(c)) return true;
        }
        return false;
    }

    /** Yerin növü: {növ, bina adı, bina id}. növ: "bina" (mövcud bina), "yenibina" (mövcud küçədə yeni bina), "yenikuce" (yeni fayl/küçə/bina), "yenielave" («🆕 Yeni əlavələr») */
    private String[] peekPlace(android.database.sqlite.SQLiteDatabase d, String st, String[] sp) {
        if (!st.isEmpty() && !firstNumJ(sp[1]).isEmpty() && !sp[0].isEmpty()) {
            android.database.Cursor bc = d.rawQuery("SELECT b.id, b.name FROM buildings b JOIN files f ON f.id = b.file_id ORDER BY f.ord, b.ord", null);
            try {
                while (bc.moveToNext()) {
                    String[] bs = splitNumJ(bc.getString(1));
                    if (!firstNumJ(bs[1]).equals(firstNumJ(sp[1]))) continue;
                    if (!sameStreetNameJ(sp[0], bs[0])) continue;
                    return new String[]{"bina", bc.getString(1) == null ? "" : bc.getString(1), String.valueOf(bc.getLong(0))};
                }
            } finally { bc.close(); }
            android.database.Cursor sc = d.rawQuery("SELECT s.name, f.name FROM streets s JOIN files f ON f.id = s.file_id ORDER BY f.ord, s.ord", null);
            try {
                while (sc.moveToNext()) {
                    String fn = sc.getString(1) == null ? "" : sc.getString(1);
                    if (fn.startsWith("⭐") || fn.startsWith("🆕")) continue;
                    if (sc.getString(0) != null && sameStreetNameJ(sp[0], sc.getString(0))) {
                        return new String[]{"yenibina", sc.getString(0).trim() + " " + sp[1].trim(), "-1"};
                    }
                }
            } finally { sc.close(); }
            String ab = abbrevStreetJ(sp[0]);
            if (!ab.isEmpty()) return new String[]{"yenikuce", ab + " " + sp[1].trim(), "-1"};
        }
        return new String[]{"yenielave", st.isEmpty() ? "Küçə adı yazılmayıb" : st, "-1"};
    }

    /**
     * YVÖK bazada yoxdursa təklif: {növ, təsvir}; YVÖK bazada var, ad yoxdur və ya baza oxunmursa null.
     * növ: "menzil" (yeni mənzil) və ya "kuce" (yeni küçə).
     */
    public String[] previewNew(String code, String name, String street, String menzil) {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        if (c.length() != 7 || name == null || name.trim().isEmpty()) return null;
        String full = "10011" + c;
        android.database.sqlite.SQLiteDatabase d = null;
        try {
            d = openRead();
            android.database.Cursor q = d.rawQuery("SELECT cells FROM rows WHERE cells LIKE ? LIMIT 30", new String[]{"%" + c + "\"%"});
            try { while (q.moveToNext()) if (rowHasCode(new JSONArray(q.getString(0)), full, c)) return null; } finally { q.close(); }
            String st = street == null ? "" : street.replaceAll("\\s+", " ").trim();
            String[] pk = peekPlace(d, st, splitNumJ(st));
            String nm = name.replaceAll("\\s+", " ").trim().toUpperCase(new Locale("az"));
            String mz = menzil == null ? "" : menzil.trim();
            boolean newStreet = pk[0].equals("yenikuce") || pk[0].equals("yenielave");
            String where = pk[0].equals("yenielave") ? "🆕 Yeni əlavələr" : pk[1];
            String head = newStreet ? "🛣 Yeni küçə + mənzil: " : "➕ Yeni mənzil: ";
            return new String[]{newStreet ? "kuce" : "menzil",
                head + where + (mz.isEmpty() ? "" : " · mənzil " + mz) + "\n" + nm + " · " + full};
        } catch (Throwable t) {
            return null;
        } finally { if (d != null) try { d.close(); } catch (Throwable ignore) { } }
    }

    /** YVÖK bazada var, amma küçə/bina fərqlidirsə təklifin təsviri; dəyişiklik yoxdursa null */
    public String previewRelocate(String code, String street) {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        if (c.length() != 7) return null;
        String full = "10011" + c;
        String st = street == null ? "" : street.replaceAll("\\s+", " ").trim();
        String[] sp = splitNumJ(st);
        if (st.isEmpty() || sp[0].isEmpty() || firstNumJ(sp[1]).isEmpty()) return null;
        android.database.sqlite.SQLiteDatabase d = null;
        try {
            d = openRead();
            long oldB = -1; String oldBName = "";
            android.database.Cursor q = d.rawQuery(
                "SELECT r.cells, b.id, b.name FROM rows r JOIN buildings b ON b.id = r.building_id WHERE r.cells LIKE ? ORDER BY r.id LIMIT 30",
                new String[]{"%" + c + "\"%"});
            try {
                while (q.moveToNext()) {
                    if (rowHasCode(new JSONArray(q.getString(0)), full, c)) {
                        oldB = q.getLong(1); oldBName = q.getString(2) == null ? "" : q.getString(2);
                        break;
                    }
                }
            } finally { q.close(); }
            if (oldB < 0) return null;
            String[] bs = splitNumJ(oldBName);
            if (bs[0].isEmpty() || firstNumJ(bs[1]).isEmpty()) return null;
            if (firstNumJ(bs[1]).equals(firstNumJ(sp[1])) && sameStreetNameJ(sp[0], bs[0])) return null;
            String[] pk = peekPlace(d, st, sp);
            if (pk[0].equals("bina") && pk[2].equals(String.valueOf(oldB))) return null;
            String to = pk[0].equals("yenielave") ? "🆕 Yeni əlavələr" : pk[1];
            boolean newStreet = pk[0].equals("yenikuce");
            return (newStreet ? "🛣 Yeni küçəyə köçür: " : "🔀 Köçür: ") + full + "\n" + oldBName.replaceAll("\\s+", " ").trim() + " → " + to;
        } catch (Throwable t) {
            return null;
        } finally { if (d != null) try { d.close(); } catch (Throwable ignore) { } }
    }

    /** YVÖK bazada varmı (təklifin təsdiqi anında hələ də aktualdırmı yoxlamaq üçün) */
    public boolean existsInBaza(String code) {
        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
        if (c.length() != 7) return false;
        String full = "10011" + c;
        android.database.sqlite.SQLiteDatabase d = null;
        try {
            d = openRead();
            android.database.Cursor q = d.rawQuery("SELECT cells FROM rows WHERE cells LIKE ? LIMIT 30", new String[]{"%" + c + "\"%"});
            try { while (q.moveToNext()) if (rowHasCode(new JSONArray(q.getString(0)), full, c)) return true; } finally { q.close(); }
        } catch (Throwable t) { } finally { if (d != null) try { d.close(); } catch (Throwable ignore) { } }
        return false;
    }

}
