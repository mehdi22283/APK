(function(code){
  var S = window.__yS;
  if (!S || S.code !== code) { S = window.__yS = { code: code, filled: false, clicked: false, polls: 0, field: null }; }
  S.polls++;
  function vis(el){ var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function fire(el){
    var r = el.getBoundingClientRect();
    var o = {bubbles:true, cancelable:true, view:window, clientX:r.left+r.width/2, clientY:r.top+r.height/2};
    ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){
      try { var E = (n.indexOf('pointer')===0 && window.PointerEvent) ? PointerEvent : MouseEvent; el.dispatchEvent(new E(n, o)); } catch(e){}
    });
    try { el.click(); } catch(e){}
  }
  function leaf(re){
    var els = [].slice.call(document.querySelectorAll('body *'));
    for (var i=0; i<els.length; i++){
      var e = els[i];
      if (e.children.length > 0 || !vis(e)) continue;
      if (re.test(((e.innerText||e.textContent)+'').trim())) return e;
    }
    return null;
  }
  function textAfter(re){
    var l = leaf(re);
    if (!l) return '';
    var lt = ((l.innerText||l.textContent)+'').trim();
    var p = l;
    for (var d=0; d<4 && p; d++){
      p = p.parentElement; if (!p) break;
      var t = ((p.innerText||'')+'').replace(lt,'').replace(/\s+/g,' ').trim();
      if (t) return t;
    }
    return '';
  }
  // Yalnız "Məbləğ (AZN)" sahələri sayılır; "Xidmət haqqı (AZN)" məbləğləri borca qatılmır.
  // Bir neçə istifadəçi/kart göstəriləndə hər kartın məbləği ayrıca götürülür.
  function amountVals(){
    var labels = [].slice.call(document.querySelectorAll('body *')).filter(function(e){
      return e.children.length === 0 && vis(e) && /^məbləğ\s*\(?\s*azn\s*\)?\s*:?$/i.test(((e.innerText||e.textContent||'')+'').trim());
    });
    var entries = [];
    labels.forEach(function(label){
      var p = label, found = '', selected = false, radioKnown = false;
      for (var d=0; d<7 && p; d++){
        p = p.parentElement; if (!p) break;
        // Radio düyməsi olan kartlarda yalnız seçilmiş istifadəçinin məbləği əsas borc götürülür.
        // Kart konteyneri bir radio saxlayırsa, həmin radio bu etiketə aiddir.
        var radios = [].slice.call(p.querySelectorAll('input[type=radio],[role=radio]'));
        if (!radioKnown && radios.length === 1) {
          radioKnown = true;
          selected = !!(radios[0].checked || radios[0].getAttribute('aria-checked') === 'true');
        }
        var ins = [].slice.call(p.querySelectorAll('input:not([type=hidden]),textarea')).filter(vis);
        for (var i=0; i<ins.length; i++){
          var v = (ins[i].value||'').trim();
          if (/^[+−–-]?\d+(?:[.,]\d+)?$/.test(v)) { found = v; break; }
        }
        if (found) break;
        // Bəzi Yelo versiyalarında məbləğ input deyil, eyni kartın mətn sətridir.
        var lines = ((p.innerText||'')+'').split(/\r?\n/).map(function(x){return x.trim();}).filter(Boolean);
        var ix = lines.findIndex(function(x){return /^məbləğ\s*\(?\s*azn\s*\)?\s*:?$/i.test(x);});
        if (ix >= 0 && ix+1 < lines.length && /^[+−–-]?\d+(?:[.,]\d+)?(?:\s*azn)?$/i.test(lines[ix+1])) {
          found = lines[ix+1].replace(/\s*azn$/i,'').trim(); break;
        }
      }
      if (found) entries.push({value:found.replace(/,/g,'.'), selected:selected, radioKnown:radioKnown});
    });
    // Seçilmiş kart varsa onun AZN məbləği əvvəl verilir; bütün kartlar sayılır (eyni rəqəm olsa belə).
    if (entries.some(function(x){return x.radioKnown && x.selected;})) {
      entries.sort(function(a,b){ return (b.radioKnown && b.selected ? 1 : 0) - (a.radioKnown && a.selected ? 1 : 0); });
    }
    return entries.map(function(x){ return x.value; });
  }
  function amountVal(){
    var l = leaf(/^məbləğ\s*\(azn\)\s*:?$/i);
    if (!l) return '';
    var p = l;
    for (var d=0; d<5 && p; d++){
      p = p.parentElement; if (!p) break;
      var ins = p.querySelectorAll('input');
      for (var i=0; i<ins.length; i++){
        var v = (ins[i].value||'').trim();
        if (/^-?\d+([.,]\d+)?$/.test(v)) return v;
      }
      if (ins.length) return '';
    }
    return '';
  }
  function findBtn(){
    var ft = S.field ? S.field.getBoundingClientRect().top : 0;
    var els = [].slice.call(document.querySelectorAll('button,a,span,div,p,label,input[type=submit],input[type=button]')).filter(function(e){
      if (!vis(e)) return false;
      var t = ((e.innerText||e.value||'')+'').trim().toLowerCase();
      return t === 'axtar' && e.getBoundingClientRect().top >= ft - 5;
    });
    if (els.length) {
      var e0 = els[els.length-1];
      for (var q=0; q<els.length; q++){ if (els[q].tagName==='BUTTON' || els[q].tagName==='INPUT'){ e0 = els[q]; break; } }
      var c = e0.closest ? e0.closest('button,a,[role=button],[onclick]') : null;
      return c || e0;
    }
    var btns = [].slice.call(document.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a.btn,a[class*=btn],div[class*=btn]')).filter(vis);
    var words = ['axtar','search','yoxla','tap','göstər','sorğu'];
    for (var w=0; w<words.length; w++) for (var j=0; j<btns.length; j++){
      var t2 = ((btns[j].innerText||btns[j].value||btns[j].getAttribute('aria-label')||'')+'').toLowerCase();
      if (t2.indexOf(words[w]) >= 0) return btns[j];
    }
    for (var j2=0; j2<btns.length; j2++) if ((btns[j2].type||'') === 'submit') return btns[j2];
    var p = S.field;
    for (var d=0; d<5 && p; d++){
      p = p.parentElement; if (!p) break;
      var bs = [].slice.call(p.querySelectorAll('button,input[type=submit]')).filter(vis);
      if (bs.length) return bs[bs.length-1];
    }
    return btns.length ? btns[btns.length-1] : null;
  }
  var out = { payer:'', yvok:'', amount:'', nf:false, st:'' };
  if (!S.filled) {
    var inputs = [].slice.call(document.querySelectorAll('input')).filter(function(i){
      var t = (i.type||'text').toLowerCase();
      if (i.readOnly || i.disabled || !vis(i)) return false;
      if (!(t==='text'||t==='search'||t==='tel'||t==='number')) return false;
      if ((i.placeholder||'').toLowerCase().indexOf('axtar') >= 0) return false;
      if (i.closest && i.closest('[class*=searchContainer]')) return false;
      if ((i.value||'').trim().toLowerCase() === 'yvök') return false;
      return true;
    });
    if (!inputs.length) { out.st = 'wait'; return JSON.stringify(out); }
    var f = inputs[inputs.length-1];
    S.field = f;
    var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
    f.focus(); setter.call(f, code);
    ['keydown','input','keyup','change'].forEach(function(n){
      try { f.dispatchEvent(n.indexOf('key')===0 ? new KeyboardEvent(n,{key:'0',bubbles:true}) : new Event(n,{bubbles:true})); } catch(e){}
    });
    S.filled = true; out.st = 'filled';
    return JSON.stringify(out);
  }
  out.payer = textAfter(/^ödəyən\s*:$/i);
  out.yvok = textAfter(/^yvök\s*:$/i);
  out.amounts = amountVals();
  out.amountCount = out.amounts.length;
  out.amount = out.amounts.length ? out.amounts[0] : '';
  if (!out.amount) out.amount = amountVal();
  if (out.payer && out.amount) { out.st = 'result'; return JSON.stringify(out); }
  if (!S.clicked) {
    var b = findBtn();
    if (!b) { out.st = 'nobtn'; return JSON.stringify(out); }
    if (b.disabled) { try { S.field.dispatchEvent(new Event('input',{bubbles:true})); } catch(e){} out.st = 'btndis'; return JSON.stringify(out); }
    S.clicked = true; S.clickPoll = S.polls;
    fire(b);
    out.st = 'clicked';
    return JSON.stringify(out);
  }
  // "tapılmadı" xəbərdarlığı yalnız düymə basıldıqdan bir neçə sorğu sonra yoxlanılır
  if (S.polls - S.clickPoll >= 6) {
    var bt = ((document.body && document.body.innerText) || '');
    if (/tapılmad[ıi]|tapılmay[ıi]b|mövcud deyil|məlumat yoxdur|düzgün deyil/i.test(bt)) out.nf = true;
  }
  out.st = 'waiting';
  return JSON.stringify(out);
})('__CODE__')
