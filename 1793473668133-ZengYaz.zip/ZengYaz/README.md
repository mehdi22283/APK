# ZengYaz

Telefon zənglərini və VOIP (WhatsApp, Telegram, Viber) zənglərini yazan tətbiq. Wi-Fi olmadan və kompüter olmadan işləyir.

## JemRec (base.apk) zəngi necə yazır

Tətbiqin özündə RECORD_AUDIO icazəsi yoxdur və audio cihaz açmır (manifestdəki təsvirdə də belə yazılıb). Səsi adb vasitəsilə shell istifadəçisi (uid 2000) ilə qalxan ayrıca bir proses yazır: tətbiq assets/jemrec-capture.jar faylını /data/local/tmp qovluğuna qoyur və `app_process` ilə işə salır, proses 127.0.0.1:28472 loopback soketini dinləyir, tətbiq yazını bu soketdən götürür. Jar scrcpy-nin audio kodu üzərində qurulub (saxta ActivityThread/Application, paket adı com.android.shell).

Adi zəng üçün mənbə AudioSource.VOICE_CALL-dur (modemin səs yolu, iki tərəf birlikdə). Alternativlər: VOICE_UPLINK, VOICE_DOWNLINK, VOICE_PERFORMANCE, MIC, MIC_CAMCORDER, MIC_UNPROCESSED, MIC_VOICE_COMMUNICATION, MIC_VOICE_RECOGNITION. Android shell-in zəng səsini kopyalamasına icazə verməsə, mikrofona keçir.

VOIP zəngi üçün AudioManager.getMode() izlənir: MODE_IN_CALL adi zəngdir, MODE_IN_COMMUNICATION messenger zəngidir. Qarşı tərəfin səsi `AudioPolicy` + `AudioMix` ilə (USAGE_VOICE_COMMUNICATION qaydası, ROUTE_FLAG_LOOP_BACK_RENDER) alınır: səs dinamikdən çıxmağa davam edir, kopyası yazılır. Öz səsin mikrofondan yazılır. getActiveRecordingConfigurations ilə hansı tətbiqin (uid) zəngdə olduğu, bildiriş dinləyicisi ilə ad və istiqamət tapılır. WhatsApp: com.whatsapp, com.whatsapp.w4b; Telegram: org.telegram.messenger; Viber: com.viber.voip.

ADB-yə qoşulma: libadb-android (SPAKE2 cütləməsi, mDNS). İlk dəfə Wi-Fi + Wireless debugging cütləməsi, sonra `tcpip:5555`; bundan sonra tətbiq 127.0.0.1:5555 ilə lokal qoşulur. Telefon yenidən başlayanda port bağlanır, bir dəfə Wi-Fi lazım olur.

## Bu layihə

Eyni arxitektura, sıfırdan yazılıb. `shell/Daemon.java` shell prosesidir (APK-nın özündən `app_process` ilə qalxır, ayrıca jar lazım deyil). O, zəng başlayanda özü yazmağa başlayır, tətbiq bağlı olsa da (swipe) işləyir. Tətbiq yalnız quraşdırma, siyahı, pleyer və bildirişdir.

Qurulum: Wi-Fi ilə bir dəfə «Qur» düyməsi → Developer options → USB debugging və Wireless debugging → Pair with code → bildirişə kodu yazın. Sonra yaşıl zolaq «Hazırdır» göstərir.

Mənbə düyməsi: auto (voice_call, sonra split, sonra mic), voice_call, split, mic, voice_comm, voice_perf, camcorder. Yazı səssizdirsə bildiriş bunu deyir; «Log» düyməsi daemon logunu göstərir.

Build: GitHub-a yükləyin, Actions → build → ZengYaz-debug.apk. Asılılıq koordinatları (libadb-android) yoxlanmayıb; uyğun gəlməsə Gradle xətasını göndərin.
