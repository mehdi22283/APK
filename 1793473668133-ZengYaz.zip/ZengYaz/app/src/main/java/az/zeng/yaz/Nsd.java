package az.zeng.yaz;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Wireless debugging xidmətlərini mDNS ilə tapır (Wi-Fi lazımdır, yalnız ilk qurulum/bərpa üçün). */
final class Nsd {
    static final String PAIRING = "_adb-tls-pairing._tcp";
    static final String CONNECT = "_adb-tls-connect._tcp";

    @SuppressWarnings("deprecation")
    static InetSocketAddress find(Context c, String type, long timeoutMs) {
        final NsdManager nm = (NsdManager) c.getSystemService(Context.NSD_SERVICE);
        final CountDownLatch latch = new CountDownLatch(1);
        final AtomicReference<InetSocketAddress> res = new AtomicReference<>();
        NsdManager.DiscoveryListener dl = new NsdManager.DiscoveryListener() {
            @Override public void onStartDiscoveryFailed(String t, int e) { latch.countDown(); }
            @Override public void onStopDiscoveryFailed(String t, int e) { }
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onServiceLost(NsdServiceInfo i) { }
            @Override public void onServiceFound(NsdServiceInfo si) {
                try {
                    nm.resolveService(si, new NsdManager.ResolveListener() {
                        @Override public void onResolveFailed(NsdServiceInfo i, int e) { }
                        @Override public void onServiceResolved(NsdServiceInfo r) {
                            InetAddress h = r.getHost();
                            if (h != null && res.compareAndSet(null, new InetSocketAddress(h, r.getPort())))
                                latch.countDown();
                        }
                    });
                } catch (Throwable ignore) { }
            }
        };
        try {
            nm.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, dl);
            latch.await(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (Throwable ignore) {
        } finally {
            try { nm.stopServiceDiscovery(dl); } catch (Throwable ignore) { }
        }
        return res.get();
    }
}
