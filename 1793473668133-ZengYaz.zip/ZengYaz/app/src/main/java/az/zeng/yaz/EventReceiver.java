package az.zeng.yaz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Daemon-dan gələn START/STOP hadisələri: bildiriş göstərir, bitəndə faylı götürür. */
public class EventReceiver extends BroadcastReceiver {
    static final String CH_REC = "rec", CH_DONE = "done";
    static final int ID = 100;

    static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel a = new NotificationChannel(CH_REC, "Zəng yazılır", NotificationManager.IMPORTANCE_HIGH);
        a.setSound(null, null);
        nm.createNotificationChannel(a);
        nm.createNotificationChannel(new NotificationChannel(CH_DONE, "Yazı hazırdır", NotificationManager.IMPORTANCE_DEFAULT));
    }

    @Override public void onReceive(final Context c, Intent i) {
        final String ev = i.getStringExtra("ev");
        final String kind = nz(i.getStringExtra("kind")), app = nz(i.getStringExtra("app"));
        final String peak = nz(i.getStringExtra("peak")), err = nz(i.getStringExtra("err"));
        final String ms = nz(i.getStringExtra("ms")), src = nz(i.getStringExtra("src"));
        if (ev == null) return;
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                channels(c);
                NotificationManager nm = c.getSystemService(NotificationManager.class);
                PendingIntent pi = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                String label = kind.equals("PHONE") ? "Telefon"
                        : app.startsWith("com.whatsapp") ? "WhatsApp" : app.startsWith("org.telegram") ? "Telegram" : "VOIP";
                if (ev.equals("START")) {
                    nm.notify(ID, new Notification.Builder(c, CH_REC)
                            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                            .setContentTitle("● Zəng yazılır").setContentText(label + " • mənbə: " + src)
                            .setOngoing(true).setCategory(Notification.CATEGORY_STATUS)
                            .setContentIntent(pi).build());
                } else if (ev.equals("STOP")) {
                    Store.pull(c);
                    long dur = 0;
                    try { dur = Long.parseLong(ms); } catch (Throwable ignore) { }
                    int pk = -99;
                    try { pk = Integer.parseInt(peak); } catch (Throwable ignore) { }
                    String title, text;
                    if (!err.isEmpty() && dur < 5000) {
                        title = "Zəng yazılmadı";
                        text = label + " • " + err;
                    } else if (pk < -60) {
                        title = "Zəng yazıldı, amma səssizdir";
                        text = label + " • " + Store.fmtDur(dur) + " • mənbəni dəyişin (" + src + ")";
                    } else {
                        title = "Zəng yazıldı";
                        text = label + " • " + Store.fmtDur(dur);
                    }
                    nm.notify(ID, new Notification.Builder(c, CH_DONE)
                            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                            .setContentTitle(title).setContentText(text)
                            .setAutoCancel(true).setContentIntent(pi).build());
                }
            } catch (Throwable ignore) {
            } finally {
                pr.finish();
            }
        }).start();
    }

    static String nz(String s) { return s == null ? "" : s; }
}
