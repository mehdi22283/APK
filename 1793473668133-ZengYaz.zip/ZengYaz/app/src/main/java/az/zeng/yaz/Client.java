package az.zeng.yaz;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

/** Shell prosesi (daemon) ilə loopback (127.0.0.1) əlaqəsi. İnternet/Wi-Fi tələb etmir. */
final class Client {
    static final int PORT = 28573;

    static String cmd(String line, int timeoutMs) throws IOException {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("127.0.0.1", PORT), 800);
            s.setSoTimeout(timeoutMs);
            s.getOutputStream().write((line + "\n").getBytes("UTF-8"));
            s.getOutputStream().flush();
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            InputStream in = s.getInputStream();
            byte[] x = new byte[4096];
            int n;
            while ((n = in.read(x)) > 0) b.write(x, 0, n);
            return b.toString("UTF-8").trim();
        }
    }

    static boolean ping() {
        try { return cmd("PING", 1500).startsWith("PONG"); } catch (Throwable t) { return false; }
    }

    static void get(String name, File dest, long size) throws IOException {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("127.0.0.1", PORT), 800);
            s.setSoTimeout(15000);
            s.getOutputStream().write(("GET " + name + "\n").getBytes("UTF-8"));
            s.getOutputStream().flush();
            InputStream in = s.getInputStream();
            StringBuilder h = new StringBuilder();
            int ch;
            while ((ch = in.read()) != -1 && ch != '\n') h.append((char) ch);
            if (!h.toString().startsWith("SIZE ")) throw new IOException("bad header " + h);
            long left = Long.parseLong(h.substring(5).trim());
            try (FileOutputStream o = new FileOutputStream(dest)) {
                byte[] x = new byte[16384];
                int n;
                while (left > 0 && (n = in.read(x, 0, (int) Math.min(x.length, left))) > 0) {
                    o.write(x, 0, n);
                    left -= n;
                }
            }
        }
    }
}
