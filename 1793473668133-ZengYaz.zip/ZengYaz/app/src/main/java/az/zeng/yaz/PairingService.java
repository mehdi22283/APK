package az.zeng.yaz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import java.net.InetSocketAddress;

/**
 * Wireless debugging cütləməsi. Android cütləmə pəncərəsini Ayarlardan çıxanda bağlayır,
 * ona görə kod bildirişdəki yazı sahəsinə daxil edilir.
 */
public class PairingService extends Service {
    static volatile InetSocketAddress target;
    static volatile boolean running;
    static volatile String status = "";

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        EventReceiver.channels(this);
        notif(this, "Wireless debugging → «Pair device with pairing code» pəncərəsini açın, sonra bu bildirişdə kodu yazın.", true);
        if (running) return START_NOT_STICKY;
        running = true;
        target = null;
        new Thread(() -> {
            long end = System.currentTimeMillis() + 5 * 60000L;
            while (running && System.currentTimeMillis() < end && target == null) {
                target = Nsd.find(this, Nsd.PAIRING, 4000);
            }
            if (target == null) { status = "Cütləmə pəncərəsi tapılmadı (Wi-Fi açıqdırmı?)"; stop(this); }
        }).start();
        return START_NOT_STICKY;
    }

    static void notif(Context c, String text, boolean input) {
        Notification.Builder b = new Notification.Builder(c, EventReceiver.CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("ZengYaz qurulumu").setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text)).setOngoing(input);
        if (input) {
            PendingIntent pi = PendingIntent.getBroadcast(c, 1, new Intent(c, CodeReceiver.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            b.addAction(new Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(c, android.R.drawable.ic_menu_edit), "Kodu yaz", pi)
                    .addRemoteInput(new RemoteInput.Builder("code").setLabel("6 rəqəmli kod").build()).build());
        }
        Notification n = b.build();
        if (c instanceof Service) ((Service) c).startForeground(7, n);
        else c.getSystemService(NotificationManager.class).notify(7, n);
    }

    static void stop(Context c) {
        running = false;
        c.stopService(new Intent(c, PairingService.class));
    }

    /** CodeReceiver-dən çağırılır. */
    static void pair(final Context c, final String code) {
        new Thread(() -> {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            try {
                InetSocketAddress t = target;
                if (t == null) { status = "Cütləmə pəncərəsi tapılmadı"; notif(c, status, false); return; }
                AdbManager m = AdbManager.get(c);
                m.pair(t.getAddress().getHostAddress(), t.getPort(), code);
                status = "Cütləndi. Qoşulub daemon qaldırılır…";
                notif(c, status, false);
                String r = Setup.ensure(c);
                status = r == null ? "Hazırdır ✓ Artıq Wi-Fi olmadan da işləyəcək." : r;
            } catch (Throwable e) {
                status = "Cütləmə alınmadı: " + e;
            }
            nm.cancel(7);
            stop(c);
            EventReceiver.channels(c);
            nm.notify(8, new Notification.Builder(c, EventReceiver.CH_DONE)
                    .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                    .setContentTitle("ZengYaz qurulumu").setContentText(status)
                    .setStyle(new Notification.BigTextStyle().bigText(status)).setAutoCancel(true).build());
        }).start();
    }
}
