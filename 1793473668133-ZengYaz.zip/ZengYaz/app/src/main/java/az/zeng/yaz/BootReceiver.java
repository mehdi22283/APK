package az.zeng.yaz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon yenidən başlayandan sonra daemon-u qaldırmağa çalışır (5555 portu bağlıdırsa Wi-Fi + Wireless debugging lazımdır). */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(final Context c, Intent i) {
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try { Setup.ensure(c); } finally { pr.finish(); }
        }).start();
    }
}
