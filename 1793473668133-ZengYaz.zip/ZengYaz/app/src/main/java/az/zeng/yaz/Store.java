package az.zeng.yaz;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CallLog;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Yazıların siyahısı, daemon-dan götürülməsi və nömrə/ad/istiqamətin tapılması. */
final class Store {
    static final class Item {
        File f;
        long start, ms;
        String kind = "PHONE", app = "", number = "", name = "";
        int dir; // 0 bilinmir, 1 gələn, 2 gedən

        String label() {
            if (kind.equals("PHONE")) return "Telefon";
            if (app.startsWith("com.whatsapp")) return "WhatsApp";
            if (app.startsWith("org.telegram")) return "Telegram";
            if (app.equals("com.viber.voip")) return "Viber";
            return "VOIP";
        }

        String title() {
            if (!name.isEmpty()) return name;
            if (!number.isEmpty()) return number;
            return "Naməlum";
        }
    }

    static File dir(Context c) {
        File d = c.getExternalFilesDir("rec");
        if (d == null) d = new File(c.getFilesDir(), "rec");
        d.mkdirs();
        return d;
    }

    /** Daemon-un /data/local/tmp/zengrec qovluğundakı tamamlanmış yazıları tətbiqə köçürür. */
    static synchronized int pull(Context c) {
        int n = 0;
        try {
            String l = Client.cmd("LIST", 4000);
            for (String ln : l.split("\n")) {
                String[] p = ln.trim().split(" ");
                if (p.length != 2 || !p[0].endsWith(".wav")) continue;
                long size = Long.parseLong(p[1]);
                File dst = new File(dir(c), p[0]);
                if (!dst.exists() || dst.length() != size) {
                    File part = new File(dir(c), p[0] + ".part");
                    Client.get(p[0], part, size);
                    if (part.length() != size) { part.delete(); continue; }
                    dst.delete();
                    part.renameTo(dst);
                }
                Client.cmd("DEL " + p[0], 3000);
                n++;
            }
        } catch (Throwable ignore) { }
        return n;
    }

    static List<Item> list(Context c) {
        List<Item> out = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".wav"));
        if (fs == null) return out;
        Arrays.sort(fs);
        SharedPreferences meta = c.getSharedPreferences("meta", 0);
        for (File f : fs) {
            Item it = parse(f);
            if (it == null) continue;
            String m = meta.getString(f.getName(), null);
            if (m != null) {
                String[] x = m.split("\u0001", -1);
                if (x.length >= 3) { it.number = x[0]; it.name = x[1]; it.dir = Integer.parseInt(x[2]); }
            } else {
                resolve(c, it, meta);
            }
            out.add(it);
        }
        Collections.reverse(out);
        return out;
    }

    static Item parse(File f) {
        try {
            String n = f.getName().substring(0, f.getName().length() - 4);
            String[] p = n.split("_", 4);
            Item it = new Item();
            it.f = f;
            it.start = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).parse(p[0] + "_" + p[1]).getTime();
            it.kind = p[2];
            it.app = p.length > 3 ? p[3] : "";
            long bps = it.kind.equals("VOIP") ? 64000 : 32000;
            it.ms = Math.max(0, f.length() - 44) * 1000 / bps;
            return it;
        } catch (Throwable t) { return null; }
    }

    static void resolve(Context c, Item it, SharedPreferences meta) {
        boolean found = false;
        try {
            if (it.kind.equals("PHONE")) {
                if (c.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return;
                try (Cursor cu = c.getContentResolver().query(CallLog.Calls.CONTENT_URI,
                        new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE},
                        CallLog.Calls.DATE + " >= ? AND " + CallLog.Calls.DATE + " <= ?",
                        new String[]{String.valueOf(it.start - 150000), String.valueOf(it.start + 15000)},
                        CallLog.Calls.DATE + " DESC")) {
                    if (cu != null && cu.moveToFirst()) {
                        it.number = nz(cu.getString(0));
                        it.name = nz(cu.getString(1));
                        int t = cu.getInt(2);
                        it.dir = t == CallLog.Calls.OUTGOING_TYPE ? 2 : 1;
                        found = true;
                    }
                }
            } else {
                String log = c.getSharedPreferences("voip", 0).getString("log", "");
                boolean incoming = false, any = false;
                for (String e : log.split("\u0002")) {
                    String[] x = e.split("\u0001", -1);
                    if (x.length < 5) continue;
                    long t = Long.parseLong(x[0]);
                    if (t < it.start - 180000 || t > it.start + 60000) continue;
                    if (!it.app.isEmpty() && !x[1].equals(it.app)) continue;
                    if (!any) { it.name = x[2]; any = true; }
                    if (x[4].equals("1")) incoming = true;
                }
                if (any) { it.dir = incoming ? 1 : 2; found = true; }
            }
        } catch (Throwable ignore) { }
        if (found || System.currentTimeMillis() - it.start > 15 * 60000L) {
            meta.edit().putString(it.f.getName(), it.number + "\u0001" + it.name + "\u0001" + it.dir).apply();
        }
    }

    static String nz(String s) { return s == null ? "" : s; }

    static void delete(Context c, Item it) {
        it.f.delete();
        c.getSharedPreferences("meta", 0).edit().remove(it.f.getName()).apply();
    }

    static String fmtDur(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    static String fmtDate(long t) {
        return new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(new Date(t));
    }
}
