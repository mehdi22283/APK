package az.zeng.yaz;

import android.content.Context;
import android.os.Build;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;

/** libadb-android üzərində nazik qat: açar/sertifikat saxlanılır, qalan hər şey kitabxanadadır. */
public final class AdbManager extends AbsAdbConnectionManager {
    private static AdbManager inst;
    private final PrivateKey key;
    private final Certificate cert;

    public static synchronized AdbManager get(Context c) throws Exception {
        if (inst == null) inst = new AdbManager(c.getApplicationContext());
        return inst;
    }

    private AdbManager(Context c) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File kf = new File(c.getFilesDir(), "adb_key.pk8");
        File cf = new File(c.getFilesDir(), "adb_cert.der");
        PrivateKey k = null;
        Certificate ce = null;
        if (kf.exists() && cf.exists()) {
            try {
                k = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(read(kf)));
                ce = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(read(cf)));
            } catch (Throwable t) { k = null; }
        }
        if (k == null) {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            KeyPair kp = g.generateKeyPair();
            X500Name n = new X500Name("CN=ZengYaz");
            long now = System.currentTimeMillis();
            JcaX509v3CertificateBuilder b = new JcaX509v3CertificateBuilder(n, BigInteger.valueOf(now),
                    new Date(now - 86400000L), new Date(now + 25L * 365 * 86400000L), n, kp.getPublic());
            ContentSigner s = new JcaContentSignerBuilder("SHA256withRSA").setProvider(new BouncyCastleProvider())
                    .build(kp.getPrivate());
            ce = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider()).getCertificate(b.build(s));
            k = kp.getPrivate();
            try (FileOutputStream o = new FileOutputStream(kf)) { o.write(k.getEncoded()); }
            try (FileOutputStream o = new FileOutputStream(cf)) { o.write(ce.getEncoded()); }
        }
        key = k;
        cert = ce;
    }

    private static byte[] read(File f) throws Exception {
        try (InputStream in = new FileInputStream(f); ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] x = new byte[4096];
            int n;
            while ((n = in.read(x)) > 0) b.write(x, 0, n);
            return b.toByteArray();
        }
    }

    @Override public PrivateKey getPrivateKey() { return key; }
    @Override public Certificate getCertificate() { return cert; }
    @Override public String getDeviceName() { return "ZengYaz"; }
}
