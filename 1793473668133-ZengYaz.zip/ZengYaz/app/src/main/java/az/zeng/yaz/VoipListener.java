package az.zeng.yaz;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Yalnız ad və istiqamət üçün: WhatsApp/Telegram zəng bildirişlərini xatırlayır. Səs yazmaqla əlaqəsi yoxdur. */
public class VoipListener extends NotificationListenerService {
    static final Set<String> PK = new HashSet<>(Arrays.asList("com.whatsapp", "com.whatsapp.w4b",
            "org.telegram.messenger", "org.telegram.messenger.web", "com.viber.voip"));

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (!PK.contains(sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            boolean call = Notification.CATEGORY_CALL.equals(n.category) || n.fullScreenIntent != null;
            if (!call) return;
            Bundle e = n.extras;
            String title = str(e.getCharSequence(Notification.EXTRA_TITLE));
            String text = str(e.getCharSequence(Notification.EXTRA_TEXT)).toLowerCase();
            if (title.isEmpty()) return;
            boolean incoming = n.fullScreenIntent != null || text.contains("incoming") || text.contains("gələn")
                    || text.contains("входящ");
            SharedPreferences sp = getSharedPreferences("voip", 0);
            String[] old = sp.getString("log", "").split("\u0002");
            StringBuilder sb = new StringBuilder();
            sb.append(System.currentTimeMillis()).append('\u0001').append(sbn.getPackageName()).append('\u0001')
                    .append(title).append('\u0001').append(text).append('\u0001').append(incoming ? "1" : "0");
            for (int i = 0; i < Math.min(old.length, 11); i++) {
                if (old[i].isEmpty()) continue;
                sb.append('\u0002').append(old[i]);
            }
            sp.edit().putString("log", sb.toString()).apply();
        } catch (Throwable ignore) { }
    }

    static String str(CharSequence s) { return s == null ? "" : s.toString(); }
}
