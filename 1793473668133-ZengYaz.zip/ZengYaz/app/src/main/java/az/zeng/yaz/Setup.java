package az.zeng.yaz;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.provider.Settings;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.InetSocketAddress;

import io.github.muntashirakon.adb.AdbStream;

/**
 * Shell prosesinin qurulması. İlk dəfə Wi-Fi + Wireless debugging cütləməsi lazımdır;
 * ondan sonra adbd "tcpip:5555" rejiminə keçir və tətbiq 127.0.0.1:5555 ilə (Wi-Fi-sız, PC-siz) qoşulur.
 */
final class Setup {
    static volatile String last = "";

    static String pref(Context c) {
        return c.getSharedPreferences("cfg", 0).getString("src", "auto");
    }

    /** null = hər şey qaydasındadır, əks halda səbəb mətni. */
    static synchronized String ensure(Context c) {
        try {
            if (Client.ping()) {
                Client.cmd("SET src " + pref(c), 2000);
                last = "";
                return null;
            }
            keepAdbOn(c);
            AdbManager m = AdbManager.get(c);
            if (!connectLocal(c, m)) {
                last = "ADB-yə qoşulmaq alınmadı. «Qur» düyməsi ilə bir dəfə Wireless debugging cütləməsi edin.";
                return last;
            }
            last = install(c, m);
            try { m.disconnect(); } catch (Throwable ignore) { }
            return last;
        } catch (Throwable t) {
            last = "Xəta: " + t;
            return last;
        }
    }

    static void keepAdbOn(Context c) {
        try {
            if (Settings.Global.getInt(c.getContentResolver(), Settings.Global.ADB_ENABLED, 1) == 0
                    && c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED)
                Settings.Global.putInt(c.getContentResolver(), Settings.Global.ADB_ENABLED, 1);
        } catch (Throwable ignore) { }
    }

    static boolean connectLocal(Context c, AdbManager m) {
        try { if (m.connect("127.0.0.1", 5555)) return true; } catch (Throwable ignore) { }
        try { // 5555 bağlıdır: Wireless debugging ilə qoşul və portu aç
            InetSocketAddress a = Nsd.find(c, Nsd.CONNECT, 5000);
            if (a != null && m.connect(a.getAddress().getHostAddress(), a.getPort())) {
                try { sh(m, "true"); } catch (Throwable ignore) { }
                try (AdbStream s = m.openStream("tcpip:5555")) { drain(s.openInputStream()); } catch (Throwable ignore) { }
                Thread.sleep(2500);
                try { m.disconnect(); } catch (Throwable ignore) { }
                return m.connect("127.0.0.1", 5555);
            }
        } catch (Throwable ignore) { }
        return false;
    }

    static void drain(InputStream in) {
        try { byte[] b = new byte[2048]; while (in.read(b) > 0) { /* skip */ } } catch (Throwable ignore) { }
    }

    static String sh(AdbManager m, String cmd) throws Exception {
        try (AdbStream s = m.openStream("shell:" + cmd)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            try {
                InputStream in = s.openInputStream();
                byte[] x = new byte[4096];
                int n;
                while ((n = in.read(x)) > 0) b.write(x, 0, n);
            } catch (Throwable ignore) { }
            return b.toString("UTF-8");
        }
    }

    /** İcazələr + bildiriş dinləyicisi + batareya + daemon-un işə salınması. */
    static String install(Context c, AdbManager m) throws Exception {
        String pkg = c.getPackageName();
        String[] grants = {"android.permission.READ_CALL_LOG", "android.permission.POST_NOTIFICATIONS",
                "android.permission.WRITE_SECURE_SETTINGS"};
        for (String g : grants) { try { sh(m, "pm grant " + pkg + " " + g); } catch (Throwable ignore) { } }
        try { sh(m, "cmd notification allow_listener " + pkg + "/" + pkg + ".VoipListener"); } catch (Throwable ignore) { }
        try { sh(m, "dumpsys deviceidle whitelist +" + pkg); } catch (Throwable ignore) { }
        try { sh(m, "appops set " + pkg + " RUN_IN_BACKGROUND allow"); } catch (Throwable ignore) { }
        try { Client.cmd("QUIT", 1000); Thread.sleep(800); } catch (Throwable ignore) { }
        sh(m, "mkdir -p /data/local/tmp/zengrec");
        sh(m, "CLASSPATH=$(pm path " + pkg + " | head -1 | cut -d: -f2) setsid nohup app_process / "
                + "az.zeng.yaz.shell.Daemon " + Client.PORT + " </dev/null >/data/local/tmp/zeng.out 2>&1 &");
        for (int i = 0; i < 12; i++) {
            Thread.sleep(500);
            if (Client.ping()) {
                Client.cmd("SET src " + pref(c), 2000);
                return null;
            }
        }
        return "Daemon qalxmadı:\n" + sh(m, "tail -n 8 /data/local/tmp/zeng.out; tail -n 8 /data/local/tmp/zeng.log");
    }
}
