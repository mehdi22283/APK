package az.zeng.yaz.shell;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.AttributionSource;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioRecordingConfiguration;
import android.os.Build;
import android.os.Looper;
import android.system.Os;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * adb ilə belə işə salınır (shell uid = 2000):
 *   CLASSPATH=<base.apk> app_process / az.zeng.yaz.shell.Daemon 28573
 *
 * Hər 500 ms səs rejiminə baxır: MODE_IN_CALL = adi zəng, MODE_IN_COMMUNICATION = VOIP (WhatsApp...).
 * Zəng başlayanda faylı /data/local/tmp/zengrec/ altına yazır, bitəndə tətbiqə yayım göndərir.
 * Tətbiq faylları loopback soket vasitəsilə götürür (PING/LIST/GET/DEL/SET/LOG/TEST/QUIT).
 */
@SuppressLint({"NewApi", "PrivateApi", "DiscouragedPrivateApi", "BlockedPrivateApi", "SoonBlockedPrivateApi"})
public final class Daemon {
    static final String TMP = "/data/local/tmp/zengrec";
    static final String LOGF = "/data/local/tmp/zeng.log";
    static final String VER = "1";
    static final int RATE = 16000;   // faylın nümunə tezliyi
    static final int CHUNK = 320;    // 20 ms

    static Context ctx;
    static AudioManager am;
    static volatile String srcPref = "auto";
    static volatile boolean quit;
    static volatile Rec cur;

    // ------------------------------------------------------------------ log
    static synchronized void log(String s) {
        try (FileWriter w = new FileWriter(LOGF, true)) {
            w.write(new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US).format(new Date()) + " " + s + "\n");
        } catch (Throwable ignore) { }
    }

    static int db(int peak) {
        return peak <= 0 ? -99 : (int) Math.round(20 * Math.log10(peak / 32768.0));
    }

    // ------------------------------------------------------------------ main
    public static void main(String[] a) throws Exception {
        int port = Integer.parseInt(a[0]);
        new File(TMP).mkdirs();
        File lf = new File(LOGF);
        if (lf.length() > 200000) lf.delete();
        log("daemon start v" + VER + " sdk=" + Build.VERSION.SDK_INT + " " + Build.MODEL + " uid=" + Os.getuid());
        ServerSocket ss;
        try {
            ss = new ServerSocket(port, 8, InetAddress.getByName("127.0.0.1"));
        } catch (Throwable t) {
            log("port busy, exiting: " + t);
            return;
        }
        try {
            boot();
            am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            log("boot ok, audio manager=" + (am != null));
        } catch (Throwable t) {
            log("boot FAILED: " + t);
        }
        final ServerSocket fss = ss;
        new Thread(() -> serve(fss), "zeng-srv").start();
        monitor();
        try { ss.close(); } catch (Throwable ignore) { }
        System.exit(0);
    }

    // scrcpy-nin "Workarounds" üsulu: shell prosesinə saxta ActivityThread/Application verilir ki,
    // AudioRecord paket adını "com.android.shell" görsün.
    static class Fake extends ContextWrapper {
        Fake(Context b) { super(b); }
        @Override public String getPackageName() { return "com.android.shell"; }
        public String getOpPackageName() { return "com.android.shell"; }
        @Override public Context getApplicationContext() { return this; }
        @Override public AttributionSource getAttributionSource() {
            return new AttributionSource.Builder(2000).setPackageName("com.android.shell").build();
        }
    }

    static void boot() throws Exception {
        try { Looper.prepareMainLooper(); } catch (Throwable ignore) { }
        Class<?> atc = Class.forName("android.app.ActivityThread");
        Constructor<?> c = atc.getDeclaredConstructor();
        c.setAccessible(true);
        Object at = c.newInstance();
        Field f = atc.getDeclaredField("sCurrentActivityThread");
        f.setAccessible(true);
        f.set(null, at);
        f = atc.getDeclaredField("mSystemThread");
        f.setAccessible(true);
        f.setBoolean(at, true);
        try { // Android 13+
            Class<?> cc = Class.forName("android.app.ConfigurationController");
            Class<?> ati = Class.forName("android.app.ActivityThreadInternal");
            Constructor<?> cn = cc.getDeclaredConstructor(ati);
            cn.setAccessible(true);
            Field fc = atc.getDeclaredField("mConfigurationController");
            fc.setAccessible(true);
            fc.set(at, cn.newInstance(at));
        } catch (Throwable ignore) { }
        Class<?> abd = Class.forName("android.app.ActivityThread$AppBindData");
        Constructor<?> ac = abd.getDeclaredConstructor();
        ac.setAccessible(true);
        Object bd = ac.newInstance();
        ApplicationInfo ai = new ApplicationInfo();
        ai.packageName = "com.android.shell";
        Field fa = abd.getDeclaredField("appInfo");
        fa.setAccessible(true);
        fa.set(bd, ai);
        Field fb = atc.getDeclaredField("mBoundApplication");
        fb.setAccessible(true);
        fb.set(at, bd);
        Method gsc = atc.getDeclaredMethod("getSystemContext");
        Context sys = (Context) gsc.invoke(at);
        ctx = new Fake(sys);
        Application app = new Application();
        Field mb = ContextWrapper.class.getDeclaredField("mBase");
        mb.setAccessible(true);
        mb.set(app, ctx);
        Field ia = atc.getDeclaredField("mInitialApplication");
        ia.setAccessible(true);
        ia.set(at, app);
    }

    // ------------------------------------------------------------------ zəng izləyici
    static void monitor() {
        int on = 0, off = 0;
        boolean armed = true;
        while (!quit) {
            int mode = -1;
            try { if (am != null) mode = am.getMode(); } catch (Throwable ignore) { }
            boolean call = mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION;
            Rec r = cur;
            if (r == null) {
                if (!call) { off++; on = 0; if (off >= 2) armed = true; }
                else { off = 0; on++; }
                if (armed && on >= 2) { on = 0; startRec(mode); }
            } else {
                off = call ? 0 : off + 1;
                if (off >= 4 || r.done) {
                    r.stop = true;
                    try { r.t.join(5000); } catch (Throwable ignore) { }
                    cur = null;
                    armed = false;
                    off = 0;
                    on = 0;
                }
            }
            try { Thread.sleep(500); } catch (InterruptedException ignore) { }
        }
        Rec r = cur;
        if (r != null) {
            r.stop = true;
            try { r.t.join(5000); } catch (Throwable ignore) { }
        }
    }

    static void startRec(int mode) {
        boolean voip = mode == AudioManager.MODE_IN_COMMUNICATION;
        String app = voip ? findVoipApp() : "";
        String name = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date())
                + (voip ? "_VOIP" + (app.isEmpty() ? "" : "_" + app) : "_PHONE") + ".wav";
        Rec r = new Rec(new File(TMP, name), voip, app);
        cur = r;
        r.start();
    }

    static String findVoipApp() {
        for (int i = 0; i < 4; i++) {
            try {
                List<AudioRecordingConfiguration> l = am.getActiveRecordingConfigurations();
                for (AudioRecordingConfiguration c : l) {
                    String p = (String) c.getClass().getMethod("getClientPackageName").invoke(c);
                    if (p != null && !p.equals("com.android.shell") && !p.equals("android")) return p;
                }
            } catch (Throwable t) { log("findVoipApp: " + t); }
            try { Thread.sleep(300); } catch (InterruptedException ignore) { }
        }
        return "";
    }

    // ------------------------------------------------------------------ yazıcı
    static byte[] header(long data, int ch) {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt((int) (36 + data)).put("WAVE".getBytes())
                .put("fmt ".getBytes()).putInt(16).putShort((short) 1).putShort((short) ch)
                .putInt(RATE).putInt(RATE * ch * 2).putShort((short) (ch * 2)).putShort((short) 16)
                .put("data".getBytes()).putInt((int) data);
        return b.array();
    }

    static void patch(RandomAccessFile o, long data, int ch) throws Exception {
        long pos = o.getFilePointer();
        o.seek(0);
        o.write(header(data, ch));
        o.seek(pos);
    }

    static void event(String ev, String... kv) {
        new Thread(() -> {
            try {
                List<String> c = new ArrayList<>(Arrays.asList("am", "broadcast", "--user", "0", "-f", "32",
                        "-n", "az.zeng.yaz/.EventReceiver", "-a", "az.zeng.yaz.EVENT", "--es", "ev", ev));
                for (int i = 0; i + 1 < kv.length; i += 2) { c.add("--es"); c.add(kv[i]); c.add(kv[i + 1]); }
                Process p = new ProcessBuilder(c).redirectErrorStream(true).start();
                InputStream in = p.getInputStream();
                byte[] b = new byte[512];
                while (in.read(b) > 0) { /* drain */ }
                p.waitFor();
            } catch (Throwable t) { log("event fail: " + t); }
        }, "zeng-ev").start();
    }

    static List<Src> chain(boolean voip) {
        List<Src> l = new ArrayList<>();
        if (voip) { l.add(new Voip()); return l; }
        String p = srcPref;
        boolean auto = p.equals("auto");
        if (auto || p.equals("voice_call")) l.add(new Direct(4, "voice_call"));
        if (auto || p.equals("split")) l.add(new Split());
        if (auto || p.equals("mic")) l.add(new Direct(1, "mic"));
        if (p.equals("voice_comm")) l.add(new Direct(7, "voice_comm"));
        if (p.equals("camcorder")) l.add(new Direct(5, "camcorder"));
        if (p.equals("voice_perf")) l.add(new Direct(10, "voice_perf"));
        return l;
    }

    static final class Rec implements Runnable {
        final File f;
        final boolean voip;
        final String app;
        volatile boolean stop, done;
        Thread t;
        final long t0 = System.currentTimeMillis();
        int peakAll;
        String used = "", err = "";

        Rec(File f, boolean voip, String app) { this.f = f; this.voip = voip; this.app = app; }

        void start() { t = new Thread(this, "zeng-rec"); t.start(); }

        @Override public void run() {
            RandomAccessFile out = null;
            Src s = null;
            long data = 0;
            int ch = voip ? 2 : 1;
            try {
                List<Src> chain = chain(voip);
                int idx = 0;
                for (; idx < chain.size(); idx++) {
                    if (chain.get(idx).open()) { s = chain.get(idx); break; }
                    log("open failed: " + chain.get(idx).name());
                }
                if (s == null) { err = "mənbə açılmadı"; return; }
                used = s.name();
                log("recording " + f.getName() + " via " + used);
                event("START", "kind", voip ? "VOIP" : "PHONE", "app", app, "file", f.getName(), "src", used);
                out = new RandomAccessFile(f, "rw");
                out.setLength(0);
                out.write(header(0, ch));
                short[] buf = new short[CHUNK * 2];
                byte[] bb = new byte[CHUNK * 4];
                long lastHdr = t0, checkAt = t0 + 10000;
                int winPeak = 0, bad = 0;
                while (!stop) {
                    int n = s.read(buf);
                    if (n <= 0) {
                        if (++bad > 25) { err = "oxuma xətası"; break; }
                        continue;
                    }
                    bad = 0;
                    for (int i = 0; i < n; i++) {
                        short v = buf[i];
                        bb[2 * i] = (byte) v;
                        bb[2 * i + 1] = (byte) (v >> 8);
                        int a = v < 0 ? -v : v;
                        if (a > winPeak) winPeak = a;
                        if (a > peakAll) peakAll = a;
                    }
                    out.write(bb, 0, n * 2);
                    data += n * 2;
                    long now = System.currentTimeMillis();
                    if (now - lastHdr > 2000) { patch(out, data, ch); lastHdr = now; }
                    if (!voip && now >= checkAt) {
                        // auto rejimdə: ilk 10 saniyə tam səssizdirsə, növbəti mənbəyə keç
                        if (peakAll < 40 && idx + 1 < chain.size()) {
                            log("silent via " + s.name() + ", switching");
                            s.close();
                            s = null;
                            for (idx = idx + 1; idx < chain.size(); idx++) {
                                if (chain.get(idx).open()) { s = chain.get(idx); break; }
                            }
                            if (s == null) { err = "bütün mənbələr uğursuz"; break; }
                            used = s.name();
                            log("now via " + used);
                        }
                        winPeak = 0;
                        checkAt = now + 10000;
                    }
                }
                patch(out, data, ch);
            } catch (Throwable e) {
                err = String.valueOf(e);
                log("rec error: " + e);
            } finally {
                try { if (s != null) s.close(); } catch (Throwable ignore) { }
                try { if (out != null) out.close(); } catch (Throwable ignore) { }
                done = true;
                log("stopped " + f.getName() + " bytes=" + data + " peak=" + db(peakAll) + "dB src=" + used
                        + (err.isEmpty() ? "" : " err=" + err));
                event("STOP", "kind", voip ? "VOIP" : "PHONE", "app", app, "file", f.getName(),
                        "ms", String.valueOf(System.currentTimeMillis() - t0),
                        "peak", String.valueOf(db(peakAll)), "src", used, "err", err);
            }
        }
    }

    // ------------------------------------------------------------------ mənbələr
    interface Src {
        boolean open();
        int read(short[] b);   // ədəd short qaytarır (mono: n, stereo: 2n)
        void close();
        String name();
    }

    static AudioRecord mk(int src, int rate, int mask) {
        try {
            int min = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT);
            AudioRecord.Builder b = new AudioRecord.Builder();
            try {
                b.setAudioSource(src);
            } catch (Throwable t) {
                b.getClass().getMethod("setInternalCapturePreset", int.class).invoke(b, src);
            }
            b.setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(mask).build());
            b.setBufferSizeInBytes(Math.max(min * 4, rate * 2));
            AudioRecord r = b.build();
            if (r.getState() != AudioRecord.STATE_INITIALIZED) { r.release(); return null; }
            return r;
        } catch (Throwable t) {
            log("mk(" + src + "," + rate + ") " + t);
            return null;
        }
    }

    static final class Direct implements Src {
        final int src;
        final String nm;
        AudioRecord r;

        Direct(int src, String nm) { this.src = src; this.nm = nm; }

        @Override public boolean open() {
            r = mk(src, RATE, AudioFormat.CHANNEL_IN_MONO);
            if (r == null) return false;
            try {
                r.startRecording();
                if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) { close(); return false; }
                return true;
            } catch (Throwable t) { log("start " + nm + ": " + t); close(); return false; }
        }

        @Override public int read(short[] b) { return r.read(b, 0, CHUNK); }

        @Override public void close() {
            try { if (r != null) { try { r.stop(); } catch (Throwable ignore) { } r.release(); } } catch (Throwable ignore) { }
            r = null;
        }

        @Override public String name() { return nm; }
    }

    /** VOICE_UPLINK (öz səsin) + VOICE_DOWNLINK (qarşı tərəf) ayrı-ayrı, mono-ya toplanır. */
    static final class Split implements Src {
        final Direct up = new Direct(2, "uplink"), down = new Direct(3, "downlink");
        final short[] t = new short[CHUNK];

        @Override public boolean open() {
            if (!up.open()) return false;
            if (!down.open()) { up.close(); return false; }
            return true;
        }

        @Override public int read(short[] b) {
            int n1 = up.read(b), n2 = down.read(t);
            int n = Math.min(n1, n2);
            if (n <= 0) return -1;
            for (int i = 0; i < n; i++) b[i] = (short) Math.max(-32768, Math.min(32767, b[i] + t[i]));
            return n;
        }

        @Override public void close() { up.close(); down.close(); }

        @Override public String name() { return "split"; }
    }

    /** VOIP: sol kanal = mikrofon (sən), sağ kanal = zəng səsinin kopyası (qarşı tərəf). */
    static final class Voip implements Src {
        AudioRecord mic, lb;
        Object policy;
        volatile boolean run;
        Thread pump;
        final ArrayBlockingQueue<short[]> q = new ArrayBlockingQueue<>(400);
        final short[] in = new short[CHUNK];
        String how = "voip-mic";

        @Override public boolean open() {
            mic = mk(1, RATE, AudioFormat.CHANNEL_IN_MONO);
            if (mic == null) return false;
            try { mic.startRecording(); } catch (Throwable t) { log("mic start: " + t); return false; }
            try {
                lb = openLoopback();
                lb.startRecording();
                run = true;
                final AudioRecord l = lb;
                pump = new Thread(() -> {
                    short[] lbuf = new short[CHUNK * 6];
                    while (run) {
                        int n = l.read(lbuf, 0, lbuf.length);
                        if (n <= 0) { try { Thread.sleep(5); } catch (InterruptedException ignore) { } continue; }
                        int m = n / 6;
                        short[] o = new short[m];
                        for (int i = 0; i < m; i++) {
                            int sum = 0;
                            for (int k = 0; k < 6; k++) sum += lbuf[i * 6 + k];
                            o[i] = (short) (sum / 6);
                        }
                        q.offer(o);
                    }
                }, "zeng-lb");
                pump.start();
                how = "voip-loopback+mic";
            } catch (Throwable t) {
                log("loopback FAILED, only microphone: " + t);
            }
            return true;
        }

        @Override public int read(short[] b) {
            int n = mic.read(in, 0, CHUNK);
            if (n <= 0) return -1;
            while (q.size() > 60) q.poll();
            short[] o = null;
            try { o = q.poll(2, TimeUnit.MILLISECONDS); } catch (InterruptedException ignore) { }
            for (int i = 0; i < n; i++) {
                b[2 * i] = in[i];
                b[2 * i + 1] = (o != null && i < o.length) ? o[i] : 0;
            }
            return n * 2;
        }

        @Override public void close() {
            run = false;
            try { if (mic != null) { mic.stop(); mic.release(); } } catch (Throwable ignore) { }
            try { if (lb != null) { lb.stop(); lb.release(); } } catch (Throwable ignore) { }
            try {
                if (policy != null) {
                    Class<?> pc = Class.forName("android.media.audiopolicy.AudioPolicy");
                    AudioManager.class.getMethod("unregisterAudioPolicy", pc).invoke(am, policy);
                }
            } catch (Throwable t) { log("unregister policy: " + t); }
        }

        @Override public String name() { return how; }

        /** AudioPolicy + AudioMix (LOOP_BACK|RENDER): VOICE_COMMUNICATION çıxışının kopyası; səs yenə də dinamikdən çıxır. */
        AudioRecord openLoopback() throws Exception {
            AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).build();
            Class<?> rbc = Class.forName("android.media.audiopolicy.AudioMixingRule$Builder");
            Object rb = rbc.getConstructor().newInstance();
            rbc.getMethod("addRule", AudioAttributes.class, int.class).invoke(rb, aa, 1); // RULE_MATCH_ATTRIBUTE_USAGE
            Object rule = rbc.getMethod("build").invoke(rb);
            Class<?> ruleC = Class.forName("android.media.audiopolicy.AudioMixingRule");
            Class<?> mbc = Class.forName("android.media.audiopolicy.AudioMix$Builder");
            Object mb = mbc.getConstructor(ruleC).newInstance(rule);
            AudioFormat fmt = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(48000).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build();
            mbc.getMethod("setFormat", AudioFormat.class).invoke(mb, fmt);
            mbc.getMethod("setRouteFlags", int.class).invoke(mb, 3); // RENDER | LOOP_BACK
            Object mix = mbc.getMethod("build").invoke(mb);
            Class<?> pbc = Class.forName("android.media.audiopolicy.AudioPolicy$Builder");
            Object pb = pbc.getConstructor(Context.class).newInstance(ctx);
            Class<?> mixC = Class.forName("android.media.audiopolicy.AudioMix");
            pbc.getMethod("addMix", mixC).invoke(pb, mix);
            pbc.getMethod("setLooper", Looper.class).invoke(pb, Looper.getMainLooper());
            policy = pbc.getMethod("build").invoke(pb);
            Class<?> polC = Class.forName("android.media.audiopolicy.AudioPolicy");
            int res = (Integer) AudioManager.class.getMethod("registerAudioPolicy", polC).invoke(am, policy);
            if (res != 0) throw new IllegalStateException("registerAudioPolicy=" + res);
            return (AudioRecord) polC.getMethod("createAudioRecordSink", mixC).invoke(policy, mix);
        }
    }

    // ------------------------------------------------------------------ idarə soketi
    static void w(OutputStream o, String s) throws Exception {
        o.write((s + "\n").getBytes("UTF-8"));
        o.flush();
    }

    static void serve(ServerSocket ss) {
        while (!quit) {
            try {
                final Socket s = ss.accept();
                new Thread(() -> handle(s), "zeng-c").start();
            } catch (Throwable t) { if (quit) break; }
        }
    }

    static boolean okName(String n) {
        return n != null && n.endsWith(".wav") && !n.contains("/") && !n.contains("..");
    }

    static void handle(Socket sock) {
        try (Socket c = sock) {
            c.setSoTimeout(5000);
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            String line = r.readLine();
            if (line == null) return;
            OutputStream o = c.getOutputStream();
            String[] p = line.trim().split(" ", 3);
            switch (p[0]) {
                case "PING":
                    w(o, "PONG " + VER + " " + Build.VERSION.SDK_INT + " rec=" + (cur != null ? 1 : 0)
                            + " boot=" + (am != null ? 1 : 0));
                    break;
                case "SET":
                    if (p.length >= 3 && p[1].equals("src")) { srcPref = p[2]; w(o, "OK"); } else w(o, "ERR");
                    break;
                case "LOG": {
                    File lf = new File(LOGF);
                    long len = lf.length();
                    try (FileInputStream in = new FileInputStream(lf)) {
                        if (len > 12000) in.skip(len - 12000);
                        byte[] b = new byte[4096];
                        int n;
                        while ((n = in.read(b)) > 0) o.write(b, 0, n);
                    } catch (Throwable ignore) { }
                    o.flush();
                    break;
                }
                case "LIST": {
                    File[] fs = new File(TMP).listFiles();
                    StringBuilder sb = new StringBuilder();
                    if (fs != null) {
                        Rec rc = cur;
                        for (File f : fs) {
                            if (!f.getName().endsWith(".wav")) continue;
                            if (rc != null && rc.f.equals(f) && !rc.done) continue;
                            sb.append(f.getName()).append(' ').append(f.length()).append('\n');
                        }
                    }
                    o.write(sb.toString().getBytes("UTF-8"));
                    o.flush();
                    break;
                }
                case "GET": {
                    if (p.length < 2 || !okName(p[1])) { w(o, "ERR"); break; }
                    File f = new File(TMP, p[1]);
                    long n = f.length();
                    w(o, "SIZE " + n);
                    try (FileInputStream in = new FileInputStream(f)) {
                        byte[] b = new byte[16384];
                        long left = n;
                        int k;
                        while (left > 0 && (k = in.read(b, 0, (int) Math.min(b.length, left))) > 0) {
                            o.write(b, 0, k);
                            left -= k;
                        }
                    }
                    o.flush();
                    break;
                }
                case "DEL":
                    if (p.length >= 2 && okName(p[1])) { new File(TMP, p[1]).delete(); w(o, "OK"); } else w(o, "ERR");
                    break;
                case "TEST": {
                    if (cur != null) { w(o, "BUSY"); break; }
                    Direct d = new Direct(1, "mic");
                    if (!d.open()) { w(o, "FAIL open (log-a baxın)"); break; }
                    short[] b = new short[CHUNK];
                    int pk = 0;
                    long end = System.currentTimeMillis() + 2000;
                    while (System.currentTimeMillis() < end) {
                        int n = d.read(b);
                        for (int i = 0; i < n; i++) pk = Math.max(pk, Math.abs(b[i]));
                    }
                    d.close();
                    w(o, "OK mic peak=" + db(pk) + "dB");
                    break;
                }
                case "QUIT":
                    quit = true;
                    w(o, "OK");
                    break;
                default:
                    w(o, "ERR");
            }
        } catch (Throwable ignore) { }
    }
}
