package az.zeng.yaz;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    static final String[] SRC = {"auto", "voice_call", "split", "mic", "voice_comm", "voice_perf", "camcorder"};

    final Handler h = new Handler(Looper.getMainLooper());
    final List<Store.Item> data = new ArrayList<>();
    TextView status;
    Button srcBtn;
    Adapter ad;
    MediaPlayer mp;
    String playing;
    boolean dragging;
    String details = "";

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        EventReceiver.channels(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(30), dp(10), dp(6));

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        status.setTypeface(null, android.graphics.Typeface.BOLD);
        status.setPadding(dp(14), dp(12), dp(14), dp(12));
        status.setText("● Yoxlanılır…");
        paint(0xFF757575);
        status.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Vəziyyət").setMessage(details)
                .setPositiveButton("Bağla", null).show());
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(0, dp(6), 0, dp(6));
        bar.addView(btn("Qur", v -> setupFlow()), new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(btn("Yenilə", v -> refresh()), new LinearLayout.LayoutParams(0, -2, 1));
        srcBtn = btn("", v -> cycleSource());
        bar.addView(srcBtn, new LinearLayout.LayoutParams(0, -2, 1.4f));
        bar.addView(btn("Log", v -> showLog()), new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        srcLabel();

        ListView lv = new ListView(this);
        ad = new Adapter();
        lv.setAdapter(ad);
        lv.setOnItemLongClickListener((p, v, pos, id) -> {
            final Store.Item it = data.get(pos);
            new AlertDialog.Builder(this).setTitle("Silinsin?").setMessage(it.title() + " • " + Store.fmtDate(it.start))
                    .setPositiveButton("Sil", (d, w) -> { if (it.f.getName().equals(playing)) stopPlay(); Store.delete(this, it); load(); })
                    .setNegativeButton("Ləğv", null).show();
            return true;
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    @Override protected void onResume() { super.onResume(); load(); refresh(); }
    @Override protected void onPause() { super.onPause(); stopPlay(); }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setOnClickListener(l);
        return b;
    }

    void paint(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        status.setBackground(g);
    }

    void srcLabel() { srcBtn.setText("Mənbə: " + Setup.pref(this)); }

    void cycleSource() {
        String cur = Setup.pref(this);
        int i = 0;
        for (int k = 0; k < SRC.length; k++) if (SRC[k].equals(cur)) i = k;
        final String next = SRC[(i + 1) % SRC.length];
        getSharedPreferences("cfg", 0).edit().putString("src", next).apply();
        srcLabel();
        new Thread(() -> { try { Client.cmd("SET src " + next, 2000); } catch (Throwable ignore) { } }).start();
    }

    void setupFlow() {
        new AlertDialog.Builder(this).setTitle("Bir dəfəlik qurulum")
                .setMessage("1) Wi-Fi-a qoşulun.\n2) Developer options-da USB debugging və Wireless debugging açın.\n"
                        + "3) Wireless debugging → «Pair device with pairing code» pəncərəsini açın.\n"
                        + "4) Pəncərə açıq qalarkən bildirişi aşağı çəkib 6 rəqəmli kodu bildirişə yazın.\n\n"
                        + "Cütləmədən sonra tətbiq portu 5555-ə keçirir və Wi-Fi olmadan da lokal qoşulur.")
                .setPositiveButton("Başla", (d, w) -> {
                    startForegroundService(new Intent(this, PairingService.class));
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); } catch (Throwable ignore) { }
                }).setNegativeButton("Ləğv", null).show();
    }

    void showLog() {
        new Thread(() -> {
            String t;
            try { t = Client.cmd("LOG", 3000); } catch (Throwable e) { t = "Daemon cavab vermir: " + e + "\n" + Setup.last; }
            final String s = t.isEmpty() ? "(boşdur)" : t;
            h.post(() -> {
                TextView tv = new TextView(this);
                tv.setText(s);
                tv.setTextSize(11);
                tv.setTextIsSelectable(true);
                tv.setPadding(dp(12), dp(8), dp(12), dp(8));
                ScrollView sv = new ScrollView(this);
                sv.addView(tv);
                new AlertDialog.Builder(this).setTitle("Daemon logu").setView(sv).setPositiveButton("Bağla", null).show();
            });
        }).start();
    }

    void refresh() {
        status.setText("● Yoxlanılır…");
        paint(0xFF757575);
        new Thread(() -> {
            String err = Setup.ensure(this);
            boolean up = Client.ping();
            if (up) Store.pull(this);
            boolean cl = checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED;
            String en = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            boolean nl = en != null && en.contains(getPackageName());
            boolean adb = Settings.Global.getInt(getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1;
            final String d = "Shell prosesi (daemon): " + (up ? "işləyir ✓" : "yoxdur ✗") + "\n"
                    + "USB debugging: " + (adb ? "açıq ✓" : "bağlı ✗") + "\n"
                    + "Zəng jurnalı icazəsi (ad/nömrə üçün): " + (cl ? "var ✓" : "yoxdur ✗") + "\n"
                    + "Bildiriş dinləyicisi (WhatsApp adı üçün): " + (nl ? "açıqdır ✓" : "bağlıdır ✗") + "\n"
                    + (err != null ? "\n" + err : "");
            final boolean ok = up && cl;
            h.post(() -> {
                details = d;
                status.setText(ok ? "● Hazırdır — zənglər avtomatik yazılır" : "● Qurulum lazımdır (toxunun)");
                paint(ok ? 0xFF2E7D32 : 0xFFC62828);
                load();
            });
        }).start();
    }

    void load() {
        new Thread(() -> {
            final List<Store.Item> l = Store.list(this);
            h.post(() -> { data.clear(); data.addAll(l); ad.notifyDataSetChanged(); });
        }).start();
    }

    // ----------------------------------------------------------- player
    void toggle(Store.Item it) {
        try {
            String n = it.f.getName();
            if (n.equals(playing) && mp != null) {
                if (mp.isPlaying()) mp.pause(); else mp.start();
            } else {
                stopPlay();
                mp = new MediaPlayer();
                mp.setDataSource(it.f.getAbsolutePath());
                mp.prepare();
                mp.setOnCompletionListener(m -> { stopPlay(); ad.notifyDataSetChanged(); });
                mp.start();
                playing = n;
                tick();
            }
            ad.notifyDataSetChanged();
        } catch (Throwable e) { stopPlay(); }
    }

    void stopPlay() {
        if (mp != null) { try { mp.release(); } catch (Throwable ignore) { } mp = null; }
        playing = null;
    }

    void tick() {
        h.postDelayed(() -> {
            if (mp != null && playing != null) {
                if (!dragging) ad.notifyDataSetChanged();
                tick();
            }
        }, 400);
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return data.size(); }
        @Override public Object getItem(int i) { return data.get(i); }
        @Override public long getItemId(int i) { return i; }

        TextView tv(String t, int sp, int color) {
            TextView v = new TextView(MainActivity.this);
            v.setText(t);
            v.setTextSize(sp);
            v.setTextColor(color);
            return v;
        }

        @Override public View getView(int pos, View cv, ViewGroup parent) {
            final Store.Item it = data.get(pos);
            final boolean cur = it.f.getName().equals(playing) && mp != null;
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(8), dp(10), dp(8), dp(10));

            LinearLayout l1 = new LinearLayout(MainActivity.this);
            l1.setGravity(Gravity.CENTER_VERTICAL);
            TextView arrow = tv(it.dir == 2 ? "↗" : it.dir == 1 ? "↙" : "•", 22,
                    it.dir == 2 ? 0xFF1E6FE0 : it.dir == 1 ? 0xFF2E9E43 : 0xFF888888);
            arrow.setPadding(0, 0, dp(8), 0);
            TextView title = tv(it.title(), 16, Color.BLACK);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            TextView chip = tv(it.label(), 12, Color.DKGRAY);
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFFE0E0E0);
            g.setCornerRadius(dp(8));
            chip.setBackground(g);
            chip.setPadding(dp(8), dp(2), dp(8), dp(2));
            l1.addView(arrow);
            l1.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
            l1.addView(chip);
            row.addView(l1);

            TextView sub = tv(Store.fmtDate(it.start) + " • " + Store.fmtDur(it.ms) + (it.number.isEmpty() || it.name.isEmpty() ? "" : " • " + it.number), 12, 0xFF777777);
            sub.setPadding(dp(30), 0, 0, 0);
            row.addView(sub);

            LinearLayout l3 = new LinearLayout(MainActivity.this);
            l3.setGravity(Gravity.CENTER_VERTICAL);
            Button play = btn(cur && mp.isPlaying() ? "❚❚" : "▶", v -> toggle(it));
            play.setMinWidth(dp(56));
            play.setMinimumWidth(dp(56));
            SeekBar sb = new SeekBar(MainActivity.this);
            if (cur) {
                try { sb.setMax(mp.getDuration()); sb.setProgress(mp.getCurrentPosition()); } catch (Throwable ignore) { }
            } else {
                sb.setMax(100);
            }
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                    if (user && cur && mp != null) mp.seekTo(p);
                }
                @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; }
                @Override public void onStopTrackingTouch(SeekBar s) { dragging = false; }
            });
            l3.addView(play, new LinearLayout.LayoutParams(-2, dp(44)));
            l3.addView(sb, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(l3);
            return row;
        }
    }
}
