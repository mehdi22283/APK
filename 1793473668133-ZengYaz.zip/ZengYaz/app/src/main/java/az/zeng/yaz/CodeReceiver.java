package az.zeng.yaz;

import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Bildirişdəki sahəyə yazılan 6 rəqəmli cütləmə kodunu qəbul edir. */
public class CodeReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        android.os.Bundle r = RemoteInput.getResultsFromIntent(i);
        CharSequence code = r == null ? null : r.getCharSequence("code");
        if (code != null) PairingService.pair(c.getApplicationContext(), code.toString().trim());
    }
}
