package az.yvok.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Collections;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");
    private static final Pattern NAME_OK = Pattern.compile("^[\\p{L}\\s.'\\-]{3,100}$");
    // Sayt adın yanında mötərizədə qeyd göndərə bilər: "AD SOYAD ATA (Vəliyev Seymur Vahid oğlu tərəfindən ödənilir)".
    // Mötərizənin içi (qapanmamış olsa da) yoxlamadan kənarda qalır, qalan hissə əvvəlki qaydaya uyğun olmalıdır.
    private static boolean nameOk(String n) {
        if (n == null) return false;
        String main = n.replaceAll("\\([^()]*\\)", " ").replaceAll("\\([^)]*$", " ")
                .replace("(", " ").replace(")", " ").replaceAll("\\s+", " ").trim();
        return NAME_OK.matcher(main).matches();
    }
    private static final Pattern DEBT_OK = Pattern.compile("^(\\d{1,9}(\\.\\d{1,2})?)?$");
    private static final int REQ_OCR = 7001;
    private static final int REQ_SCAN = 7009;
    private static final int REQ_CONTACT = 7002;
    private static final int REQ_XLSX = 7003;
    private static final int CV_MAX = 33;   // gündəlik Cloud Vision sorğu limiti (sayğac)
    // OCR səhvlərinə tolerant: 1/I/L/| və 0/O/Q/D qarışıqlığı "10011" prefiksində düzəldilir,
    // sonrakı 7 simvol isə mövqeyə görə normallaşdırılır (bax: fixOcrTail)
    private static final Pattern OCR_CODE = Pattern.compile("[1IL|!][0OQD][0OQD][1IL|!][1IL|!]([A-Z0-9|!]{7,8})");

    // ======== TOPLU YOXLAMA: 8 GB RAM üçün sabit dəyərlər (cihazın RAM-ından asılı deyil) ========
    private static final int MAX_WORKERS = 14;             // paralel gizli səhifə sayı
    private static final int MAX_JOBS_PER_VIEW = 15;       // bu qədər sorğudan sonra gizli WebView yenidən yaradılır (yaddaş yığılmasın)
    private static final int LOAD_LIMIT_MS = 15000;        // ilkin kod: nəticə gözləmə həddi (keçəndə təzə səhifədə dərhal təkrar, əl çəkilmir)
    private static final int VARIANT_LIMIT_MS = 8000;      // variant (təxmin) kodlar: doğru variant tez cavab verir, səhv olan uzun gözlədilmir
    private static final int PAGE_GUARD_MS = 15000;        // səhifənin özü açılmasa qoruyucu
    private static final long EBEL_DOWN_MS = 60000;        // sayt açılmayanda ehtiyat mənbəyə keçid müddəti
    private static final long RETRY_BACKOFF_MS = 200L;     // cavab gəlməyəndə təkrar cəhd arasında gözləmə (hər cəhddə artır)
    private static final long RETRY_BACKOFF_MAX_MS = 2000L; // gözləmənin yuxarı həddi
    // ===========================================================================================

    private static class Job {
        final String code;          // hazırda yoxlanılan kod (O/Q variantı ola bilər)
        final String orig;          // istifadəçinin siyahısındakı ilkin kod
        final boolean batch;
        int noResp = 0;             // cavab gəlmədiyi üçün neçə dəfə təkrar başladılıb (ilkin kodlar cavab alınana qədər əl çəkmir)
        int pageRetries = 0;        // səhifə açılmadığı üçün neçə dəfə təkrar başladılıb
        ArrayDeque<String> variants = null;   // yoxlanılmamış O/Q/I variantları (ilk "tapılmadı"dan sonra qurulur)
        Group grp = null;                     // variant sorğuları eyni qrupda paralel yoxlanılır
        String mode = null;                   // null: ümumi yoxlayıcı rejimi; "ebel" / "race" (tək yoxlama)
        int portTries = 0;                    // Toplu yoxlama: portmanat.az-da neçə dəfə cavab gəlməyib (yalnız portmanat.az açıqdır)
        int extTried = 0;                     // Toplu yoxlama: cavab verə bilməyən xarici mənbələr (1 = yelo.az, 2 = hesab.az, 4 = portmanat.az)
        Boolean combo = null;                 // Toplu yoxlama: kodda qarışa bilən simvol (hərf kombinasiyası) var? null = hələ hesablanmayıb
        Race race = null;                     // YVÖK xanası: ardıcıl yoxlama (yelo.az -> e-belediyye -> hesab.az -> portmanat.az)
        Job(String code, boolean batch) { this.code = code; this.orig = code; this.batch = batch; }
        Job(String code, Job from) { this.code = code; this.orig = from.orig; this.batch = from.batch; this.variants = from.variants; }
    }

    // YVÖK xanası: mənbələr ardıcıl yoxlanılır; ehtiyat yalnız sayt cavab verməyəndə/işləməyəndə aktivləşir
    private static class Race {
        boolean won = false;     // nəticə artıq alınıb (və ya sorğu ləğv edilib)
        int fails = 0;           // uğursuz bitən tərəflərin sayı
        int expected = 1;        // xəta yalnız bütün mənbələr uğursuz olanda göstərilir
        boolean claim() { if (won) return false; won = true; return true; }
    }
    private Race currentRace = null;
    private YeloChecker yeloSingle;
    private YeloChecker yeloSingle() {
        if (yeloSingle == null) {
            yeloSingle = new YeloChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            yeloSingle.setMaxWait(SINGLE_WAIT_MS);   // 5 san cavab gəlməsə yelo.az "cavab vermədi" sayılır və ehtiyat mənbəyə keçilir
        }
        return yeloSingle;
    }
    private String modeOf(Job j) { return j.mode != null ? j.mode : checkerMode(); }
    private static final long SINGLE_WAIT_MS = 5000;   // YVÖK xanası: mənbə 5 san ərzində cavab verməsə növbəti mənbəyə keçilir
    private PortmanatChecker portSingle;
    private PortmanatChecker portSingle() {
        if (portSingle == null) {
            portSingle = new PortmanatChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            portSingle.setMaxWait(20000);   // ehtiyat mənbə: vaxtı məhdudlaşdır ki, növbəti mənbəyə vaxtında keçsin
        }
        return portSingle;
    }
    private HesabChecker hesabSingle;      // YVÖK xanası üçün ayrıca hesab.az səhifəsi (Toplu yoxlamaya toxunmur)
    private HesabChecker hesabSingle() {
        if (hesabSingle == null) {
            hesabSingle = new HesabChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            hesabSingle.setMaxWait(SINGLE_WAIT_MS);
        }
        return hesabSingle;
    }
    private Worker ebelSingle;             // YVÖK xanası üçün ayrıca e-belediyye səhifəsi (Yelo-dan sonra yaradılır)
    private void cancelRace() {
        if (currentRace != null) currentRace.won = true;
        currentRace = null;
        if (yeloSingle != null) yeloSingle.clear();
        if (portSingle != null) portSingle.clear();
        if (hesabSingle != null) hesabSingle.clear();
        if (portTax != null) portTax.clear();
        if (ebelSingle != null && ebelSingle.current != null) recycle(ebelSingle);
    }

    // Vergi sətirləri: yelo.az-da iki «rəqəm + AZN» görünəndə portmanat.az paralel yoxlanılır ("Ödəniş üçün seçin" siyahısı)
    private PortmanatChecker portTax;
    private PortmanatChecker portTax() {
        if (portTax == null) {
            portTax = new PortmanatChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1);
            portTax.setMaxWait(25000);
        }
        return portTax;
    }

    /** Vergi sətirləri (ən azı 2 sətir) mesaja yazılır, Borc xanasına məbləğlərin cəmi qoyulur */
    private void applyTaxItems(Job j, java.util.List<String> raw) {
        if (j.race == null || currentRace != j.race) return;     // sorğu ləğv olunub / yeni kod yazılıb
        java.util.List<String> items = PortmanatChecker.normalizeItems(raw);
        if (items.size() < 2) return;
        JSONArray ja = new JSONArray();
        for (String it : items) ja.put(it);
        ui.evaluateJavascript("window.setTaxItems(" + ja.toString() + "," + JSONObject.quote(PortmanatChecker.sumItems(items)) + ");", null);
    }

    private void startTaxItems(final Job j) {
        if (j.race == null || currentRace != j.race) return;
        portTax().check(j.orig, new PortmanatChecker.Callback() {
            @Override public void onResult(String name, String debt) { }
            @Override public void onResult(String name, String debt, java.util.List<String> items) { applyTaxItems(j, items); }
            @Override public void onFail() { }
        });
    }

    // Bir kodun variantları: boş işçilərdə PARALEL yoxlanılır, ilk tapılan nəticə qazanır, qalanları ləğv olunur
    private static class Group {
        final Job root;       // istifadəçinin siyahısındakı ilkin sorğu
        int left;             // hələ "tapılmadı" deməyən variant sayı
        boolean done = false; // nəticə tapılıb və ya hamısı uğursuz olub
        Group(Job root) { this.root = root; }
    }

    // Hər Worker = e-belediyye.gov.az açıq olan bir gizli WebView (ui-nin ARXASINDA işləyir)
    private class Worker {
        WebView wv;                       // köhnələndə yenisi ilə əvəz olunur
        int jobs = 0;                     // bu WebView neçə sorğu emal edib
        boolean loaded = false;
        boolean error = false;            // əsas səhifə xəta ilə bitib (xəta səhifəsi "hazır" sayılmasın)
        int errs = 0;                     // ardıcıl səhifə xətası sayı (təkrar cəhd gecikməsi artır)
        String pending = null;
        Job current = null;
        final Runnable watchdog = () -> onWatchdog(this);
    }

    private FrameLayout root;
    private WebView ui;
    private String injectJs;
    private final ArrayList<Worker> pool = new ArrayList<>(); // yalnız toplu yoxlama üçün
    private final ArrayDeque<Job> batchJobs = new ArrayDeque<>();
    private Uri cameraUri = null;
    private TextRecognizer mlRec = null;

    private volatile boolean waModalOpen = false;   // Whatsapp nömrə pəncərəsi açıqdır (geri düyməsi onu bağlayır)

    private synchronized TextRecognizer recognizer() {
        if (mlRec == null) mlRec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        return mlRec;
    }

    @Override
    public void onBackPressed() {
        if (waModalOpen) {                        // Whatsapp nömrə pəncərəsi açıqdır: geri düyməsi yalnız onu bağlayır
            waModalOpen = false;
            ui.evaluateJavascript("window.hidePhoneModal && hidePhoneModal();", null);
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mlRec != null) { mlRec.close(); mlRec = null; }
        if (hesab != null) { hesab.destroy(); hesab = null; }
        if (yeloSingle != null) { yeloSingle.destroy(); yeloSingle = null; }
        if (portSingle != null) { portSingle.destroy(); portSingle = null; }
        if (hesabSingle != null) { hesabSingle.destroy(); hesabSingle = null; }
        if (yeloBatch != null) { yeloBatch.destroy(); yeloBatch = null; }
        if (portBatch != null) { portBatch.destroy(); portBatch = null; }
    }
    private int maxWorkers = MAX_WORKERS;   // güclü cihazlarda daha çox paralel gizli səhifə
    // ---- əsas yoxlama mənbəyi: hesab.az ----
    private HesabChecker hesab;

    // YVÖK bölməsində ünvan yalnız mənzil kartının bina/ünvan adından götürülür.
    // IV Sahə, V Sahə və s. ərazi prefiksləri göstərilmir; küçə adı tam yazılır.
    // Bələdiyyə bazasındakı göy yazının altındakı mətnə (bina başlığı) baxır: KÜÇƏSİ/KÜÇ -> «küç.», PR-Tİ/PROSPEKT -> «pr.»;
    // mötərizədəki mətn nəzərə alınmır, ilk rast gəlinən göstərici seçilir (BazaActivity ilə eyni qayda).
    private static String streetKindFromTitle(String title) {
        if (title == null) return "";
        String t = title.replaceAll("\\([^)]*\\)", " ");
        java.util.regex.Matcher pr = java.util.regex.Pattern.compile("(?iu)(?<!\\p{L})(?:PR(?!\\p{L})|PROSPEKT)").matcher(t);
        java.util.regex.Matcher kc = java.util.regex.Pattern.compile("(?iu)(?<!\\p{L})K[ÜU][ÇC]").matcher(t);
        int p = pr.find() ? pr.start() : Integer.MAX_VALUE;
        int k = kc.find() ? kc.start() : Integer.MAX_VALUE;
        if (p == Integer.MAX_VALUE && k == Integer.MAX_VALUE) return "";
        return p < k ? "pr." : "küç.";
    }

    private static String fullStreetBuildingLabel(String street, String building, String title) {
        String raw = building == null ? "" : building.trim().replaceAll("\\s+", " ");
        raw = raw.replaceFirst("(?iu)^\\s*(?:VI|IV|V|III|II|I|VII|VIII|IX|X)\\s*SAHƏ\\s*[.,:;—–-]*\\s*", "");
        // Göy yazıdakı kimi: «MTK» sözü göstərilmir (boş qalan mötərizə də silinir)
        raw = raw.replaceAll("(?iu)(?<![\\p{L}\\d])MTK(?![\\p{L}\\d])", " ")
                 .replaceAll("\\(\\s*\\)", " ").replaceAll("\\s+\\)", ")").replaceAll("\\(\\s+", "(").replaceAll("\\s+", " ").trim();
        if (raw.matches("(?iu)^Ş(?:ƏMSİ|\\.)?\\s*RƏH[İI]MOV[\\s.\\-]*55C[\\s.,\\-]*\\(?\\s*S(?:ƏTTAR|\\.)?\\s*BƏHLULZAD[ƏE]?\\s*28\\s*\\)?$"))
            return "Şəmsi Rəhimov 55C (Səttar Bəhlulzadə 28)";
        if (raw.matches("(?iu)^Ş\\.?\\s*MƏMMƏDOVA[\\s.\\-]*9C(?![\\p{L}\\d])[\\s\\S]*$"))
            return "Şövkət Məmmədova küç. 9C";
        if (raw.matches("(?iu)^(?:C[ƏE]F[ƏE]R\\s*|C\\.\\s*)X[ƏE]NDAN[\\s.\\-]*54(?![\\p{L}\\d])[\\s\\S]*$"))
            return "Cəfər Xəndan küç. 54";
        if (raw.matches("(?iu)^[İI]\\.?\\s*H[ƏE][ŞS][İI]MOV[\\s.\\-]*7(?![\\p{L}\\d])[\\s\\S]*$"))
            return "İbrahimpaşa Həşimov küç. 7";
        java.util.regex.Matcher mm = java.util.regex.Pattern.compile("(?iu)^M[İI]R[\\s.]*C[ƏE]LAL[\\s.\\-]*127\\s*E(?![\\p{L}\\d])[\\s\\S]*?(\\d+)\\s*BL").matcher(raw);
        if (mm.find())
            return "Mir Cəlal küç. 127 Blok " + mm.group(1);
        java.util.regex.Matcher km = java.util.regex.Pattern.compile("(?iu)^KE[ÇC][İI]D[\\s.\\-]*(10|8)\\s*$").matcher(raw);
        if (km.matches())
            return "Keçid 1410 Mirmahmud Kazımovski küç. " + km.group(1);
        String key = raw.toUpperCase(java.util.Locale.ROOT);
        String[][] names = {
            {"Ə.ƏLİXANOV", "Ənvər Əlixanov"}, {"İ.HƏŞİMOV", "İsrafil Həşimov"},
            {"İ.CÜMŞÜDOV", "İlqar Cümşüdov"}, {"M.KAZIMOVSKİ", "Mir Mahmud Kazımovski"},
            {"R.BEHBUDOV", "Rəşid Behbudov"}, {"S.MƏMMƏDOVA", "Svetlana Məmmədova"},
            {"Ü.HACIBƏYOV", "Üzeyir Hacıbəyov"}, {"A.KUNANBAYEV", "Abay Kunanbayev"},
            {"S.S.AXUNDOV", "Süleyman Sani Axundov"}, {"S.AXUNDOV", "Süleyman Sani Axundov"},
            {"H.HÜSEYNOV", "Heydər Hüseynov"}, {"İ.DADAŞOV", "İbrahimpaşa Dadaşov"},
            {"N.NƏRİMANOV", "Nəriman Nərimanov"}, {"Ş.MƏMMƏDOVA", "Şövkət Məmmədova"},
            {"A.MƏMMƏDOV", "Adil Məmmədov"}, {"CAVADXAN", "Cavad xan"},
            {"H.BABAŞOV", "Həmzə Babaşov"}, {"MİR CƏLAL", "Mir Cəlal"},
            {"SEYİDZADƏ", "Hüseyn Seyidzadə"}, {"AZADLIQ PR", "Azadlıq prospekti"},
            {"A.GƏRYABƏYLİ", "Ağasadıq Gəraybəyli"}, {"CƏFƏR XƏNDAN", "Cəfər Xəndan"},
            {"C.HACIBƏYLİ", "Ceyhun Hacıbəyli"}, {"K.RƏHİMOV", "Koroğlu Rəhimov"},
            {"S.BƏHLULZADƏ", "Səttar Bəhlulzadə"}, {"Z.BÜNYADOV", "Ziya Bünyadov"},
            {"ATATÜRK", "Atatürk Prospekti"}, {"Ə.NAXÇIVANİ", "Əcəmi Naxçıvani"},
            {"NAXÇIVANİ", "Əcəmi Naxçıvani"}, {"NAXÇİVANİ", "Əcəmi Naxçıvani"},
            {"Ş.RƏHİMOV", "Şəmsi Rəhimov"}, {"KEÇİD", "Keçid"}
        };
        for (String[] pair : names) {
            String k = pair[0];
            if (key.equals(k) || key.startsWith(k + " ") || key.startsWith(k + ",") || key.startsWith(k + "-"))
            {
                // Göy yazıdakı ilə eyni: küçə adından sonra başlığa görə küç. / pr.
                String kind = pair[1].toLowerCase(java.util.Locale.ROOT).contains("prospekt") ? "" : streetKindFromTitle(title);
                String rem = cleanStreetBuildingWords(raw.substring(k.length()));
                return cleanStreetBuildingWords(pair[1]) + (kind.isEmpty() ? "" : " " + kind) + (rem.isEmpty() ? "" : " " + rem);
            }
        }
        // Kartda qısaltma olmasa belə, kartın öz ünvanını təmizlə; başqa kateqoriya adını
        // (məsələn, fayl/qovluq adı olan küçə parametrini) küçə kimi əlavə etmə.
        if (!raw.isEmpty()) return cleanStreetBuildingWords(raw);
        String streetFull = street == null ? "" : street.trim();
        for (String[] pair : names) if (streetFull.equalsIgnoreCase(pair[0])) { streetFull = pair[1]; break; }
        return cleanStreetBuildingWords(streetFull);
    }

    private static String cleanStreetBuildingWords(String value) {
        if (value == null) return "";
        return value.replaceAll("(?iu)\\b(küçəsi|küçə|bina)\\b", " ")
            .replaceAll("[,.:;()—–-]+", " ")
            .replaceAll("\\s+", " ").trim();
    }

    // Bələdiyyə bazasına yazan əməliyyatlar (BazaActivity-nin «Dəyişikliklər» təsdiqi də eyni kodu işlədir)
    private BazaOps bazaOps;
    private BazaOps ops() { if (bazaOps == null) bazaOps = new BazaOps(this); return bazaOps; }
    private File bazaFile() throws Exception { return ops().bazaFile(); }

    private String checkerMode() { return "ebel"; }   // Toplu yoxlama: yalnız e-belediyye (sayt seçimi silinib)
    private long ebelDownUntil = 0;     // e-belediyye səhifəsi açılmayıb: bu vaxta qədər yeni kodlar birbaşa hesab.az-a gedir
    private boolean ebelDown() { return android.os.SystemClock.elapsedRealtime() < ebelDownUntil; }

    // YVÖK xanası: yelo.az əsas mənbədir. Ehtiyat sıra (e-belediyye -> hesab.az -> portmanat.az) yalnız sayt cavab verməyəndə
    // (açılmayıb / vaxt bitib) yoxlanılır. Sayt cavab verib "tapılmadı" deyibsə (və ya format tanınmayıbsa) birbaşa "Məlumat tapılmadı" göstərilir.
    private static final int SINGLE_NOT_OK = 0, SINGLE_OK = 1, SINGLE_BAD = 2;
    private int singleResult(Job j, String name, String debt) {
        String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        String d = debt == null ? "" : debt.trim();
        if (!nameOk(n) || !DEBT_OK.matcher(d).matches()) return SINGLE_BAD;
        if (j.race != null && !j.race.claim()) return SINGLE_OK;    // sorğu ləğv edilib / başqa nəticə artıq alınıb
        ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
        if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        return SINGLE_OK;
    }

    private boolean raceDead(Job j) { return j.race == null || j.race.won; }

    private void startYeloSingle(final Job j) {
        yeloSingle().check(j.orig, new YeloChecker.Callback() {
            @Override public void onResult(String name, String debt) { onResult(name, debt, 0); }
            @Override public void onResult(String name, String debt, int azn) {
                if (raceDead(j)) return;
                int sr = singleResult(j, name, debt);
                if (sr == SINGLE_BAD && !raceDead(j)) startEbelSingle(j); // Yelo cavabı istifadə edilə bilmirsə növbəti mənbə
                else if (sr == SINGLE_OK && azn != 1) startTaxItems(j);    // iki «rəqəm + AZN»: portmanat.az paralel yoxlanılır
            }
            @Override public void onNotFound() { if (!raceDead(j)) failJob(j, "Məlumat tapılmadı"); }
            @Override public void onFail() { if (!raceDead(j)) startEbelSingle(j); }              // Yelo cavab vermədisə e-bələdiyyə yoxlanılır
        });
    }

    private void startPortSingle(final Job j) {
        if (raceDead(j)) return;
        portSingle().check(j.orig, new PortmanatChecker.Callback() {
            @Override public void onResult(String name, String debt) { onResult(name, debt, new java.util.ArrayList<String>()); }
            @Override public void onResult(String name, String debt, java.util.List<String> items) {
                if (raceDead(j)) return;
                int sr = singleResult(j, name, debt);
                if (sr == SINGLE_BAD && !raceDead(j)) failJob(j, "Məlumat tapılmadı");
                else if (sr == SINGLE_OK) applyTaxItems(j, items);          // Portmanat özü nəticə verəndə siyahı da hazırdır
            }
            @Override public void onNotFound() { if (!raceDead(j)) failJob(j, "Məlumat tapılmadı"); }
            @Override public void onFail() { if (!raceDead(j)) failJob(j, "Məlumat tapılmadı"); }   // son mənbə: Portmanat
        });
    }

    private void startHesabSingle(final Job j) {
        if (raceDead(j)) return;
        hesabSingle().check(j.orig, new HesabChecker.Callback() {
            @Override public void onResult(String name, String debt) { onResult(name, debt, new java.util.ArrayList<String>()); }
            @Override public void onResult(String name, String debt, java.util.List<String> items) {
                if (raceDead(j)) return;
                int sr = singleResult(j, name, debt);
                if (sr == SINGLE_BAD && !raceDead(j)) startPortSingle(j);
                else if (sr == SINGLE_OK) applyTaxItems(j, items);
            }
            @Override public void onFail() { if (!raceDead(j)) startPortSingle(j); }              // hesab.az cavab vermədisə son ehtiyat Portmanat-dır
            @Override public void onNotFound() { if (!raceDead(j)) failJob(j, "Məlumat tapılmadı"); } // sayt cavab verdi: ehtiyata keçmə
        });
    }

    // Yelo cavab verməyəndə ikinci mənbə e-bələdiyyədir.
    private void startEbelSingle(final Job j) {
        if (raceDead(j)) return;
        if (ebelSingle == null) ebelSingle = createWorker(false);
        start(ebelSingle, j);
    }

    // Avtomatik rejimdə istifadə olunan ayrıca fallback; YVÖK mətn xanasının ardıcıllığından ayrıdır.
    private void fallbackOrFail(final Job j, final String msg) {
        if (hesab == null || j.batch) { failJob(j, msg); return; }   // toplu yoxlamada son nəticə: əlavə mənbəyə keçid yoxdur
        hesab.check(j.orig, new HesabChecker.Callback() {
            @Override
            public void onResult(String name, String debt) {
                String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
                String d = debt == null ? "" : debt.trim();
                if (!nameOk(n) || !DEBT_OK.matcher(d).matches()) { failJob(j, msg); return; }
                if (j.batch) {
                    claimBatch(j.orig); ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.orig) + ","
                            + JSONObject.quote(n) + "," + JSONObject.quote(d) + "," + JSONObject.quote(j.orig) + ");", null);
                } else {
                    ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                            + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
                }
            }

            @Override
            public void onFail() { failJob(j, msg); }
        });
    }

    private String ocrEngine = "mlkit";   // "mlkit" və ya "cloud"
    private String cvKey = "";

    /**
     * Portmanat səhifəsi tətbiqin HTML-ində iframe olduğuna görə onun DOM-u ana səhifədən
     * idarə edilə bilməz (same-origin qaydası). Yalnız həmin iframe-in əsas HTML cavabına
     * kiçik avtomatlaşdırma əlavə olunur; ödəniş təsdiqi heç vaxt kliklənmir.
     */
    private WebResourceResponse interceptPortmanatFrame(WebResourceRequest request) {
        if (request == null || request.isForMainFrame() || request.getUrl() == null) return null;
        Uri uri = request.getUrl();
        if (!"portmanat.az".equalsIgnoreCase(uri.getHost())
                || !"/project/belediyye".equals(uri.getPath())
                || uri.getQueryParameter("yvok") == null) return null;

        HttpURLConnection connection = null;
        try {
            URL url = new URL(uri.toString());
            connection = (HttpURLConnection) url.openConnection();
            connection.setInstanceFollowRedirects(true);
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setRequestMethod("GET");
            Map<String, String> requestHeaders = request.getRequestHeaders();
            if (requestHeaders != null) {
                for (Map.Entry<String, String> entry : requestHeaders.entrySet()) {
                    String key = entry.getKey();
                    String value = entry.getValue();
                    if (key == null || value == null) continue;
                    String lower = key.toLowerCase(Locale.ROOT);
                    if (lower.equals("host") || lower.equals("connection") || lower.equals("content-length")
                            || lower.equals("accept-encoding") || lower.equals("cookie")) continue;
                    connection.setRequestProperty(key, value);
                }
            }
            connection.setRequestProperty("Accept-Encoding", "identity");
            String cookie = CookieManager.getInstance().getCookie(uri.toString());
            if (cookie != null && !cookie.isEmpty()) connection.setRequestProperty("Cookie", cookie);

            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) return null;
            String contentType = connection.getContentType();
            if (contentType != null && !contentType.toLowerCase(Locale.ROOT).contains("text/html")) return null;

            byte[] bytes;
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                bytes = output.toByteArray();
            }
            String html = new String(bytes, "UTF-8");
            if (!html.contains("id=\"root\"") && !html.contains("id='root'")) return null;

            String automation = "<script>(function(){"
                    + "var code='';try{code=(new URLSearchParams(location.search).get('yvok')||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase()}catch(e){}"
                    + "if(!/^10011[A-Z0-9]{7}$/.test(code))return;"
                    + "var state={lastFill:0,clicked:false,clickAt:0,tries:0,selected:false};"
                    + "function clean(x){return String(x||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase()}"
                    + "function text(e){return String(e&&(e.innerText||e.textContent||e.value)||'').replace(/\\u00a0/g,' ').replace(/\\s+/g,' ').trim()}"
                    + "function visible(e){if(!e||e.disabled||e.hidden)return false;var s=getComputedStyle(e);if(s.display==='none'||s.visibility==='hidden'||s.opacity==='0')return false;var r=e.getBoundingClientRect();return r.width>0&&r.height>0}"
                    + "function fieldHint(e){var a=[e.placeholder,e.getAttribute('aria-label'),e.name,e.id,e.title];try{if(e.id){var l=document.querySelector('label[for=\\\"'+e.id.replace(/\\\"/g,'\\\\\\\"')+'\\\"]');if(l)a.push(text(l))}}catch(x){}try{if(e.parentElement)a.push(text(e.parentElement).slice(0,100))}catch(x){}return a.filter(Boolean).join(' ').toLowerCase()}"
                    + "function field(){var a=[].slice.call(document.querySelectorAll('input:not([type=hidden]),textarea')).filter(function(e){return visible(e)&&!e.readOnly});a.sort(function(x,y){function score(e){var h=fieldHint(e),v=0;if(/yv[oö]k|vergi|identifikasiya/i.test(h))v+=100;if(/telefon|mobil|kart|məbləğ|mebleg|amount|borc/i.test(h))v-=50;return v}return score(y)-score(x)||x.getBoundingClientRect().top-y.getBoundingClientRect().top});return a[0]||null}"
                    + "function action(re){var a=[].slice.call(document.querySelectorAll('button,a,[role=button],input[type=submit],input[type=button],select,[role=combobox]'));for(var i=0;i<a.length;i++){var e=a[i];if(!visible(e))continue;var t=(e.tagName==='INPUT'?e.value:text(e)||e.getAttribute('aria-label')||e.title).toLocaleLowerCase('az');if(re.test(t))return e}var leaves=[].slice.call(document.querySelectorAll('div,span,p,label,strong,b,li'));for(var j=0;j<leaves.length;j++){var x=leaves[j];if(!visible(x)||x.children.length)continue;var tx=text(x).toLocaleLowerCase('az');if(tx&&tx.length<60&&re.test(tx)){return x.closest('button,a,[role=button],[onclick],.btn,[class*=btn]')||x}}return null}"
                    + "function write(e){try{e.scrollIntoView({block:'center'})}catch(x){}try{e.focus()}catch(x){}try{e.dispatchEvent(new InputEvent('beforeinput',{bubbles:true,cancelable:true,inputType:'insertText',data:code}))}catch(x){}var p=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,d=Object.getOwnPropertyDescriptor(p,'value');try{if(d&&d.set)d.set.call(e,code);else e.value=code}catch(x){e.value=code}try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:code}))}catch(x){e.dispatchEvent(new Event('input',{bubbles:true}))}e.dispatchEvent(new Event('change',{bubbles:true}))}"
                    + "function step(){if(document.readyState==='loading'||!document.body)return;var f=field();if(!state.clicked){if(!f)return;if(clean(f.value)!==code){if(!state.lastFill||Date.now()-state.lastFill>350){write(f);state.lastFill=Date.now()}return}if(!state.lastFill){state.lastFill=Date.now();return}if(Date.now()-state.lastFill<450)return;var b=action(/^davam\\s*et(?:mək)?$/i);if(b&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'){b.click();state.clicked=true;state.tries=1;state.clickAt=Date.now()}return}var pay=action(/^ödəniş\\s*üçün\\s*seçin$/i);if(pay&&!state.selected){pay.click();state.selected=true;return}if(!state.selected&&f&&clean(f.value)===code&&Date.now()-state.clickAt>3000&&state.tries<2){var again=action(/^davam\\s*et(?:mək)?$/i);if(again&&!again.disabled){again.click();state.tries++;state.clickAt=Date.now()}}}"
                    + "var timer=setInterval(step,250);window.addEventListener('load',step);setTimeout(function(){clearInterval(timer)},60000);"
                    + "})();</script>";
            int insertAt = html.toLowerCase(Locale.ROOT).lastIndexOf("</body>");
            if (insertAt >= 0) html = html.substring(0, insertAt) + automation + html.substring(insertAt);
            else html += automation;

            Map<String, String> responseHeaders = new HashMap<>();
            responseHeaders.put("Content-Type", "text/html; charset=UTF-8");
            responseHeaders.put("Cache-Control", "no-store");
            return new WebResourceResponse("text/html", "UTF-8", status,
                    connection.getResponseMessage() == null ? "OK" : connection.getResponseMessage(),
                    responseHeaders, new ByteArrayInputStream(html.getBytes("UTF-8")));
        } catch (Exception ignored) {
            // İntersept alınmasa, WebView normal şəkildə saytı yükləməyə davam edir.
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        az.axtaris.baza.PendingChanges.init(this);          // «Dəyişikliklər» təklifləri Supabase ilə sinxron
        az.axtaris.baza.PendingChanges.syncSoon();
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        injectJs = readAsset("inject.js");
        clearOcrCache();                      // əvvəlki sessiyadan qalan kamera şəkilləri

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ui.setFocusable(true);
        ui.setFocusableInTouchMode(true);
        root.addView(ui, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        // hesab.az söndürülüb: səhifə yaradılmır
        setupCommon(ui);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                // Açılışda "Nömrə daxil edin" xanasına avtomatik keçid və klaviatura ləğv edilib
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                WebResourceResponse local = loader.shouldInterceptRequest(r.getUrl());
                if (local != null) return local;
                // Portmanat-ın görünən iframe-i də öz WebView daxilində işləsin: saytın əsas HTML-inə
                // yalnız YVÖK doldurma/oxuma skripti əlavə edilir. Digər sayt resurslarına toxunulmur.
                return interceptPortmanatFrame(r);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // Xarici iframe-lər öz WebView sahəsində açılsın; yalnız əsas səhifənin xarici keçidləri tətbiqə ötürülür.
                if (!r.isForMainFrame()) return false;
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public String getCheckerMode() { return checkerMode(); }

            @JavascriptInterface
            public void setCheckerMode(String mode) {
                String m = ("hesab".equals(mode) || "auto".equals(mode)) ? mode : "ebel";
                getSharedPreferences("yvok_checker", MODE_PRIVATE).edit().putString("mode", m).apply();
            }

            // YVÖK xanası (mesaj göndərmə): yalnız öz gizli səhifəsini sıfırlayır
            @JavascriptInterface
            public void reset() {
                runOnUiThread(() -> cancelRace());
            }

            // Whatsapp nömrə pəncərəsinin açıq/bağlı vəziyyəti (geri düyməsi üçün)
            @JavascriptInterface
            public void modalOpen(boolean open) {
                waModalOpen = open;
            }

            // YVÖK xanasına ilk toxunuşdan sonra yelo.az səhifəsi arxada hazır gözləyir (bağlanmır, hər istifadədən sonra təzəsi hazırlanır)
            @JavascriptInterface
            public void warm() {
                runOnUiThread(() -> yeloSingle().warmUp());
            }

            // Bələdiyyə bazasında YVÖK axtarışı (7 simvol): tapılsa {"street":"bina adı","menzil":"..."}, yoxsa ""
            @JavascriptInterface
            public String findBaza(String code) {
                android.database.sqlite.SQLiteDatabase d = null;
                try {
                    String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
                    if (c.length() != 7) return "";
                    File f = bazaFile();
                    d = android.database.sqlite.SQLiteDatabase.openDatabase(f.getPath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
                    String full = "10011" + c;
                    android.database.Cursor cur = d.rawQuery(
                        "SELECT r.menzil, b.name, s.name, r.cells, b.title FROM rows r JOIN buildings b ON b.id = r.building_id JOIN streets s ON s.id = b.street_id WHERE r.cells LIKE ? ORDER BY r.id LIMIT 30",
                        new String[]{"%" + c + "\"%"});
                    try {
                        while (cur.moveToNext()) {
                            JSONArray arr = new JSONArray(cur.getString(3));
                            boolean ok = false;
                            for (int i = 0; i < arr.length(); i++) {
                                String v = arr.optString(i, "").trim().toUpperCase();
                                if (v.equals(full) || v.equals(c)) { ok = true; break; }
                            }
                            if (!ok) continue;
                            JSONObject o = new JSONObject();
                            String building = cur.getString(1) == null ? "" : cur.getString(1).replaceAll("\\s+", " ").trim();
                            String street = cur.getString(2) == null ? "" : cur.getString(2).replaceAll("\\s+", " ").trim();
                            String title = cur.getString(4) == null ? "" : cur.getString(4).replaceAll("\\s+", " ").trim();
                            o.put("street", fullStreetBuildingLabel(street, building, title));
                            o.put("menzil", cur.getString(0) == null ? "" : cur.getString(0).trim());
                            return o.toString();
                        }
                    } finally { cur.close(); }
                } catch (Throwable t) {
                    // axtarış alınmadısa sakitcə boş qaytar: əl ilə yazmaq işləyir
                } finally {
                    if (d != null) try { d.close(); } catch (Throwable ignore) { }
                }
                return "";
            }

            // Whatsapp göndərildikdən sonra: nömrə bazada yoxdursa yazılan YVÖK-ün sətrinə «Nömrə» xanasına əlavə olunur
            @JavascriptInterface
            public void addPhoneToBaza(final String code, final String phone) {
                new Thread(() -> {
                    try {
                        if (ops().addPhoneToBazaImpl(code, phone)) {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Nömrə bazaya əlavə olundu", Toast.LENGTH_SHORT).show());
                        }
                    } catch (Throwable ignore) { }
                }).start();
            }

            // Whatsapp göndərildikdən sonra:
            //  - YVÖK bazada VAR: yeni nömrə bazada yoxdursa əlavə olunur, bazadakı ad köhnədirsə, mənzil dəyişdirilibsə yenilənir (avtomatik);
            //  - qalan hər şey (YVÖK bazada yoxdur: yeni mənzil/küçə; küçə/bina fərqlidir: köçürmə) bazaya YAZILMIR,
            //    «📝 Dəyişikliklər» düyməsinə təklif kimi düşür, orada təsdiq və ya ləğv olunur.
            @JavascriptInterface
            public void saveToBaza(final String code, final String phone, final String name, final String borc,
                                   final String street, final String menzil) {
                new Thread(() -> {
                    try {
                        BazaOps o = ops();
                        String c = code == null ? "" : code.toUpperCase().replaceAll("[^A-Z0-9]", "");
                        if (c.length() != 7) return;
                        String key = "10011" + c;

                        // YVÖK bazada yoxdur: yeni mənzil / yeni küçə təklifi
                        String[] np = o.previewNew(c, name, street, menzil);
                        if (np != null) {
                            JSONObject p = new JSONObject();
                            p.put("code", c); p.put("phone", phone == null ? "" : phone); p.put("name", name == null ? "" : name);
                            p.put("borc", borc == null ? "" : borc); p.put("street", street == null ? "" : street);
                            p.put("menzil", menzil == null ? "" : menzil);
                            az.axtaris.baza.PendingChanges.add(MainActivity.this,
                                "kuce".equals(np[0]) ? az.axtaris.baza.PendingChanges.KIND_KUCE : az.axtaris.baza.PendingChanges.KIND_MENZIL,
                                key, np[1], p.toString());
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "«Dəyişikliklər»ə təklif əlavə olundu", Toast.LENGTH_SHORT).show());
                            return;
                        }
                        if (!o.existsInBaza(c)) return;   // ad gəlməyib (səhv/tapılmayan YVÖK): heç nə

                        // YVÖK bazada var: avtomatik yalnız yeni nömrə və köhnə ad
                        boolean phoneAdded = o.addPhoneToBazaImpl(c, phone);
                        boolean nameUpdated = o.updateNameImpl(c, name);
                        boolean menzilUpdated = o.updateMenzilImpl(c, menzil);   // mesajda əllə dəyişdirilmiş mənzil bazada da yenilənir

                        // küçə/bina fərqlidirsə: köçürmə təklifi (bazaya toxunulmur)
                        String rel = o.previewRelocate(c, street);
                        boolean proposed = false;
                        if (rel != null) {
                            JSONObject p = new JSONObject();
                            p.put("code", c); p.put("street", street == null ? "" : street);
                            az.axtaris.baza.PendingChanges.add(MainActivity.this,
                                az.axtaris.baza.PendingChanges.KIND_KOCUR, key, rel, p.toString());
                            proposed = true;
                        }
                        final String msg = proposed ? "«Dəyişikliklər»ə köçürmə təklifi əlavə olundu"
                            : menzilUpdated ? "Bazada mənzil yeniləndi"
                            : (nameUpdated && phoneAdded) ? "Nömrə əlavə olundu, ad yeniləndi"
                            : nameUpdated ? "Bazada ad yeniləndi"
                            : phoneAdded ? "Nömrə bazaya əlavə olundu" : null;
                        if (msg != null) runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
                    } catch (Throwable ignore) { }
                }).start();
            }

            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> {
                    cancelRace();                                  // əvvəlki sorğunu ləğv et (bütün mənbələr)
                    ui.evaluateJavascript("window.setTaxItems([],'');", null);   // əvvəlki kodun vergi sətirləri silinir
                    status("loading");
                    final Job j = new Job(v, false);
                    j.mode = "race";
                    final Race r = new Race();
                    r.expected = 1;                                // xəta yalnız zəncirin sonu da uğursuz olanda göstərilir
                    currentRace = r;
                    j.race = r;
                    startYeloSingle(j);                            // sürətli əsas mənbə; yalnız cavab gəlməyəndə ehtiyat mənbələrə keçir
                });
            }

            // Konkret Whatsapp (və ya Business) tətbiqinə yönləndir; uzun mesaj əvvəlcə redaktə olunur.
            @JavascriptInterface
            public void openWa(String phone, String text, boolean business) {
                runOnUiThread(() -> confirmOrSendMessage(phone, text, true, business));
            }

            // Toplu yoxlama nəticələrini fayla yaz (xlsx / txt / pdf): rows = [[kod, borc, ad], ...]
            @JavascriptInterface
            public void exportFile(String format, String rowsJson) {
                final String fmt = format == null ? "" : format;
                final String js = rowsJson == null ? "[]" : rowsJson;
                new Thread(() -> doExport(fmt, js)).start();
            }

            // Excel (xlsx) / csv / txt faylından YVÖK kodlarını oxu
            @JavascriptInterface
            public void pickExcel() {
                runOnUiThread(() -> {
                    try {
                        Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        it.addCategory(Intent.CATEGORY_OPENABLE);
                        it.setType("*/*");
                        it.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel", "text/csv", "text/plain",
                                "application/octet-stream"});
                        startActivityForResult(it, REQ_XLSX);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Fayl seçmək mümkün olmadı", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            // Kontaktlar siyahısını aç (icazə tələb etmir: yalnız seçilən kontaktın nömrəsi oxunur)
            @JavascriptInterface
            public void pickContact() {
                runOnUiThread(() -> {
                    try {
                        Intent it = new Intent(Intent.ACTION_PICK,
                                android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                        startActivityForResult(it, REQ_CONTACT);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Kontaktlar tətbiqi tapılmadı", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            // Android mesajlaşma (SMS) tətbiqinə yönləndir; uzun mesaj əvvəlcə redaktə olunur.
            @JavascriptInterface
            public void openSms(String phone, String text) {
                runOnUiThread(() -> confirmOrSendMessage(phone, text, false, false));
            }

            // 160 simvoldan uzun SMS göndərməzdən əvvəl göstərilir və redaktə olunur (Bələdiyyə bazasındakı kimi).
            // Standart sətirlər (başlıq, «Borc:», «YVOK:», «Elaqe:») pəncərədə silinə bilməz.
            private void confirmOrSendMessage(String phone, String text, boolean whatsapp, boolean business) {
                final String draft = text == null ? "" : text;
                // Uzun mesaj xəbərdarlığı yalnız SMS üçün göstərilsin; WhatsApp birbaşa açılsın.
                if (whatsapp || draft.length() <= 160) {
                    openMessageNow(phone, draft, whatsapp, business);
                    return;
                }
                showSmsEditor(phone, draft);
            }

            private void showSmsEditor(String phone, String draft) {
                final String[] ln = draft.split("\n", -1);
                int from = 0, to = ln.length;
                String h = "", f = "";
                if (to > 0 && ln[0].startsWith("Bineqedi belediyyesi")) { h = ln[0]; from = 1; }
                if (to > from && ln[to - 1].startsWith("Elaqe:")) { f = ln[to - 1]; to--; }
                final String head = h, foot = f;
                StringBuilder bb = new StringBuilder();
                for (int i = from; i < to; i++) { if (bb.length() > 0) bb.append('\n'); bb.append(ln[i]); }
                final String body = bb.toString();
                final boolean needBorc = body.startsWith("Borc:") || body.contains("\nBorc:");
                final boolean needYvok = body.startsWith("YVOK:") || body.contains("\nYVOK:");

                int pad = (int) (16 * getResources().getDisplayMetrics().density + 0.5f);
                int sm = pad / 2;
                android.widget.LinearLayout box = new android.widget.LinearLayout(MainActivity.this);
                box.setOrientation(android.widget.LinearLayout.VERTICAL);
                box.setPadding(pad, sm, pad, 0);

                android.widget.TextView warn = new android.widget.TextView(MainActivity.this);
                warn.setText("Diqqət: mesaj 160 simvoldan uzundur (" + draft.length() + " simvol). Göndərməzdən əvvəl mətni redaktə edin.");
                warn.setTextSize(14f);
                warn.setTextColor(android.graphics.Color.parseColor("#FFB74D"));
                warn.setPadding(0, 0, 0, sm);
                box.addView(warn);

                if (!head.isEmpty()) box.addView(fixedLine(head, sm));

                final EditText editor = new EditText(MainActivity.this);
                editor.setText(body);
                editor.setSelection(editor.getText().length());
                editor.setMinLines(3);
                editor.setMaxLines(8);
                editor.setGravity(Gravity.TOP | Gravity.START);
                editor.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                        | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
                box.addView(editor);

                if (!foot.isEmpty()) box.addView(fixedLine(foot, sm));

                final android.widget.TextView count = new android.widget.TextView(MainActivity.this);
                count.setTextSize(12f);
                count.setPadding(0, sm, 0, 0);
                box.addView(count);

                final String[] lastValid = { body };
                final boolean[] busy = { false };
                editor.addTextChangedListener(new android.text.TextWatcher() {
                    @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                    @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                    @Override public void afterTextChanged(android.text.Editable e) {
                        if (busy[0]) return;
                        String t = e.toString();
                        boolean ok = (!needBorc || t.startsWith("Borc:") || t.contains("\nBorc:"))
                                && (!needYvok || t.startsWith("YVOK:") || t.contains("\nYVOK:"));
                        if (!ok) {           // standart sətir silinməyə çalışıldı: əvvəlki hala qaytar
                            busy[0] = true;
                            editor.setText(lastValid[0]);
                            editor.setSelection(editor.getText().length());
                            busy[0] = false;
                            t = lastValid[0];
                        } else lastValid[0] = t;
                        int n = composeSms(head, t, foot).length();
                        count.setText(n + " simvol" + (n > 160 ? " · 160-dən çox" : ""));
                        count.setTextColor(android.graphics.Color.parseColor(n > 160 ? "#FFB74D" : "#8FD18F"));
                    }
                });
                int n0 = draft.length();
                count.setText(n0 + " simvol" + (n0 > 160 ? " · 160-dən çox" : ""));
                count.setTextColor(android.graphics.Color.parseColor(n0 > 160 ? "#FFB74D" : "#8FD18F"));

                android.widget.ScrollView scroll = new android.widget.ScrollView(MainActivity.this);
                scroll.addView(box);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Mesajı redaktə edin")
                        .setView(scroll)
                        .setPositiveButton("Redaktə olunmuş mətni istifadə et", (dialog, which) -> {
                            String edited = composeSms(head, editor.getText().toString(), foot).trim();
                            if (edited.isEmpty()) {
                                Toast.makeText(MainActivity.this, "Mesaj boş ola bilməz", Toast.LENGTH_SHORT).show();
                            } else {
                                openMessageNow(phone, edited, false, false);
                            }
                        })
                        .setNegativeButton("Ləğv et", null)
                        .show();
            }

            private android.widget.TextView fixedLine(String t, int pad) {
                android.widget.TextView v = new android.widget.TextView(MainActivity.this);
                v.setText(t);
                v.setTextSize(15f);
                v.setTextColor(android.graphics.Color.parseColor("#B3B3BD"));
                v.setPadding(0, pad / 2, 0, pad / 2);
                return v;
            }

            private String composeSms(String head, String body, String foot) {
                StringBuilder sb = new StringBuilder();
                if (!head.isEmpty()) sb.append(head);
                String b = body == null ? "" : body.trim();
                if (!b.isEmpty()) { if (sb.length() > 0) sb.append('\n'); sb.append(b); }
                if (!foot.isEmpty()) { if (sb.length() > 0) sb.append('\n'); sb.append(foot); }
                return sb.toString();
            }

            private void openMessageNow(String phone, String text, boolean whatsapp, boolean business) {
                try {
                    if (whatsapp) {
                        String pkg = business ? "com.whatsapp.w4b" : "com.whatsapp";
                        String url = "whatsapp://send?phone=994" + (phone == null ? "" : phone)
                                + (!text.isEmpty() ? "&text=" + Uri.encode(text) : "");
                        Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        it.setPackage(pkg);
                        startActivity(it);
                    } else {
                        Intent it = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+994" + (phone == null ? "" : phone)));
                        it.putExtra("sms_body", text);
                        startActivity(it);
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            whatsapp ? (business ? "Whatsapp Business tapılmadı" : "Whatsapp tapılmadı")
                                    : "Mesajlaşma tətbiqi tapılmadı",
                            Toast.LENGTH_SHORT).show();
                }
            }

            // YVÖK xanasına fokus verildikdə klaviaturanı aç
            @JavascriptInterface
            public void kbd() {
                runOnUiThread(() -> {
                    ui.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                });
            }

            // Toplu yoxlama: vergüllə ayrılmış tam kodlar (10011XXXXXXX)
            @JavascriptInterface
            public void batch(String csv) { enqueueBatch(csv, false); }

            // Əllə redaktə olunan kod: heç bir variant/kombinasiya yoxlanmır, yalnız həmin kod yoxlanılır
            @JavascriptInterface
            public void batchExact(String csv) { enqueueBatch(csv, true); }

            private void enqueueBatch(String csv, final boolean exact) {
                if (csv == null) return;
                final String[] parts = csv.split(",");
                runOnUiThread(() -> {
                    for (String c : parts) {
                        c = c.trim().toUpperCase();
                        if (!CODE.matcher(c).matches()) continue;
                        boolean dup = false;
                        for (Worker w : pool) {
                            if (w.current != null && (w.current.code.equals(c) || w.current.orig.equals(c))) { dup = true; break; }
                        }
                        if (!dup) for (Job j : batchJobs) if (j.code.equals(c)) { dup = true; break; }
                        if (!dup && extActive.contains(c)) dup = true;   // yelo.az / hesab.az-da yoxlanılır
                        if (!dup) {
                            resolvedCodes.remove(c); inflight.remove(c);   // təkrar yoxlama: əvvəlki nəticə vəziyyəti sıfırlanır
                            Job nj = new Job(c, true);
                            if (exact) nj.variants = new ArrayDeque<>();   // boş növbə: variant qurulmur
                            batchJobs.addLast(nj);
                        }
                    }
                    pumpBatch();
                });
            }

            // Canlı kamera skanı (Toplu yoxlama): düzbucaqda kod tanınır, borc yazılır
            @JavascriptInterface
            public void scan() {
                runOnUiThread(() -> startActivityForResult(new Intent(MainActivity.this, ScanActivity.class), REQ_SCAN));
            }

            // Şəkildən kod oxu: kamera və ya qalereya
            @JavascriptInterface
            public void ocr(String engine, String key) {
                final String eng = "cloud".equals(engine) ? "cloud" : "mlkit";
                final String k = key == null ? "" : key.trim();
                runOnUiThread(() -> {
                    ocrEngine = eng;
                    cvKey = k;
                    if ("cloud".equals(eng) && cvLeft() <= 0) {
                        toast("Cloud Vision limiti bitib (0/" + CV_MAX + "), ML Kit ilə oxunacaq");
                        ocrEngine = "mlkit";
                    }
                    openOcrChooser();
                });
            }

            // Mikrorayon baza bölməsini aç (ayrıca ekran; geri düyməsi bura qaytarır)
            @JavascriptInterface
            public void openBaza() {
                runOnUiThread(() -> { trimIdle(0); startActivity(new Intent(MainActivity.this, az.axtaris.baza.BazaActivity.class)); });   // baza açılanda boş gizli səhifələr RAM-ı boşaldır
            }

            // Qalan Cloud Vision sorğu sayı
            @JavascriptInterface
            public int cvLeft() {
                return MainActivity.this.cvLeft();
            }

            @JavascriptInterface
            public void batchStop() {
                runOnUiThread(() -> {
                    batchJobs.clear();
                    extActive.clear();
                    resetBatchState();
                    if (hesab != null) hesab.clear();
                    if (yeloBatch != null) yeloBatch.clear();
                    if (portBatch != null) portBatch.clear();
                    for (Worker w : pool) {
                        if (w.current != null) recycle(w);
                        else if (!w.loaded && w.wv != null) { w.wv.stopLoading(); w.wv.loadUrl(EBEL_URL); }   // ilişib qalmış boş səhifəni təzələ
                    }
                });
            }
        }, "Android");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

    }

    // boş (iş görməyən) toplu yoxlama səhifələrini keep sayına qədər azaldır
    private void trimIdle(int keep) {
        for (int i = pool.size() - 1; i >= 0 && pool.size() > keep; i--) {
            Worker w = pool.get(i);
            if (w.current != null || w.wv == null) continue;
            WebView old = w.wv;
            old.removeCallbacks(w.watchdog);
            w.wv = null; w.loaded = false;
            try { old.stopLoading(); old.setWebViewClient(new WebViewClient()); root.removeView(old); old.destroy(); } catch (Throwable ignored) { }
            pool.remove(i);
        }
    }

    // ---------------- OCR ----------------
    private void openOcrChooser() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        Intent chooser = Intent.createChooser(pick, "Şəkil seçin");
        cameraUri = null;
        try {
            File dir = new File(getCacheDir(), "ocr");
            dir.mkdirs();
            File f = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        } catch (Exception e) {
            cameraUri = null;   // kamera olmasa yalnız qalereya
        }
        try {
            startActivityForResult(chooser, REQ_OCR);
        } catch (Exception e) {
            toast("Şəkil seçmək mümkün olmadı");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_XLSX) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            final Uri fu = data.getData();
            new Thread(() -> importCodesFromFile(fu)).start();
            return;
        }
        if (req == REQ_SCAN) {
            if (res != RESULT_OK || data == null) return;
            String[] cs = data.getStringArrayExtra(ScanActivity.EXTRA_CODES);
            if (cs == null || cs.length == 0) return;
            ui.evaluateJavascript("window.addScanCodes(" + JSONObject.quote(android.text.TextUtils.join("\n", cs)) + ");", null);
            return;
        }
        if (req == REQ_CONTACT) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            try (android.database.Cursor c = getContentResolver().query(data.getData(),
                    new String[]{android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER,
                                 android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String num = c.getString(0);
                    String cname = c.getString(1);
                    ui.evaluateJavascript("window.setPhoneFromContact(" + JSONObject.quote(num == null ? "" : num) + ","
                        + JSONObject.quote(cname == null ? "" : cname) + ");", null);
                }
            } catch (Exception e) {
                toast("Nömrəni oxumaq mümkün olmadı");
            }
            return;
        }
        if (req != REQ_OCR) return;
        if (res != RESULT_OK) { clearOcrCache(); return; }
        ArrayList<Uri> uris = new ArrayList<>();
        if (data != null && data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data != null && data.getData() != null) {
            uris.add(data.getData());
        } else if (cameraUri != null) {
            uris.add(cameraUri);      // kamera çəkilişi
        }
        if (uris.isEmpty()) return;
        runOcr(uris);
    }

    // Hər şəkil əvvəlcə "sənəd skan" effektinə çevrilir (DocEnhance), sonra oxunur.
    // Effektli şəkildə kod tapılmasa, orijinal şəkil də yoxlanılır.
    // Şəkillər PARALEL oxunur (sürət üçün), nəticələr seçilmə sırasına görə birləşdirilir
    private void runOcr(ArrayList<Uri> uris) {
        toast("Şəkil oxunur…");
        final TextRecognizer rec = recognizer();   // bir dəfə yaradılır, hər oxumada təkrar yüklənmir
        final int n = uris.size();
        final ArrayList<ArrayList<String>> res = new ArrayList<>();
        for (int i = 0; i < n; i++) res.add(null);
        final int[] left = {n};
        final boolean cloud = "cloud".equals(ocrEngine) && !cvKey.isEmpty();
        final int avail = cloud ? cvLeft() : 0;      // qalan limit qədər şəkil Cloud Vision ilə, artığı ML Kit ilə
        if (cloud && n > avail) toast("Limit çatmır: ilk " + avail + " şəkil Cloud Vision, qalanı ML Kit ilə oxunur");
        for (int i = 0; i < n; i++) {
            final int idx = i;
            final Uri uri = uris.get(i);
            if (cloud && i < avail) {
                new Thread(() -> cloudOcr(rec, uri, idx, res, left)).start();
                continue;
            }
            mlkitMulti(rec, uri, idx, res, left);
        }
    }

    // ---------------- Cloud Vision ----------------
    private SharedPreferences cvPrefs() { return getSharedPreferences("cv", MODE_PRIVATE); }

    private static String today() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    // Qalan sorğu sayı: hər gün yenidən CV_MAX olur
    private synchronized int cvLeft() {
        SharedPreferences p = cvPrefs();
        if (!today().equals(p.getString("day", ""))) {
            p.edit().putString("day", today()).putInt("used", 0).apply();
            return CV_MAX;
        }
        return Math.max(0, CV_MAX - p.getInt("used", 0));
    }

    private synchronized void cvSetUsed(int used) {
        cvPrefs().edit().putString("day", today()).putInt("used", Math.max(0, Math.min(CV_MAX, used))).apply();
        final int left = cvLeft();
        runOnUiThread(() -> ui.evaluateJavascript("window.setCvLeft(" + left + ");", null));
    }

    private synchronized void cvUsedOne() { cvSetUsed(CV_MAX - cvLeft() + 1); }

    // Bir şəkil = bir Cloud Vision sorğusu (DOCUMENT_TEXT_DETECTION). Xəta olarsa ML Kit-ə keçilir.
    private void cloudOcr(final TextRecognizer rec, final Uri uri, final int idx,
                          final ArrayList<ArrayList<String>> res, final int[] left) {
        final ArrayList<String> found = new ArrayList<>();
        String err = null;
        try {
            Bitmap bmp = DocEnhance.load(this, uri);
            // Cloud Vision-a bütün səhifə əvəzinə kod sütununun böyüdülmüş, solğun yazıları gücləndirilmiş hissəsi göndərilir.
            // Bu, ad/telefon/məbləğ sütunlarının qarışmasını azaldır və OCR üçün simvolları böyüdür.
            float[] stripScale = {1f};
            Bitmap strip = targetCodeStrip(bmp, stripScale);
            bmp.recycle();
            Bitmap inkClean = DocEnhance.suppressBlueInk(strip);
            strip.recycle();
            Bitmap cloudImage = DocEnhance.enhance(inkClean, 0.82f, 0.99f);
            inkClean.recycle();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            cloudImage.compress(Bitmap.CompressFormat.JPEG, 95, bos);
            cloudImage.recycle();
            String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);

            JSONObject image = new JSONObject().put("content", b64);
            JSONObject feat = new JSONObject().put("type", "DOCUMENT_TEXT_DETECTION");
            JSONObject req = new JSONObject().put("image", image).put("features", new JSONArray().put(feat));
            byte[] body = new JSONObject().put("requests", new JSONArray().put(req)).toString().getBytes("UTF-8");

            URL url = new URL("https://vision.googleapis.com/v1/images:annotate?key=" + URLEncoder.encode(cvKey, "UTF-8"));
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream os = c.getOutputStream()) { os.write(body); }
            int code = c.getResponseCode();
            InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream rb = new ByteArrayOutputStream();
            if (is != null) {
                byte[] buf = new byte[8192];
                int r;
                while ((r = is.read(buf)) > 0) rb.write(buf, 0, r);
                is.close();
            }
            String txt = rb.toString("UTF-8");
            if (code == 200) {
                cvUsedOne();
                JSONObject first = new JSONObject(txt).getJSONArray("responses").getJSONObject(0);
                if (first.has("error")) {
                    err = first.getJSONObject("error").optString("message", "Cloud Vision xətası");
                } else {
                    JSONObject fta = first.optJSONObject("fullTextAnnotation");
                    String text = fta == null ? "" : fta.optString("text", "");
                    ArrayList<String> colLines = null;
                    try { colLines = cloudColumnLines(fta); } catch (Throwable ignored) { }
                    // Sütun etibarlı müəyyən edilməyibsə, bütün səhifə mətnini oxuyub siyahıya qatma.
                    // Boş nəticədə aşağıda ML Kit-in hədəf-sütun skanı işə düşəcək.
                    if (colLines != null) {
                        for (String line : colLines) found.addAll(lineCodes(line.toUpperCase()));
                    }
                }
            } else {
                String msg = "";
                try { msg = new JSONObject(txt).getJSONObject("error").optString("message", ""); } catch (Exception ignored) { }
                if (code == 429) { cvSetUsed(CV_MAX); err = "Google Cloud Vision limiti dolub"; }
                else if (code == 400 && msg.toLowerCase(Locale.ROOT).contains("api key")) err = "Cloud Vision API açarı yanlışdır";
                else if (code == 403) err = "Cloud Vision API açarı icazəsizdir və ya Cloud Vision API aktiv deyil";
                else err = "Cloud Vision xətası (" + code + ")" + (msg.isEmpty() ? "" : ": " + msg);
            }
        } catch (Throwable t) {
            err = "Cloud Vision-a qoşulmaq mümkün olmadı";
        }
        final String e = err;
        runOnUiThread(() -> {
            if (e != null) toast(e);
            // Cloud Vision heç nə qaytarmayıbsa, hədəf sütunu böyüdən çoxkeçidli ML Kit skanına keç.
            if (found.isEmpty()) { mlkitMulti(rec, uri, idx, res, left); return; }
            // Cloud Vision nəticəsini böyüdülmüş yerli skanla da müqayisə et; daha çox sətir tapılan nəticəni seç.
            mlkitSupplement(rec, uri, idx, res, left, found);
        });
    }

    // Cloud Vision: sözləri qutularına görə sütuna süzür və sətirlərə yığır; sütun tapılmasa null qaytarır
    private ArrayList<String> cloudColumnLines(JSONObject fta) throws Exception {
        if (fta == null) return null;
        ArrayList<String> wt = new ArrayList<>();
        ArrayList<int[]> wb = new ArrayList<>();   // {sol, sağ, yuxarı, aşağı, sətir sonu?1:0}
        JSONArray pages = fta.optJSONArray("pages");
        if (pages == null) return null;
        for (int a = 0; a < pages.length(); a++) {
            JSONArray blocks = pages.getJSONObject(a).optJSONArray("blocks");
            if (blocks == null) continue;
            for (int b = 0; b < blocks.length(); b++) {
                JSONArray paras = blocks.getJSONObject(b).optJSONArray("paragraphs");
                if (paras == null) continue;
                for (int c = 0; c < paras.length(); c++) {
                    JSONArray words = paras.getJSONObject(c).optJSONArray("words");
                    if (words == null) continue;
                    for (int d = 0; d < words.length(); d++) {
                        JSONObject w = words.getJSONObject(d);
                        JSONArray syms = w.optJSONArray("symbols");
                        JSONArray vs = w.getJSONObject("boundingBox").optJSONArray("vertices");
                        if (syms == null || vs == null || vs.length() == 0) continue;
                        StringBuilder sb = new StringBuilder();
                        boolean eol = false;
                        for (int k = 0; k < syms.length(); k++) {
                            JSONObject sy = syms.getJSONObject(k);
                            sb.append(sy.optString("text", ""));
                            JSONObject pr = sy.optJSONObject("property");
                            JSONObject br = pr == null ? null : pr.optJSONObject("detectedBreak");
                            if (br != null) {
                                String ty = br.optString("type", "");
                                if (ty.equals("EOL_SURE_SPACE") || ty.equals("LINE_BREAK")) eol = true;
                            }
                        }
                        int l = Integer.MAX_VALUE, r = Integer.MIN_VALUE, tp = Integer.MAX_VALUE, bt = Integer.MIN_VALUE;
                        for (int k = 0; k < vs.length(); k++) {
                            JSONObject v = vs.getJSONObject(k);
                            int x = v.optInt("x", 0), y = v.optInt("y", 0);
                            l = Math.min(l, x); r = Math.max(r, x); tp = Math.min(tp, y); bt = Math.max(bt, y);
                        }
                        wt.add(sb.toString().toUpperCase());
                        wb.add(new int[]{l, r, tp, bt, eol ? 1 : 0});
                    }
                }
            }
        }
        ArrayList<Integer> ls = new ArrayList<>(), ws = new ArrayList<>();
        for (int i = 0; i < wt.size(); i++)
            if (OCR_CODE.matcher(wt.get(i)).find()) { ls.add(wb.get(i)[0]); ws.add(wb.get(i)[1] - wb.get(i)[0]); }
        if (ls.isEmpty()) return null;
        Collections.sort(ls); Collections.sort(ws);
        int medL = ls.get(ls.size() / 2), medW = Math.max(1, ws.get(ws.size() / 2));
        float cl = medL - 0.35f * medW, cr = medL + 1.35f * medW;   // sütunun üfüqi aralığı
        ArrayList<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < wt.size(); i++) {
            int[] q = wb.get(i);
            float cx = (q[0] + q[1]) / 2f;
            if (cx >= cl && cx <= cr) { if (cur.length() > 0) cur.append(' '); cur.append(wt.get(i)); }
            if (q[4] == 1) { if (cur.length() > 0) lines.add(cur.toString()); cur.setLength(0); }
        }
        if (cur.length() > 0) lines.add(cur.toString());
        return lines;
    }

    // ---------------- ML Kit: çoxkeçidli oxuma ----------------
    // Hər şəkil bir neçə həssaslıqda oxunur: adi, solğun, çox solğun (DocEnhance) və orijinal.
    // Hər effektli şəkil həm bütöv, həm də 10011 sütunu kəsilib böyüdülmüş halda oxunur.
    // Nəticələr cərgə mövqeyinə görə birləşdirilir: eyni cərgədə fərqli oxunuşlar olsa səsvermə ilə seçilir,
    // yalnız bir keçiddə görünən (solğun) kod isə itmir.
    private static final class Hit {
        final String code; final float y; final int pass; final boolean partial;
        Hit(String code, float y, int pass) { this.code = code; this.y = y; this.pass = pass; this.partial = code.startsWith("~"); }
    }

    private void mlkitMulti(final TextRecognizer rec, final Uri uri, final int idx,
                            final ArrayList<ArrayList<String>> res, final int[] left) {
        new Thread(() -> {
            ArrayList<String> r = new ArrayList<>();
            try { r = multiPass(rec, uri); } catch (Throwable ignored) { }
            final ArrayList<String> fr = r;
            runOnUiThread(() -> ocrImgDone(rec, fr, idx, res, left));
        }).start();
    }

    private void mlkitSupplement(final TextRecognizer rec, final Uri uri, final int idx,
                                 final ArrayList<ArrayList<String>> res, final int[] left,
                                 final ArrayList<String> cloudFound) {
        new Thread(() -> {
            ArrayList<String> localFound = new ArrayList<>();
            try { localFound = multiPass(rec, uri); } catch (Throwable ignored) { }
            // Eyni sayda sətirdə Cloud Vision üstün tutulur; lokal OCR yalnız əlavə sətir taparsa seçilir.
            final ArrayList<String> chosen = localFound.size() > cloudFound.size() ? localFound : cloudFound;
            runOnUiThread(() -> ocrImgDone(rec, chosen, idx, res, left));
        }).start();
    }

    private static Text runRec(TextRecognizer rec, Bitmap bmp) {
        try { return Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 40, TimeUnit.SECONDS); }
        catch (Throwable e) { return null; }
    }

    private static final class PassOut {
        final ArrayList<Hit> hits = new ArrayList<>();
        final ArrayList<Float> lineHs = new ArrayList<>();
        int pass;
    }

    // kind: 0 = effektli (a,b), 1 = orijinal, 2 = yerli kontrast (a), 3 = fon-müstəqil (a,b), 4 = tərs boz
    private PassOut onePass(TextRecognizer rec, Bitmap bmp, int kind, float a, float b, int pass, float H) {
        PassOut po = new PassOut();
        po.pass = pass;
        try {
            if (kind == 1) {
                collectHits(runRec(rec, bmp), po.hits, pass, 0f, 1f, H, po.lineHs);
                return po;
            }
            Bitmap enh = null;
            try {
                if (kind == 0) enh = DocEnhance.enhance(bmp, a, b);
                else if (kind == 2) enh = DocEnhance.enhanceLocal(bmp, a);
                else if (kind == 3) enh = DocEnhance.enhanceBg(bmp, a, b);
                else enh = DocEnhance.invertGray(bmp);
            } catch (Throwable ignored) { }
            if (enh != null) {
                readEnhanced(rec, enh, po.hits, pass, kind == 2 ? enh.getHeight() : H, po.lineHs);
                enh.recycle();
            }
        } catch (Throwable ignored) { }
        return po;
    }

    // Keçidləri paralel işlədir (effekt hesablaması ML Kit oxuması ilə üst-üstə düşür); nəticələr keçid sırası ilə qaytarılır
    private ArrayList<PassOut> runPasses(final TextRecognizer rec, final Bitmap bmp, final float H, final float[][] specs) {
        ArrayList<PassOut> outs = new ArrayList<>();
        java.util.concurrent.ExecutorService ex = java.util.concurrent.Executors.newFixedThreadPool(2);
        try {
            ArrayList<java.util.concurrent.Future<PassOut>> fs = new ArrayList<>();
            for (final float[] sp : specs) {
                fs.add(ex.submit(() -> onePass(rec, bmp, (int) sp[0], sp[1], sp[2], (int) sp[3], H)));
            }
            for (java.util.concurrent.Future<PassOut> f : fs) {
                try { outs.add(f.get()); } catch (Throwable ignored) { }
            }
        } finally { ex.shutdown(); }
        return outs;
    }

    // Sürətli mərhələ kifayətdirmi: bütün cərgələr tam kodlu, hər biri ən azı iki dəfə oxunub, cərgələr arasında boşluq (itmiş solğun cərgə) yoxdur
    private boolean confident(ArrayList<Hit> hits, ArrayList<Float> lineHs, ArrayList<String> out, ArrayList<Float> ys) {
        if (out.isEmpty()) return false;
        for (String c : out) if (c.startsWith("~")) return false;
        int full = 0;
        for (Hit h : hits) if (!h.partial) full++;
        if (full < 2 * out.size()) return false;
        if (ys.size() >= 3) {
            ArrayList<Float> gaps = new ArrayList<>();
            for (int i = 1; i < ys.size(); i++) gaps.add(ys.get(i) - ys.get(i - 1));
            ArrayList<Float> sg = new ArrayList<>(gaps);
            Collections.sort(sg);
            float med = sg.get(sg.size() / 2);
            for (float g : gaps) if (med > 0f && g > 1.7f * med) return false;
        }
        return true;
    }

    private ArrayList<String> multiPass(TextRecognizer rec, Uri uri) throws Exception {
        Bitmap bmp = DocEnhance.load(this, uri);
        final float H = bmp.getHeight();
        ArrayList<Hit> hits = new ArrayList<>();
        ArrayList<Float> lineHs = new ArrayList<>();
        ArrayList<String> out;

        // Mərhələ A: adi effekt + orijinal.
        ArrayList<PassOut> a = runPasses(rec, bmp, H, new float[][]{{0, 0.45f, 0.90f, 0}, {1, 0, 0, 6}});
        for (PassOut po : a) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }
        ArrayList<Float> ysA = new ArrayList<>();
        out = mergeHits(new ArrayList<>(hits), new ArrayList<>(lineHs), ysA);
        boolean needDeepPasses = !confident(hits, lineHs, out, ysA);

        // Mərhələ B/C: yalnız ilkin oxunuş əmin deyilsə, digər adaptiv kontrast variantları.
        if (needDeepPasses) {
            ArrayList<PassOut> bs = runPasses(rec, bmp, H, new float[][]{
                    {0, 0.70f, 0.97f, 2}, {0, 0.82f, 0.99f, 4}, {2, 0.55f, 0, 7}, {2, 0.35f, 0, 9}});
            for (PassOut po : bs) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }
            ArrayList<Float> ys = new ArrayList<>();
            out = mergeHits(hits, lineHs, ys);

            // Rəngli/boz fon üçün əlavə üsullar yalnız əvvəlki üsullar nəticə verməyəndə.
            if (out.isEmpty()) {
                ArrayList<PassOut> cs = runPasses(rec, bmp, H, new float[][]{
                        {3, 14f, 60f, 11}, {3, 7f, 30f, 13}, {4, 0, 0, 15}});
                for (PassOut po : cs) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }
            }
        }

        // Müstəqil hədəf-sütun skanı: kodları əvvəlcə oxumaqla sütunu tapmaq tələb olunmur.
        // Beləliklə, solğun sətirlər ilkin OCR-dən yayınsa belə, həmin zolaq böyüdülərək yenidən oxunur.
        ArrayList<PassOut> targeted = runTargetStripPasses(rec, bmp, H);
        for (PassOut po : targeted) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }

        ArrayList<Float> ysFinal = new ArrayList<>();
        out = mergeHits(hits, lineHs, ysFinal);
        bmp.recycle();
        return out;
    }

    /**
     * Cədvəlin 10011 kod sütununun yerləşdiyi mərkəzi zolağı bütün hündürlük boyunca kəsir.
     * Kəsim əlavə keçiddir; bütün səhifə skanını əvəz etmir. Yalnız bu zolaq gücləndirilir və OCR edilir.
     */
    private Bitmap targetCodeStrip(Bitmap src, float[] scaleOut) {
        int w = src.getWidth(), h = src.getHeight();
        // Bu tip cədvəldə kod sütunu səhifənin təxminən 28%-58% eni arasındadır.
        int x0 = Math.max(0, Math.min(w - 1, Math.round(w * 0.28f)));
        int x1 = Math.max(x0 + 1, Math.min(w, Math.round(w * 0.58f)));
        Bitmap crop = Bitmap.createBitmap(src, x0, 0, x1 - x0, h);
        int cw = crop.getWidth();
        // Böyütməni yaddaş daxilində saxla ki, ML Kit böyük, solğun simvolları daha rahat seçsin.
        double pixelCap = Math.sqrt(2_700_000.0 / Math.max(1.0, (double) cw * h));
        float scale = (float) Math.min(2.5, Math.min(pixelCap,
                Math.min(950.0 / cw, 3600.0 / Math.max(1, h))));
        if (scale < 1f) scale = 1f;
        Bitmap scaled = crop;
        if (scale > 1.01f) {
            scaled = Bitmap.createScaledBitmap(crop, Math.max(1, Math.round(cw * scale)),
                    Math.max(1, Math.round(h * scale)), true);
            if (scaled != crop) crop.recycle();
        }
        scaleOut[0] = scale;
        return scaled;
    }

    private PassOut oneTargetStripPass(TextRecognizer rec, Bitmap strip, float scale, float H,
                                       int kind, float a, float b, int pass) {
        PassOut po = new PassOut();
        po.pass = pass;
        Bitmap enhanced = null;
        try {
            if (kind == 0) enhanced = DocEnhance.enhance(strip, a, b);
            else if (kind == 3) enhanced = DocEnhance.enhanceBg(strip, a, b);
            else enhanced = strip;
            Text t = runRec(rec, enhanced);
            collectHits(t, po.hits, pass, 0f, scale, H, po.lineHs);
        } catch (Throwable ignored) {
        } finally {
            if (enhanced != null && enhanced != strip) enhanced.recycle();
        }
        return po;
    }

    private ArrayList<PassOut> runTargetStripPasses(TextRecognizer rec, Bitmap original, float H) {
        ArrayList<PassOut> outs = new ArrayList<>();
        float[] info = {1f};
        Bitmap strip = null;
        try {
            strip = targetCodeStrip(original, info);
            float scale = info[0];
            // Mavi qələm qeydlərini ağlaşdır, boz/qara çap edilmiş kodları saxla.
            Bitmap inkClean = DocEnhance.suppressBlueInk(strip);
            strip.recycle();
            strip = inkClean;
            // Raw, orta kontrast, çox həssas kontrast və fon fərqinə əsaslanan variantlar.
            // Keçidlər ardıcıl işləyir ki, zəif telefonlarda yaddaş pik həddi böyüməsin.
            outs.add(oneTargetStripPass(rec, strip, scale, H, 1, 0f, 0f, 21));
            outs.add(oneTargetStripPass(rec, strip, scale, H, 0, 0.70f, 0.97f, 23));
            outs.add(oneTargetStripPass(rec, strip, scale, H, 0, 0.82f, 0.99f, 25));
            outs.add(oneTargetStripPass(rec, strip, scale, H, 3, 7f, 30f, 27));
        } catch (Throwable ignored) {
        } finally {
            if (strip != null && !strip.isRecycled()) strip.recycle();
        }
        return outs;
    }

    // Bir keçid: bütöv şəkil + 10011 sütunu kəsilib böyüdülmüş hal (keçid nömrələri: pass və pass+1)
    private void readEnhanced(TextRecognizer rec, Bitmap enh, ArrayList<Hit> hits, int pass, float H, ArrayList<Float> lineHs) {
        Text t = runRec(rec, enh);
        collectHits(t, hits, pass, 0f, 1f, H, lineHs);
        Bitmap crop = null;
        float[] info = {0f, 1f};
        try { if (t != null) crop = cropColumn(enh, t, info); } catch (Throwable ignored) { }
        if (crop != null) {
            Text t2 = runRec(rec, crop);
            collectHits(t2, hits, pass + 1, info[0], info[1], H, lineHs);
            crop.recycle();
        }
    }

    // 10011 sütununun üfüqi aralığı [sol, sağ, orta qutu hündürlüyü]; sütun tapılmasa null (süzgəc işləmir)
    private float[] columnRange(Text t) {
        ArrayList<Rect> bx = codeBoxes(t);
        if (bx.isEmpty()) {                                   // sütun 1 koddan ibarətdirsə həmin kodun qutusu götürülür
            for (Text.TextBlock b : t.getTextBlocks())
                for (Text.Line ln : b.getLines())
                    for (Text.Element el : ln.getElements()) {
                        Rect r = el.getBoundingBox();
                        if (r != null && OCR_CODE.matcher(el.getText().toUpperCase()).find()) bx.add(r);
                    }
            if (bx.size() != 1) return null;
        }
        int l = Integer.MAX_VALUE, r = Integer.MIN_VALUE;
        ArrayList<Integer> hs = new ArrayList<>(), ws = new ArrayList<>();
        for (Rect q : bx) { l = Math.min(l, q.left); r = Math.max(r, q.right); hs.add(q.height()); ws.add(q.width()); }
        Collections.sort(hs); Collections.sort(ws);
        float pad = 0.25f * Math.max(1, ws.get(ws.size() / 2));
        return new float[]{l - pad, r + pad, Math.max(1, hs.get(hs.size() / 2))};
    }

    // Əlyazma və sütundan kənar mətnlər nəzərə alınmır: yalnız 10011 sütununun içindəki çap sözlər oxunur.
    private void collectHits(Text t, ArrayList<Hit> hits, int pass, float yOff, float sc, float H, ArrayList<Float> lineHs) {
        if (t == null) return;
        final float[] col = columnRange(t);
        for (Text.TextBlock b : t.getTextBlocks())
            for (Text.Line ln : b.getLines()) {
                String u = ln.getText().toUpperCase();
                Rect r = ln.getBoundingBox();
                float medH = 0f;
                if (col != null) {
                    StringBuilder sb = new StringBuilder();
                    Rect un = null;
                    for (Text.Element el : ln.getElements()) {
                        Rect er = el.getBoundingBox();
                        if (er == null) continue;
                        float cx = er.centerX();
                        if (cx < col[0] || cx > col[1]) continue;      // sütundan kənardakı söz (əlyazma, qeyd) atılır
                        if (sb.length() > 0) sb.append(' ');
                        sb.append(el.getText().toUpperCase());
                        if (un == null) un = new Rect(er); else un.union(er);
                    }
                    if (un == null) continue;
                    u = sb.toString();
                    r = un;
                    medH = col[2];
                }
                ArrayList<String> ms = lineCodes(u);
                // Kod formatına uyğun gəlməyən adi mətn heç vaxt toplu siyahıya əlavə edilmir.
                // Yarımçıq namizədlər lineCodes/partialsIn daxilində ən azı 5 simvol şərtindən keçir.
                if (ms.isEmpty() || r == null) continue;
                // Yarımçıq oxunuşlar üçün: yazının hündürlüyü çap koduna uyğun olmalıdır (iri/əyri əlyazma atılır)
                if (medH > 0f) {
                    boolean hasFull = false;
                    for (String m : ms) if (!m.startsWith("~")) { hasFull = true; break; }
                    if (!hasFull && (r.height() > 2.2f * medH || r.height() < 0.35f * medH)) continue;
                }
                float y = (yOff + r.centerY() / sc) / H;          // şəkil hündürlüyünə nisbətdə mövqe
                lineHs.add(r.height() / sc / H);
                for (String m : ms) hits.add(new Hit(m, y, pass));
            }
    }

    private ArrayList<String> mergeHits(ArrayList<Hit> hits, ArrayList<Float> lineHs, ArrayList<Float> ysOut) {
        ArrayList<String> out = new ArrayList<>();
        if (hits.isEmpty()) return out;
        Collections.sort(lineHs);
        float tol = Math.max(0.004f, 0.5f * lineHs.get(lineHs.size() / 2));   // yarım sətir hündürlüyü: eyni cərgə
        Collections.sort(hits, (p, q) -> Float.compare(p.y, q.y));
        ArrayList<ArrayList<Hit>> groups = new ArrayList<>();
        ArrayList<Hit> cur = null;
        float curY = 0f;
        for (Hit h : hits) {
            boolean join = cur != null && Math.abs(h.y - curY) <= tol;
            if (join) for (Hit g : cur) if (g.pass == h.pass && !g.code.equals(h.code)) { join = false; break; }   // eyni keçiddə iki fərqli kod = iki cərgə
            if (!join) { cur = new ArrayList<>(); groups.add(cur); cur.add(h); curY = h.y; }
            else { cur.add(h); curY = (curY * (cur.size() - 1) + h.y) / cur.size(); }
        }
        ArrayList<Object[]> rows = new ArrayList<>();
        for (ArrayList<Hit> g : groups) {
            ArrayList<Hit> pool = new ArrayList<>();
            for (Hit a : g) if (!a.partial) pool.add(a);
            final boolean onlyPartial = pool.isEmpty();       // cərgədə heç bir keçiddə tam kod oxunmayıb
            if (onlyPartial) pool = g;
            String best = null;
            int bestVotes = -1, bestFirst = Integer.MAX_VALUE, bestLen = -1;
            for (Hit a : pool) {
                int votes = 0, first = Integer.MAX_VALUE;
                for (Hit b : pool) if (b.code.equals(a.code)) { votes++; first = Math.min(first, b.pass); }
                int len = a.code.length();
                boolean better = votes > bestVotes
                        || (votes == bestVotes && onlyPartial && len > bestLen)
                        || (votes == bestVotes && (!onlyPartial || len == bestLen) && first < bestFirst);
                if (better) { best = a.code; bestVotes = votes; bestFirst = first; bestLen = len; }
            }
            if (best != null) {
                float sy = 0f;
                for (Hit a : g) sy += a.y;
                rows.add(new Object[]{sy / g.size(), best});
            }
        }
        // Tam kodlu cərgənin yanında (eyni cərgənin başqa keçiddəki yarımçıq oxunuşu) yarımçıq kod ayrıca cərgə sayılmır
        ArrayList<Float> fullYs = new ArrayList<>();
        for (Object[] r : rows) if (!((String) r[1]).startsWith("~")) fullYs.add((Float) r[0]);
        for (int i = rows.size() - 1; i >= 0; i--) {
            if (!((String) rows.get(i)[1]).startsWith("~")) continue;
            float py = (Float) rows.get(i)[0];
            for (float fy : fullYs) if (Math.abs(fy - py) <= 1.5f * tol) { rows.remove(i); break; }
        }
        // Fotodakı ardıcıllıq: cərgələr yalnız şəkildəki mövqeyinə (yuxarıdan aşağı) görə düzülür
        Collections.sort(rows, (p, q) -> Float.compare((Float) p[0], (Float) q[0]));
        for (Object[] r : rows) { out.add((String) r[1]); ysOut.add((Float) r[0]); }
        return out;
    }

    // Yalnız 10011 sütununa aid qutular (başqa sütundan təsadüfi uyğunluqlar atılır)
    private ArrayList<Rect> codeBoxes(Text t) {
        ArrayList<Rect> rs = new ArrayList<>();
        for (Text.TextBlock b : t.getTextBlocks())
            for (Text.Line ln : b.getLines())
                for (Text.Element el : ln.getElements()) {
                    Rect r = el.getBoundingBox();
                    if (r != null && OCR_CODE.matcher(el.getText().toUpperCase()).find()) rs.add(r);
                }
        if (rs.size() < 2) {          // kod bir neçə sözə bölünübsə sətir qutularına bax
            rs.clear();
            for (Text.TextBlock b : t.getTextBlocks())
                for (Text.Line ln : b.getLines()) {
                    Rect r = ln.getBoundingBox();
                    String u = ln.getText().toUpperCase();
                    if (r != null && (OCR_CODE.matcher(u).find() || OCR_CODE.matcher(u.replaceAll("\\s+", "")).find())) rs.add(r);
                }
        }
        ArrayList<Rect> out = new ArrayList<>();
        if (rs.size() < 2) return out;
        ArrayList<Integer> ls = new ArrayList<>(), ws = new ArrayList<>();
        for (Rect r : rs) { ls.add(r.left); ws.add(r.width()); }
        Collections.sort(ls); Collections.sort(ws);
        int medL = ls.get(ls.size() / 2), medW = Math.max(1, ws.get(ws.size() / 2));
        for (Rect r : rs) if (Math.abs(r.left - medL) <= 0.6f * medW) out.add(r);
        return out;
    }

    private Bitmap cropColumn(Bitmap bmp, Text t, float[] info) {
        ArrayList<Rect> bx = codeBoxes(t);
        int n = bx.size();
        if (n < 2) return null;
        int l = Integer.MAX_VALUE, r = Integer.MIN_VALUE, top = Integer.MAX_VALUE, bot = Integer.MIN_VALUE;
        ArrayList<Integer> hs = new ArrayList<>(), ws = new ArrayList<>();
        for (Rect q : bx) {
            l = Math.min(l, q.left); r = Math.max(r, q.right);
            top = Math.min(top, q.top); bot = Math.max(bot, q.bottom);
            hs.add(q.height()); ws.add(q.width());
        }
        Collections.sort(hs); Collections.sort(ws);
        int medH = Math.max(6, hs.get(n / 2)), medW = Math.max(1, ws.get(n / 2));
        int pad = Math.max(8, medW / 8);
        int x = Math.max(0, l - pad), x2 = Math.min(bmp.getWidth(), r + pad);
        if (x2 - x > 0.9f * bmp.getWidth()) { x = 0; x2 = bmp.getWidth(); }
        int w = x2 - x;
        int y = Math.max(0, top - medH), y2 = Math.min(bmp.getHeight(), bot + medH);
        int h = y2 - y;
        if (w < 20 || h < 20) return null;
        Bitmap c = Bitmap.createBitmap(bmp, x, y, w, h);
        float sc = Math.min(4f, Math.min(1400f / w, 4096f / h));   // yaddaş/ML Kit həddinə qədər maksimum yaxınlaşdırma
        if (sc > 1.1f) c = Bitmap.createScaledBitmap(c, Math.round(w * sc), Math.round(h * sc), true);
        info[0] = y;                                  // kəsilmiş hissənin şəkildəki yuxarı mövqeyi
        info[1] = (float) c.getHeight() / h;          // şaquli miqyas
        return c;
    }

    private void ocrImgDone(TextRecognizer rec, ArrayList<String> s, int idx,
                            ArrayList<ArrayList<String>> res, int[] left) {
        res.set(idx, s);
        if (--left[0] > 0) return;
        ArrayList<String> found = new ArrayList<>();
        for (ArrayList<String> x : res) if (x != null) found.addAll(x);   // indeks sırası = seçilmə sırası
        ocrFinish(rec, found);
    }

    // Kameradan çəkilən müvəqqəti şəkillər (cache/ocr) oxunandan sonra silinir.
    // Qalereyadan seçilən şəkillərə toxunulmur.
    private void clearOcrCache() {
        try {
            File[] fs = new File(getCacheDir(), "ocr").listFiles();
            if (fs != null) for (File f : fs) f.delete();
        } catch (Exception ignored) { }
        cameraUri = null;
    }

    private void ocrFinish(TextRecognizer rec, ArrayList<String> found) {
        clearOcrCache();
        if (found.isEmpty()) {
            toast("Şəkildə kod tapılmadı");
            return;
        }
        ui.evaluateJavascript("window.addOcrCodes(" + JSONObject.quote(String.join("\n", found)) + ");", null);
    }

    private static float centerY(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.centerY();
    }

    private static int left(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.left;
    }

    // Bir sətirdəki bütün 10011 kodları: tam kodlar + yarımçıq/oxunmayanlar ("~" + oxunan mətn).
    // Dublikatlar silinmir, heç bir 10011 itmir.
    private ArrayList<String> lineCodes(String u) {
        ArrayList<String> out = matchesIn(u);
        if (out.isEmpty()) {
            ArrayList<String> sp = matchesIn(u.replaceAll("\\s+", ""));   // kod boşluqla bölünüb
            if (!sp.isEmpty()) return sp;
        }
        out.addAll(partialsIn(u));
        return out;
    }

    private static final String[] PRE_SETS = {"1IL|!", "0OQD", "0OQD", "1IL|!", "1IL|!"};

    private static int preScore(String t) {
        int n = Math.min(5, t.length()), sc = 0;
        for (int i = 0; i < n; i++) if (PRE_SETS[i].indexOf(t.charAt(i)) >= 0) sc++;
        return sc;
    }

    // Tam koda çevrilməyən, amma 10011-ə bənzəyən sözlər: yarımçıq (7 simvoldan az/çox), pozulmuş prefiks və s.
    private ArrayList<String> partialsIn(String u) {
        ArrayList<String> out = new ArrayList<>();
        String[] tk = u.trim().split("\\s+");
        for (int i = 0; i < tk.length; i++) {
            if (tk[i].matches("[0-9]+[.,:/-][0-9]+.*")) continue;   // məbləğ, tarix və s. rəqəm formatları kod deyil
            String t = tk[i].replaceAll("[^A-Z0-9|!]", "");
            if (t.length() < 5) continue;
            if (OCR_CODE.matcher(t).find()) continue;             // tam kod artıq götürülüb
            if (preScore(t) < 4) continue;                         // 10011-ə kifayət qədər bənzəmir
            String cand = t;
            if (cand.length() == 5 && preScore(cand) == 5 && i + 1 < tk.length) {   // "10011 ABC12": prefiks ayrı sözdədirsə növbəti söz birləşir
                String nx = tk[i + 1].replaceAll("[^A-Z0-9|!]", "");
                if (nx.length() >= 2 && nx.length() <= 7 && nx.matches(".*[0-9].*") && !tk[i + 1].matches("[0-9]+[.,:/-][0-9]+.*") && !OCR_CODE.matcher(nx).find()) { cand = cand + nx; i++; }
            }
            if (cand.length() >= 5 && preScore(cand) == 5) cand = "10011" + fixOcrTail(cand.substring(5));
            out.add("~" + cand);
        }
        return out;
    }


    private ArrayList<String> matchesIn(String s) {
        ArrayList<String> out = new ArrayList<>();
        java.util.regex.Matcher m = OCR_CODE.matcher(s);
        while (m.find()) {
            String tail = m.group(1);
            if (tail.length() == 8) {
                // OCR bəzən "H" hərfini "II" kimi oxuyur (10011HEX1150 -> 10011IIEX1150): kod bir simvol uzanır.
                // Hərf hissəsində (ilk 3 simvol) yanaşı iki I/1/L varsa onlar "H" ilə əvəz olunur, sondakı simvol itmir.
                String merged = null;
                for (int i = 0; i < 3 && merged == null; i++) {
                    if (isIlike(tail.charAt(i)) && isIlike(tail.charAt(i + 1)))
                        merged = tail.substring(0, i) + "H" + tail.substring(i + 2);
                }
                tail = merged != null ? merged : tail.substring(0, 7);
            }
            out.add("10011" + fixOcrTail(tail));
        }
        return out;
    }

    private static boolean isIlike(char c) { return c == 'I' || c == '1' || c == 'L' || c == '|' || c == '!'; }

    // Koddakı 7 simvolun qaydası: 6-8-ci simvollar (tail[0..2]) hərf, 9-12-ci simvollar (tail[3..6]) rəqəmdir.
    // Hərf yerində: 0 -> O, 1/|/! -> I   (O, Q və digər hərflər olduğu kimi qalır)
    // Rəqəm yerində: O/Q/D -> 0, I/L/|/! -> 1, S -> 5
    private static String fixOcrTail(String t) {
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (i < 3) {
                if (c == '0') c = 'O';
                else if (c == '1' || c == '|' || c == '!') c = 'I';
            } else {
                if (c == 'O' || c == 'Q' || c == 'D') c = '0';
                else if (c == 'I' || c == 'L' || c == '|' || c == '!') c = '1';
                else if (c == 'S') c = '5';
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private interface ProgressCb { void on(int percent); }
    private int loadLimit() { return LOAD_LIMIT_MS; }
    private int variantLimit() { return VARIANT_LIMIT_MS; }

    // Səhifə (YVÖK xanası) hazırdır: gözləyən kod dərhal yazılır
    private void markReady(Worker w) {
        w.loaded = true;
        w.errs = 0;
        ebelDownUntil = 0;                     // e-belediyye açılır: ehtiyat mənbə lazım deyil
        if (w.pending != null) {
            String p = w.pending;
            w.pending = null;
            runFill(w, p);
        }
    }

    // Əsas səhifə açılmadı (şəbəkə / SSL / 5xx / 429): xəta səhifəsi "hazır" sayılmır, gecikmə artırılaraq təkrar yüklənir
    private void pageError(final Worker w, final WebView wv) {
        if (w.wv != wv) return;
        w.error = true;
        w.loaded = false;
        long delay = Math.min(800L + 700L * w.errs, 5000L);
        w.errs++;
        wv.postDelayed(() -> {
            if (w.wv == wv && w.error) { wv.stopLoading(); wv.loadUrl(EBEL_URL); }
        }, delay);
    }

    private Worker createWorker(boolean batch) {
        final Worker w = new Worker();
        if (batch) pool.add(w);
        attachWebView(w);
        return w;
    }

    // Şəkil, şrift, video, fayl, ikon, reklam və izləmə sorğuları boş cavabla əvəz olunur (ortaq filtr: SiteBlocker)
    private static WebResourceResponse blockHeavy(WebResourceRequest r) {
        return SiteBlocker.intercept(r);
    }

    private void attachWebView(final Worker w) {
        final WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.WHITE);
        wv.setFocusable(false);                       // klaviaturanı/fokusu oğurlamasın
        wv.setFocusableInTouchMode(false);
        // ui-nin ARXASINA (index 0) əlavə olunur: tam ölçüdə layout alır, amma görünmür
        root.addView(wv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupCommon(wv);
        // Səhifənin əksəriyyəti yüklənən kimi (65%) YVÖK yazılır: yavaş şəkil/izləmə sorğularını gözləmirik
        wv.setTag((ProgressCb) p -> { if (p >= 65 && w.wv == wv && !w.loaded && !w.error) markReady(w); });
        wv.getSettings().setLoadsImagesAutomatically(false);   // gizli səhifədə şəkil lazım deyil: daha tez açılır
        wv.getSettings().setBlockNetworkImage(true);
        wv.getSettings().setMediaPlaybackRequiresUserGesture(true);
        wv.getSettings().setSupportMultipleWindows(false);
        wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        wv.getSettings().setGeolocationEnabled(false);
        w.wv = wv;
        w.loaded = false;
        w.error = false;
        wv.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void result(final String code, final String name, final String debt) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelResult(w, code, name, debt); });
            }

            @JavascriptInterface
            public void fail(final String code, final String reason) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelFail(w, code, reason); });
            }

            // sayt cavab vermədi (saytın "tapılmadı" cavabı deyil): ilkin kod təzə səhifədə cavab gələnə qədər təkrar yoxlanılır
            @JavascriptInterface
            public void retry(final String code, final String reason) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelRetry(w, code); });
            }
        }, "AndroidEbel");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return blockHeavy(r);     // yalnız YVÖK xanası, Yoxla düyməsi və nəticə üçün lazım olanlar yüklənir
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                if (w.wv == wv) { w.loaded = false; w.error = false; }     // yeni yükləmə başlayıb: köhnə "hazırdır" siqnalı keçərsiz
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (w.wv != wv) return;
                v.clearHistory();                      // hər təzələmə tarixçəni şişirtməsin
                if (w.error) return;                   // xəta səhifəsi: təkrar yükləmə artıq planlaşıb
                if (!w.loaded) markReady(w);
                else { w.errs = 0; ebelDownUntil = 0; }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r == null || !r.isForMainFrame()) return;
                pageError(w, wv);
            }

            @Override
            public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse resp) {
                if (r == null || !r.isForMainFrame() || resp == null) return;
                int sc = resp.getStatusCode();
                if (sc >= 500 || sc == 429 || sc == 408) pageError(w, wv);
            }

            @Override
            public void onReceivedSslError(WebView v, android.webkit.SslErrorHandler handler, android.net.http.SslError err) {
                handler.cancel();                      // təhlükəsizlik: sertifikat xətası qəbul edilmir, yalnız təkrar cəhd olunur
                pageError(w, wv);
            }
        });
        wv.loadUrl(EBEL_URL);
    }

    // Köhnə WebView tam məhv edilir, yenisi açılır (uzun işləyəndə yaddaş və yavaşlıq yığılmasın)
    private void rebuild(Worker w) {
        WebView old = w.wv;
        old.removeCallbacks(w.watchdog);
        w.wv = null;
        old.stopLoading();
        old.setWebViewClient(new WebViewClient());
        root.removeView(old);
        old.destroy();
        w.jobs = 0;
        w.current = null;
        w.pending = null;
        attachWebView(w);
    }

    // Səhifəni təzədən yüklə: hər kod TƏMİZ səhifədə yoxlanılır, əvvəlki sorğunun vəziyyəti qalmır
    private void recycle(Worker w) {
        if (w.current != null && ++w.jobs >= MAX_JOBS_PER_VIEW) { rebuild(w); return; }
        w.wv.removeCallbacks(w.watchdog);
        w.current = null;
        w.pending = null;
        w.loaded = false;
        w.wv.stopLoading();
        w.wv.loadUrl(EBEL_URL);
    }

    private void start(Worker w, Job j) {
        // Seçilmiş yoxlama mənbəyi: e-belediyye standartdır; Avto uğursuzluqda hesab.az-a keçir.
        if ("hesab".equals(modeOf(j))) { w.current = null; fallbackOrFail(j, "Məlumat tapılmadı"); return; }
        w.current = j;
        srcTag(j, "e-belediyye");
        w.wv.removeCallbacks(w.watchdog);
        if (w.loaded) {
            runFill(w, j.code);                          // 5 san sayğacı runFill-də başlayır
        } else {
            w.pending = j.code;                          // səhifə hələ açılır: sayğac açılandan sonra başlayacaq
            w.wv.postDelayed(w.watchdog, PAGE_GUARD_MS);
        }
    }

    private Worker pickBatchWorker() {
        int active = 0;
        for (Worker w : pool) if (w.current != null) active++;
        for (Worker w : pool) if (w.current == null && w.loaded) return w;
        for (Worker w : pool) if (w.current == null) return w;
        if (pool.size() < maxWorkers) return createWorker(true);
        return null;
    }

    // ---- Toplu yoxlama: dörd mənbə (e-belediyye, yelo.az, hesab.az, portmanat.az) arasında yük bölüşdürmə ----
    private static final int SRC_E = 0, SRC_Y = 1, SRC_H = 2, SRC_P = 3;
    private static final int YELO_BATCH_PAR = 5;          // yelo.az-da eyni anda işləyən səhifə (əvvəl 8: yükün bir hissəsi portmanat.az-a verildi)
    private static final int PORT_BATCH_PAR = 5;          // portmanat.az: 4 paralel səhifə; yüklənmə hazır olana qədər sorğular növbədə gözləyir
    private static final int HESAB_BATCH_PAR = 3;         // hesab.az-da eyni anda işləyən səhifə
    private static final int EBEL_BATCH_PAR = 3;          // e-belediyye-də eyni anda işləyən səhifə (Bələdiyyə bazası ilə eyni: Yelo 5, Portmanat 4, e-belediyye 3, hesab.az 2)
    private static final int EBEL_BIT = 8;                // Job.extTried: e-belediyye bu kod üçün sınanıb
    private static final long EXT_WAIT_MS = 15000;        // xarici mənbə bir kod üçün bu qədər cavab verməsə kod digər mənbəyə keçir
    private static final long EXT_PROBE_MS = 10000;      // dayanmış mənbə hər 10 san bir kodla yenidən yoxlanılır; cavab verən kimi pay bərpa olunur
    private static final long EXT_DOWN_MS = 300000;        // 3 ardıcıl uğursuzluqdan sonra mənbə bu müddət "dayanıb" sayılır
    private YeloChecker yeloBatch;
    private final java.util.HashSet<String> extActive = new java.util.HashSet<>();
    private int extRr = 0;
    private int yeloFails = 0, hesabFails = 0, portFails = 0;
    private long yeloDownUntil = 0, hesabDownUntil = 0, portDownUntil = 0;
    private final long[] probeAt = new long[4];
    private final boolean[] probing = new boolean[4];       // dayanmış mənbədə hazırda yoxlama kodu işləyir (eyni anda yalnız biri)
    private int lastMask = 15;
    private long downUntilOf(int s) { return s == SRC_Y ? yeloDownUntil : (s == SRC_H ? hesabDownUntil : (s == SRC_P ? portDownUntil : ebelDownUntil)); }
    private void setDownUntil(int s, long v) { if (s == SRC_Y) yeloDownUntil = v; else if (s == SRC_H) hesabDownUntil = v; else if (s == SRC_P) portDownUntil = v; else ebelDownUntil = v; }
    private boolean hardDown(int s) { return now() < downUntilOf(s); }
    /** mənbə işləyir; ya da dayanıb, amma yoxlama vaxtı çatıb və hazırda yoxlayan kod yoxdur */
    private boolean usable(int s) { return !hardDown(s) || (now() >= probeAt[s] && !probing[s]); }
    private PortmanatChecker portBatch;

    private PortmanatChecker portBatch() {
        if (portBatch == null) {
            portBatch = new PortmanatChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, PORT_BATCH_PAR);
            portBatch.setMaxWait(25000);   // ehtiyat mənbə: gec cavabda digər mənbəyə keçid sürətlənsin
            portBatch.arm();               // YVÖK xanasındakı kimi: səhifələr öncədən açılır, hər istifadədən sonra təzəsi hazırlanır
        }
        return portBatch;
    }

    /** Pay (çəki) işləyən mənbələrin sayına görə: 4 işləyir -> Yelo 30 / Portmanat 30 / e-bələdiyyə 20 / hesab.az 20; 3 -> Yelo 40 / Portmanat 40 / digəri 20; 2 -> 50 / 50; 1 -> 100. mask: işləyən mənbələrin bitləri. Dayanmış mənbə (yalnız yoxlama kodu) çəki 1 alır. */
    private static double wFor(int s, int mask) {
        if ((mask & (1 << s)) == 0) return 1;
        int n = Integer.bitCount(mask);
        boolean yp = (mask & (1 << SRC_Y)) != 0 && (mask & (1 << SRC_P)) != 0;
        boolean isYP = s == SRC_Y || s == SRC_P;
        if (n >= 4) return isYP ? 30 : 20;
        if (n == 3) return yp ? (isYP ? 40 : 20) : (isYP ? 40 : 30);
        if (n == 2) return 50;
        return 100;
    }
    private final int[] asg = new int[4];   // hər mənbəyə hazırda verilmiş (uğursuz olub geri qaytarılmayan) kod sayı
    private static int bitOf(int s) { return s == SRC_Y ? 1 : (s == SRC_H ? 2 : 4); }
    private boolean yeloOkFor(Job j) { return (j.extTried & 1) == 0 && usable(SRC_Y) && yeloBatch().load() < YELO_BATCH_PAR; }
    private boolean hesabOkFor(Job j) { return (j.extTried & 2) == 0 && usable(SRC_H) && hesabBatch().load() < HESAB_BATCH_PAR; }
    private boolean portOkFor(Job j) { return (j.extTried & 4) == 0 && usable(SRC_P) && portBatch().load() < PORT_BATCH_PAR; }

    private HesabChecker hesabBatch() {
        if (hesab == null) {
            hesab = new HesabChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, HESAB_BATCH_PAR);
            hesab.setMaxWait(EXT_WAIT_MS);
        }
        return hesab;
    }

    private int ebelBusy() {
        int n = 0;
        for (Worker w : pool) if (w.current != null) n++;
        return n;
    }

    private YeloChecker yeloBatch() {
        if (yeloBatch == null) {
            yeloBatch = new YeloChecker(this, root, 0, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, YELO_BATCH_PAR);
            yeloBatch.setMaxWait(EXT_WAIT_MS);
        }
        return yeloBatch;
    }

    /** çəkilər: yelo.az 3, hesab.az 3, portmanat.az 2, e-belediyye 1 (yelo.az-ın əvvəlki 5 payı yelo.az 3 + portmanat.az 2 oldu); uyğun saytlar arasında çəkiyə görə növbə ilə */
    private int wpick(ArrayList<Integer> c) {
        int mask = (hardDown(SRC_E) ? 0 : 1 << SRC_E) | (hardDown(SRC_Y) ? 0 : 1 << SRC_Y) | (hardDown(SRC_H) ? 0 : 1 << SRC_H) | (hardDown(SRC_P) ? 0 : 1 << SRC_P);
        if (mask != lastMask) { lastMask = mask; java.util.Arrays.fill(asg, 0); }   // işləyən mənbələrin tərkibi dəyişdi: pay yenidən hesablanır
        int best = c.get(0); double bv = Double.MAX_VALUE;
        for (int s : c) { double v = asg[s] / wFor(s, mask); if (v < bv) { bv = v; best = s; } }   // hədəf payına ən çox geri qalan mənbə
        return best;
    }

    private static long now() { return android.os.SystemClock.elapsedRealtime(); }

    // ---- Bitmiş kodlar: gec gələn cavab artıq bitmiş kodu dəyişmir ------------------------------------------------
    private final java.util.HashSet<String> resolvedCodes = new java.util.HashSet<>();   // bu yoxlamada nəticəsi (və ya xətası) göndərilmiş kodlar
    private final java.util.HashMap<String, long[]> inflight = new java.util.HashMap<>(); // kod -> {mənbəyə verilmə vaxtı, mənbə}

    /** Kod ilk dəfə bitəndə true; artıq bitibsə false */
    private boolean claimBatch(String orig) {
        inflight.remove(orig);
        return resolvedCodes.add(orig);
    }

    private void resetBatchState() { resolvedCodes.clear(); inflight.clear(); }

    /** Son 1-3 YVÖK: gözləyən + hazırda yoxlanılan kodların cəmi 3 və ya azdır (pick zamanı baxılan kod da gözləyənlərdədir) */
    private boolean batchTail() {
        return batchJobs.size() + extActive.size() + ebelBusy() <= 3;
    }

    /** Növbənin sonu (gözləyən 1-2 kod qalıb): hesab.az yavaş cavab verdiyi üçün bu kodlar ona verilmir, digər 3 mənbədən birinə gedir.
     *  İstisna: kod həmin 3 mənbənin hamısında sınanıbsa və ya hamısı dayanıbsa, hesab.az ehtiyat kimi qalır. */
    private boolean skipHesabAtTail(Job j) {
        if (!batchTail()) return false;
        int others = bitOf(SRC_Y) | bitOf(SRC_P) | EBEL_BIT;
        if ((j.extTried & others) == others) return false;
        return !(hardDown(SRC_Y) && hardDown(SRC_P) && ebelDown());
    }

    /** yalnız yelo.az / hesab.az / portmanat.az arasından (e-belediyye daxil deyil): sağlam və boş yeri olan mənbələr növbə ilə; yoxdursa -1 */
    private int pickExtOnly(Job j) {
        if (j.grp != null) return -1;                         // variant (təxmin) kodlar yalnız e-belediyyedə
        ArrayList<Integer> c = new ArrayList<>(3);
        if (yeloOkFor(j)) c.add(SRC_Y);
        if (hesabOkFor(j) && !skipHesabAtTail(j)) c.add(SRC_H);
        if (portOkFor(j)) c.add(SRC_P);
        return c.isEmpty() ? -1 : wpick(c);
    }

    /** SRC_E / SRC_Y / SRC_H / SRC_P; -1: uyğun mənbələr məşğuldur (gözlə); -2: bütün mənbələr bu kod üçün sınanıb */
    private int pickBatchSource(Job j) {
        if (j.grp != null) return now() >= yeloDownUntil ? SRC_Y : SRC_E;   // variant (təxmin) kodlar yelo.az-da yoxlanılır; yelo.az dayanıbsa e-belediyyedə
        if (isCombo(j)) {                                       // hərf kombinasiyası ola bilən kod: yalnız yelo.az
            if (usable(SRC_Y)) return (j.extTried & 1) == 0 && yeloBatch().load() < YELO_BATCH_PAR ? SRC_Y : -1;
            return (j.extTried & EBEL_BIT) == 0 && !ebelDown() ? SRC_E : -1;   // yelo.az dayanıb: dayanma bitənə qədər e-belediyye
        }
        if (batchTail()) {                                      // son 1-3 YVÖK: hamısı bir sayta yığılmır, ən az məşğul mənbəyə (yelo.az / portmanat.az / e-belediyye) bölüşdürülür; hesab.az gözlənilmir
            int best = -1, bu = Integer.MAX_VALUE;
            if (yeloOkFor(j)) { int u = yeloBatch().load(); if (u < bu) { bu = u; best = SRC_Y; } }
            if (portOkFor(j)) { int u = portBatch().load(); if (u < bu) { bu = u; best = SRC_P; } }
            if ((j.extTried & EBEL_BIT) == 0 && !ebelDown() && ebelBusy() < EBEL_BATCH_PAR) { int u = ebelBusy(); if (u < bu) { bu = u; best = SRC_E; } }
            if (best >= 0) return best;
        }
        ArrayList<Integer> c = new ArrayList<>(4);
        if ((j.extTried & EBEL_BIT) == 0 && !ebelDown() && ebelBusy() < EBEL_BATCH_PAR) c.add(SRC_E);
        if (yeloOkFor(j)) c.add(SRC_Y);
        if (hesabOkFor(j) && !skipHesabAtTail(j)) c.add(SRC_H);
        if (portOkFor(j)) c.add(SRC_P);
        if (!c.isEmpty()) return wpick(c);
        return (j.extTried & 15) == 15 ? -2 : -1;
    }

    /** Toplu yoxlama: kodun hansı saytda yoxlandığı nəticə qutusunun sağ küncündə göstərilir */
    private void srcTag(Job j, String src) {
        if (j == null || !j.batch) return;
        if (j.grp == null) {                                   // eyni mənbədə təkrar cəhd gözləmə vaxtını sıfırlamır; yalnız mənbə dəyişəndə
            long sid = "yelo.az".equals(src) ? SRC_Y : ("portmanat.az".equals(src) ? SRC_P : ("hesab.az".equals(src) ? SRC_H : SRC_E));
            long[] cur = inflight.get(j.orig);
            if (cur == null || cur[1] != sid) inflight.put(j.orig, new long[]{now(), sid});
        }
        ui.evaluateJavascript("window.setBatchSource&&window.setBatchSource(" + JSONObject.quote(j.orig) + "," + JSONObject.quote(src) + ");", null);
    }

    /** Kodda qarışa bilən simvol (0/O/Q/D, 1/I/L, 5/S, II/H) varsa, onun hərf kombinasiyaları (variantları) ola bilər */
    private boolean isCombo(Job j) {
        if (j.combo == null) j.combo = !buildVariants(j.orig).isEmpty();
        return j.combo;
    }

    /** Kombinasiyaları (variantları) növbənin əvvəlinə qoyur; yelo.az-da paralel yoxlanılır. Variant yoxdursa false */
    private boolean queueVariants(Job j) {
        if (j.variants == null) j.variants = buildVariants(j.orig);
        if (j.variants.isEmpty()) return false;
        Group ng = new Group(j);
        ArrayList<Job> vs = new ArrayList<>();
        String next;
        while ((next = j.variants.pollFirst()) != null) {
            Job vj = new Job(next, j);
            vj.variants = new ArrayDeque<>();
            vj.grp = ng;
            vs.add(vj);
        }
        ng.left = vs.size();
        for (int i = vs.size() - 1; i >= 0; i--) batchJobs.addFirst(vs.get(i));
        return true;
    }

    /** Mənbə cavab verdi, lakin “tapılmadı” dedi: mənbə sağlamdır; kod başqa mənbəyə verilmir.
     *  Kombinasiyası olan kod yelo.az-da variantları ilə yoxlanılır, qalanı dərhal “Məlumat tapılmadı” olur. */
    private void extNotFound(Job j, int src) {
        if (!extActive.remove(j.orig)) return;               // “Dayandır” basılıb
        probing[src] = false;
        if (src == SRC_Y) { yeloFails = 0; yeloDownUntil = 0; }
        else if (src == SRC_P) { portFails = 0; portDownUntil = 0; }
        else { hesabFails = 0; hesabDownUntil = 0; }
        if (j.grp == null && src == SRC_Y && isCombo(j) && queueVariants(j)) { pumpBatch(); return; }
        failJob(j, "Məlumat tapılmadı");
        pumpBatch();
    }

    private void startExternal(final Job j, final int src) {
        if (j.grp == null && src >= 0 && src < 4) asg[src]++;
        if (src >= 0 && src < 4 && hardDown(src)) probing[src] = true;   // dayanmış mənbə: bu kod yoxlama kodudur
        srcTag(j, src == SRC_Y ? "yelo.az" : (src == SRC_P ? "portmanat.az" : "hesab.az"));
        extActive.add(j.orig);
        final YeloChecker.Callback yc = new YeloChecker.Callback() {
            @Override public void onResult(String name, String debt) { extDone(j, SRC_Y, name, debt); }
            @Override public void onFail() { extDone(j, SRC_Y, null, null); }
            @Override public void onNotFound() { extNotFound(j, SRC_Y); }
        };
        if (src == SRC_Y) {
            yeloBatch().check(j.orig, yc);
        } else if (src == SRC_P) {
            portBatch().check(j.orig, new PortmanatChecker.Callback() {
                @Override public void onResult(String name, String debt) { extDone(j, SRC_P, name, debt); }
                @Override public void onFail() { extDone(j, SRC_P, null, null); }
                @Override public void onNotFound() { extNotFound(j, SRC_P); }
            });
        } else {
            hesabBatch().check(j.orig, new HesabChecker.Callback() {
                @Override public void onResult(String name, String debt) { extDone(j, SRC_H, name, debt); }
                @Override public void onFail() { extDone(j, SRC_H, null, null); }
                @Override public void onNotFound() { extNotFound(j, SRC_H); }
            });
        }
    }

    /** Variant (təxmin) kodu yelo.az-da yoxlayır: ilk düzgün nəticə qrupu bitirir, qalan variantlar ləğv olunur; hamısı uğursuzdursa "Məlumat tapılmadı" */
    private void startVariantYelo(final Job j) {
        final Group g = j.grp;
        if (g == null || g.done) { pumpBatch(); return; }
        srcTag(j, "yelo.az");
        yeloBatch().check(j.code, new YeloChecker.Callback() {
            @Override public void onResult(String name, String debt) {
                if (g.done) { pumpBatch(); return; }
                String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
                String d = debt == null ? "" : debt.trim();
                if (!nameOk(n) || !DEBT_OK.matcher(d).matches()) { variantYeloFail(g); return; }
                g.done = true;
                for (java.util.Iterator<Job> it = batchJobs.iterator(); it.hasNext(); ) if (it.next().grp == g) it.remove();
                claimBatch(j.orig); ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.orig) + ","
                        + JSONObject.quote(n) + "," + JSONObject.quote(d) + "," + JSONObject.quote(j.code) + ");", null);
                pumpBatch();
            }
            @Override public void onFail() {
                if (g.done) { pumpBatch(); return; }
                variantYeloFail(g);
            }
        });
    }

    private void variantYeloFail(Group g) {
        if (!g.done && --g.left <= 0) { g.done = true; fallbackOrFail(g.root, "Məlumat tapılmadı"); }
        pumpBatch();
    }

    private void extDone(Job j, int src, String name, String debt) {
        if (!extActive.remove(j.orig)) return;               // "Dayandır" basılıb
        String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        String d = debt == null ? "" : debt.trim();
        boolean ok = name != null && nameOk(n) && DEBT_OK.matcher(d).matches();
        if (ok) {
            probing[src] = false;
            if (src == SRC_Y) { yeloFails = 0; yeloDownUntil = 0; }
            else if (src == SRC_P) { portFails = 0; portDownUntil = 0; }
            else { hesabFails = 0; hesabDownUntil = 0; }
            claimBatch(j.orig); ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + "," + JSONObject.quote(j.orig) + ");", null);
        } else {
            if (probing[src]) {                                  // yoxlama kodu da cavab almadı: mənbə dayanmış qalır, 10 san sonra yenə yoxlanılır
                probing[src] = false;
                setDownUntil(src, now() + EXT_DOWN_MS); probeAt[src] = now() + EXT_PROBE_MS;
            } else {
                int f = src == SRC_Y ? ++yeloFails : (src == SRC_P ? ++portFails : ++hesabFails);
                if (f >= 3) {
                    if (src == SRC_Y) yeloFails = 0; else if (src == SRC_P) portFails = 0; else hesabFails = 0;
                    setDownUntil(src, now() + EXT_DOWN_MS); probeAt[src] = now() + EXT_PROBE_MS;
                }
            }
            if (j.grp == null && src == SRC_Y && isCombo(j)) {   // kombinasiyası olan kod yalnız yelo.az-da yoxlanılır: mənbə dəyişmir
                if (!queueVariants(j)) failJob(j, "Məlumat tapılmadı");
            } else {
                if (j.grp == null && asg[src] > 0) asg[src]--;   // uğursuz mənbənin payı geri qaytarılır
                j.extTried |= bitOf(src);             // texniki cavabsızlıq: bu mənbə bu kod üçün bir daha sınanmır, kod digər mənbəyə qayıdır
                batchJobs.addFirst(j);
            }
        }
        pumpBatch();
    }

    private static final long TAIL_HESAB_WAIT_MS = 5000;   // növbənin sonunda hesab.az bir cəhd üçün gözləmə həddi
    private static final long TAIL_EXT_WAIT_MS = 8000;   // növbənin sonunda (gözləyən kod qalmayıb) yelo.az / portmanat.az-da bir cəhd üçün gözləmə həddi
    private static final long PORT_TAIL_WAIT_MS = TAIL_EXT_WAIT_MS;   // növbənin sonunda (gözləyən kod qalmayıb) portmanat.az-a bir cəhd üçün gözləmə həddi

    private void pumpBatch() {
        pumpBatchInner();
        // Sonuncu 1-2 kod ilişəndə bütün növbə uzun gözləməsin: növbə boşalanda cəhd vaxtı qısalır (3 cəhd × 12 san), doluyanda əvvəlki 25 san qaytarılır
        try {
            boolean tail = batchTail();
            portBatch().setMaxWait(tail ? PORT_TAIL_WAIT_MS : 25000);
            if (yeloBatch != null) yeloBatch.setMaxWait(tail ? TAIL_EXT_WAIT_MS : EXT_WAIT_MS);
            if (hesab != null) hesab.setMaxWait(tail ? TAIL_HESAB_WAIT_MS : EXT_WAIT_MS);   // son kodlarda hesab.az cavabı gözlənilmir: 5 san-dən sonra kod digər mənbəyə keçir
        } catch (Exception ignored) { }
    }

    private void pumpBatchInner() {
        boolean again = true;
        while (again && !batchJobs.isEmpty()) {
            again = false;
            for (java.util.Iterator<Job> it = batchJobs.iterator(); it.hasNext(); ) {
                Job j = it.next();
                if (resolvedCodes.contains(j.orig)) { it.remove(); again = true; break; }   // kod artıq bitib (paralel yoxlama ilə)
                int src = pickBatchSource(j);
                if (src == -2) { it.remove(); failJob(j, "Məlumat tapılmadı"); again = true; break; }   // bütün mənbələr sınanıb: növbəni dayandırma
                if (src < 0) continue;                                                                 // bu kodun mənbələri məşğuldur: növbədəki digərinə bax
                if (src != SRC_E) { it.remove(); if (j.grp != null) startVariantYelo(j); else startExternal(j, src); again = true; break; }
                Worker w = pickBatchWorker();
                if (w == null) {                                    // e-belediyye işçiləri məşğuldur: yük xarici mənbələrə verilir
                    int alt = pickExtOnly(j);
                    if (alt < 0) continue;
                    it.remove(); startExternal(j, alt); again = true; break;
                }
                it.remove(); if (j.grp == null) asg[SRC_E]++; start(w, j); again = true; break;
            }
        }
    }


    private void runFill(Worker w, String value) {
        w.wv.removeCallbacks(w.watchdog);
        final boolean isVariant = w.current != null && !w.current.code.equals(w.current.orig);
        w.wv.postDelayed(w.watchdog, isVariant ? variantLimit() : loadLimit());
        w.wv.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    private void onEbelResult(Worker w, String code, String name, String debt) {
        Job j = w.current;
        if (j == null || code == null || !j.code.equals(code)) return;   // köhnə/yad nəticə
        final String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        final String d = debt == null ? "" : debt.trim();
        final Group g = j.grp;
        if (g != null) {
            if (g.done) { recycle(w); pumpBatch(); return; }      // başqa variant artıq qazanıb
            if (nameOk(n) && DEBT_OK.matcher(d).matches()) {
                g.done = true;                                      // qalan variantları ləğv et
                for (java.util.Iterator<Job> it = batchJobs.iterator(); it.hasNext(); ) if (it.next().grp == g) it.remove();
                for (Worker o : pool) if (o != w && o.current != null && o.current.grp == g) recycle(o);
            }
        }
        recycle(w);
        if (!nameOk(n) || !DEBT_OK.matcher(d).matches()) {
            if (j.race != null && "race".equals(modeOf(j))) startHesabSingle(j);
            else failJob(j, "Məlumat formatı tanınmadı");
        } else if (j.batch) {
            claimBatch(j.orig); ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + "," + JSONObject.quote(j.code) + ");", null);
        } else {
            if (j.race != null) {
                if (!j.race.claim()) return;                       // sorğu ləğv edilib
            }
            ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
            if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        }
        if (j.batch) pumpBatch();
    }

    private void onEbelFail(Worker w, String code, String reason) {
        Job j = w.current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        // inject.js buraya yalnız saytın açıq "tapılmadı" cavabı gələndə düşür.
        // Bu, texniki cavabsızlıq deyil: ehtiyat mənbələrə keçmədən nəticəni bitir.
        if (j.race != null && "race".equals(modeOf(j))) {
            recycle(w);
            failJob(j, "Məlumat tapılmadı");
            return;
        }
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void onEbelRetry(Worker w, String code) {
        Job j = w.current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        if (j.batch && j.grp == null) retryNoResponse(w, j);
        else handleFail(w, j, "Məlumat tapılmadı");
    }

    // Toplu yoxlamada ilkin kod: YVÖK cavab verənə qədər əl çəkilmir; təzə səhifədə təkrar (cəhdlər arası gözləmə artır, 4 san-ə qədər)
    private void retryNoResponse(final Worker w, final Job j) {
        if (w.current != j) return;
        j.noResp++;
        if (j.noResp >= (batchJobs.isEmpty() ? 1 : 2)) {  // e-belediyye cavab vermir: kod digər mənbəyə verilir (növbənin sonunda ikinci cəhd gözlənilmir)
            int alt = pickExtOnly(j);
            if (alt >= 0) { j.extTried |= EBEL_BIT; if (asg[SRC_E] > 0) asg[SRC_E]--; recycle(w); startExternal(j, alt); return; }
            if ((j.extTried & 7) == 7 && j.noResp >= 3) {  // xarici mənbələrin hamısı sınanıb: sonsuz təkrar əvəzinə nəticə
                recycle(w); failJob(j, "Məlumat tapılmadı"); pumpBatch(); return;
            }
        }
        if (w.loaded) recycle(w); else rebuild(w);
        w.current = j;                                   // gözləmə zamanı başqa kod bu işçini götürməsin
        final WebView wv = w.wv;
        long d = Math.min(j.noResp * RETRY_BACKOFF_MS, RETRY_BACKOFF_MAX_MS);
        wv.postDelayed(() -> { if (w.wv == wv && w.current == j) start(w, j); }, d);
    }

    private void onWatchdog(Worker w) {
        Job j = w.current;
        if (j == null) return;
        if (j.batch && j.grp == null) { retryNoResponse(w, j); return; }   // ilkin kod: cavab gələnə qədər təkrar; variant (təxmin) kodlar əvvəlki kimi
        // Səhifə heç açılmayıbsa kod səhv deyil: variantlara keçmədən təmiz səhifədə eyni kodu təkrar yoxla
        if (!w.loaded && j.pageRetries < 2) {
            j.pageRetries++;
            rebuild(w);
            start(w, j);
            return;
        }
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void handleFail(Worker w, Job j, String msg) {
        final boolean pageDown = !w.loaded;                 // səhifənin özü açılmayıb: sayt işləmir (kod səhv deyil)
        if (pageDown) ebelDownUntil = android.os.SystemClock.elapsedRealtime() + EBEL_DOWN_MS;
        // Nəticə gəlməyibsə (kod yanlışdır) qarışan simvol variantları yoxlanılır (0/O/Q, 1/I, 9-12-ci simvollarda 5/S).
        // Variantlar artıq ardıcıl yox, boş işçilərdə PARALEL yoxlanılır. Nəticə gəlibsə koda toxunulmur.
        // "Sayt cavab vermədi" mesajı yoxdur: bütün uğursuzluqlar "Məlumat tapılmadı"dır.
        if (j.batch) {
            final Group g = j.grp;
            if (g != null) {                                        // variant sorğusu uğursuz oldu
                recycle(w);
                if (!g.done && --g.left <= 0) { g.done = true; fallbackOrFail(g.root, msg); }
                pumpBatch();
                return;
            }
            if (!pageDown && j.variants == null) j.variants = buildVariants(j.orig);
            if (!pageDown && !j.variants.isEmpty()) {
                Group ng = new Group(j);
                ArrayList<Job> vs = new ArrayList<>();
                String next;
                while ((next = j.variants.pollFirst()) != null) {
                    Job vj = new Job(next, j);
                    vj.variants = new ArrayDeque<>();
                    vj.grp = ng;
                    vs.add(vj);
                }
                ng.left = vs.size();
                for (int i = vs.size() - 1; i >= 0; i--) batchJobs.addFirst(vs.get(i));   // növbənin əvvəlinə: az dəyişikliklidən başlayaraq
                recycle(w);
                pumpBatch();
                return;
            }
        }
        recycle(w);
        if ("race".equals(modeOf(j)) && j.race != null) {
            // E-bələdiyyə səhifəsi/sorğusu cavab vermədi; növbəti ehtiyat hesab.az-dır.
            startHesabSingle(j);
        } else if ("auto".equals(modeOf(j))) fallbackOrFail(j, msg);
        else failJob(j, msg);
        if (j.batch) pumpBatch();
    }

    // Qarışan simvol qrupları: {0,O,Q,D} və {1,I,L} (6-12-ci simvollar), {5,S} (yalnız 8-12-ci simvollar). Koddakı 6-12-ci simvolların (indeks 5..11) hər biri
    // öz qrupunun istənilən üzvü ilə əvəz oluna bilər (hər iki istiqamətdə: O->0, 0->O, 0<->D, I->1, 1->I, 1<->L, O<->Q ...).
    // Variantlar az dəyişiklikdən çoxuna doğru sıralanır və MAX_VARIANTS ilə məhdudlaşdırılır.
    private static final int MAX_VARIANTS = 40;

    private static String confusableGroup(char c, int i) {
        if (c == '0' || c == 'O' || c == 'Q' || c == 'D') return "0OQD";
        if (c == '1' || c == 'I' || c == 'L') return "1IL";
        if (i >= 7 && (c == '5' || c == 'S')) return "5S";   // 8-12-ci simvollarda 5<->S qarışır
        return null;
    }

    private static ArrayDeque<String> buildVariants(String code) {
        ArrayList<Integer> pos = new ArrayList<>();
        for (int i = 5; i < code.length(); i++) if (confusableGroup(code.charAt(i), i) != null) pos.add(i);
        int n = pos.size();
        ArrayList<String> list = new ArrayList<>();
        ArrayList<int[]> meta = new ArrayList<>();
        int[] idx = new int[n];                       // hər mövqedə qrupdan seçilən üzvün nömrəsi
        while (true) {
            char[] cs = code.toCharArray();
            int d = 0;
            for (int b = 0; b < n; b++) {
                int i = pos.get(b);
                char nc = confusableGroup(code.charAt(i), i).charAt(idx[b]);
                if (cs[i] != nc) { cs[i] = nc; d++; }
            }
            if (d > 0) {
                list.add(new String(cs));
                meta.add(new int[]{d, list.size() - 1});
            }
            int b = 0;                                // sayğacı bir artır (qarışıq say sistemi)
            while (b < n) {
                if (++idx[b] < confusableGroup(code.charAt(pos.get(b)), pos.get(b)).length()) break;
                idx[b++] = 0;
            }
            if (b == n) break;
        }
        Collections.sort(meta, (p, q) -> p[0] != q[0] ? Integer.compare(p[0], q[0]) : Integer.compare(p[1], q[1]));
        ArrayDeque<String> out = new ArrayDeque<>();
        for (int[] m : meta) { if (out.size() >= MAX_VARIANTS) break; out.add(list.get(m[1])); }
        // II <-> H: OCR "H" hərfini "II" kimi oxuyub kodu bir simvol qısaldıbsa (sonu itib),
        // "II" -> "H" edilir və itən son rəqəm 0-9 ilə tamamlanır. Bu variantlar ƏVVƏLDƏ yoxlanılır.
        ArrayDeque<String> hv = new ArrayDeque<>();
        for (int i = 5; i <= 6; i++) {
            if (code.length() == 12 && isIlike(code.charAt(i)) && isIlike(code.charAt(i + 1))) {
                String base = code.substring(0, i) + "H" + code.substring(i + 2);   // 11 simvol
                for (char d = '0'; d <= '9'; d++) hv.add(base + d);
            }
        }
        if (!hv.isEmpty()) { hv.addAll(out); return hv; }
        return out;
    }

    private void failJob(Job j, String msg) {
        if (j.batch) {
            if (!claimBatch(j.orig)) return;                   // kod artıq başqa yoldan (sona qalanda paralel yoxlama) bitib
            ui.evaluateJavascript("window.setBatchFail(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(msg) + ");", null);
        } else {
            if (j.race != null) {                                  // yalnız bütün saytlar uğursuz olanda xəta göstərilir
                j.race.fails++;
                if (j.race.won || j.race.fails < j.race.expected) return;
                j.race.won = true;
            }
            status("fail");
            toast(msg);
        }
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                Object t = v.getTag();
                if (t instanceof ProgressCb) ((ProgressCb) t).on(p);
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void status(final String st) {
        runOnUiThread(() -> ui.evaluateJavascript("window.setEbelStatus('" + st + "');", null));
    }

    // ---------------- Excel / csv / txt -> YVÖK kodları (mənzil, nömrə, küçə, səhifə ilə) ----------------
    private static class XSheet {
        String name = "";
        ArrayList<java.util.TreeMap<Integer, String>> rows = new ArrayList<>();
        ArrayList<Integer> nums = new ArrayList<>();       // vərəqdəki həqiqi sətir nömrələri (rows ilə paralel)
        ArrayList<int[]> vmerges = new ArrayList<>();      // şaquli birləşdirilmiş xanalar: {sütun, sətir1, sətir2}
    }

    private static String fold(String s) {
        if (s == null) return "";
        String t = s.replace("İ", "i").replace("I", "i").toLowerCase(Locale.ROOT)
                .replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
                .replace('ş', 's').replace('ç', 'c').replace('ğ', 'g');
        return t.replaceAll("[^a-z0-9]", "");
    }

    // Seçilən faylın adı (məs. "siyahi.xlsx")
    private String fileNameOf(Uri uri) {
        String n = "";
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) { String v = c.getString(0); if (v != null) n = v; }
        } catch (Exception ignored) { }
        if (n.isEmpty()) {
            String seg = uri.getLastPathSegment();
            if (seg != null) n = seg.substring(seg.lastIndexOf('/') + 1);
        }
        return n;
    }

    private void importCodesFromFile(Uri uri) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new Exception("fayl açılmadı");
                byte[] buf = new byte[16384];
                int n; long total = 0;
                while ((n = in.read(buf)) > 0) {
                    bos.write(buf, 0, n);
                    total += n;
                    if (total > 40L * 1024 * 1024) throw new Exception("fayl çox böyükdür");
                }
            }
            byte[] bytes = bos.toByteArray();
            JSONArray out = new JSONArray();
            int found = 0;
            if (bytes.length > 4 && bytes[0] == 'P' && bytes[1] == 'K') {
                for (XSheet sh : readXlsx(bytes)) found += extractSheet(sh, out);
            } else if (bytes.length > 4 && (bytes[0] & 0xFF) == 0xD0 && (bytes[1] & 0xFF) == 0xCF) {
                toast("Köhnə .xls formatı dəstəklənmir. Faylı .xlsx kimi yadda saxla");
                return;
            } else {
                Pattern pc = Pattern.compile("10011[A-Z0-9]{7}");
                for (String line : new String(bytes, "UTF-8").split("[\\r\\n,;\\t]+")) {
                    String t = line.trim().toUpperCase(Locale.ROOT);
                    String compact = t.replaceAll("[\\s\\-]", "");
                    if (compact.matches("^10011[A-Z0-9]{7}$")) t = compact;
                    java.util.regex.Matcher m = pc.matcher(t);
                    while (m.find()) {
                        JSONObject o = new JSONObject();
                        o.put("code", m.group());
                        out.put(o);
                        found++;
                    }
                }
            }
            if (found == 0) { toast("Faylda YVÖK kodu tapılmadı"); return; }
            final String js = out.toString();
            final int cnt = found;
            toast(cnt + " sətir tapıldı");
            final String fileName = fileNameOf(uri);
            runOnUiThread(() -> ui.evaluateJavascript("window.addExcelRows(JSON.parse(" + JSONObject.quote(js) + "), " + JSONObject.quote(fileName) + ");", null));
        } catch (Exception e) {
            toast("Fayl oxunmadı: " + e.getMessage());
        }
    }

    private static boolean hasCode(String v) {
        return v != null && Pattern.compile("10011[A-Z0-9]{7}").matcher(v.toUpperCase(Locale.ROOT)).find();
    }

    private static boolean isFloorKey(String k) {
        return k.equals("mrt") || k.equals("mert") || k.startsWith("mert") || k.contains("mertebe") || k.contains("mertaba") || k.equals("etaj");
    }

    private static boolean isNameKey(String k) {
        return k.contains("soyad") || k.equals("adi") || k.equals("ad") || k.equals("adsoyad");
    }

    // Başlıq xanasını təyin edir. c: 0=YVÖK 1=Mənzil 2=Mənzilin № 3=Mərtəbə/MRT 4=Ad və soyad 5=Küçə 6=Vergidən azad olunanlar 7=Ümumi sahəsi 8=Otaqların sayı 9=Blok
    private static boolean headKey(String k, int col, int[] c, ArrayList<Integer> pl) {
        if (k == null || k.isEmpty()) return false;
        boolean vergiHead = k.length() <= 45 && k.contains("vergi") && (k.contains("azad") || k.contains("muaf") || k.contains("guzest"));
        if (!vergiHead && k.length() > 25) return false;   // uzun mətn (məs. küçə başlığı) başlıq sütunu sayılmır
        int i = -1;
        if (vergiHead) i = 6;   // "Vergidən azad olunanlar"
        else if (k.startsWith("yvok")) i = 0;
        else if (k.equals("blok") || k.startsWith("blok") || k.equals("bl") || k.equals("korpus")) i = 9;   // "Blok"
        else if (k.contains("umumisahe") || k.equals("sahe") || k.equals("sahesi")) i = 7;   // "Ümumi sahəsi"
        else if (k.contains("otaq")) i = 8;   // "Otaqların sayı"
        else if (k.contains("menzil") && (k.contains("borc") || k.contains("sahe") || k.contains("otaq") || k.contains("qiymet") || k.contains("umumi"))) return false;   // "Mənzilin borcu" və s. mənzil nömrəsi deyil
        else if (k.contains("menzil")) i = k.contains("menzilin") ? 2 : 1;
        else if (isFloorKey(k)) i = 3;
        else if (isNameKey(k)) i = 4;
        else if (isPhoneKey(k)) { if (!pl.contains(col)) pl.add(col); return true; }
        else if (k.contains("vergi") && k.contains("azad")) i = 6;   // "Vergidən azad olunanlar"
        else if (k.length() <= 12 && (k.contains("kuce") || k.contains("unvan"))) i = 5;
        if (i < 0) return false;
        if (c[i] < 0) { c[i] = col; return true; }
        return false;
    }

    private static boolean isPhoneKey(String k) {
        return k.contains("nomre") || k.contains("telefon") || k.contains("mobil") || k.equals("tel") || k.contains("whatsapp");
    }

    private static boolean phoneish(String v) {
        if (v == null) return false;
        String t = v.replace('\u00a0', ' ').trim();
        return t.matches("^[\\d\\s+\\-()]+$") && t.replaceAll("\\D", "").length() >= 7;
    }

    // Mənzil nömrəsi 34.1 / 34,5 kimi onluq rəqəm (sahə, borc) ola bilməz
    private static boolean decimalNum(String v) {
        return v != null && v.trim().matches("^\\d+[.,]\\d+$");
    }

    // "Vergidən azad olunanlar" yalnız söz qəbul edir: heç bir hərf yoxdursa (yalnız rəqəm/işarə) boş sayılır
    private static String vergiText(String v) {
        String t = cleanText(v);
        int letters = 0;
        for (int i = 0; i < t.length(); i++) if (Character.isLetter(t.charAt(i))) letters++;
        return letters >= 2 ? t : "";   // tək hərf ("C") və ya yalnız rəqəm/işarə söz sayılmır
    }

    // Vergi sütunundan sağda (başlıqsız sütunlarda) yazılmış qeyd güzəşt/azad olma sözü daşıyırsa vergidən azad sayılır
    private static boolean exemptNote(String v) {
        String k = fold(v);
        return k.contains("teqaud") || k.contains("veteran") || k.contains("guzest") || k.contains("elil")
                || k.contains("sehid") || k.contains("qazi") || k.contains("muqavile") || k.contains("cernobil")
                || k.contains("azad") || k.contains("muaf");
    }

    // "Vergidən azad olunanlar" xanası: sütunun özündəki söz + sağdakı başlıqsız sütunlardakı güzəşt qeydləri
    private static String vergiOf(java.util.TreeMap<Integer, String> row, int vergiCol) {
        if (vergiCol < 0) return "";
        StringBuilder sb = new StringBuilder(vergiText(row.get(vergiCol)));
        for (java.util.Map.Entry<Integer, String> e : row.tailMap(vergiCol, false).entrySet()) {
            String t = vergiText(e.getValue());
            if (t.isEmpty() || !exemptNote(t) || hasCode(t)) continue;
            if (sb.toString().toLowerCase(Locale.ROOT).contains(t.toLowerCase(Locale.ROOT))) continue;
            if (sb.length() > 0) sb.append("; ");
            sb.append(t);
        }
        return sb.toString();
    }

    private static String cleanText(String v) {
        return v == null ? "" : v.replace('\u00a0', ' ').replaceAll("\\s+", " ").trim();
    }

    // Bir səhifədəki (vərəqdəki) sətirləri çıxarır.
    // Başlıq: "YVÖK" (yoxdursa "Mənzil"/"Mənzilin") sətri; başlıq bir neçə sətrə bölünə bilər (MRT/Mənzilin № başlıqdan yuxarıda da ola bilər).
    // Mənzil: əvvəlcə "MƏNZİL" sütunu; o yoxdursa "Mənzilin №" sütunu. Mərtəbə: "Mərtəbə" / "MRT" sütunu. Ad: "Ad və Soyad" sütunu.
    // YVÖK xanası boşdursa və ya 10011 kodu deyilsə, sətir yenə də (mərtəbə, mənzil, ad-soyad, YVÖK xanasındakı mətn) olduğu kimi götürülür.
    private static int countCodes(String v) {
        if (v == null) return 0;
        String u = v.toUpperCase(Locale.ROOT);
        if (u.replaceAll("[\\s\\u00a0\\-]", "").matches("^10011[A-Z0-9]{7}$")) return 1;
        java.util.regex.Matcher m = Pattern.compile("10011[A-Z0-9]{7}").matcher(u);
        int n = 0;
        while (m.find()) n++;
        return n;
    }

    // Başlıq / sütun quruluşu nə olursa olsun vərəqdəki bütün 10011 kodları götürülür:
    // əvvəl başlığa görə oxunur; bəzi kodlar buraxılıbsa (başlıqdan yuxarı, başqa sütun və s.) bütün xanalar yenidən skan olunur
    private int extractSheet(XSheet sh, JSONArray out) throws Exception {
        int all = 0;
        for (java.util.TreeMap<Integer, String> row : sh.rows) for (String v : row.values()) all += countCodes(v);
        int before = out.length();
        int n = extractSheet(sh, out, false);
        int coded = 0;
        for (int i = before; i < out.length(); i++) if (!out.getJSONObject(i).optBoolean("raw", false)) coded++;
        if (coded >= all) return n;
        while (out.length() > before) out.remove(out.length() - 1);
        return extractSheet(sh, out, true);
    }

    private int extractSheet(XSheet sh, JSONArray out, boolean scanAll) throws Exception {
        Pattern pc = Pattern.compile("10011[A-Z0-9]{7}");
        int[] c = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
        int headerRow = -1, dataStart = 0;
        ArrayList<Integer> phoneCols = new ArrayList<>();
        for (int pass = 0; pass < 2 && headerRow < 0; pass++) {
            for (int r = 0; r < sh.rows.size() && (pass == 0 || r < 25) && headerRow < 0; r++) {
                int[] t = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
                ArrayList<Integer> pl = new ArrayList<>();
                for (java.util.Map.Entry<Integer, String> e : sh.rows.get(r).entrySet()) headKey(fold(e.getValue()), e.getKey(), t, pl);
                if (pass == 0 ? t[0] >= 0 : (t[1] >= 0 || t[2] >= 0)) { headerRow = r; c = t; phoneCols = pl; }
            }
        }
        if (headerRow >= 0) {
            dataStart = headerRow + 1;
            // başlıq sətrindən yuxarıdakı sətirlər: MRT, Mənzilin № və s. burada ola bilər (birləşdirilmiş xanalar)
            for (int rr = Math.max(0, headerRow - 4); rr < headerRow; rr++) {
                java.util.TreeMap<Integer, String> row = sh.rows.get(rr);
                boolean hc = false;
                for (String v0 : row.values()) if (hasCode(v0)) { hc = true; break; }
                if (hc) continue;
                for (java.util.Map.Entry<Integer, String> e : row.entrySet()) headKey(fold(e.getValue()), e.getKey(), c, phoneCols);
            }
            // başlıq ikinci sətirdə davam edə bilər (birləşdirilmiş xanalar): "NOMRE", "TELEFON" və s.
            for (int rr = headerRow + 1; rr < sh.rows.size() && rr <= headerRow + 2; rr++) {
                java.util.TreeMap<Integer, String> row = sh.rows.get(rr);
                if (row.isEmpty()) { dataStart = rr + 1; continue; }
                boolean hc = false, kw = false;
                for (String v0 : row.values()) if (hasCode(v0)) { hc = true; break; }
                if (hc) break;           // kodlu sətir məlumatdır, başlıq deyil (mətni başlıq kimi oxunmasın)
                for (java.util.Map.Entry<Integer, String> e : row.entrySet()) {
                    if (headKey(fold(e.getValue()), e.getKey(), c, phoneCols)) kw = true;
                }
                if (!kw) break;
                dataStart = rr + 1;
            }
        }
        int yCol = c[0];
        if (scanAll) { yCol = -1; dataStart = 0; }   // başlıq nə olursa olsun: bütün sətirlərin bütün xanaları axtarılır
        int aptCol = c[1] >= 0 ? c[1] : c[2];     // "Mənzil" varsa o, yoxdursa "Mənzilin №"
        int floorCol = c[3], nameCol = c[4], streetCol = c[5], vergiCol = c[6], areaCol = c[7], roomsCol = c[8], blockCol = c[9];
        if (yCol < 0 && !scanAll) { // YVÖK başlığı yoxdur: kodların çoxluq təşkil etdiyi sütun
            java.util.HashMap<Integer, Integer> cc = new java.util.HashMap<>();
            for (int r = dataStart; r < sh.rows.size(); r++) {
                for (java.util.Map.Entry<Integer, String> e : sh.rows.get(r).entrySet()) {
                    String v = e.getValue() == null ? "" : e.getValue().replaceAll("[\\s\\u00a0\\-]", "").toUpperCase(Locale.ROOT);
                    if (v.matches("^10011[A-Z0-9]{7}$")) cc.merge(e.getKey(), 1, Integer::sum);
                }
            }
            int best = 0;
            for (java.util.Map.Entry<Integer, Integer> e : cc.entrySet()) if (e.getValue() > best) { best = e.getValue(); yCol = e.getKey(); }
        }
        if (phoneCols.isEmpty()) {  // nömrə başlığı yoxdur: telefon formatlı dəyərləri olan sütun
            java.util.HashMap<Integer, Integer> pcnt = new java.util.HashMap<>();
            for (int r = dataStart; r < sh.rows.size(); r++) {
                for (java.util.Map.Entry<Integer, String> e : sh.rows.get(r).entrySet()) {
                    if (e.getKey() == yCol || e.getKey() == aptCol || e.getKey() == floorCol || e.getKey() == vergiCol || e.getKey() == areaCol || e.getKey() == roomsCol || e.getKey() == blockCol) continue;
                    if (phoneish(e.getValue())) pcnt.merge(e.getKey(), 1, Integer::sum);
                }
            }
            int best = 0, bc = -1;
            for (java.util.Map.Entry<Integer, Integer> e : pcnt.entrySet()) if (e.getValue() > best) { best = e.getValue(); bc = e.getKey(); }
            if (bc >= 0) phoneCols.add(bc);
        }
        String nameHead = "";
        if (nameCol < 0) {          // "Ad və Soyad" başlığı yoxdur: ən çox hərfli mətn olan sütun
            java.util.HashMap<Integer, Integer> ncnt = new java.util.HashMap<>();
            for (int r = Math.max(0, dataStart); r < sh.rows.size(); r++) {
                for (java.util.Map.Entry<Integer, String> e : sh.rows.get(r).entrySet()) {
                    int k = e.getKey();
                    if (k == yCol || k == aptCol || k == floorCol || k == vergiCol || k == areaCol || k == roomsCol || k == blockCol || phoneCols.contains(k)) continue;
                    String v = cleanText(e.getValue());
                    if (v.isEmpty() || hasCode(v) || phoneish(v)) continue;
                    int letters = 0, digits = 0;
                    for (int i = 0; i < v.length(); i++) {
                        char ch = v.charAt(i);
                        if (Character.isLetter(ch)) letters++; else if (Character.isDigit(ch)) digits++;
                    }
                    if (letters >= 3 && letters > digits) ncnt.merge(k, 1, Integer::sum);
                }
            }
            int best = 1, bc = -1;
            for (java.util.Map.Entry<Integer, Integer> e : ncnt.entrySet()) if (e.getValue() > best) { best = e.getValue(); bc = e.getKey(); }
            if (bc >= 0) {
                nameCol = bc;
                // bu sütunun başlığı ad-soyad sözü deyilsə (məs. "CAVADXAN 41C") küçə/blok adıdır
                for (int rr = 0; rr <= headerRow && rr < sh.rows.size() && nameHead.isEmpty(); rr++) {
                    String hv = cleanText(sh.rows.get(rr).get(nameCol));
                    if (!hv.isEmpty() && hv.matches(".*\\p{L}.*") && !isNameKey(fold(hv))) nameHead = hv;
                }
            }
        }
        int leftCol = Integer.MAX_VALUE;
        for (java.util.TreeMap<Integer, String> row : sh.rows) if (!row.isEmpty()) leftCol = Math.min(leftCol, row.firstKey());
        if (aptCol >= 0) leftCol = Math.min(leftCol, aptCol);
        // küçə adı: kodlardan/başlıqdan əvvəlki ilk mətn sətri (adətən faylın birinci sətri); başlıq sözləri olan sətirlər (MRT, Mənzilin №...) küçə sayılmır
        int topBound = headerRow;
        if (topBound < 0) {
            topBound = sh.rows.size();
            for (int r = 0; r < sh.rows.size(); r++) {
                boolean f = false;
                for (String v : sh.rows.get(r).values()) if (hasCode(v)) { f = true; break; }
                if (f) { topBound = r; break; }
            }
        }
        String curStreet = "";
        for (int r = 0; r < topBound && r < sh.rows.size() && curStreet.isEmpty(); r++) {
            boolean kwRow = false;
            int[] tmp = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
            ArrayList<Integer> tpl = new ArrayList<>();
            for (java.util.Map.Entry<Integer, String> e : sh.rows.get(r).entrySet()) {
                if (headKey(fold(e.getValue()), e.getKey(), tmp, tpl)) kwRow = true;
            }
            if (kwRow) continue;
            StringBuilder sb = new StringBuilder();
            for (String v : sh.rows.get(r).values()) {
                String t = cleanText(v);
                if (!t.isEmpty()) { if (sb.length() > 0) sb.append(' '); sb.append(t); }
            }
            String t = sb.toString();
            if (!t.isEmpty() && t.matches(".*\\p{L}.*")) curStreet = t;
        }
        // səhifənin üstündə küçə adı yoxdursa: ad sütununun başlığı, o da yoxdursa (standart olmayan) vərəq adı
        if (curStreet.isEmpty() && !nameHead.isEmpty()) curStreet = nameHead;
        if (curStreet.isEmpty()) {
            String sn = cleanText(sh.name);
            if (!sn.isEmpty() && !sn.toLowerCase(Locale.ROOT).matches("^(sheet|list|лист|səhifə|vərəq|sehife|vereq)\\s*\\d*$")) curStreet = sn;
        }
        // "Mənzil" sütununda ümumiyyətlə nömrə yazılıbsa, boş xanalar boş qalır; heç nə yazılmayıbsa ilk sətirdən 1, 2, 3...
        boolean aptFilled = false;
        if (aptCol >= 0) {
            for (int r = Math.max(0, dataStart); r < sh.rows.size() && !aptFilled; r++) {
                String v = sh.rows.get(r).get(aptCol);
                if (v != null && !v.trim().isEmpty() && !decimalNum(v) && !fold(v).contains("menzil")) aptFilled = true;
            }
        }
        int count = 0, ord = 0;
        boolean started = false;
        for (int r = Math.max(0, dataStart); r < sh.rows.size(); r++) {
            java.util.TreeMap<Integer, String> row = sh.rows.get(r);
            if (row.isEmpty()) continue;
            ArrayList<String> codes = new ArrayList<>();
            String cell = yCol >= 0 ? row.get(yCol) : null;
            if (cell != null) {
                String compact = cell.replaceAll("[\\s\\u00a0\\-]", "").toUpperCase(Locale.ROOT);
                if (compact.matches("^10011[A-Z0-9]{7}$")) codes.add(compact);
                else {
                    java.util.regex.Matcher m = pc.matcher(cell.toUpperCase(Locale.ROOT));
                    while (m.find()) codes.add(m.group());
                }
            }
            if (codes.isEmpty()) {     // YVÖK xanasında kod yoxdursa sətirdəki digər xanalarda yazılmış kodlar da (təkrarlar daxil) götürülür
                for (String v : row.values()) {
                    java.util.regex.Matcher m = pc.matcher(v == null ? "" : v.toUpperCase(Locale.ROOT));
                    while (m.find()) codes.add(m.group());
                }
            }
            String nm = nameCol >= 0 ? cleanText(row.get(nameCol)) : "";
            boolean raw = false;
            String yRaw = "";
            if (codes.isEmpty()) {
                int nonEmpty = 0, onlyCol = -1; String only = "";
                boolean hdr = false;
                for (java.util.Map.Entry<Integer, String> e : row.entrySet()) {
                    String v = e.getValue();
                    if (v != null && !v.trim().isEmpty()) {
                        nonEmpty++; only = cleanText(v); onlyCol = e.getKey();
                        String k = fold(v);
                        // yalnız qısa başlıq xanası (uzun ad mətnində "mənzil" sözü ola bilər: "BOŞANIBLAR MƏNZİL 10 İLƏ BİRLƏŞDİRİLİB")
                        if (k.length() <= 14 && (k.startsWith("yvok") || k.contains("menzil"))) hdr = true;
                    }
                }
                if (hdr) { started = false; ord = 0; continue; }     // təkrarlanan başlıq: yeni cədvəl, sayma yenidən
                // cədvəl arasında tək xanalı mətn sətri (ən sol sütunda) = yeni küçə başlığı
                if (nonEmpty == 1 && only.length() > 3 && only.matches(".*\\p{L}.*") && onlyCol <= leftCol) {
                    curStreet = only; started = false; ord = 0;
                    continue;
                }
                // YVÖK boş və ya 10011 kodu deyil: sətir yenə də olduğu kimi köçürülür (mərtəbə, mənzil, ad-soyad, YVÖK xanasındakı mətn)
                yRaw = yCol >= 0 ? cleanText(row.get(yCol)) : "";
                String flR = floorCol >= 0 ? cleanText(row.get(floorCol)) : "";
                String apR = aptCol >= 0 ? cleanText(row.get(aptCol)) : "";
                boolean repeatedHead = !nm.isEmpty() && isNameKey(fold(nm));
                boolean keep = !repeatedHead && (!yRaw.isEmpty() || !nm.isEmpty()
                        || (started && ((!flR.isEmpty() && !isFloorKey(fold(flR))) || !apR.isEmpty())));
                if (!keep) { if (started) ord++; continue; }
                raw = true;
                codes.add("");   // bir sətir yazılsın
            }
            if (!started) { started = true; ord = 1; } else ord++;
            if (!raw) yRaw = cell == null ? "" : cleanText(cell);   // YVÖK xanası faylda necədirsə
            String street = curStreet;
            if (streetCol >= 0 && row.get(streetCol) != null && !row.get(streetCol).trim().isEmpty()) street = cleanText(row.get(streetCol));
            // mənzil: "Mənzil" (yoxdursa "Mənzilin №") sütunundan, faylda necə yazılıbsa; boşdursa ilk sətirdən başlayaraq sıra nömrəsi
            String apt = aptCol >= 0 && row.get(aptCol) != null ? row.get(aptCol) : "";
            if (decimalNum(apt)) apt = "";   // 34.1 kimi onluq rəqəm mənzil sayılmır
            // mənzil faylda necə yazılıbsa elə köçürülür; boş xana boş qalır. Yalnız sütunun altı tamamilə boşdursa (və ya sütun yoxdursa) 1, 2, 3... yazılır
            if (apt.trim().isEmpty()) apt = aptFilled ? "" : String.valueOf(ord);
            String floor = floorCol >= 0 && row.get(floorCol) != null ? row.get(floorCol) : "";
            StringBuilder phSb = new StringBuilder();
            for (int pc2 : phoneCols) {
                String pv = row.get(pc2);
                if (pv != null && !pv.trim().isEmpty()) { if (phSb.length() > 0) phSb.append(", "); phSb.append(pv.trim()); }
            }
            // vergi sütununa düşmüş telefon nömrələri (yalnız rəqəm) vergi sayılmır, "Nömrə"yə köçürülür
            if (vergiCol >= 0) {
                String vr = cleanText(row.get(vergiCol));
                if (!vr.isEmpty() && vergiText(vr).isEmpty() && vr.matches("^[\\d\\s+\\-()/]+$") && vr.replaceAll("\\D", "").length() >= 5
                        && !phSb.toString().contains(vr)) {
                    if (phSb.length() > 0) phSb.append(", ");
                    phSb.append(vr);
                }
            }
            String phone = phSb.toString();
            String vergi = vergiOf(row, vergiCol);
            String area = areaCol >= 0 ? cleanText(row.get(areaCol)) : "";
            String rooms = roomsCol >= 0 ? cleanText(row.get(roomsCol)) : "";
            String block = blockCol >= 0 ? cleanText(row.get(blockCol)) : "";
            for (String cd : codes) {
                JSONObject o = new JSONObject();
                o.put("code", cd);
                o.put("sheet", sh.name);
                o.put("street", street);
                o.put("apt", apt);
                o.put("floor", floor);
                o.put("block", block);
                o.put("phone", phone);
                o.put("vergi", vergi);
                o.put("area", area);
                o.put("rooms", rooms);
                if (vergiCol >= 0) o.put("hasVergi", true);
                o.put("ycell", yRaw);
                if (raw) o.put("raw", true);
                out.put(o);
                count++;
            }
        }
        return count;
    }

    private ArrayList<XSheet> readXlsx(byte[] bytes) throws Exception {
        java.util.HashMap<String, byte[]> files = new java.util.HashMap<>();
        try (java.util.zip.ZipInputStream z = new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(bytes))) {
            java.util.zip.ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String nm = e.getName();
                if (!(nm.equals("xl/sharedStrings.xml") || nm.equals("xl/workbook.xml")
                        || nm.equals("xl/_rels/workbook.xml.rels")
                        || (nm.startsWith("xl/worksheets/") && nm.endsWith(".xml")))) continue;
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = z.read(buf)) > 0) b.write(buf, 0, n);
                files.put(nm, b.toByteArray());
            }
        }
        // ümumi mətnlər
        ArrayList<String> sst = new ArrayList<>();
        byte[] shared = files.get("xl/sharedStrings.xml");
        if (shared != null) {
            org.xmlpull.v1.XmlPullParser p = android.util.Xml.newPullParser();
            p.setInput(new java.io.ByteArrayInputStream(shared), "UTF-8");
            StringBuilder cur = null;
            boolean inT = false;
            int ev = p.getEventType();
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    String t = p.getName();
                    if (t.equals("si")) cur = new StringBuilder();
                    else if (t.equals("t")) inT = true;
                } else if (ev == org.xmlpull.v1.XmlPullParser.TEXT) {
                    if (inT && cur != null) cur.append(p.getText());
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG) {
                    String t = p.getName();
                    if (t.equals("t")) inT = false;
                    else if (t.equals("si") && cur != null) { sst.add(cur.toString()); cur = null; }
                }
                ev = p.next();
            }
        }
        // vərəq adları və fayl yolları (workbook.xml + rels)
        java.util.HashMap<String, String> relTarget = new java.util.HashMap<>();
        byte[] rels = files.get("xl/_rels/workbook.xml.rels");
        if (rels != null) {
            org.xmlpull.v1.XmlPullParser p = android.util.Xml.newPullParser();
            p.setInput(new java.io.ByteArrayInputStream(rels), "UTF-8");
            int ev = p.getEventType();
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG && p.getName().equals("Relationship")) {
                    String id = p.getAttributeValue(null, "Id"), tg = p.getAttributeValue(null, "Target");
                    if (id != null && tg != null) {
                        tg = tg.startsWith("/") ? tg.substring(1) : "xl/" + tg;
                        relTarget.put(id, tg);
                    }
                }
                ev = p.next();
            }
        }
        ArrayList<String[]> order = new ArrayList<>();   // {ad, yol}
        byte[] wbx = files.get("xl/workbook.xml");
        if (wbx != null) {
            org.xmlpull.v1.XmlPullParser p = android.util.Xml.newPullParser();
            p.setInput(new java.io.ByteArrayInputStream(wbx), "UTF-8");
            int ev = p.getEventType();
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG && p.getName().equals("sheet")) {
                    String nm = p.getAttributeValue(null, "name");
                    String rid = null;
                    for (int i = 0; i < p.getAttributeCount(); i++) {
                        String an = p.getAttributeName(i);
                        if (an.equals("id") || an.endsWith(":id")) rid = p.getAttributeValue(i);
                    }
                    String path = rid == null ? null : relTarget.get(rid);
                    if (path != null && files.containsKey(path)) order.add(new String[]{nm == null ? "" : nm, path});
                }
                ev = p.next();
            }
        }
        if (order.isEmpty()) {       // ehtiyat: fayl adlarına görə
            java.util.TreeMap<Integer, String> tm = new java.util.TreeMap<>();
            for (String k : files.keySet()) {
                java.util.regex.Matcher m = Pattern.compile("sheet(\\d+)\\.xml$").matcher(k);
                if (k.startsWith("xl/worksheets/") && m.find()) tm.put(Integer.parseInt(m.group(1)), k);
            }
            for (java.util.Map.Entry<Integer, String> e : tm.entrySet()) order.add(new String[]{"Səhifə " + e.getKey(), e.getValue()});
        }
        ArrayList<XSheet> result = new ArrayList<>();
        for (String[] so : order) {
            XSheet sh = new XSheet();
            sh.name = so[0];
            org.xmlpull.v1.XmlPullParser p = android.util.Xml.newPullParser();
            p.setInput(new java.io.ByteArrayInputStream(files.get(so[1])), "UTF-8");
            java.util.TreeMap<Integer, String> row = null;
            String type = "";
            int col = -1, autoCol = -1, curRowNum = 0;
            StringBuilder val = null;
            boolean inV = false, inT = false;
            int ev = p.getEventType();
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    String t = p.getName();
                    if (t.equals("row")) {
                        row = new java.util.TreeMap<>(); autoCol = -1;
                        String rn = p.getAttributeValue(null, "r");
                        try { curRowNum = rn != null ? Integer.parseInt(rn.trim()) : curRowNum + 1; } catch (Exception ex) { curRowNum++; }
                    } else if (t.equals("mergeCell")) {
                        String mr = p.getAttributeValue(null, "ref");
                        java.util.regex.Matcher mm = mr == null ? null : Pattern.compile("^([A-Za-z]+)(\\d+):([A-Za-z]+)(\\d+)$").matcher(mr);
                        if (mm != null && mm.find() && mm.group(1).equalsIgnoreCase(mm.group(3))) {   // yalnız şaquli birləşmə (məs. mərtəbə sütunu)
                            int cc = 0;
                            for (char ch : mm.group(1).toUpperCase(Locale.ROOT).toCharArray()) cc = cc * 26 + (ch - 'A' + 1);
                            int r1 = Integer.parseInt(mm.group(2)), r2 = Integer.parseInt(mm.group(4));
                            if (cc > 0 && r2 > r1 && r2 - r1 <= 2000) sh.vmerges.add(new int[]{cc - 1, r1, r2});
                        }
                    }
                    else if (t.equals("c")) {
                        type = p.getAttributeValue(null, "t");
                        if (type == null) type = "";
                        String ref = p.getAttributeValue(null, "r");
                        autoCol++;
                        if (ref != null) {
                            int c = 0, k = 0;
                            while (k < ref.length() && Character.isLetter(ref.charAt(k))) {
                                c = c * 26 + (Character.toUpperCase(ref.charAt(k)) - 'A' + 1);
                                k++;
                            }
                            if (c > 0) autoCol = c - 1;
                        }
                        col = autoCol;
                        val = new StringBuilder();
                    } else if (t.equals("v")) inV = true;
                    else if (t.equals("t")) inT = true;
                } else if (ev == org.xmlpull.v1.XmlPullParser.TEXT) {
                    if (val != null && (inV || inT)) val.append(p.getText());
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG) {
                    String t = p.getName();
                    if (t.equals("v")) inV = false;
                    else if (t.equals("t")) inT = false;
                    else if (t.equals("c") && val != null) {
                        String s = val.toString();
                        if (type.equals("s")) {
                            try {
                                int idx = Integer.parseInt(s.trim());
                                s = idx >= 0 && idx < sst.size() ? sst.get(idx) : "";
                            } catch (Exception ex) { s = ""; }
                        } else if (type.isEmpty() || type.equals("n")) {
                            try { s = new java.math.BigDecimal(s.trim()).stripTrailingZeros().toPlainString(); } catch (Exception ex) { /* olduğu kimi */ }
                        }
                        if (row != null && col >= 0 && !s.trim().isEmpty()) row.put(col, s);
                        val = null;
                    } else if (t.equals("row") && row != null) {
                        sh.rows.add(row);
                        sh.nums.add(curRowNum);
                        row = null;
                    }
                }
                ev = p.next();
            }
            // şaquli birləşdirilmiş xanalar: yuxarıdakı dəyər birləşmə daxilindəki bütün sətirlərə yayılır
            if (!sh.vmerges.isEmpty()) {
                java.util.HashMap<Integer, Integer> byNum = new java.util.HashMap<>();
                for (int i = 0; i < sh.nums.size(); i++) byNum.put(sh.nums.get(i), i);
                for (int[] mg : sh.vmerges) {
                    Integer top = byNum.get(mg[1]);
                    if (top == null) continue;
                    String tv = sh.rows.get(top).get(mg[0]);
                    if (tv == null || tv.trim().isEmpty()) continue;
                    for (int rn2 = mg[1] + 1; rn2 <= mg[2]; rn2++) {
                        Integer ix = byNum.get(rn2);
                        if (ix != null && !sh.rows.get(ix).containsKey(mg[0])) sh.rows.get(ix).put(mg[0], tv);
                    }
                }
            }
            result.add(sh);
        }
        return result;
    }

    // ---------------- Export (xlsx / txt / pdf) ----------------
    private static class ExRow {
        String sheet = "", street = "", code = "", debt = "", name = "", apt = "", phone = "", floor = "", block = "", vergi = "", area = "", rooms = "";
        boolean hasVergi = false;
    }

    private static class ExBlock {
        String street = "";
        ArrayList<ExRow> rows = new ArrayList<>();
    }

    private static class ExGroup {
        String name = "";
        ArrayList<ExBlock> blocks = new ArrayList<>();
    }

    // Sütunlar (sıra dəyişməz): [Blok] | [Mərtəbə] | Mənzil | Ad və Soyad | YVÖK | Borc | Nömrə | [Ümumi sahəsi] | [Otaqların sayı] | [Vergidən azad olunanlar]
    // "Blok" və "Mərtəbə" sütunları yalnız həmin səhifədə dəyər varsa əlavə olunur və "Mənzil"in solundadır.
    private static String[] exHeads(boolean hb, boolean hf, boolean hv, boolean ha2, boolean hr) {
        ArrayList<String> h = new ArrayList<>();
        if (hb) h.add("Blok");
        if (hf) h.add("Mərtəbə");
        h.add("Mənzil"); h.add("Soyad, Ad, Atasının adı"); h.add("YVÖK"); h.add("Borc"); h.add("Nömrə");
        if (ha2) h.add("Ümumi sahəsi");
        if (hr) h.add("Otaqların sayı");
        if (hv) h.add("Vergidən azad olunanlar");
        return h.toArray(new String[0]);
    }

    private static int[] exWidths(boolean hb, boolean hf, boolean hv, boolean ha2, boolean hr) {
        ArrayList<Integer> w = new ArrayList<>();
        if (hb) w.add(12);
        if (hf) w.add(12);
        w.add(20); w.add(34); w.add(16); w.add(12); w.add(28);
        if (ha2) w.add(16);
        if (hr) w.add(18);
        if (hv) w.add(30);
        int[] res = new int[w.size()];
        for (int i = 0; i < res.length; i++) res[i] = w.get(i);
        return res;
    }

    private static String[] exCells(ExRow r, boolean hb, boolean hf, boolean hv, boolean ha2, boolean hr) {
        ArrayList<String> c = new ArrayList<>();
        if (hb) c.add(r.block);
        if (hf) c.add(r.floor);
        c.add(r.apt); c.add(r.name); c.add(r.code); c.add(r.debt); c.add(r.phone);
        if (ha2) c.add(r.area);
        if (hr) c.add(r.rooms);
        if (hv) c.add(r.vergi);
        return c.toArray(new String[0]);
    }

    // Səhifəyə (vərəqə) və küçə adına görə qruplaşdır; səhifə və küçə sırası fayldakı ilk rast gəlinmə kimi qalır
    private static ArrayList<ExGroup> exGroup(ArrayList<ExRow> rows) {
        ArrayList<ExGroup> groups = new ArrayList<>();
        java.util.HashMap<String, ExGroup> byName = new java.util.HashMap<>();
        for (ExRow r : rows) {
            String gn = r.sheet == null || r.sheet.isEmpty() ? "Nəticə" : r.sheet;
            ExGroup g = byName.get(gn);
            if (g == null) { g = new ExGroup(); g.name = gn; byName.put(gn, g); groups.add(g); }
            String st = r.street == null ? "" : r.street;
            ExBlock b = null;
            for (ExBlock x : g.blocks) if (x.street.equals(st)) { b = x; break; }   // eyni küçə ayrı-ayrı yerdə olsa da bir blokda toplanır
            if (b == null) {
                b = new ExBlock();
                b.street = st;
                g.blocks.add(b);
            }
            b.rows.add(r);
        }
        return groups;
    }

    private void doExport(String fmt, String rowsJson) {
        try {
            JSONArray arr = new JSONArray(rowsJson);
            ArrayList<ExRow> rows = new ArrayList<>();
            boolean ha = false, hp = false;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                ExRow r = new ExRow();
                r.sheet = o.optString("sheet", "");
                r.street = o.optString("street", "");
                r.code = o.optString("code", "");
                r.debt = o.optString("debt", "");
                r.name = o.optString("name", "");
                r.apt = o.optString("apt", "");
                r.phone = o.optString("phone", "");
                r.floor = o.optString("floor", "");
                r.block = o.optString("block", "");
                r.vergi = o.optString("vergi", "");
                r.area = o.optString("area", "");
                r.rooms = o.optString("rooms", "");
                r.hasVergi = o.optBoolean("hasVergi", false);
                if (!r.apt.isEmpty()) ha = true;
                if (!r.phone.isEmpty()) hp = true;
                rows.add(r);
            }
            if (rows.isEmpty()) { toast("Export üçün nəticə yoxdur"); return; }
            ArrayList<ExGroup> groups = exGroup(rows);
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            byte[] data = buildXlsx(groups, ha, hp);
            String ext = "xlsx";
            String mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            // fayl adı: faylın birinci sətrindəki küçə adları (fərqli küçələr vergüllə); küçə yoxdursa tarixli ad
            java.util.LinkedHashSet<String> sts = new java.util.LinkedHashSet<>();
            for (ExGroup g : groups) for (ExBlock b : g.blocks) {
                String st = b.street == null ? "" : b.street.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", " ").replaceAll("\\s+", " ").trim();
                if (!st.isEmpty()) sts.add(st);
            }
            String base = android.text.TextUtils.join(", ", sts).trim();
            if (base.length() > 100) base = base.substring(0, 100).trim();
            if (base.isEmpty()) base = "YVOK_netice_" + stamp;
            String name = base + "." + ext;
            saveExport(name, mime, data);
        } catch (Exception e) {
            toast("Export alınmadı: " + e.getMessage());
        }
    }

    private static String xmlEsc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    // "45,678" / "45.678 m²" -> "45.68" (yüzdə birə qədər); ədəd deyilsə null (xana mətn kimi qalır)
    private static String roundArea(String v) {
        if (v == null) return null;
        String t = v.trim().replace(',', '.').replaceAll("[^0-9.]", "");
        if (t.isEmpty() || !t.matches("^\\d+(\\.\\d+)?$")) return null;
        try {
            return new java.math.BigDecimal(t).setScale(2, java.math.RoundingMode.HALF_UP).toPlainString();
        } catch (Exception e) {
            return null;
        }
    }

    private static void xlsxStr(StringBuilder sh, String ref, String v, int style) {
        sh.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(style > 0 ? " s=\"" + style + "\"" : "")
          .append("><is><t xml:space=\"preserve\">").append(xmlEsc(v)).append("</t></is></c>");
    }

    private byte[] buildXlsx(ArrayList<ExGroup> groups, boolean ha, boolean hp) throws Exception {
        ArrayList<String> names = new ArrayList<>();
        ArrayList<String> sheetXml = new ArrayList<>();
        for (ExGroup g : groups) {
            boolean hf = false;   // Mərtəbə sütunu yalnız həmin səhifədə mərtəbə (MRT) yazılıbsa olur
            for (ExBlock b0 : g.blocks) for (ExRow r0 : b0.rows) if (r0.floor != null && !r0.floor.isEmpty()) hf = true;
            boolean hb = false;   // "Blok" sütunu yalnız həmin səhifədə blok yazılıbsa olur
            for (ExBlock b0 : g.blocks) for (ExRow r0 : b0.rows) if (r0.block != null && !r0.block.isEmpty()) hb = true;
            boolean hv = false;   // "Vergidən azad olunanlar" sütunu yalnız həmin səhifədə dəyər varsa olur
            for (ExBlock b0 : g.blocks) for (ExRow r0 : b0.rows) if (r0.vergi != null && !r0.vergi.isEmpty()) hv = true;
            boolean ha2 = false, hr = false;   // "Ümumi sahəsi" / "Otaqların sayı" sütunları yalnız həmin səhifədə dəyər varsa olur
            for (ExBlock b0 : g.blocks) for (ExRow r0 : b0.rows) {
                if (r0.area != null && !r0.area.isEmpty()) ha2 = true;
                if (r0.rooms != null && !r0.rooms.isEmpty()) hr = true;
            }
            String[] heads = exHeads(hb, hf, hv, ha2, hr);
            int off = (hb ? 1 : 0) + (hf ? 1 : 0);
            int debtCol = 3 + off;
            int areaCol = 5 + off;   // "Ümumi sahəsi" sütunu (Nömrə sütunundan sonra)
            StringBuilder sh = new StringBuilder();
            sh.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            sh.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols>");
            int[] cw = exWidths(hb, hf, hv, ha2, hr);
            for (int c = 0; c < heads.length; c++) {
                sh.append("<col min=\"").append(c + 1).append("\" max=\"").append(c + 1)
                  .append("\" width=\"").append(cw[c]).append("\" customWidth=\"1\"/>");
            }
            sh.append("</cols><sheetData>");
            int n = 1;
            ArrayList<String> merges = new ArrayList<>();
            for (ExBlock b : g.blocks) {
                if (!b.street.isEmpty()) {
                    sh.append("<row r=\"").append(n).append("\">");
                    xlsxStr(sh, "A" + n, b.street.toUpperCase(new Locale("az", "AZ")), 3);
                    for (int c = 1; c < heads.length; c++) sh.append("<c r=\"").append((char) ('A' + c)).append(n).append("\" s=\"3\"/>");
                    merges.add("A" + n + ":" + (char) ('A' + heads.length - 1) + n);
                    sh.append("</row>");
                    n++;
                }
                sh.append("<row r=\"").append(n).append("\">");
                for (int c = 0; c < heads.length; c++) xlsxStr(sh, (char) ('A' + c) + "" + n, heads[c], 1);
                sh.append("</row>");
                n++;
                for (ExRow r : b.rows) {
                    String[] cells = exCells(r, hb, hf, hv, ha2, hr);
                    // qırmızı: borc məbləği və borcu olmayan (borc yoxdur / 0 / tapılmadı / yoxlanılmayıb) YVÖK
                    boolean noDebt = false;   // yalnız borcu 0 olan sətir
                    try { String dv = cells[debtCol].replace(',', '.').trim(); noDebt = !dv.isEmpty() && Double.parseDouble(dv) <= 0; } catch (Exception ex) { noDebt = false; }
                    int codeCol = 2 + off;
                    sh.append("<row r=\"").append(n).append("\">");
                    for (int c = 0; c < cells.length; c++) {
                        String ref = (char) ('A' + c) + "" + n;
                        String areaNum = (ha2 && c == areaCol) ? roundArea(cells[c]) : null;
                        boolean nf = r.name != null && (r.name.startsWith("Məlumat tapılmadı") || r.name.startsWith("Yoxlanılmayıb"));
                        boolean red = (noDebt && (c == debtCol || c == codeCol)) || (nf && c == codeCol);
                        if (c == debtCol && cells[c].matches("^\\d+(\\.\\d+)?$")) {
                            sh.append("<c r=\"").append(ref).append("\" s=\"").append(red ? 5 : 2).append("\"><v>").append(cells[c]).append("</v></c>");
                        } else if (areaNum != null) {
                            // "Ümumi sahəsi": yüzdə birə qədər yuvarlaqlaşdırılmış ədəd (0.00 formatı)
                            sh.append("<c r=\"").append(ref).append("\" s=\"2\"><v>").append(areaNum).append("</v></c>");
                        } else if (!cells[c].isEmpty()) {
                            xlsxStr(sh, ref, cells[c], red ? 4 : 0);
                        }
                    }
                    sh.append("</row>");
                    n++;
                }
                n++;    // küçələr arasında boş sətir
            }
            sh.append("</sheetData>");
            if (!merges.isEmpty()) {
                sh.append("<mergeCells count=\"").append(merges.size()).append("\">");
                for (String mg : merges) sh.append("<mergeCell ref=\"").append(mg).append("\"/>");
                sh.append("</mergeCells>");
            }
            sh.append("</worksheet>");
            String nm = g.name.replaceAll("[\\\\/?*\\[\\]:]", "").trim();
            if (nm.isEmpty()) nm = "Səhifə " + (names.size() + 1);
            if (nm.length() > 31) nm = nm.substring(0, 31);
            String base = nm; int k = 2;
            while (names.contains(nm)) {
                String suf = " (" + k++ + ")";
                nm = (base.length() + suf.length() > 31 ? base.substring(0, 31 - suf.length()) : base) + suf;
            }
            names.add(nm);
            sheetXml.add(sh.toString());
        }
        int N = names.size();
        String styles = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"0.00\"/></numFmts>"
                + "<fonts count=\"4\"><font><sz val=\"12\"/><name val=\"Times New Roman\"/></font>"
                + "<font><b/><sz val=\"12\"/><name val=\"Times New Roman\"/></font>"
                + "<font><b/><sz val=\"14\"/><name val=\"Times New Roman\"/></font>"
                + "<font><sz val=\"12\"/><color rgb=\"FFFF0000\"/><name val=\"Times New Roman\"/></font></fonts>"
                + "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"6\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
                + "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>"
                + "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>"
                + "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
                + "<xf numFmtId=\"164\" fontId=\"3\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyNumberFormat=\"1\"/></cellXfs>"
                + "</styleSheet>";
        StringBuilder ct = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        StringBuilder wb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        StringBuilder wbRels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 0; i < N; i++) {
            ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
              .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            wb.append("<sheet name=\"").append(xmlEsc(names.get(i))).append("\" sheetId=\"").append(i + 1)
              .append("\" r:id=\"rId").append(i + 1).append("\"/>");
            wbRels.append("<Relationship Id=\"rId").append(i + 1)
                  .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                  .append(i + 1).append(".xml\"/>");
        }
        ct.append("</Types>");
        wb.append("</sheets></workbook>");
        wbRels.append("<Relationship Id=\"rId").append(N + 1)
              .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        String rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                + "</Relationships>";

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        java.util.zip.ZipOutputStream z = new java.util.zip.ZipOutputStream(bos);
        zipPut(z, "[Content_Types].xml", ct.toString());
        zipPut(z, "_rels/.rels", rels);
        zipPut(z, "xl/workbook.xml", wb.toString());
        zipPut(z, "xl/_rels/workbook.xml.rels", wbRels.toString());
        zipPut(z, "xl/styles.xml", styles);
        for (int i = 0; i < N; i++) zipPut(z, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml.get(i));
        z.close();
        return bos.toByteArray();
    }

    private static void zipPut(java.util.zip.ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new java.util.zip.ZipEntry(name));
        z.write(content.getBytes("UTF-8"));
        z.closeEntry();
    }

    // Android 10+: birbaşa Downloads qovluğuna; köhnə versiyalarda paylaşma pəncərəsi
    private void saveExport(String name, String mime, byte[] data) throws Exception {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            android.content.ContentValues cvs = new android.content.ContentValues();
            cvs.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cvs.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cvs.put(MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cvs);
            if (uri == null) throw new Exception("fayl yaradıla bilmədi");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                os.write(data);
            }
            toast("Downloads qovluğuna yadda saxlanıldı: " + name);
        } else {
            File dir = new File(getCacheDir(), "export");
            dir.mkdirs();
            File f = new File(dir, name);
            try (OutputStream os = new java.io.FileOutputStream(f)) { os.write(data); }
            final Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            final String m = mime;
            runOnUiThread(() -> {
                Intent it = new Intent(Intent.ACTION_SEND);
                it.setType(m);
                it.putExtra(Intent.EXTRA_STREAM, uri);
                it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(it, "Faylı yadda saxla / paylaş"));
            });
        }
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
