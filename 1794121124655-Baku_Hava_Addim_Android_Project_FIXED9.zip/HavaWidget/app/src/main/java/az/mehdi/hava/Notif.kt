package az.mehdi.hava

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

object Notif {
    fun channels(c: Context) {
        val m = c.getSystemService(NotificationManager::class.java)
        m.createNotificationChannel(NotificationChannel("steps", "Addımölçən", NotificationManager.IMPORTANCE_MIN))
        m.createNotificationChannel(NotificationChannel("info", "Hava məlumatı", NotificationManager.IMPORTANCE_LOW))
        m.createNotificationChannel(NotificationChannel("alert", "Hava xəbərdarlığı", NotificationManager.IMPORTANCE_HIGH))
        m.createNotificationChannel(NotificationChannel("daily", "Gündəlik proqnoz", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun open(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun stepNotif(c: Context): Notification =
        Notification.Builder(c, "steps")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("${Steps.stepsText(c)} addım")
            .setContentText("Bu gün ${Steps.kmText(c)} gəzdiniz")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open(c))
            .build()

    fun post(c: Context, id: Int, ch: String, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        channels(c)
        val n = Notification.Builder(c, ch)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open(c))
            .setOnlyAlertOnce(ch != "alert")
            .setAutoCancel(true)
            .build()
        c.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

object Alerts {
    fun check(c: Context, w: Weather) {
        val n = w.nowIndex()
        if (n < 0) return
        val o = w.outlook() ?: return
        val h = w.hours[n]
        val p = c.getSharedPreferences("alerts", Context.MODE_PRIVATE)

        // 1) Cari vəziyyət bildirişi (səssiz, yalnız mətn dəyişəndə)
        val title = "Bakı · ${h.temp.roundToInt()}° ${T.desc(h.code)}"
        val sig = title + o.text
        if (p.getString("info", "") != sig) {
            Notif.post(c, 10, "info", title, o.text)
            p.edit().putString("info", sig).apply()
        }

        // 2) Xəbərdarlıq: 3 saat ərzində yağış/qar/tufan/güclü külək və ya hazırda var
        if (o.kind != null && (o.ongoing || o.inHours <= 3) && p.getString("key", "") != o.key) {
            Notif.post(c, 11, "alert", "Hava xəbərdarlığı", o.text)
            p.edit().putString("key", o.key).apply()
        }

        // 3) Səhər proqnozu (07:00–10:59, gündə bir dəfə)
        val today = LocalDate.now(BAKU).toString()
        val hr = LocalDateTime.now(BAKU).hour
        if (hr in 7..10 && p.getString("daily", "") != today) {
            val d = w.upcomingDays().firstOrNull()
            if (d != null) {
                Notif.post(
                    c, 12, "daily", "Bu gün Bakıda",
                    "${T.desc(d.code)} · ${d.max.roundToInt()}°/${d.min.roundToInt()}° · yağış ehtimalı ${d.prob}% · yağıntı ${w.precipHours(d)} saat"
                )
                p.edit().putString("daily", today).apply()
            }
        }
    }
}

object Scheduler {
    private fun net() = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build()

    fun start(c: Context) {
        val req = PeriodicWorkRequestBuilder<UpdateWorker>(60, TimeUnit.MINUTES).setConstraints(net()).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("hava", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun now(c: Context) {
        WorkManager.getInstance(c).enqueue(OneTimeWorkRequestBuilder<UpdateWorker>().setConstraints(net()).build())
    }

    fun hasActivityPerm(c: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

    fun startSteps(c: Context) {
        if (!hasActivityPerm(c)) return
        try {
            c.startForegroundService(Intent(c, StepService::class.java))
        } catch (e: Exception) {
        }
    }
}

class UpdateWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        val w = WeatherApi.refresh(ctx)
        WeatherWidget.refresh(ctx)
        if (w != null) Alerts.check(ctx, w)
        return if (w != null) Result.success() else Result.retry()
    }
}
