package az.mehdi.ottdl

import android.app.Activity
import android.content.ContentValues
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.CookieHandler
import java.net.CookieManager
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var content: LinearLayout
    private lateinit var logView: TextView
    private val logBuf = StringBuilder()
    private var sid: String? = null
    private var baseUrl = DEFAULT_URL
    private var reqId = 1

    companion object { const val DEFAULT_URL = "https://api.ottplayer.tv:9000" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CookieHandler.setDefault(CookieManager())
        prefs = getSharedPreferences("ott", MODE_PRIVATE)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(24))
        }
        root.addView(label("OTT M3U Yüklə", 24f, true))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content)
        root.addView(label("Texniki jurnal (xəta olsa bunu göndər)", 13f, true))
        logView = TextView(this).apply { textSize = 11f; typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        root.addView(logView)
        scroll.addView(root)
        setContentView(scroll)
        showLogin()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(6))
    }

    private fun field(hint: String, v: String, pw: Boolean = false, url: Boolean = false) = EditText(this).apply {
        setHint(hint); setText(v); setSingleLine()
        inputType = when {
            pw -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            url -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            else -> InputType.TYPE_CLASS_TEXT
        }
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun log(s: String) {
        logBuf.append(s).append("\n\n")
        if (logBuf.length > 6000) logBuf.delete(0, logBuf.length - 6000)
        runOnUiThread { logView.text = logBuf.toString() }
    }

    private fun showLogin() {
        content.removeAllViews()
        val user = field("Login (e-poçt)", prefs.getString("user", "") ?: "")
        val pass = field("Şifrə", prefs.getString("pass", "") ?: "", pw = true)
        val url = field("Server", prefs.getString("url", DEFAULT_URL) ?: DEFAULT_URL, url = true)
        val status = label("")
        content.addView(label("Ottplayer hesabın"))
        content.addView(user); content.addView(pass)
        content.addView(label("Server ünvanı (dəyişmək lazım deyil)", 13f))
        content.addView(url)
        content.addView(button("Daxil ol") {
            val u = user.text.toString().trim(); val p = pass.text.toString(); val s = url.text.toString().trim().trimEnd('/')
            if (u.isEmpty() || p.isEmpty()) { status.text = "Login və şifrə yaz"; return@button }
            prefs.edit().putString("user", u).putString("pass", p).putString("url", s).apply()
            baseUrl = s; sid = null
            status.text = "Daxil olunur..."
            Thread {
                try {
                    val r = rpc("login", JSONArray().put(u).put(p).put(deviceId()))
                    sid = when (r) {
                        is String -> r
                        is JSONObject -> listOf("sid", "session", "session_id", "token", "key", "access_token")
                            .firstNotNullOfOrNull { k -> r.optString(k).takeIf { it.isNotEmpty() && it != "null" } }
                        else -> null
                    }
                    val list = toObjects(rpc("get_playlists", JSONArray()))
                    runOnUiThread { showPlaylists(list) }
                } catch (e: Exception) {
                    log("XƏTA: ${e.message}")
                    runOnUiThread { status.text = "Alınmadı: ${e.message}" }
                }
            }.start()
        })
        content.addView(status)
    }

    private fun showPlaylists(list: List<JSONObject>) {
        content.removeAllViews()
        val status = label("")
        content.addView(label("Playlistlər (${list.size})", 18f, true))
        if (list.isEmpty()) content.addView(label("Playlist tapılmadı. Ottplayer.tv saytında playlist əlavə et."))
        list.forEach { pl ->
            val name = str(pl, "name", "title").ifEmpty { "playlist_" + pl.opt("id") }
            content.addView(button("⬇  $name") {
                status.text = "Yüklənir: $name ..."
                Thread {
                    try {
                        val m3u = buildM3u(pl.opt("id"))
                        val where = saveM3u(name, m3u.first)
                        runOnUiThread { status.text = "Hazırdır: ${m3u.second} kanal\n$where" }
                    } catch (e: Exception) {
                        log("XƏTA: ${e.message}")
                        runOnUiThread { status.text = "Alınmadı: ${e.message}" }
                    }
                }.start()
            })
        }
        content.addView(status)
        content.addView(button("Çıxış") { sid = null; showLogin() })
    }

    // ---------- API ----------
    private fun deviceId(): String {
        var d = prefs.getString("dev", null)
        if (d == null) { d = UUID.randomUUID().toString().replace("-", "").take(16); prefs.edit().putString("dev", d).apply() }
        return d
    }

    private fun rpc(method: String, params: JSONArray): Any? {
        val body = JSONObject().put("id", reqId++).put("method", method).put("params", params)
        sid?.let { body.put("sid", it) }
        val conn = URL(baseUrl).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000; conn.readTimeout = 60000; conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        sid?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        log("$method -> HTTP $code (${text.length} bayt)\n${text.take(700)}")
        val t = text.trim()
        val json = when {
            t.startsWith("[") -> JSONObject().put("result", JSONArray(t))
            t.startsWith("{") -> JSONObject(t)
            else -> throw Exception("Gözlənilməyən cavab (HTTP $code)")
        }
        val err = json.opt("error")
        if (err != null && err != JSONObject.NULL) throw Exception("API: $err")
        return if (json.has("result")) json.opt("result") else json
    }

    private fun toObjects(r: Any?): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        fun fromArr(a: JSONArray) { for (i in 0 until a.length()) a.optJSONObject(i)?.let { out.add(it) } }
        when (r) {
            is JSONArray -> fromArr(r)
            is JSONObject -> {
                val arr = r.keys().asSequence().map { r.opt(it) }.firstOrNull { it is JSONArray } as? JSONArray
                if (arr != null) fromArr(arr)
                else r.keys().forEach { k -> r.optJSONObject(k)?.let { out.add(it) } }
            }
        }
        return out
    }

    private fun str(o: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = o.opt(k) ?: continue
            if (v == JSONObject.NULL) continue
            val s = if (v is JSONObject) v.optString("name") else v.toString()
            if (s.isNotEmpty() && s != "null") return s
        }
        return ""
    }

    private fun buildM3u(playlistId: Any?): Pair<String, Int> {
        val groups = HashMap<String, String>()
        try {
            toObjects(rpc("get_groups", JSONArray())).forEach { g ->
                groups[g.opt("id").toString()] = str(g, "name", "title")
            }
        } catch (e: Exception) { log("get_groups keçildi: ${e.message}") }

        val channels = toObjects(rpc("get_channels", JSONArray().put(playlistId)))
        val sb = StringBuilder("#EXTM3U\n")
        var n = 0
        for (ch in channels) {
            val url = str(ch, "url", "stream", "stream_url", "uri", "src", "link", "source")
            if (url.isEmpty()) continue
            val name = str(ch, "name", "title", "channel_name").replace("\n", " ").ifEmpty { "Kanal ${n + 1}" }
            val logo = str(ch, "icon", "logo", "image", "picture", "tvg_logo").replace("\"", "'")
            var grp = str(ch, "group", "group_name", "category", "category_name")
            if (grp.isEmpty()) grp = groups[ch.opt("group_id").toString()] ?: ""
            sb.append("#EXTINF:-1")
            if (logo.isNotEmpty()) sb.append(" tvg-logo=\"$logo\"")
            if (grp.isNotEmpty()) sb.append(" group-title=\"${grp.replace("\"", "'")}\"")
            sb.append(",").append(name).append("\n").append(url).append("\n")
            n++
        }
        if (n == 0) throw Exception("Kanal tapılmadı (jurnala bax)")
        return Pair(sb.toString(), n)
    }

    // ---------- Save ----------
    private fun saveM3u(name: String, text: String): String {
        val fn = name.replace(Regex("[^\\w.-]+"), "_") + ".m3u"
        return if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fn)
                put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw Exception("Fayl yaradıla bilmədi")
            contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
            "Downloads/$fn"
        } else {
            val f = File(getExternalFilesDir(null), fn)
            f.writeText(text)
            f.absolutePath
        }
    }
}
