package az.mehdi.hava

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import kotlin.math.roundToInt

/** Yalnız şarja taxılanda: 100%-ə qalan vaxt (taxılmayıbsa boş mətn) */
object Battery {
    /** Telefon hazırda şarja taxılıdır? */
    fun charging(c: Context): Boolean = try {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i != null && (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 ||
            i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING)
    } catch (e: Exception) { false }

    /** Batareya faizi (bilinmirsə -1) */
    fun pct(c: Context): Int = try {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (l < 0 || sc <= 0) -1 else (l * 100f / sc).roundToInt()
    } catch (e: Exception) { -1 }

    private fun dur(min: Int): String = when {
        min < 60 -> "$min Dəq"
        min % 60 == 0 -> "${min / 60} saat"
        else -> "${min / 60} saat ${min % 60} Dəq"
    }

    fun text(c: Context): String {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return ""
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return ""
            val pct = (level * 100f / scale).roundToInt()
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            when {
                status == BatteryManager.BATTERY_STATUS_FULL || (plugged && pct >= 100) -> ""
                status == BatteryManager.BATTERY_STATUS_CHARGING || plugged -> {
                    var ms = -1L
                    if (Build.VERSION.SDK_INT >= 28) {
                        ms = c.getSystemService(BatteryManager::class.java).computeChargeTimeRemaining()
                    }
                    if (ms > 0) "⚡ ${dur((ms / 60000).toInt().coerceAtLeast(1))}"
                    else "⚡ …"
                }
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }
    }
}
