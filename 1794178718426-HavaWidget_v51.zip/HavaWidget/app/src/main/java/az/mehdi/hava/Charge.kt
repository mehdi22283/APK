package az.mehdi.hava

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Telefon şarja taxılan kimi vidcetdəki "⚡ şarj dəqiqəsi" dərhal görünsün.
 * ACTION_POWER_CONNECTED manifestdə işləmir (Android 8+), fon xidməti də şarj yeyər —
 * ona görə "yalnız şarjdadırsa" şərtli WorkManager işi istifadə olunur.
 * Şarj zamanı vidcet hər ~3 dəq yenilənir (internet yoxdur, yalnız yaddaşdakı məlumat), çıxarılanda göstərici silinir.
 */
object ChargeWatch {
    private const val ON = "charge_on"
    private const val TICK = "charge_tick"

    /** Növbəti şarja taxılmanı gözləyir (artıq gözləyirsə toxunmur) */
    fun arm(c: Context) {
        try {
            val req = OneTimeWorkRequestBuilder<ChargeOnWorker>()
                .setConstraints(Constraints.Builder().setRequiresCharging(true).build())
                .build()
            WorkManager.getInstance(c).enqueueUniqueWork(ON, ExistingWorkPolicy.KEEP, req)
        } catch (e: Exception) { }
    }

    fun tick(c: Context, minutes: Long, policy: ExistingWorkPolicy) {
        try {
            val req = OneTimeWorkRequestBuilder<ChargeTickWorker>()
                .setInitialDelay(minutes, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(c).enqueueUniqueWork(TICK, policy, req)
        } catch (e: Exception) { }
    }

    /** 100%-də göstərici gizlidir, ona görə seyrək yoxlanır */
    fun delay(c: Context): Long = if (Battery.pct(c) >= 100) 20L else 3L
}

/** Şarja taxılan an işləyir */
class ChargeOnWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        WeatherWidget.refresh(ctx)
        ChargeWatch.tick(ctx, ChargeWatch.delay(ctx), ExistingWorkPolicy.REPLACE)
        return Result.success()
    }
}

/** Şarj davam etdikcə vidceti yeniləyir; çıxarılıbsa göstəricini silib növbəti taxılmanı gözləyir */
class ChargeTickWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        WeatherWidget.refresh(ctx)
        if (Battery.charging(ctx)) ChargeWatch.tick(ctx, ChargeWatch.delay(ctx), ExistingWorkPolicy.APPEND_OR_REPLACE)
        else ChargeWatch.arm(ctx)
        return Result.success()
    }
}
