package az.mehdi.hava

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0F1B2A")
    private val CARD = Color.parseColor("#1B2B3F")
    private val GREY = Color.parseColor("#90A4AE")
    private val BLUE = Color.parseColor("#4FC3F7")
    private val YELLOW = Color.parseColor("#FFD54F")
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private var stepsView: TextView? = null
    private var kmView: TextView? = null
    private val ticker = object : Runnable {
        override fun run() {
            updateSteps()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        sv.addView(root)
        setContentView(sv)
        Scheduler.start(this)
        Midnight.schedule(this)
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        render()
        handler.post(ticker)
        if (WeatherApi.ageMin(this) > 15) fetch()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun fetch() {
        Thread {
            val w = WeatherApi.refresh(this)
            WeatherWidget.refresh(this)
            if (w != null) Alerts.check(this, w)
            runOnUiThread {
                if (w != null) render()
                else Toast.makeText(this, "İnternet yoxdur, məlumat yenilənmədi", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else Scheduler.startSteps(this)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        Scheduler.startSteps(this)
        Scheduler.now(this)
    }

    // ---------- UI ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, sp: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false, parent: LinearLayout = root): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        parent.addView(t)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(CARD)
        bg.cornerRadius = dp(16).toFloat()
        c.background = bg
        c.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        root.addView(c, lp)
        return c
    }

    private fun section(s: String) {
        val t = label(s, 14f, GREY, true)
        t.setPadding(0, dp(16), 0, 0)
    }

    private fun row(p: LinearLayout, a: String, b: String, c: String, d: String, hi: Boolean) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(0, dp(5), 0, dp(5))
        fun cell(s: String, wt: Float, col: Int, bold: Boolean) {
            val t = TextView(this)
            t.text = s
            t.textSize = 13f
            t.setTextColor(col)
            if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, wt))
        }
        cell(a, 2.1f, GREY, false)
        cell(b, 3.6f, Color.WHITE, false)
        cell(c, 2.0f, Color.WHITE, true)
        cell(d, 1.7f, if (hi) BLUE else GREY, hi)
        p.addView(r)
    }

    private fun button(caption: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = caption
        b.setOnClickListener { onClick() }
        root.addView(b)
    }

    private fun render() {
        root.removeAllViews()
        stepsView = null
        kmView = null
        val w = WeatherApi.cached(this)
        val n = w?.nowIndex() ?: -1
        label("Bakı", 14f, GREY, true)
        if (w == null || n < 0) {
            label("Məlumat yüklənir…", 18f, Color.WHITE, true)
        } else {
            val h = w.hours[n]
            label("${T.icon(h.code)} ${h.temp.roundToInt()}°", 56f, Color.WHITE, true)
            label("${T.desc(h.code)}  ·  💨 ${h.wind.roundToInt()} km/s", 16f)

            val o = w.outlook()
            if (o != null) label(o.text, 17f, YELLOW, true, card())

            section("Növbəti saatlar")
            val hc = card()
            listOf(1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 21, 24).filter { n + it < w.hours.size }.forEach {
                val x = w.hours[n + it]
                row(hc, x.time.substring(11, 16), "${T.icon(x.code)} ${T.desc(x.code)}", "${x.temp.roundToInt()}°", "💧${x.prob}%", x.prob >= 50)
            }

            section("Bu gün və növbəti 7 gün")
            val dc = card()
            w.upcomingDays().forEachIndexed { i, d ->
                val name = if (i == 0) "Bu gün" else "${T.dayName(d.date)} ${d.date.substring(8, 10)}.${d.date.substring(5, 7)}"
                row(dc, name, "${T.icon(d.code)} ${T.desc(d.code)}", "${d.max.roundToInt()}°/${d.min.roundToInt()}°", "💧${d.prob}%", d.prob >= 50)
            }
        }

        section("Addımölçən")
        val sc = card()
        stepsView = label("", 26f, Color.WHITE, true, sc)
        kmView = label("", 18f, BLUE, true, sc)
        val sm = getSystemService(SensorManager::class.java)
        if (sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null) {
            label("Bu cihazda addımölçən sensoru yoxdur", 13f, GREY, false, sc)
        }
        label("Boyunuz (sm) — km hesabı üçün:", 13f, GREY, false, sc)
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setText(Steps.height(this).toString())
        et.setTextColor(Color.WHITE)
        sc.addView(et)
        val save = Button(this)
        save.text = "Saxla"
        save.setOnClickListener {
            val v = et.text.toString().toIntOrNull()
            if (v != null && v in 100..230) {
                Steps.setHeight(this, v)
                updateSteps()
                WeatherWidget.refresh(this)
                Toast.makeText(this, "Saxlandı", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "100–230 arası yazın", Toast.LENGTH_SHORT).show()
        }
        sc.addView(save)
        updateSteps()

        val gap = TextView(this)
        gap.height = dp(12)
        root.addView(gap)
        button("🔄 Yenilə") { fetch() }
        button("➕ Ana ekrana widget əlavə et") { pinWidget() }
    }

    private fun updateSteps() {
        stepsView?.text = "🚶 ${Steps.stepsText(this)} addım"
        kmView?.text = "📏 Bu gün ${Steps.kmText(this)} gəzdiniz"
    }

    private fun pinWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) {
            m.requestPinAppWidget(ComponentName(this, WeatherWidget::class.java), null, null)
        } else {
            Toast.makeText(this, "Ana ekranda boş yerə uzun basın → Widgetlər → Bakı Hava", Toast.LENGTH_LONG).show()
        }
    }
}
