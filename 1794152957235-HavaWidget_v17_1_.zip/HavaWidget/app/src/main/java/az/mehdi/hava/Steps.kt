package az.mehdi.hava

import android.app.Notification
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.app.NotificationManager
import java.time.LocalDate
import java.util.Locale

object Steps {
    private fun p(c: Context) = c.getSharedPreferences("steps", Context.MODE_PRIVATE)

    /** Sensor dəyəri (açılışdan bəri addımlar) -> bu günün addımları */
    fun onSensor(c: Context, raw: Float): Int {
        val p = p(c)
        val today = LocalDate.now(BAKU).toString()
        var base = p.getFloat("base", raw)
        var offset = p.getInt("offset", 0)
        if (p.getString("day", "") != today) {
            base = raw
            offset = 0
        } else if (raw < p.getFloat("lastRaw", raw)) { // telefon yenidən başladılıb
            offset = p.getInt("steps", 0)
            base = 0f
        }
        val steps = offset + (raw - base).toInt()
        // dəyişiklik yoxdursa yazma (batareya/yaddaş)
        if (p.getString("day", "") == today && p.getInt("steps", -1) == steps && p.getFloat("lastRaw", -1f) == raw) return steps
        p.edit().putString("day", today).putFloat("base", base).putInt("offset", offset)
            .putFloat("lastRaw", raw).putInt("steps", steps).apply()
        return steps
    }

    fun get(c: Context): Int {
        val p = p(c)
        return if (p.getString("day", "") == LocalDate.now(BAKU).toString()) p.getInt("steps", 0) else 0
    }

    /** Boy sabitdir: 180 sm */
    @Suppress("UNUSED_PARAMETER")
    fun height(c: Context): Int = 180

    // addım uzunluğu ≈ boy × 0.415
    fun km(c: Context): Double = get(c) * height(c) * 0.415 / 100000.0
    fun kmText(c: Context): String = String.format(Locale.US, "%.2f km", km(c))
    fun stepsText(c: Context): String = String.format(Locale.US, "%,d", get(c)).replace(',', ' ')
}

class StepService : Service(), SensorEventListener {
    private var lastWidget = 0L
    private var lastSteps = -1
    private var sm: SensorManager? = null
    private var lastBatt = 0L
    private val battRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val t = SystemClock.elapsedRealtime()
            if (i.action == Intent.ACTION_BATTERY_CHANGED && t - lastBatt < 120_000) return
            lastBatt = t
            WeatherWidget.refresh(c)
        }
    }

    companion object {
        @Volatile private var inst: StepService? = null

        /** Toplu yığılmış sensor dəyərlərini dərhal gətirir (tətbiq açılanda) */
        fun flush() {
            try {
                val i = inst ?: return
                i.sm?.flush(i)
            } catch (e: Exception) {
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Notif.channels(this)
        val n: Notification = Notif.stepNotif(this)
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        else startForeground(1, n)
        val sm = getSystemService(SensorManager::class.java)
        this.sm = sm
        inst = this
        val bf = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(battRx, bf, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(battRx, bf)
        } catch (e: Exception) {
        }
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        // Maksimum batareya qənaəti: sensor 15 dəq. toplu çatdırılır (addımları aparat özü sayır,
        // prosessor hər addımda oyanmır). Tətbiq açılanda flush() ilə dərhal yenilənir.
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL, 900_000_000) else stopSelf()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val steps = Steps.onSensor(this, e.values[0])
        if (steps != lastSteps) {
            lastSteps = steps
            // bildiriş və widget ən çox 10 dəq.-də bir yenilənir (batareya)
            val t = SystemClock.elapsedRealtime()
            if (t - lastWidget > 600_000) {
                lastWidget = t
                getSystemService(NotificationManager::class.java).notify(1, Notif.stepNotif(this))
                WeatherWidget.refresh(this)
            }
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        inst = null
        try { unregisterReceiver(battRx) } catch (e: Exception) { }
        getSystemService(SensorManager::class.java).unregisterListener(this)
        super.onDestroy()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.start(c)
        Midnight.schedule(c)
        Scheduler.now(c)
        Scheduler.startSteps(c)
        WeatherWidget.refresh(c)
    }
}
