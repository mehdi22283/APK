package az.mehdi.hava

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import kotlin.math.roundToInt

/** Yalnız şarja taxılanda: 100%-ə qalan vaxt (taxılmayıbsa boş mətn) */
object Battery {
    private fun dur(min: Int): String = when {
        min < 60 -> "$min dəq"
        min % 60 == 0 -> "${min / 60} saat"
        else -> "${min / 60} saat ${min % 60} dəq"
    }

    fun text(c: Context): String {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return ""
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return ""
            val pct = (level * 100f / scale).roundToInt()
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            when {
                status == BatteryManager.BATTERY_STATUS_FULL || (plugged && pct >= 100) -> "Şarj 100% · tam doludur"
                status == BatteryManager.BATTERY_STATUS_CHARGING || plugged -> {
                    var ms = -1L
                    if (Build.VERSION.SDK_INT >= 28) {
                        ms = c.getSystemService(BatteryManager::class.java).computeChargeTimeRemaining()
                    }
                    if (ms > 0) "Şarj $pct% · 100%-ə ${dur((ms / 60000).toInt().coerceAtLeast(1))} qalıb"
                    else "Şarj $pct% · 100%-ə qalan vaxt hesablanır…"
                }
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }
    }
}
