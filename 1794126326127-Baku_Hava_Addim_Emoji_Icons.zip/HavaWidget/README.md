# Bakı Hava (HavaWidget)
- Bakı: bu gün + 7 gün, hər gün üçün yağış ehtimalı (Open-Meteo, API açarı lazım deyil)
- "3 saat sonra yağış yağacaq" tipli proqnoz — tətbiqdə, widgetdə və bildirişdə
- Yağış / qar / tufan / güclü külək xəbərdarlığı (bildiriş), səhər proqnozu
- UV indeksi (indiki + günün maksimumu) və hava keyfiyyəti AQI + PM2.5 (Open-Meteo Air Quality, açar lazım deyil); koordinat 40.427565, 49.822425
- Addımölçən + km (boyunuza görə), widgetdə də görünür
- Widget: ana ekran → uzun bas → Widgetlər → Bakı Hava (və ya tətbiqdəki "widget əlavə et" düyməsi)

Build: layihəni GitHub-a yükləyin → Actions → "Build APK" → artifact: HavaWidget-apk

## Yeniliklər (FIXED9)
- Widgetin kənar boşluqları sıfırlandı (Xiaomi 12T)
- Tarixin altında hər gün üçün fərqli "günün sözü" 💡 və "atalar sözü" 📜 (365 ədəd; fayllar: app/src/main/res/raw/gunun_sozu.txt və atalar_sozu.txt — hər sətir bir cümlə, istədiyiniz kimi dəyişə bilərsiniz)
- 8 günlük sırada çərçivə: yağış → göy, güclü külək (≥40 km/saat) → boz, qar → ağ

## Yeniliklər (FIXED10)
- Saat, hava və 7 günlük proqnoz arasındakı boşluqlar silindi
- Android emojiləri əvəzinə tətbiqin öz vektor ikonları (res/drawable/ic_*.xml)
- Şrift: Arial ölçülü Liberation Sans (res/font/arial_*.ttf), bütün tətbiqdə və widgetdə
- Bu gün və 7 günlük proqnozda yağıntı saatları (Open-Meteo precipitation_hours); widgetdə, tətbiqdə və səhər bildirişində

## FIXED11
- Widgetdə xüsusi şrift faylı "Widget yüklənə bilmir" xətası verə bilirdi; şrift sistemin Sans (sans-serif) şriftinə keçirildi (widget + tətbiq)

## FIXED12
- Tətbiqdə canlı (animasiyalı) ikonlar: günəş şüaları fırlanır, buludlar yırğalanır, yağış/qar düşür, ildırım parlayır, ürək döyünür, saatın əqrəbi dönür və s. (res/drawable/ic_*_a.xml, res/animator/)
- Widgetdə Android animasiyanı dəstəkləmir, orada adi ikonlar qalır

## FIXED13
- Canlı (animasiyalı) ikonlar silindi; əvəzinə daha canlı rəngli, çoxqatlı sabit ikonlar (günəş, bulud, damla, ürək və s.)

## FIXED14
- Qar ikonu düzəldildi: bulud + altında üç qar dənəsi

## FIXED15
- Qar ikonları simmetrik edildi: buludun hər iki tərəfi eyni, altında bərabər aralıqlı üç qar dənəsi; iri qar dənəsi tam altıbucaqlı simmetriyadadır

## FIXED16
- Bütün ikonlar yenidən çəkildi: rəngli dairəvi lövhə üzərində ağ simvollar (hava, külək, günəş çıxma/batma, addım, ürək və s.)
- Şrift standart (sistem şrifti): xüsusi şrift təyini tamamilə silindi
