package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.SurfaceView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** Media3 üçün HTTP müştərisi: vaxtı keçmiş/özü imzalı sertifikatlı IPTV serverləri üçün yoxlama söndürülüb (mpv-dəki tls-verify=no kimi). */
private object StreamHttp {
    val client: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val b = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .protocols(listOf(Protocol.HTTP_1_1))
            .followRedirects(true)
            .followSslRedirects(true)
            .hostnameVerifier { _, _ -> true }
        runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            b.sslSocketFactory(ctx.socketFactory, trustAll)
        }
        b.build()
    }
}

/**
 * Birinci mühərrik: Media3 (ExoPlayer). Yalnız http/https (m3u8, mpd, ts, mp4 ...).
 *
 * Codec/format dəstəklənmirsə [PlayerCallback.onCodecUnsupported] ilə DƏRHAL xəbər verir
 * (PlayerManager o anda mpv-yə keçir). Aşkar edilən hallar:
 *  - onTracksChanged: video və ya səs qrupu var, amma heç bir treki dekodlana bilmir (səssiz/qara ekranda ilişməsin);
 *  - onPlayerError: dekoder açılmadı/dekodlama xətası/format dəstəklənmir/konteyner tanınmadı.
 * Bütün çağırışlar yalnız əsas (UI) thread-dədir.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class Media3Engine(
    context: Context,
    private val view: SurfaceView,
    private val callback: PlayerCallback
) {
    companion object {
        private const val TAG = "IPTV-MEDIA3"
        private const val DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"

        // MPEG-TS (IPTV-də ən çox rast gəlinən): AUD olmayan H.264, non-IDR açar kadrlar, HDMV DTS səsi.
        private const val TS_FLAGS =
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS

        private fun isCodecError(code: Int): Boolean = when (code) {
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> true
            else -> false
        }
    }

    private val appContext = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())

    private var player: ExoPlayer? = null
    private var released = false
    private var generation = 0
    private var url: String? = null
    private var timeoutMs = 5_000L
    private var playing = false
    private var buffering = false
    private var lastBufferingAt = 0L
    private var firstFrame = false
    private var hasVideoGroup = false
    private var tracksKnown = false
    private var openTimeout: Runnable? = null
    private val speed = SpeedMeter()

    private val listener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            if (!isCurrent()) return
            var v = 0; var vOk = false; var a = 0; var aOk = false
            for (g in tracks.groups) {
                when (g.type) {
                    C.TRACK_TYPE_VIDEO -> { v++; if (g.isSupported(false)) vOk = true }
                    C.TRACK_TYPE_AUDIO -> { a++; if (g.isSupported(false)) aOk = true }
                }
            }
            if (v + a == 0) return // treklər hələ məlum deyil
            hasVideoGroup = v > 0
            tracksKnown = true
            if ((v > 0 && !vOk) || (a > 0 && !aOk)) {
                val what = if (v > 0 && !vOk) "video" else "səs"
                codecFail("Media3: $what codec-i dəstəklənmir")
                return
            }
            maybeMarkPlaying()
        }

        override fun onRenderedFirstFrame() {
            if (!isCurrent()) return
            firstFrame = true
            maybeMarkPlaying()
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (!isCurrent()) return
            when (state) {
                Player.STATE_BUFFERING -> if (playing && !buffering) {
                    buffering = true
                    lastBufferingAt = SystemClock.elapsedRealtime()
                    callback.onBuffering(true)
                }
                Player.STATE_READY -> {
                    if (buffering) { buffering = false; callback.onBuffering(false) }
                    maybeMarkPlaying()
                }
                Player.STATE_ENDED -> failNow("Yayım bitdi")
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            if (!isCurrent()) return
            Log.w(TAG, "Xəta: ${error.errorCodeName}", error)
            if (isCodecError(error.errorCode)) codecFail("Media3: ${error.errorCodeName}")
            else failNow("Media3: ${error.errorCodeName}")
        }
    }

    private fun isCurrent(): Boolean {
        val p = player ?: return false
        return !released && url != null && p.currentMediaItem?.mediaId == generation.toString()
    }

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        // Əvvəl cihazın MediaCodec (HW) dekoderi; açmasa FFmpeg (SW) dekoderləri (NextLib) işə düşür.
        // Hər ikisi də olmasa onCodecUnsupported → mpv.
        val renderers = NextRenderersFactory(appContext)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        // 2 GB RAM: kiçik bufer (mpv ilə eyni ttutum).
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 20_000, 1_500, 2_500)
            .setTargetBufferBytes(24 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        val p = ExoPlayer.Builder(appContext, renderers)
            .setLoadControl(load)
            .build()
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            false
        )
        p.addListener(listener)
        player = p
        return p
    }

    private fun maybeMarkPlaying() {
        if (playing || url == null) return
        val p = player ?: return
        if (p.playbackState != Player.STATE_READY) return
        // Görüntülü yayım: ilk kadr çəkilib; yalnız səs (radio): video qrupu yoxdur.
        if (!(firstFrame || (tracksKnown && !hasVideoGroup))) return
        playing = true
        cancelTimeout()
        callback.onPlaying()
    }

    private fun codecFail(message: String) {
        playing = false
        cancelTimeout()
        callback.onCodecUnsupported(message)
    }

    private fun failNow(message: String) {
        playing = false
        cancelTimeout()
        callback.onFailed(message)
    }

    private fun cancelTimeout() {
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
    }

    private fun armTimeout(g: Int) {
        cancelTimeout()
        val r = Runnable {
            openTimeout = null
            if (released || g != generation || url == null || playing) return@Runnable
            failNow("Media3 ${timeoutMs / 1000} saniyədə açmadı")
        }
        openTimeout = r
        ui.postDelayed(r, timeoutMs)
    }

    fun play(newUrl: String, ua: String?, ref: String?, timeoutMs: Long) {
        if (released) return
        val g = ++generation
        cancelTimeout()
        url = newUrl
        this.timeoutMs = timeoutMs
        playing = false
        buffering = false
        firstFrame = false
        hasVideoGroup = false
        tracksKnown = false
        speed.reset()
        try {
            val p = ensurePlayer()
            p.stop()
            p.clearMediaItems()
            val http = OkHttpDataSource.Factory(StreamHttp.client)
                .setUserAgent(ua?.takeIf { it.isNotBlank() } ?: DEFAULT_UA)
            ref?.takeIf { it.isNotBlank() }?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
            val low = newUrl.lowercase()
            val item = MediaItem.Builder()
                .setUri(newUrl)
                .setMediaId(g.toString())
                .apply {
                    when {
                        low.contains(".m3u8") -> setMimeType(MimeTypes.APPLICATION_M3U8)
                        low.contains(".mpd") -> setMimeType(MimeTypes.APPLICATION_MPD)
                    }
                }
                .build()
            val ds = DefaultDataSource.Factory(appContext, http)
            val src = if (low.contains(".m3u8")) {
                HlsMediaSource.Factory(ds)
                    .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, false))
                    .createMediaSource(item)
            } else {
                DefaultMediaSourceFactory(ds, DefaultExtractorsFactory().setTsExtractorFlags(TS_FLAGS))
                    .createMediaSource(item)
            }
            p.setVideoSurfaceView(view)
            p.setMediaSource(src)
            p.prepare()
            p.playWhenReady = true
            armTimeout(g)
        } catch (t: Throwable) {
            Log.e(TAG, "Media3 başladılmadı", t)
            ui.post { if (!released && g == generation && url != null) failNow("Media3 işə düşmədi") }
        }
    }

    fun stop() {
        generation++
        cancelTimeout()
        url = null
        playing = false
        buffering = false
        player?.let { runCatching { it.stop(); it.clearMediaItems() } }
    }

    /** mpv-yə keçməzdən əvvəl: dekoder və video səthi tam azad edilir (mpv eyni səthi götürəcək). */
    fun releaseSurface() {
        stop()
        player?.let { runCatching { it.clearVideoSurfaceView(view) } }
    }

    fun stopForBackground() = stop()

    fun togglePause() {
        val p = player ?: return
        if (released || !playing) return
        p.playWhenReady = !p.playWhenReady
    }

    /** Oynatma mövqeyi (ms); yayım donanda dəyişmir. Naməlum: -1. */
    fun position(): Long {
        val p = player ?: return -1L
        return if (!playing) -1L else p.currentPosition
    }

    fun stats(): PlayerStats? {
        val p = player ?: return null
        if (released || !playing) return null
        val now = SystemClock.elapsedRealtime()
        val level = when {
            buffering -> 2
            now - lastBufferingAt < 12_000L -> 1
            else -> 0
        }
        val bps = speed.sample(uidRxBytes(), now)
        val vb = p.videoFormat?.bitrate ?: -1
        val ab = p.audioFormat?.bitrate ?: -1
        val trackBr = if (vb > 0) (vb + maxOf(ab, 0)).toLong() else 0L
        val br = if (trackBr > 0) trackBr else bps
        val size = p.videoSize
        return PlayerStats(size.width, size.height, p.totalBufferedDuration, level, bps, "", br)
    }

    fun release() {
        if (released) return
        released = true
        generation++
        cancelTimeout()
        url = null
        player?.let { runCatching { it.removeListener(listener); it.release() } }
        player = null
    }
}
