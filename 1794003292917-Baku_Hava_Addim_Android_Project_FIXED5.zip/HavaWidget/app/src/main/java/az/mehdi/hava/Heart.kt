package az.mehdi.hava

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Ürək döyüntüsü ölçmələrinin tarixçəsi (ən yenisi birinci). */
object Heart {
    private fun p(c: Context) = c.getSharedPreferences("heart", Context.MODE_PRIVATE)

    fun save(c: Context, bpm: Int, front: Boolean = false) {
        val old = p(c).getString("hist", "") ?: ""
        val list = (listOf("${System.currentTimeMillis()},$bpm,${if (front) "f" else "r"}") + old.split(";").filter { it.isNotBlank() }).take(10)
        p(c).edit().putString("hist", list.joinToString(";")).apply()
    }

    fun history(c: Context): List<Pair<Long, Int>> =
        (p(c).getString("hist", "") ?: "").split(";").mapNotNull {
            val a = it.split(",")
            val t = a.getOrNull(0)?.toLongOrNull()
            val b = a.getOrNull(1)?.toIntOrNull()
            if (t != null && b != null) Pair(t, b) else null
        }

    /** (vaxt, bpm, ön kameradır?) */
    fun historyFull(c: Context): List<Triple<Long, Int, Boolean>> =
        (p(c).getString("hist", "") ?: "").split(";").mapNotNull {
            val a = it.split(",")
            val t = a.getOrNull(0)?.toLongOrNull()
            val b = a.getOrNull(1)?.toIntOrNull()
            if (t != null && b != null) Triple(t, b, a.getOrNull(2) == "f") else null
        }

    fun last(c: Context): Pair<Long, Int>? = history(c).firstOrNull()

    fun timeText(ts: Long): String {
        val z = Instant.ofEpochMilli(ts).atZone(BAKU)
        return if (z.toLocalDate() == LocalDate.now(BAKU)) z.format(DateTimeFormatter.ofPattern("HH:mm"))
        else z.format(DateTimeFormatter.ofPattern("dd.MM HH:mm"))
    }

    fun open(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 1, Intent(c, HeartActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}
