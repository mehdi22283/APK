package az.m3u.sinayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.webkit.CookieManager
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** writer(ad, yazıcı) → faylı Downloads-a yazır (MediaStore / birbaşa), nəticə Uri. */
typealias DlWriter = (String, (OutputStream) -> Unit) -> Uri

/**
 * Tətbiqin öz endirmə meneceri: server "Range" dəstəkləyirsə fayl hissələrə bölünür və
 * paralel (CONNS bağlantı) endirilir — tək axına nisbətən ciddi sürət artımı.
 * Dəstək yoxdursa / ölçü məlum deyilsə tək axınla (böyük buferlə) endirilir.
 * Endirmə fon xidməti ilə qorunur: tətbiqdən çıxılsa da davam edir. Bitəndə fayl Downloads-a yazılır.
 */
object FastDl {
    private const val CONNS = 8                 // paralel bağlantı sayı
    private const val MIN_PARALLEL = 2L shl 20  // 2 MB-dan kiçik fayl tək axınla
    private const val BUF = 256 * 1024
    private const val RETRIES = 4

    private class Res(val finalUrl: String, val headers: Map<String, String>, val total: Long, val ranges: Boolean)

    fun start(ctx: Context, url: String, ua: String?, referer: String?, name: String,
              writer: DlWriter, onDone: (ok: Boolean, msg: String, uri: Uri?) -> Unit) {
        val app = ctx.applicationContext
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "yukleme_" + System.currentTimeMillis() + ".zip" }
        val cookie = try { CookieManager.getInstance().getCookie(url) } catch (e: Exception) { null }
        KeepAlive.begin(app)
        val dn = DlNotif(app, safe, -1)
        Thread {
            var tmp: File? = null
            var saved: Uri? = null
            var size = 0L
            try {
                val base = LinkedHashMap<String, String>()
                base["Accept-Encoding"] = "identity"
                if (!ua.isNullOrBlank()) base["User-Agent"] = ua
                if (!referer.isNullOrBlank()) base["Referer"] = referer
                if (!cookie.isNullOrBlank()) base["Cookie"] = cookie
                val res = resolve(url, base)
                dn.setTotal(res.total)
                if (res.ranges && res.total >= MIN_PARALLEL) {
                    val f = File(app.cacheDir, "fastdl_" + System.nanoTime() + ".part")
                    tmp = f
                    parallel(res, f, dn)
                    if (f.length() != res.total) throw IOException("Fayl tam deyil (${f.length()}/${res.total})")
                    saved = writer(safe) { out -> f.inputStream().use { it.copyTo(out, 1 shl 20) } }; size = f.length()
                } else {
                    // tək axın: birbaşa Downloads-a yazılır
                    saved = writer(safe) { out ->
                        val c = open(res.finalUrl, res.headers, null)
                        try {
                            c.inputStream.use { ins ->
                                val buf = ByteArray(1 shl 20)
                                while (true) { val n = ins.read(buf); if (n < 0) break; out.write(buf, 0, n); dn.add(n.toLong()) }
                            }
                        } finally { c.disconnect() }
                    }
                }
                if (size == 0L) size = maxOf(res.total, 0L)
                saved?.let { DlLog.add(app, safe, it.toString(), size) }
                dn.finish(safe, if (safe.endsWith(".apk", true)) saved else null)
                onDone(true, safe, saved)
            } catch (e: Exception) {
                dn.fail(e.message ?: e.toString())
                onDone(false, e.message ?: e.toString(), null)
            } finally {
                tmp?.delete()
                KeepAlive.end(app)
            }
        }.start()
    }

    /** Yönləndirmələri əl ilə izləyir (host dəyişəndə Cookie/Referer göndərilmir), ölçünü və Range dəstəyini öyrənir. */
    private fun resolve(url: String, base: Map<String, String>): Res {
        var cur = url
        var h = LinkedHashMap(base)
        repeat(8) {
            val c = open(cur, h, "bytes=0-0", follow = false)
            try {
                val code = c.responseCode
                if (code in 300..399 && code != 304) {
                    val loc = c.getHeaderField("Location") ?: throw IOException("redirect without location")
                    val next = URL(URL(cur), loc).toString()
                    if (URL(next).host != URL(cur).host) { h = LinkedHashMap(h); h.remove("Cookie"); h.remove("Referer") }
                    cur = next
                } else if (code == 206) {
                    val total = c.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull() ?: -1L
                    return Res(cur, h, total, total > 0)
                } else if (code in 200..299) {
                    return Res(cur, h, c.contentLengthLong, false)   // Range dəstəklənmir
                } else throw IOException("HTTP $code")
            } finally { c.disconnect() }
        }
        throw IOException("həddindən çox yönləndirmə")
    }

    private fun open(url: String, h: Map<String, String>, range: String?, follow: Boolean = true): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 30000; c.instanceFollowRedirects = follow
        for ((k, v) in h) c.setRequestProperty(k, v)
        if (range != null) c.setRequestProperty("Range", range)
        return c
    }

    /** Fayl kiçik hissələrə bölünür, CONNS işçi növbədən hissə götürüb paralel endirir; xətalı hissə təkrarlanır. */
    private fun parallel(r: Res, out: File, dn: DlNotif) {
        val total = r.total
        RandomAccessFile(out, "rw").use { raf ->
            raf.setLength(total)
            val ch = raf.channel
            val chunk = (total / (CONNS * 4)).coerceIn(1L shl 20, 8L shl 20)
            val q = ConcurrentLinkedQueue<LongArray>()
            var p = 0L
            while (p < total) { q.add(longArrayOf(p, minOf(p + chunk, total) - 1)); p += chunk }
            val failed = AtomicBoolean(false)
            val err = AtomicInteger(0)
            var firstErr: Exception? = null
            val pool = Executors.newFixedThreadPool(CONNS)
            repeat(CONNS) {
                pool.execute {
                    val buf = ByteArray(BUF)
                    while (!failed.get()) {
                        val part = q.poll() ?: break
                        var pos = part[0]; val end = part[1]
                        var tries = 0
                        while (pos <= end && !failed.get()) {
                            try {
                                val c = open(r.finalUrl, r.headers, "bytes=$pos-$end")
                                try {
                                    if (c.responseCode != 206) throw IOException("HTTP ${c.responseCode}")
                                    c.inputStream.use { ins ->
                                        while (pos <= end) {
                                            val n = ins.read(buf, 0, minOf(buf.size.toLong(), end - pos + 1).toInt())
                                            if (n < 0) throw IOException("bağlantı kəsildi")
                                            ch.write(ByteBuffer.wrap(buf, 0, n), pos)
                                            pos += n; dn.add(n.toLong())
                                        }
                                    }
                                } finally { c.disconnect() }
                            } catch (e: Exception) {
                                if (++tries > RETRIES) { synchronized(err) { if (firstErr == null) firstErr = e }; failed.set(true); err.incrementAndGet() }
                                else try { Thread.sleep(500L * tries) } catch (_: InterruptedException) {}
                            }
                        }
                    }
                }
            }
            pool.shutdown()
            while (!pool.awaitTermination(1, java.util.concurrent.TimeUnit.SECONDS)) { /* gözlə */ }
            firstErr?.let { throw it }
        }
    }

    /** Aktiv endirmə olanda prosesi canlı saxlayan ön plan xidməti (sayğacla). */
    class KeepAlive : Service() {
        override fun onBind(i: Intent?): IBinder? = null
        override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Endirmə xidməti", NotificationManager.IMPORTANCE_MIN))
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else @Suppress("DEPRECATION") Notification.Builder(this)
            val n = b.setSmallIcon(R.drawable.ic_notif).setContentTitle("Endirmə davam edir").setOngoing(true).build()
            try {
                if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(ID, n)
            } catch (e: Exception) { stopSelf() }
            return START_NOT_STICKY
        }
        companion object {
            private const val CH = "dl_keepalive"
            private const val ID = 4202
            private val active = AtomicInteger(0)
            fun begin(c: Context) {
                if (active.getAndIncrement() == 0) try {
                    val i = Intent(c, KeepAlive::class.java)
                    if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
                } catch (e: Exception) { }
            }
            fun end(c: Context) {
                if (active.decrementAndGet() <= 0) { active.set(0); try { c.stopService(Intent(c, KeepAlive::class.java)) } catch (e: Exception) { } }
            }
        }
    }
}
