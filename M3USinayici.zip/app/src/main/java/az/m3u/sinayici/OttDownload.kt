package az.m3u.sinayici

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import java.net.HttpURLConnection
import java.net.URL

/**
 * Ottplayer playlist yükləmə linkinə (https://ottplayer.tv/playlist/download/215091118) arxa planda daxil olub
 * playlisti oxuyur. Giriş ekranı gəlsə email/şifrəni avtomatik doldurur, sonra
 * https://ottplayer.tv/playlist/original səhifəsinə keçir və yükləməni təkrar sınayır.
 * Nəticə: cb(mətn, info) — mətn null-dursa uğursuzdur, info səbəbdir.
 */
object OttDownload {
    private const val DL = "https://ottplayer.tv/playlist/download/215091118"
    private const val HOME = "https://ottplayer.tv/playlist/original"
    private const val TIMEOUT_MS = 90_000L
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    @SuppressLint("SetJavaScriptEnabled")
    fun run(act: Activity, cb: (String?, String) -> Unit) {
        if (running) { cb(null, "Yükləmə artıq gedir"); return }
        running = true
        val host = act.window.decorView as ViewGroup
        val web = WebView(act)
        val live = LivePanel(act, web)
        var finished = false
        var attempts = 0            // yükləmə cəhdi sayı (giriş edildikdən sonra təkrar)
        var phase = "dl"            // dl = yükləmə linki, home = giriş sonrası Ottplayer ana səhifə
        var fetching = false
        var ua = web.settings.userAgentString

        fun finish(text: String?, info: String) {
            if (finished) return
            finished = true
            main.removeCallbacksAndMessages(null)
            live.remove()
            try { web.stopLoading(); web.destroy() } catch (e: Exception) { }
            running = false
            cb(text, info)
        }

        /** Cookie-lərlə linki birbaşa oxuyur; M3U gəlməsə (giriş səhifəsi və s.) null qaytarır. */
        fun fetch(url: String, agent: String?, after: (String?) -> Unit) {
            if (fetching) return
            fetching = true
            Thread {
                var out: String? = null
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000; c.readTimeout = 60000
                    c.instanceFollowRedirects = true
                    c.setRequestProperty("User-Agent", agent ?: ua)
                    c.setRequestProperty("Referer", HOME)
                    CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                    if (c.responseCode in 200..299) {
                        val t = c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
                        if (t.contains("#EXTINF") || t.trimStart().startsWith("#EXTM3U")) out = t
                    }
                    c.disconnect()
                } catch (e: Exception) { out = null }
                main.post { fetching = false; after(out) }
            }.start()
        }

        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; javaScriptCanOpenWindowsAutomatically = false }
        CookieManager.getInstance().setAcceptCookie(true)
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean { r?.confirm(); return true }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean { r?.confirm(); return true }
        }

        fun tryDownloadPage() {
            phase = "dl"; attempts++
            live.setStatus("⬇️ Playlist yüklənir... (cəhd " + attempts + ")")
            web.loadUrl(DL)
        }

        // Sayt faylı "download" kimi göndərəndə (Content-Disposition) burada tutulur
        web.setDownloadListener { url, agent, _, _, _ ->
            if (finished || fetching) return@setDownloadListener
            fetch(url, agent) { t ->
                if (t != null) { live.setStatus("✅ Playlist endirildi"); finish(t, "yükləndi") }
                else if (attempts < 2) main.post { web.loadUrl(HOME); phase = "home" }
                else finish(null, "Endirilən fayl M3U deyil (giriş tələb oluna bilər)")
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = !OttLogin.host(r.url.host)
            override fun onPageFinished(v: WebView, url: String?) {
                super.onPageFinished(v, url)
                if (finished) return
                val h = try { android.net.Uri.parse(url ?: "").host } catch (e: Exception) { null }
                if (!OttLogin.host(h)) return
                // Səhifədə şifrə sahəsi varsa — giriş ekranıdır: avtomatik doldur
                v.evaluateJavascript("(function(){return !!document.querySelector('input[type=password]');})()") { r ->
                    if (finished) return@evaluateJavascript
                    if (r == "true") {
                        live.setStatus("🔑 Ottplayer-ə giriş edilir...")
                        v.evaluateJavascript(OttLogin.js(), null)   // doldurur və OK-ə basır → səhifə yenilənəcək
                        phase = "home"
                        return@evaluateJavascript
                    }
                    if (phase == "home") {
                        // giriş edildi: https://ottplayer.tv/playlist/original açılmalıdır
                        if (url != null && url.startsWith(HOME)) { main.postDelayed({ if (!finished) tryDownloadPage() }, 1200) }
                        else v.loadUrl(HOME)
                    } else {
                        // yükləmə linki giriş tələb etmədi, amma fayl səhifə kimi göstərilib: oxu
                        fetch(DL, null) { t ->
                            if (t != null) { live.setStatus("✅ Playlist endirildi"); finish(t, "yükləndi") }
                            else if (attempts < 2) { phase = "home"; v.loadUrl(HOME) }
                            else finish(null, "Yükləmə linki M3U qaytarmadı")
                        }
                    }
                }
            }
        }
        main.postDelayed({ finish(null, "Ottplayer-dən yükləmə 90 saniyəyə tamamlanmadı") }, TIMEOUT_MS)
        tryDownloadPage()
    }
}
