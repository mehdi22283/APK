package az.m3u.sinayici

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * GitHub Release: mehdi22283/APK reposunun ən son Release-indəki .apk faylını tapır,
 * PARALEL bağlantılarla YALNIZ tətbiqin öz keşinə (cache/apk) endirir və quraşdırır.
 * Telefon yaddaşına (Downloads) heç nə yazılmır; quraşdırma bitəndən sonra keş təmizlənir.
 */
object ApkTool {
    const val APK_REPO = "mehdi22283/APK"
    private const val BUF = 256 * 1024
    private const val PARTS = 6

    fun clean(t: String) = t.replace(Regex("(?i)^\\s*(bearer|token)\\s+"), "").replace(Regex("[\\s\"']+"), "")

    private fun get(url: String, token: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 30000
        val t = clean(token)
        if (t.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $t")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "M3USinayici")
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        c.disconnect()
        return code to txt
    }

    private fun fail(code: Int, body: String): IOException {
        val msg = try { JSONObject(body).optString("message", "") } catch (e: Exception) { "" }
        return when (code) {
            401 -> IOException("Token yanlışdır və ya vaxtı bitib (401)")
            403 -> IOException(msg.ifEmpty { "HTTP 403" } + " — GitHub limiti dolub ola bilər, bir az sonra yenidən cəhd edin")
            404 -> IOException("Release tapılmadı ($APK_REPO). Repo private-dırsa token-ə bu repoya oxuma icazəsi (Contents: Read) verin")
            else -> IOException(msg.ifEmpty { "GitHub xətası (HTTP $code)" })
        }
    }

    /** Ən son Release. Token bu repoya çatmırsa (401/403/404) tokensiz də yoxlanır (public repo üçün). */
    fun latestRelease(token: String): JSONObject {
        val base = "https://api.github.com/repos/$APK_REPO/releases"
        fun call(path: String): Pair<Int, String> {
            var r = get(base + path, token)
            if (clean(token).isNotEmpty() && r.first in intArrayOf(401, 403, 404)) r = get(base + path, "")
            return r
        }
        val r = call("/latest")
        if (r.first == 200) return JSONObject(r.second)
        val l = call("?per_page=5")      // /latest yalnız pre-release olanda 404 verir — siyahının ilk draft olmayanı
        if (l.first == 200) {
            val a = JSONArray(l.second)
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (!o.optBoolean("draft", false)) return o }
        }
        throw fail(r.first, r.second)
    }

    /** Release-in əlavələrindən .apk faylı (unsigned olmayan üstündür). */
    fun pickApk(rel: JSONObject): JSONObject? {
        val arr = rel.optJSONArray("assets") ?: return null
        val list = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.optString("name").endsWith(".apk", true) }
        return list.firstOrNull { !it.optString("name").contains("unsigned", true) } ?: list.firstOrNull()
    }

    /** Endirmə linki: tokenlə API-dən imzalı yönləndirmə alınır (private repo üçün), alınmasa birbaşa browser_download_url. */
    fun downloadUrl(asset: JSONObject, token: String): String {
        val t = clean(token)
        if (t.isNotEmpty()) try {
            val c = URL(asset.getString("url")).openConnection() as HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 30000; c.instanceFollowRedirects = false
            c.setRequestProperty("Authorization", "Bearer $t")
            c.setRequestProperty("Accept", "application/octet-stream")
            c.setRequestProperty("User-Agent", "M3USinayici")
            val code = c.responseCode
            val loc = c.getHeaderField("Location")
            c.disconnect()
            if (code in 300..399 && !loc.isNullOrEmpty()) return loc
        } catch (e: Exception) { }
        return asset.getString("browser_download_url")
    }

    private fun raw(url: String, range: String?): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 30000
        c.setRequestProperty("Accept-Encoding", "identity")
        c.setRequestProperty("User-Agent", "M3USinayici")
        if (range != null) c.setRequestProperty("Range", range)
        return c
    }

    /** Maksimum sürət: server Range dəstəkləyirsə PARTS hissəyə bölünüb paralel, yoxsa tək axınla. Hər hissə 3 dəfə davam edir. */
    fun fetch(url: String, hint: Long, dest: File, onProgress: (Long, Long) -> Unit) {
        dest.parentFile?.mkdirs(); if (dest.exists()) dest.delete()
        var total = -1L
        var ranges = false
        try {
            val p = raw(url, "bytes=0-0")
            val code = p.responseCode
            if (code == 206) {
                total = (p.getHeaderField("Content-Range") ?: "").substringAfter('/', "").trim().toLongOrNull() ?: -1L
                ranges = total > 0
            } else if (code in 200..299) total = p.contentLengthLong
            p.disconnect()
        } catch (e: Exception) { }
        if (total <= 0) total = hint
        val done = AtomicLong(0)
        val failed = AtomicBoolean(false)
        var err: Exception? = null
        fun report() = onProgress(done.get(), total)

        if (ranges && total > 2L * 1024 * 1024) {
            RandomAccessFile(dest, "rw").use { it.setLength(total) }
            val part = (total + PARTS - 1) / PARTS
            val threads = (0 until PARTS).map { idx ->
                Thread {
                    val start = idx * part
                    val end = minOf(total - 1, start + part - 1)
                    var pos = start
                    var tries = 0
                    while (pos <= end && !failed.get()) {
                        try {
                            val c = raw(url, "bytes=$pos-$end")
                            if (c.responseCode != 206) throw IOException("Server hissəli endirməni rədd etdi (HTTP ${c.responseCode})")
                            RandomAccessFile(dest, "rw").use { f ->
                                f.seek(pos)
                                val buf = ByteArray(BUF)
                                c.inputStream.use { ins ->
                                    while (pos <= end) {
                                        val n = ins.read(buf, 0, minOf(buf.size.toLong(), end - pos + 1).toInt())
                                        if (n < 0) break
                                        f.write(buf, 0, n); pos += n; done.addAndGet(n.toLong())
                                    }
                                }
                            }
                            c.disconnect()
                            if (pos <= end) throw IOException("Bağlantı yarımçıq kəsildi")
                        } catch (e: Exception) {
                            if (++tries >= 3) { err = e; failed.set(true) }
                        }
                    }
                }.also { it.start() }
            }
            while (threads.any { it.isAlive }) { report(); try { Thread.sleep(300) } catch (e: InterruptedException) { } }
            report()
            if (failed.get()) { dest.delete(); throw (err ?: IOException("Endirmə uğursuz oldu")) }
        } else {
            val c = raw(url, null)
            if (c.responseCode !in 200..299) throw IOException("Endirmə xətası (HTTP ${c.responseCode})")
            if (total <= 0) total = c.contentLengthLong
            var last = 0L
            c.inputStream.use { ins ->
                dest.outputStream().buffered(BUF).use { out ->
                    val buf = ByteArray(BUF)
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        out.write(buf, 0, n); done.addAndGet(n.toLong())
                        val now = System.currentTimeMillis()
                        if (now - last > 300) { last = now; report() }
                    }
                }
            }
            c.disconnect(); report()
        }
        if (total > 0 && dest.length() != total) { dest.delete(); throw IOException("Fayl tam endirilmədi (${dest.length()} / $total bayt)") }
    }

    private fun apkDir(ctx: Context) = File(ctx.cacheDir, "apk")

    fun lastApk(ctx: Context): File? =
        apkDir(ctx).listFiles()?.filter { it.name.endsWith(".apk") && it.length() > 0 }?.maxByOrNull { it.lastModified() }

    /** Sistem quraşdırıcısını açır. "Naməlum mənbə" icazəsi yoxdursa, əvvəlcə həmin ayar səhifəsini açır. */
    fun install(ctx: Context, apk: File): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                false
            } else {
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            }
        } catch (e: Exception) { false }
    }

    /** Keşdəki endirilmiş APK-ları silir (quraşdırmadan sonra). */
    fun clearCache(ctx: Context) {
        try { apkDir(ctx).listFiles()?.forEach { it.delete() } } catch (e: Exception) { }
        try { ctx.getSharedPreferences("m3u", Context.MODE_PRIVATE).edit().remove("apkDl").apply() } catch (e: Exception) { }
    }

    private fun verOf(pi: android.content.pm.PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()

    // ---- Mini brauzerdən endirilən APK-ların izlənməsi (Downloads-a yazılır, quraşdırılandan sonra silinir) ----
    private const val PREF_TRK = "apkTrack"

    /** Quraşdırmaq üçün endirilən APK-nı izləyir: tətbiqə qayıdanda və ya yeniləmə bitəndə quraşdırılıbsa, fayl telefondan silinir. */
    fun track(ctx: Context, loc: String) {
        if (loc.isEmpty()) return
        Thread {
            try {
                var pkg = ""; var ver = 0L
                try {
                    var pfd: android.os.ParcelFileDescriptor? = null
                    val path = if (loc.startsWith("content://")) {
                        pfd = ctx.contentResolver.openFileDescriptor(Uri.parse(loc), "r")
                        "/proc/self/fd/" + pfd!!.fd
                    } else (Uri.parse(loc).path ?: loc)
                    val pi = ctx.packageManager.getPackageArchiveInfo(path, 0)
                    try { pfd?.close() } catch (e: Exception) { }
                    if (pi != null) { pkg = pi.packageName; ver = verOf(pi) }
                } catch (e: Exception) { }
                synchronized(ApkTool) {
                    val sp = ctx.getSharedPreferences("m3u", Context.MODE_PRIVATE)
                    val old = try { org.json.JSONArray(sp.getString(PREF_TRK, "[]")) } catch (e: Exception) { org.json.JSONArray() }
                    val arr = org.json.JSONArray()
                    for (i in 0 until old.length()) { val o = old.optJSONObject(i); if (o != null && o.optString("loc") != loc) arr.put(o) }
                    arr.put(JSONObject().put("loc", loc).put("pkg", pkg).put("ver", ver).put("at", System.currentTimeMillis()))
                    sp.edit().putString(PREF_TRK, arr.toString()).apply()
                }
            } catch (e: Exception) { }
        }.start()
    }

    private fun deleteLoc(ctx: Context, loc: String) {
        try {
            if (loc.startsWith("content://")) ctx.contentResolver.delete(Uri.parse(loc), null, null)
            else File(Uri.parse(loc).path ?: loc).delete()
        } catch (e: Exception) { }
    }

    /** İzlənən APK-lardan quraşdırılmış olanları (paket quraşdırıldı/yeniləndi) telefondan silir. */
    fun cleanInstalled(ctx: Context) {
        Thread {
            try {
                synchronized(ApkTool) {
                    val sp = ctx.getSharedPreferences("m3u", Context.MODE_PRIVATE)
                    val old = try { org.json.JSONArray(sp.getString(PREF_TRK, "[]")) } catch (e: Exception) { return@synchronized }
                    if (old.length() == 0) return@synchronized
                    val keep = org.json.JSONArray()
                    for (i in 0 until old.length()) {
                        val o = old.optJSONObject(i) ?: continue
                        val pkg = o.optString("pkg"); val at = o.optLong("at"); val ver = o.optLong("ver")
                        var installed = false
                        if (pkg.isNotEmpty()) try {
                            val pi = ctx.packageManager.getPackageInfo(pkg, 0)
                            // eyni versiya kodu olan köhnə nüsxəni quraşdırılmış saymamaq üçün: yeniləmə vaxtı endirmədən sonra olmalıdır
                            installed = verOf(pi) >= ver && pi.lastUpdateTime >= at
                        } catch (e: Exception) { }
                        if (installed) deleteLoc(ctx, o.optString("loc"))
                        else if (System.currentTimeMillis() - at < 7L * 24 * 3600 * 1000) keep.put(o)   // 7 gündən köhnəsi izlənmir
                    }
                    sp.edit().putString(PREF_TRK, keep.toString()).apply()
                }
            } catch (e: Exception) { }
        }.start()
    }

    /** Tətbiq açılanda: keşdəki APK artıq quraşdırılmış (eyni və ya daha yeni) versiyadırsa silinir. Yarımçıq endirməyə toxunmur. */
    fun cleanStale(ctx: Context) {
        Thread {
            try {
                val files = apkDir(ctx).listFiles()?.filter { it.name.endsWith(".apk") } ?: return@Thread
                val cur = verOf(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
                for (f in files) {
                    val pi = ctx.packageManager.getPackageArchiveInfo(f.absolutePath, 0) ?: continue
                    if (pi.packageName == ctx.packageName && verOf(pi) <= cur) f.delete()
                }
            } catch (e: Exception) { }
        }.start()
    }
}

/** Tətbiq yeni APK ilə yenilənəndən sonra (quraşdırma bitdi) keş təmizlənir. */
class ApkInstalledReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        if (i?.action == Intent.ACTION_MY_PACKAGE_REPLACED) { ApkTool.clearCache(c); ApkTool.cleanInstalled(c) }
    }
}

/** Bildirişə toxunanda görünməz aktivlik: quraşdırma ekranını açıb bağlanır. */
class InstallActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val f = ApkTool.lastApk(this)
        if (f != null) ApkTool.install(this, f)
        try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(4302) } catch (e: Exception) { }
        finish()
    }
}

/** Fon xidməti: son Release-dən APK-nı keşə endirir (faizlə), sonra quraşdırma ekranını açır və bildiriş qoyur. */
class ApkWatchService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_WORK, "APK endirmə", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "APK hazırdır", NotificationManager.IMPORTANCE_HIGH))
        }
        val token = i?.getStringExtra("token") ?: ""
        startFg(workNotif("Release yoxlanır...", -1))
        Thread { download(nm, token) }.start()
        return START_NOT_STICKY
    }

    private fun mb(b: Long) = String.format(Locale.US, "%.1f MB", b / 1048576.0)

    private fun download(nm: NotificationManager, token: String) {
        try {
            status("🔎 Release yoxlanır (${ApkTool.APK_REPO})...", -1)
            val rel = ApkTool.latestRelease(token)
            val asset = ApkTool.pickApk(rel) ?: throw IOException("Son Release-də .apk faylı tapılmadı (${rel.optString("tag_name")})")
            val size = asset.optLong("size", 0L)
            val url = ApkTool.downloadUrl(asset, token)
            val dir = File(cacheDir, "apk"); dir.mkdirs()
            dir.listFiles()?.forEach { it.delete() }
            val apk = File(dir, asset.optString("name", "app.apk"))
            status("⬇️ ${asset.optString("name")} endirilir...", -1)
            var lastPct = -1; var lastT = System.currentTimeMillis(); var lastB = 0L; var speed = 0.0
            ApkTool.fetch(url, size, apk) { done, total ->
                val now = System.currentTimeMillis()
                if (now - lastT >= 500) {
                    speed = (done - lastB) * 1000.0 / (now - lastT) / 1048576.0
                    lastT = now; lastB = done
                }
                val pct = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else -1
                if (pct != lastPct) {
                    lastPct = pct
                    val txt = if (pct >= 0) "$pct% — ${mb(done)} / ${mb(total)} · " + String.format(Locale.US, "%.1f MB/s", speed)
                              else mb(done) + " endirildi"
                    nm.notify(ID_WORK, workNotif(txt, pct))
                    status("⬇️ $txt", pct)
                }
            }
            status("✅ APK hazırdır (" + mb(apk.length()) + ") — quraşdırma açılır", 100)
            installNotif(nm, apk)
            ApkTool.install(this, apk)          // tətbiq önplandadırsa dərhal açılır; yoxsa bildirişə toxunmaq kifayətdir
        } catch (e: Exception) {
            val m = e.message ?: e.toString()
            status("❌ $m", -1)
            fail(nm, "❌ Endirmə xətası", m)
            return
        }
        stopForeground(true); stopSelf()
    }

    private fun installPi(): PendingIntent =
        PendingIntent.getActivity(this, 8, Intent(this, InstallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun installNotif(nm: NotificationManager, apk: File) {
        val pi = installPi()
        val txt = apk.name + " (" + mb(apk.length()) + ") — quraşdırmaq üçün toxunun"
        val b = builder(CH_DONE).setSmallIcon(R.drawable.ic_notif).setContentTitle("✅ APK endirildi").setContentText(txt)
            .setStyle(Notification.BigTextStyle().bigText(txt)).setAutoCancel(true).setContentIntent(pi)
        b.addAction(Notification.Action.Builder(null, "📲 Quraşdır", pi).build())
        nm.notify(ID_DONE, b.build())
    }

    private fun fail(nm: NotificationManager, title: String, text: String) {
        val b = builder(CH_DONE).setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(openPi())
        nm.notify(ID_DONE, b.build())
        stopForeground(true)
        stopSelf()
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else @Suppress("DEPRECATION") Notification.Builder(this)

    private fun openPi(): PendingIntent? = packageManager.getLaunchIntentForPackage(packageName)?.let {
        PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** pct >= 0: faiz çubuğu; pct < 0: qeyri-müəyyən (animasiyalı). */
    private fun workNotif(text: String, pct: Int): Notification {
        val b = builder(CH_WORK).setSmallIcon(R.drawable.ic_notif).setContentTitle(if (pct >= 0) "APK endirilir" else "APK")
            .setContentText(text).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(openPi())
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun startFg(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID_WORK, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(ID_WORK, n)
        } catch (e: Exception) { }
    }

    companion object {
        private const val CH_WORK = "apk_work"
        private const val CH_DONE = "apk_done"
        private const val ID_WORK = 4301
        private const val ID_DONE = 4302

        /** Tətbiqin GitHub bölməsinə canlı vəziyyət (mətn, faiz) ötürür; MainActivity təyin edir. */
        @Volatile var listener: ((String, Int) -> Unit)? = null
        private fun status(t: String, pct: Int) { try { listener?.invoke(t, pct) } catch (e: Exception) { } }

        fun download(c: Context, token: String) {
            val i = Intent(c, ApkWatchService::class.java).putExtra("token", token)
            try { if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) } catch (e: Exception) { }
        }
        fun install(c: Context): Boolean = ApkTool.lastApk(c)?.let { ApkTool.install(c, it) } ?: false
    }
}
