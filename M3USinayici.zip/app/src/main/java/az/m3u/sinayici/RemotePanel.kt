package az.m3u.sinayici

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.ConsumerIrManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.io.File
import dadb.AdbKeyPair
import dadb.Dadb

/**
 * Xiaomi Mi Box (2-ci nəsil) pultu — tam ekran.
 * Power / səs düymələri: telefonun IR göndəricisi ilə LG 42LF560V televizoruna (NEC protokolu).
 * Qalan düymələr: Mi Box-a WiFi ilə (ADB, 192.168.31.220:5555) göndərilir.
 */
class RemotePanel(private val act: Activity) : Dialog(act, android.R.style.Theme_Material_NoActionBar_Fullscreen) {

    companion object {
        /** Mi Box-un sabit IP ünvanı (ADB, port 5555) */
        const val MI_BOX_IP = "192.168.31.220"
        /** Açıq pult paneli (MainActivity icazə nəticəsini ora ötürür). */
        @Volatile var current: RemotePanel? = null

        // LG televizorları: NEC, ünvan 0x04 (kodlar MSB-first yazılıb)
        const val LG_POWER = 0x20DF10EFL
        const val LG_VOL_UP = 0x20DF40BFL
        const val LG_VOL_DOWN = 0x20DFC03FL
        const val LG_MUTE = 0x20DF906FL
        const val LG_INPUT = 0x20DFD02FL
        const val LG_UP = 0x20DF02FDL
        const val LG_DOWN = 0x20DF827DL
        const val LG_LEFT = 0x20DFE01FL
        const val LG_RIGHT = 0x20DF609FL
        const val LG_OK = 0x20DF22DDL
        const val LG_BACK = 0x20DF14EBL

        // HID klaviatura istifadə kodları
        const val K_UP = 0x52
        const val K_DOWN = 0x51
        const val K_LEFT = 0x50
        const val K_RIGHT = 0x4F
        const val K_ENTER = 0x28

        // HID consumer istifadə kodları
        const val C_MENU = 0x0040
        const val C_PLAY_PAUSE = 0x00CD
        const val C_HOME = 0x0223
        const val C_BACK = 0x0224

        fun show(a: Activity) {
            if (current?.isShowing == true) return
            RemotePanel(a).show()
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var wifi: WifiRemote? = null
    private lateinit var wstatus: TextView
    private val ir: ConsumerIrManager? = try { act.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager } catch (e: Exception) { null }

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density + 0.5f).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        window?.apply {
            addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        setContentView(buildUi())
        current = this
        setOnDismissListener { current = null; h.removeCallbacksAndMessages(null); wifi?.close(); wifi = null }
        connectWifi(MI_BOX_IP)   // Mi Box-a WiFi ilə avtomatik qoşulur
    }

    private fun toast(t: String) = Toast.makeText(act, t, Toast.LENGTH_SHORT).show()

    // ───────────────────────────── WiFi (ADB) ─────────────────────────────

    private fun setWStatus(t: String, ok: Boolean) {
        if (!::wstatus.isInitialized) return
        wstatus.text = (if (ok) "● " else "○ ") + t
        wstatus.setTextColor(if (ok) Color.parseColor("#3ECF8E") else Color.parseColor("#9AA3B2"))
    }

    private fun connectWifi(ip: String) {
        val w = wifi ?: WifiRemote(act, h) { t, ok -> setWStatus(t, ok) }.also { wifi = it }
        w.connect(ip)
    }

    private fun androidKey(consumer: Boolean, code: Int): Int = if (!consumer) when (code) {
        K_UP -> 19; K_DOWN -> 20; K_LEFT -> 21; K_RIGHT -> 22; K_ENTER -> 23; else -> -1
    } else when (code) {
        C_BACK -> 4; C_HOME -> 3; C_MENU -> 82; C_PLAY_PAUSE -> 85; else -> -1
    }

    // ───────────────────────────── IR (LG) ─────────────────────────────

    private fun hasIr(): Boolean {
        val ok = try { ir?.hasIrEmitter() == true } catch (e: Exception) { false }
        if (!ok) toast("Bu telefonda IR göndərici yoxdur")
        return ok
    }

    /** NEC çərçivəsi: 9ms/4.5ms başlıq, 32 bit (MSB-first), son impuls. */
    private fun nec(code: Long): IntArray {
        val p = IntArray(67)
        var i = 0
        p[i++] = 9000; p[i++] = 4500
        for (b in 31 downTo 0) {
            p[i++] = 560
            p[i++] = if (((code shr b) and 1L) == 1L) 1690 else 560
        }
        p[i] = 560
        return p
    }

    private fun irSend(code: Long) {
        try { ir?.transmit(38000, nec(code)) } catch (e: Exception) { }
    }

    private fun irBtn(v: View, code: Long, repeat: Boolean) {
        val rep = object : Runnable { override fun run() { irSend(code); h.postDelayed(this, 130) } }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.alpha = 0.6f
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    if (hasIr()) { if (repeat) h.post(rep) else irSend(code) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { view.alpha = 1f; h.removeCallbacks(rep) }
            }
            true
        }
    }

    // ───────────────────────────── Mi Box (WiFi) ─────────────────────────────

    private fun btBtn(v: View, consumer: Boolean, code: Int) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.alpha = 0.6f
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    val w = wifi
                    val ak = androidKey(consumer, code)
                    if (w == null || !w.connected()) {
                        toast("Mi Box ilə WiFi qoşulması yoxdur"); connectWifi(MI_BOX_IP)
                    } else if (ak >= 0) w.key(ak)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.alpha = 1f
            }
            true
        }
    }

    // ───────────────────────────── UI ─────────────────────────────

    private fun shape(color: Int, oval: Boolean, radiusDp: Int = 16): GradientDrawable = GradientDrawable().apply {
        if (oval) setShape(GradientDrawable.OVAL) else { setShape(GradientDrawable.RECTANGLE); cornerRadius = dp(radiusDp).toFloat() }
        setColor(color)
    }

    private fun circle(text: String, size: Int, color: Int, sp: Float = 20f): TextView = TextView(act).apply {
        this.text = text; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = sp
        background = shape(color, true)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).also { it.setMargins(dp(6), dp(6), dp(6), dp(6)) }
    }

    private fun label(t: String): TextView = TextView(act).apply {
        text = t; setTextColor(Color.parseColor("#7C8696")); textSize = 12f
        setPadding(dp(4), dp(14), dp(4), dp(2)); gravity = Gravity.CENTER
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        views.forEach { addView(it) }
    }

    private fun spacer(size: Int): View = View(act).apply {
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).also { it.setMargins(dp(6), dp(6), dp(6), dp(6)) }
    }

    private fun smallBtn(t: String, onClick: () -> Unit): TextView = TextView(act).apply {
        text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = shape(Color.parseColor("#26303F"), false, 20)
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.setMargins(dp(4), 0, dp(4), 0) }
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val bt = Color.parseColor("#2B3445")     // Mi Box (WiFi)
        val tv = Color.parseColor("#6B4410")     // TV (IR)
        val root = FrameLayout(act).apply { setBackgroundColor(Color.parseColor("#0F1115")) }
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(34), dp(16), dp(24))
        }

        // Yuxarı sətir: bağla + başlıq
        val close = TextView(act).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            background = shape(Color.parseColor("#26303F"), true)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            setOnClickListener { dismiss() }
        }
        val title = TextView(act).apply {
            text = "Mi Box 2-ci nəsil pult"; setTextColor(Color.WHITE); textSize = 17f
            setPadding(dp(12), 0, 0, 0)
        }
        col.addView(LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(close); addView(title)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        wstatus = TextView(act).apply {
            text = "○ WiFi hazırlanır…"; setTextColor(Color.parseColor("#9AA3B2")); textSize = 13f
            setPadding(dp(4), dp(10), dp(4), dp(8)); gravity = Gravity.CENTER
        }
        col.addView(wstatus)
        col.addView(LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(smallBtn("📶 Yenidən qoş") { connectWifi(MI_BOX_IP) })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // TV: Power + Mute
        col.addView(label("TELEVİZOR · LG 42LF560V (IR)"))
        val power = circle("⏻", 72, Color.parseColor("#C62828"), 28f)
        val mute = circle("🔇", 56, tv, 20f)
        val input = circle("INPUT", 56, tv, 11f)
        irBtn(power, LG_POWER, false); irBtn(mute, LG_MUTE, false); irBtn(input, LG_INPUT, false)
        col.addView(row(power, mute, input))

        // LG naviqasiya (IR): giriş siyahısında və TV menyusunda gəzmək üçün
        col.addView(label("LG NAVİQASİYA (IR)"))
        val lu = circle("▲", 52, tv, 16f); val ld = circle("▼", 52, tv, 16f)
        val ll = circle("◀", 52, tv, 16f); val lr = circle("▶", 52, tv, 16f)
        val lok = circle("OK", 52, Color.parseColor("#B8731A"), 14f)
        val lback = circle("↩", 52, tv, 18f)
        irBtn(lu, LG_UP, true); irBtn(ld, LG_DOWN, true); irBtn(ll, LG_LEFT, true)
        irBtn(lr, LG_RIGHT, true); irBtn(lok, LG_OK, false); irBtn(lback, LG_BACK, false)
        col.addView(row(spacer(52), lu, spacer(52)))
        col.addView(row(ll, lok, lr))
        col.addView(row(lback, ld, spacer(52)))

        // Mi Box: D-pad
        col.addView(label("MI BOX (WiFi)"))
        val up = circle("▲", 64, bt); val down = circle("▼", 64, bt)
        val left = circle("◀", 64, bt); val right = circle("▶", 64, bt)
        val ok = circle("OK", 72, Color.parseColor("#3B82F6"), 18f)
        btBtn(up, false, K_UP); btBtn(down, false, K_DOWN); btBtn(left, false, K_LEFT)
        btBtn(right, false, K_RIGHT); btBtn(ok, false, K_ENTER)
        val pad = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = shape(Color.parseColor("#171B22"), true)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(row(spacer(64), up, spacer(64)))
            addView(row(left, ok, right))
            addView(row(spacer(64), down, spacer(64)))
        }
        col.addView(pad)

        // Geri / Home / Menu / Play-Pause
        val back = circle("↩", 60, bt, 22f); val home = circle("⌂", 60, bt, 24f)
        val menu = circle("☰", 60, bt, 22f); val play = circle("⏯", 60, bt, 20f)
        btBtn(back, true, C_BACK); btBtn(home, true, C_HOME); btBtn(menu, true, C_MENU); btBtn(play, true, C_PLAY_PAUSE)
        col.addView(row(back, home, menu, play))

        // Səs (LG IR)
        col.addView(label("SƏS · LG (IR)"))
        val vm = circle("−", 64, tv, 28f); val vp = circle("+", 64, tv, 28f)
        irBtn(vm, LG_VOL_DOWN, true); irBtn(vp, LG_VOL_UP, true)
        col.addView(row(vm, vp))

        root.addView(ScrollView(act).apply { isFillViewport = true; addView(col) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return root
    }
}

/** Mi Box-a WiFi ilə (ADB, port 5555) qoşulub düymə kodlarını «input keyevent» ilə göndərir. */
class WifiRemote(private val ctx: Context, private val main: Handler, private val onState: (String, Boolean) -> Unit) {
    private val ex = Executors.newSingleThreadExecutor()
    @Volatile private var dadb: Dadb? = null
    @Volatile private var ok = false

    fun connected() = ok

    private fun post(t: String, good: Boolean) { main.post { onState(t, good) } }

    fun connect(host: String) {
        ex.execute {
            post("WiFi: $host qoşulur… (TV-də sorğu çıxsa «İcazə ver» seçin)", false)
            try {
                closeNow()
                val priv = File(ctx.filesDir, "adbkey")
                val pub = File(ctx.filesDir, "adbkey.pub")
                if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create(host, 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok")
                dadb = d; ok = true
                post("WiFi qoşuldu: $host", true)
            } catch (e: Throwable) {
                ok = false
                post("WiFi qoşulmadı: " + (e.message ?: e.javaClass.simpleName), false)
            }
        }
    }

    fun key(code: Int) {
        ex.execute {
            try { dadb?.shell("input keyevent $code") }
            catch (e: Throwable) { ok = false; post("WiFi bağlantısı kəsildi — yenidən qoşun", false) }
        }
    }

    private fun closeNow() { try { dadb?.close() } catch (e: Throwable) { }; dadb = null; ok = false }
    fun close() { ex.execute { closeNow() } }
}
