package az.mehdi.iptvplayer

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.content.Context
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import java.util.Locale

/**
 * Ehtiyat link: playlistdəki əsas link işləməsə, yoda.az səhifəsi gizli WebView-da açılır,
 * səhifənin pleyerinin göndərdiyi tokenli .m3u8 linki tutulur və pleyerə verilir.
 * Token IP və User-Agent-ə bağlıdır, buna görə link bu cihazda, WebView-nın User-Agent-i ilə alınır.
 */
object Backup {
    /**
     * Azərbaycan kanalları → yoda.az səhifəsi. Qrupun və kanalın adı nə olursa olsun (HD/FHD, "AZ:" prefiksi, "TV"/"Televiziyası",
     * Ə/E, İ/I fərqləri) ad "əsas ada" gətirilib bu siyahıdakı ləqəblərlə tam uyğunlaşdırılır.
     * aliases: qrupdan asılı olmayaraq uyğunlaşan adlar. azOnlyAliases: Türkiyə kanalı ilə qarışa bilən adlar (ATV, NTV) –
     * yalnız Azərbaycan konteksti varsa (qrup/ad/tvg-id) uyğunlaşır.
     */
    private class Site(val id: String, val page: String, val aliases: List<String>, val azOnlyAliases: List<String> = emptyList()) {
        val keys: Set<String> = aliases.map { baseOf(analyze(it).first) }.toSet()
        val azKeys: Set<String> = azOnlyAliases.map { baseOf(analyze(it).first) }.toSet()
    }

    private val SITES: List<Site> by lazy {
        listOf(
            Site("aztv", "https://yoda.az/tv/azertv/", listOf("aztv", "azertv", "azerbaycan tv", "azerbaycan", "azerbaijan tv", "azerbaijan")),
            Site("medeniyyettv", "https://yoda.az/tv/medeniyyettele/", listOf("medeniyyet tv", "medeniyyet", "medeniyyet tele", "medeniyyet televiziyasi")),
            Site("idmantv", "https://yoda.az/tv/idmantele/", listOf("idman tv", "idman", "idman tele", "idman televiziyasi")),
            Site("biznestv", "https://yoda.az/tv/biznestv/", listOf("biznes tv", "biznes")),
            Site("bakutv", "https://yoda.az/tv/bakutv/", listOf("baku tv", "baki tv", "baku", "baki")),
            Site("apatv", "https://yoda.az/tv/apatv/", listOf("apa tv", "apa")),
            Site("realtv", "https://yoda.az/tv/real/", listOf("real tv", "real")),
            Site("arb24", "https://yoda.az/tv/arb24/", listOf("arb 24", "arb24")),
            Site("arbgunes", "https://yoda.az/tv/arbgunesh/", listOf("arb gunes", "arb gunesh", "arbgunes", "arbgunesh")),
            Site("arb", "https://yoda.az/tv/arb/", listOf("arb", "arb tv")),
            Site("ictimaitv", "https://yoda.az/tv/ictimaitele/", listOf("ictimai tv", "ictimai", "ictimai tele", "ictimai televiziyasi")),
            Site("spacetv", "https://yoda.az/tv/space/", listOf("space tv", "space")),
            Site("atv", "https://yoda.az/tv/atv/", listOf("atv azad")), // yalnız "ATV Azad" = Azərbaycan ATV-si; sadə "ATV" = Türkiyə ATV-si (yoda.az-a düşmür)
            Site("xezertv", "https://yoda.az/tv/xazartv/", listOf("xezer tv", "xezer", "xazar tv", "xazar", "khazar tv", "khazar")),
            Site("dunyatv", "https://yoda.az/tv/dunyatv/", listOf("dunya tv", "dunya")),
            Site("naxcivantv", "https://yoda.az/tv/ntv/", listOf("naxcivan tv", "naxcivan"), listOf("ntv")),
            Site("kanal35", "https://yoda.az/tv/kanal35/", listOf("kanal 35", "kanal35")),
            Site("qafqaztv", "https://yoda.az/tv/qafkaz/", listOf("qafqaz tv", "qafqaz", "qafkaz tv", "qafkaz")),
            Site("eltv", "https://yoda.az/tv/eltv/", listOf("el tv", "el")),
            Site("mtv", "https://yoda.az/tv/mtvaz/", listOf("mtv", "mtv az", "mtv azerbaycan"))
        )
    }

    internal fun norm(name: String): String {
        val sb = StringBuilder()
        for (c in name) {
            when (c) {
                'Ə', 'ə', 'E', 'e' -> sb.append('e')
                'İ', 'I', 'ı', 'i' -> sb.append('i')
                'Ö', 'ö', 'O', 'o' -> sb.append('o')
                'Ü', 'ü', 'U', 'u' -> sb.append('u')
                'Ç', 'ç', 'C', 'c' -> sb.append('c')
                'Ş', 'ş', 'S', 's' -> sb.append('s')
                'Ğ', 'ğ', 'G', 'g' -> sb.append('g')
                else -> if (c.isLetterOrDigit()) sb.append(c.lowercaseChar())
            }
        }
        var r = sb.toString()
        if (r.endsWith("hd") && r.length > 4) r = r.removeSuffix("hd")
        return r
    }

    private val QUALITY = setOf("hd", "fhd", "uhd", "sd", "4k", "8k", "hevc", "h265", "h264", "1080p", "720p", "576p", "480p", "tr")
    private val NOISE = QUALITY + setOf("backup", "ehtiyat", "biraz", "canli", "live")
    private val TV_WORDS = setOf("tv", "tele", "televiziya", "televiziyasi", "televizya", "televizyon")
    private val AZ_WORDS = setOf("az", "azerbaycan", "azerbaijan")

    /** "TV" + rəqəm ("TV 8", "TV 8.5") bir söz sayılır: "tv8", "tv85" (TV sözü atılanda "8" qalmasın). */
    private fun mergeTvDigits(t: List<String>): List<String> {
        val out = ArrayList<String>()
        var i = 0
        while (i < t.size) {
            if (t[i] == "tv" && i + 1 < t.size && t[i + 1][0].isDigit()) { out.add("tv" + t[i + 1]); i += 2 }
            else { out.add(t[i]); i++ }
        }
        return out
    }

    /**
     * Ad → (söz siyahısı, adda "AZ/Azərbaycan" sözü varmı). Keyfiyyət/etiket sözləri (HD, TR, Backup...), mötərizə içi və
     * "TV" sözü (hər yerdə) atılır; AZ sözü başqa söz qalırsa atılır. "Live" yalnız adın özüdürsə ("Live TV") saxlanır.
     */
    private fun analyze(name: String): Pair<List<String>, Boolean> {
        val stripped = name.replace(Regex("[(\\[{].*?[)\\]}]"), " ").trim()
        val tokens = mergeTvDigits(
            (if (stripped.isEmpty()) name else stripped).split(Regex("[^\\p{L}\\p{N}]+"))
                .filter { it.isNotEmpty() }.map { norm(it) }.filter { it.isNotEmpty() }
        )
        val filtered = tokens.filter { it !in NOISE }
        val all = if (filtered.any { it !in TV_WORDS && it !in AZ_WORDS }) filtered else tokens.filter { it !in QUALITY }
        val rest = all.filter { it !in AZ_WORDS }
        val hasAz = rest.size != all.size
        val core = rest.filter { it !in TV_WORDS }
        // Yalnız "AZ TV" / "Azərbaycan" kimi adlarda AZ sözü adın özüdür, atılmır.
        val keep = if (core.isNotEmpty()) core else all
        return keep to hasAz
    }

    /**
     * Əsas başlanğıc ad: "Kanal D HD TR Kanka" → əvvəl bütün ad, sonra sondan söz-söz qısaldılaraq ("kanald") uyğunlaşdırılır.
     * Qısaldılmış başlanğıc ən azı 3 hərf olmalıdır ("A Para" → ATV-yə düşməsin).
     */
    private fun prefixBases(words: List<String>): List<Pair<String, Boolean>> {
        val out = ArrayList<Pair<String, Boolean>>()
        for (n in words.size downTo 1) {
            val sub = words.subList(0, n)
            val b = baseOf(sub)
            if (b.isEmpty()) continue
            if (n < words.size && sub.joinToString("").length < 3) continue
            out.add(b to (n == words.size))
        }
        return out
    }

    /** Sonundakı TV/Televiziyası sözləri və "...tv" şəkilçisi atılır: "Xəzər TV", "Xəzər", "XəzərTV" eyni əsas ad verir. */
    private fun baseOf(words: List<String>): String {
        val l = words.toMutableList()
        while (l.isNotEmpty() && l.last() in TV_WORDS) l.removeAt(l.size - 1)
        var s = l.joinToString("")
        if (s.endsWith("tv") && s.length > 2) s = s.removeSuffix("tv")
        return s
    }

    private fun isTurkish(ch: Channel): Boolean {
        val g = norm(ch.group)
        val id = (ch.tvgId ?: "").lowercase()
        return g.contains("turk") || g == "tr" || id.endsWith(".tr")
    }

    private fun azContext(ch: Channel, nameHasAz: Boolean): Boolean {
        val g = norm(ch.group)
        val id = (ch.tvgId ?: "").lowercase()
        if (isTurkish(ch)) return false
        return nameHasAz || g == "az" || g.contains("azer") || id.endsWith(".az")
    }

    private fun siteFor(ch: Channel): Site? {
        for (nm in listOf(ch.name, ch.tvgName)) {
            if (nm.isNullOrBlank()) continue
            val (words, hasAz) = analyze(nm)
            val az = azContext(ch, hasAz)
            for ((b, full) in prefixBases(words)) {
                // Başlanğıc ada görə (qısaldılmış) uyğunlaşma yalnız Azərbaycan kontekstində: "Real Madrid TV" → Real TV olmasın.
                if (!full && !az) continue
                SITES.firstOrNull { b in it.keys }?.let { return it }
                if (az) SITES.firstOrNull { b in it.azKeys }?.let { return it }
            }
        }
        return null
    }

    /**
     * Kanal açılış sırası:
     *  - Azərbaycan kanalları (canlitv səhifəsi olanlar, YODA_FIRST_IDS): canlitv.com → playlistdəki link → yoda.az
     *  - Azərbaycan kanalları (canlitv səhifəsi olmayanlar, YODA_FIRST_IDS): yoda.az → playlistdəki link
     *  - Türkiyə kanalları: playlistdəki link → canlitv.com (yoda.az yoxdur)
     *  - digər kanallar: playlistdəki link → yoda.az (səhifəsi varsa) → canlitv.com
     * Real, İdman, Space, Dünya və MTV adları başqa ölkələrdə də var: yalnız Azərbaycan kontekstində (qrup/ad/tvg-id) Azərbaycan sayılır.
     */
    private val AZ_ONLY = setOf("realtv", "idmantv", "spacetv", "dunyatv", "mtv")

    /** true: bu kanal Azərbaycan kanalıdır (yoda.az səhifəsi var, Türkiyə deyil) və əvvəl yoda.az-dan açılır. */
    fun yodaFirst(ch: Channel): Boolean {
        if (isTurkish(ch)) return false
        val id = siteFor(ch)?.id ?: return false
        if (id !in YODA_FIRST_IDS) return false // qalan kanallar: playlist → yoda.az → canlitv.com
        if (id in AZ_ONLY && !azOk(ch)) return false
        return !canlitvFirst(ch) // canlitv səhifəsi olanlar: canlitv → playlist → yoda.az
    }

    /**
     * Bu siyahıdakı kanallar: canlitv.com səhifəsi varsa canlitv → playlist → yoda.az, yoxdursa yoda.az → playlist:
     * Mədəniyyət, Real, İdman, Space, MTV + APA TV, Biznes TV, Qafqaz TV, Naxçıvan TV, Kanal 35.
     */
    private val YODA_FIRST_IDS = setOf(
        "medeniyyettv", "realtv", "idmantv", "spacetv", "mtv",
        "apatv", "biznestv", "qafqaztv", "naxcivantv", "kanal35"
    )

    /** Application context: canlitv_channels.txt siyahısını oxumaq üçün (App.onCreate-də verilir). */
    @Volatile private var appCtx: Context? = null
    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    /**
     * v1.62: canlitv.com səhifəsi olan "yoda-first" kanallar üçün sıra: canlitv.com → playlistdəki link → yoda.az.
     * canlitv səhifəsi olmayan kanallar (məs. Biznes TV, APA TV, Qafqaz TV, Kanal 35...) əvvəlki sırada qalır: yoda.az → playlist.
     */
    /** v1.65: İdman TV və Real TV həmişə yoda.az → playlist → canlitv.com sırasındadır (canlitv birinci olmur). */
    private val YODA_ALWAYS_FIRST = setOf("idmantv", "realtv")

    fun canlitvFirst(ch: Channel): Boolean {
        if (isTurkish(ch)) return false
        val id = siteFor(ch)?.id ?: return false
        if (id !in YODA_FIRST_IDS || id in YODA_ALWAYS_FIRST) return false
        if (id in AZ_ONLY && !azOk(ch)) return false
        val ctx = appCtx ?: return false
        return canlitvPageFor(ctx, ch) != null
    }

    private fun azOk(ch: Channel): Boolean {
        val hasAz = listOf(ch.name, ch.tvgName).any { !it.isNullOrBlank() && analyze(it).second }
        return azContext(ch, hasAz)
    }

    /** true: playlist linki ən sonda gəlir (yoda.az mərhələsi var və playlist ondan sonradır). */
    fun playlistLast(ch: Channel): Boolean = yodaFirst(ch) || canlitvFirst(ch)

    // ---------- canlitv.com: 3-cü ehtiyat link ----------
    /** assets/canlitv_channels.txt: "Ad | səhifə | az" və ya "| tr". Yalnız burada olan kanalların canlitv ehtiyatı var. */
    private class Listed(val az: Map<String, String>, val tr: Map<String, String>)

    @Volatile private var listedCache: Listed? = null

    private fun listed(ctx: Context): Listed {
        listedCache?.let { return it }
        val az = LinkedHashMap<String, String>()
        val tr = LinkedHashMap<String, String>()
        runCatching {
            ctx.assets.open("canlitv_channels.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val parts = line.split("|").map { it.trim() }
                    if (parts.size < 3 || !parts[1].startsWith("http")) continue
                    val b = baseOf(analyze(parts[0]).first)
                    if (b.isEmpty()) continue
                    (if (parts[2] == "az") az else tr).putIfAbsent(b, parts[1])
                }
            }
        }
        return Listed(az, tr).also { listedCache = it }
    }

    /**
     * Kanalın canlitv.com səhifəsi. Sıra: playlist → yoda.az → canlitv.com. Yalnız siyahıdakı Azərbaycan/Türkiyə kanalları.
     * Ad əvvəl bütövlükdə, sonra sondan söz-söz qısaldılaraq uyğunlaşır ("Kanal D HD TR Kanka" → "Kanal D").
     * Adda "AZ" sözü varsa yalnız Azərbaycan siyahısı; Türkiyə qrupunda yalnız Türkiyə siyahısı; digər hallarda ikisi də
     * (qrup AZ-dırsa əvvəl Azərbaycan, əks halda əvvəl Türkiyə). Sadə "ATV" = Türkiyə ATV-si, "ATV Azad" = Azərbaycan ATV-si.
     */
    fun canlitvPageFor(ctx: Context, ch: Channel): String? {
        val l = listed(ctx)
        // ARB Günəş canlitv siyahısında ayrıca yoxdursa, qısaldılaraq "ARB" kanalına düşməməlidir (başqa kanaldır).
        val siteId = siteFor(ch)?.id
        if (siteId == "arbgunes" || siteId == "arb") return null // ARB Günəş və ARB: canlitv.com ehtiyatı yoxdur (playlist → yoda.az)
        val strict = false
        for (nm in listOf(ch.name, ch.tvgName)) {
            if (nm.isNullOrBlank()) continue
            val (words, hasAz) = analyze(nm)
            val az = azContext(ch, hasAz)
            val regions: List<Map<String, String>> = when {
                hasAz -> listOf(l.az)
                isTurkish(ch) -> listOf(l.tr)
                az -> listOf(l.az, l.tr)
                else -> listOf(l.tr, l.az)
            }
            for (reg in regions) {
                for ((b, full) in prefixBases(words)) {
                    if (strict && !full) continue
                    if (!full && reg === l.az && !az) continue
                    reg[b]?.let { return it }
                }
            }
        }
        return null
    }

    /** Kanalın yoda.az ehtiyat səhifəsi: qrupdan asılı deyil; yalnız ATV/NTV üçün Azərbaycan konteksti tələb olunur (Türkiyə ATV/NTV ilə qarışmasın). */
    fun pageFor(ch: Channel): String? = if (isTurkish(ch)) null else siteFor(ch)?.page
}

/**
 * Gizli WebView-larda (yoda.az və canlitv.com link alma) lazımsız sorğuların bloklanması: şəkil, stil, şrift, reklam videosu,
 * reklam/izləyici hostları. .m3u8 sorğuları heç vaxt bloklanmır.
 */
internal object WebBlock {
    private val EXT = setOf(
        "png", "jpg", "jpeg", "gif", "gifv", "webp", "avif", "bmp", "jfif", "apng", "svg", "ico",
        "css", "woff", "woff2", "ttf", "otf", "eot", "map", "mp4", "webm"
    )
    private val HOSTS = listOf(
        "doubleclick", "googlesyndication", "google-analytics", "googletagmanager", "googletagservices",
        "googleadservices", "adservice", "adnxs", "taboola", "outbrain", "facebook", "yandex",
        "fonts.googleapis", "fonts.gstatic", "gstatic.com/images", "scorecardresearch", "hotjar", "clarity.ms",
        "amazon-adsystem", "criteo", "pubmatic", "rubiconproject", "adform", "adsrvr", "smartadserver",
        "popads", "propellerads", "onesignal", "twitter", "t.co", "instagram", "tiktok", "addthis", "sharethis",
        "adsystem", "advertising", "adserver", "banner"
    )

    /** Sorğunun Accept başlığından: şəkil / stil / şrift sorğuları uzantısı olmasa da bloklanır. */
    private fun isMediaAccept(r: WebResourceRequest): Boolean {
        if (r.isForMainFrame) return false
        val a = r.requestHeaders?.get("Accept") ?: return false
        return a.startsWith("image/") || a.startsWith("text/css") || a.startsWith("font/")
    }

    fun shouldBlock(r: WebResourceRequest): Boolean {
        val u = r.url.toString()
        if (u.contains(".m3u8", true) || r.isForMainFrame) return false
        val ext = u.substringBefore('?').substringBefore('#').substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext in EXT) return true
        val host = r.url.host
        if (host != null && HOSTS.any { host.contains(it) }) return true
        return isMediaAccept(r)
    }

    fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
}

/** Gizli WebView ilə yoda.az səhifəsindən yayım linkini (ilk .m3u8) alır. Yalnız lazım olanda yaradılır, iş bitəndə yaddaşdan silinir. */
class YodaResolver(private val activity: Activity, private val container: ViewGroup) {

    class Result(val url: String, val referer: String, val userAgent: String)

    companion object {
        const val TIMEOUT_MS = 20_000L
        internal const val AUTOPLAY_JS = """
(function(){
  function go(){
    try{ document.querySelectorAll('video').forEach(function(v){ v.muted=true; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }); }catch(e){}
    try{ var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="big-play"],[class*="PlayButton"]'); if(b) b.click(); }catch(e){}
  }
  go(); setTimeout(go,1500); setTimeout(go,4000); setTimeout(go,8000);
})();
"""
        // Səhifə tam yüklənməsini (onPageFinished) gözləmir: pleyer görünən kimi dərhal başladır. Yalnız dayanmış videoya toxunur.
        internal const val PLAY_EVERY_MS = 600L
        internal const val PLAY_TICK_JS = """(function(){try{var vs=document.querySelectorAll('video'),need=vs.length==0;
vs.forEach(function(v){if(v.paused){need=true;v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}});
if(need){var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="big-play"],[class*="PlayButton"]');if(b)b.click();}}catch(e){}})();"""
    }

    private val ui = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var done = false
    private var cb: ((Result?) -> Unit)? = null
    private var page = ""
    private var ua = ""

    private val timeoutRun = Runnable { finish(null) }
    private val playRun = object : Runnable {
        override fun run() {
            val w = web ?: return
            if (done) return
            w.evaluateJavascript(PLAY_TICK_JS, null)
            ui.postDelayed(this, PLAY_EVERY_MS)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun resolve(pageUrl: String, timeoutMs: Long = TIMEOUT_MS, onResult: (Result?) -> Unit) {
        cancel()
        done = false
        cb = onResult
        page = pageUrl
        try {
            val w = WebView(activity)
            web = w
            val s = w.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.cacheMode = WebSettings.LOAD_NO_CACHE
            s.blockNetworkImage = true // şəkillər lazım deyil: WebView prosesinin RAM-ı xeyli azalır
            s.javaScriptCanOpenWindowsAutomatically = false   // reklam pop-up pəncərələri açılmasın
            s.setSupportMultipleWindows(false)
            s.setGeolocationEnabled(false)
            ua = s.userAgentString
            w.alpha = 0.01f
            val px = (8 * activity.resources.displayMetrics.density).toInt()
            container.addView(w, FrameLayout.LayoutParams(px, px, Gravity.BOTTOM or Gravity.END))
            w.webChromeClient = WebChromeClient()
            w.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val req = request ?: return null
                    val u = req.url.toString()
                    if (WebBlock.shouldBlock(req)) return WebBlock.empty()
                    if (u.substringBefore("?").lowercase(Locale.ROOT).endsWith(".m3u8")) {
                        val ref = req.requestHeaders?.get("Referer")?.takeIf { it.startsWith("http") } ?: page
                        val r = Result(u, ref, ua)
                        ui.post { onM3u8(r) }
                    }
                    return null
                }

                // WebView render prosesi (2 GB RAM-da yaddaş azlığından) ölərsə, bunu tutmayan tətbiq TAM ÇÖKÜR.
                // true qaytarılır: tətbiq yaşayır, WebView atılır və ehtiyat link prosesi nəticəsiz bitir.
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    android.util.Log.w("IPTV-BACKUP", "WebView prosesi dayandı (çökmə=${detail?.didCrash()})")
                    ui.post { if (!done) finish(null) }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!done && url != null && url != "about:blank") view?.evaluateJavascript(AUTOPLAY_JS, null)
                }
            }
            if (timeoutMs > 0) ui.postDelayed(timeoutRun, timeoutMs) // timeoutMs <= 0: link alınana qədər müddətsiz gözlənilir
            ui.postDelayed(playRun, 800)
            w.loadUrl(pageUrl)
        } catch (e: Throwable) {
            android.util.Log.e("IPTV-BACKUP", "WebView açıla bilmədi", e)
            finish(null)
        }
    }

    /** İlk çıxan .m3u8 linki (tokenli-tokensiz fərq etmir) dərhal götürülür. */
    private fun onM3u8(r: Result) {
        if (done) return
        finish(r)
    }

    private fun finish(r: Result?) {
        if (done) return
        done = true
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(playRun)
        val callback = cb
        cb = null
        destroyWeb()
        android.util.Log.i("IPTV-BACKUP", "yoda nəticə: " + (r?.url ?: "tapılmadı") + " (səhifə: $page)")
        callback?.invoke(r)
    }

    private fun destroyWeb() {
        val w = web ?: return
        web = null
        runCatching {
            w.stopLoading()
            w.loadUrl("about:blank")
            container.removeView(w)
            w.destroy()
        }
    }

    fun cancel() {
        done = true
        cb = null
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(playRun)
        destroyWeb()
    }
}

/**
 * canlitv.com-dan m3u8 linkini gizli WebView ilə tutur (3-cü ehtiyat link).
 * Sorğuları dinləyir və səhifənin HTML-ni skan edir; ilk tapılan .m3u8 qəbul edilir.
 */
class CanlitvResolver(private val activity: Activity, private val container: ViewGroup) {

    companion object {
        const val TIMEOUT_MS = 20_000L
        private const val SITE = "https://www.canlitv.com/"
        private const val SCAN_EVERY_MS = 700L
        private val M3U8 = Regex("""https?://[^\s"'<>\\]+\.m3u8[^\s"'<>\\]*""", RegexOption.IGNORE_CASE)
        private const val SCAN_JS = """(function(){try{var s='';document.querySelectorAll('video,source').forEach(function(e){s+=' '+(e.currentSrc||e.src||'');});return s+' '+document.documentElement.innerHTML;}catch(e){return '';}})();"""
    }

    private val ui = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var done = false

    private var cb: ((YodaResolver.Result?) -> Unit)? = null
    private var ua = ""
    private var page = ""

    private val timeoutRun = Runnable { finish(null) }
    // Pleyer avtomatik oynasın: dayanmış videoya / play düyməsinə hər 0,6 saniyədən bir toxunulur (yoda.az ilə eyni)
    private val playRun = object : Runnable {
        override fun run() {
            val w = web ?: return
            if (done) return
            w.evaluateJavascript(YodaResolver.PLAY_TICK_JS, null)
            ui.postDelayed(this, YodaResolver.PLAY_EVERY_MS)
        }
    }
    private val scanRun = object : Runnable {
        override fun run() {
            val w = web ?: return
            if (done) return
            w.evaluateJavascript(SCAN_JS) { raw -> onScan(raw) }
            ui.postDelayed(this, SCAN_EVERY_MS)
        }
    }

    private fun clean(s: String) = s.replace("\\/", "/").replace("\\u0026", "&").replace("\\u003d", "=").replace("&amp;", "&")
        .trimEnd(')', ']', ';', ',', '}')

    @SuppressLint("SetJavaScriptEnabled")
    fun resolve(pageUrl: String, timeoutMs: Long = TIMEOUT_MS, onResult: (YodaResolver.Result?) -> Unit) {
        cancel()
        done = false
        cb = onResult
        page = pageUrl
        try {
            val w = WebView(activity)
            web = w
            val s = w.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            s.loadsImagesAutomatically = false
            s.blockNetworkImage = true
            s.javaScriptCanOpenWindowsAutomatically = false   // reklam pop-up pəncərələri açılmasın
            s.setSupportMultipleWindows(false)
            s.setGeolocationEnabled(false)
            ua = s.userAgentString
            w.alpha = 0.01f
            val px = (8 * activity.resources.displayMetrics.density).toInt()
            container.addView(w, FrameLayout.LayoutParams(px, px, Gravity.BOTTOM or Gravity.END))
            w.webChromeClient = WebChromeClient()
            w.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val req = request ?: return null
                    val u = req.url.toString()
                    if (WebBlock.shouldBlock(req)) return WebBlock.empty()
                    if (u.contains(".m3u8", true)) ui.post { accept(clean(u)) }
                    return null
                }

                // v1.67: canlitv.com səhifəsi açılmadısa (şəbəkə xətası / 4xx-5xx) 5 s gözlənilmir, dərhal növbəti mənbəyə keçilir.
                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                    if (request?.isForMainFrame == true) {
                        android.util.Log.w("IPTV-BACKUP", "canlitv səhifəsi açılmadı (${error?.errorCode}) → növbəti mənbə")
                        ui.post { if (!done) finish(null) }
                    }
                }

                override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                    if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                        android.util.Log.w("IPTV-BACKUP", "canlitv səhifəsi HTTP ${errorResponse?.statusCode} → növbəti mənbə")
                        ui.post { if (!done) finish(null) }
                    }
                }

                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    android.util.Log.w("IPTV-BACKUP", "canlitv WebView prosesi dayandı (çökmə=${detail?.didCrash()})")
                    ui.post { if (!done) finish(null) }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!done && url != null && url != "about:blank") view?.evaluateJavascript(YodaResolver.AUTOPLAY_JS, null)
                }
            }
            if (timeoutMs > 0) ui.postDelayed(timeoutRun, timeoutMs) // timeoutMs <= 0: link alınana qədər müddətsiz gözlənilir
            ui.postDelayed(scanRun, 300)
            ui.postDelayed(playRun, 800)
            w.loadUrl(pageUrl, mapOf("Referer" to SITE))
        } catch (e: Throwable) {
            android.util.Log.e("IPTV-BACKUP", "canlitv WebView açıla bilmədi", e)
            finish(null)
        }
    }

    private fun onScan(raw: String?) {
        if (done || raw == null || raw == "null") return
        val text = (JSONTokener(raw).nextValue() as? String) ?: return
        for (m in M3U8.findAll(clean(text))) {
            accept(clean(m.value))
            if (done) return
        }
    }

    /** İlk çıxan .m3u8 linki (tokenli-tokensiz fərq etmir) dərhal götürülür. */
    private fun accept(url: String) {
        if (done) return
        finish(YodaResolver.Result(url, SITE, ua))
    }

    private fun finish(r: YodaResolver.Result?) {
        if (done) return
        done = true
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(scanRun)
        ui.removeCallbacks(playRun)
        val callback = cb
        cb = null
        destroyWeb()
        android.util.Log.i("IPTV-BACKUP", "canlitv nəticə: " + (r?.url ?: "tapılmadı") + " (səhifə: $page)")
        callback?.invoke(r)
    }

    private fun destroyWeb() {
        val w = web ?: return
        web = null
        runCatching {
            w.stopLoading()
            w.loadUrl("about:blank")
            container.removeView(w)
            w.destroy()
        }
    }

    fun cancel() {
        done = true
        cb = null
        ui.removeCallbacks(timeoutRun)
        ui.removeCallbacks(scanRun)
        ui.removeCallbacks(playRun)
        destroyWeb()
    }
}


/**
 * Tutulmuş ehtiyat linklərin keşi (SharedPreferences): kanalı dəyişib geri qayıdanda (və ya tətbiq yenidən açılanda)
 * gizli WebView-nı gözləmədən link dərhal açılır. Açar: "yoda:<səhifə>" / "canlitv:<səhifə>".
 * Link qırılsa keş silinir və yenisi alınır. TTL yalnız köhnə tokenli linklə vaxt itirməmək üçündür.
 */
object LinkCache {
    private const val PREFS = "backup_links"
    private const val MAX = 80
    const val YODA_TTL = 30 * 60_000L      // yoda.az tokenlidir (IP + User-Agent-ə bağlı)
    const val CANLITV_TTL = 30 * 60_000L

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(ctx: Context, key: String, ttlMs: Long): YodaResolver.Result? {
        val raw = sp(ctx).getString(key, null) ?: return null
        val p = raw.split('\t')
        if (p.size < 4) return null
        val ts = p[0].toLongOrNull() ?: return null
        if (System.currentTimeMillis() - ts > ttlMs) return null
        return YodaResolver.Result(p[1], p[2], p[3])
    }

    /** Keşdəki linkin yaşı (ms); yoxdursa -1. Fonda yenilənmə vaxtı tokenin real yaşına görə hesablanır. */
    fun age(ctx: Context, key: String): Long {
        val ts = sp(ctx).getString(key, null)?.substringBefore('\t')?.toLongOrNull() ?: return -1L
        return System.currentTimeMillis() - ts
    }

    fun put(ctx: Context, key: String, r: YodaResolver.Result) {
        val prefs = sp(ctx)
        val e = prefs.edit()
        e.putString(key, "${System.currentTimeMillis()}\t${r.url}\t${r.referer}\t${r.userAgent}")
        val all = prefs.all
        if (all.size >= MAX) {
            // ən köhnə 20 qeyd silinir
            all.entries.mapNotNull { en -> (en.value as? String)?.substringBefore('\t')?.toLongOrNull()?.let { en.key to it } }
                .sortedBy { it.second }.take(20).forEach { e.remove(it.first) }
        }
        e.apply()
    }

    fun remove(ctx: Context, key: String) {
        sp(ctx).edit().remove(key).apply()
    }

    // ---- "Əsas link problemlidir" işarəsi: kanal ehtiyat linkə keçəndə keşdə yazılır, ehtiyat linkin tokeni qədər (30 dəq) yaşayır ----
    const val MAIN_BAD_TTL = YODA_TTL

    private fun mainKey(url: String): String {
        val d = java.security.MessageDigest.getInstance("MD5").digest(url.trim().toByteArray())
        val sb = StringBuilder(16)
        for (i in 0 until 8) sb.append(String.format("%02x", d[i]))
        return "mainbad:$sb"
    }

    fun markMainBad(ctx: Context, url: String) = put(ctx, mainKey(url), YodaResolver.Result("1", "-", "-"))
    fun isMainBad(ctx: Context, url: String): Boolean = get(ctx, mainKey(url), MAIN_BAD_TTL) != null
    fun clearMainBad(ctx: Context, url: String) = remove(ctx, mainKey(url))
}
