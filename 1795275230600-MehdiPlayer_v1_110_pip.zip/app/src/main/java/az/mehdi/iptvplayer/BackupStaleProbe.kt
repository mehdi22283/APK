package az.mehdi.iptvplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.view.ViewGroup
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import kotlin.math.abs

/**
 * Ehtiyat linkin fonda səssiz yoxlanması. Cari link statik görüntü verir, amma səs gedir (musiqi kanalı) ->
 * növbəti link burada səssiz (volume 0), görünməz TextureView-da açılır və görüntünün də statik olub-olmadığı baxılır.
 *
 * Nəticə ([Result]):
 *  - MOVING: görüntü dəyişir -> ehtiyat linkə keçmək mənalıdır;
 *  - STATIC: ehtiyatda da görüntü statikdir -> keçilmir;
 *  - UNKNOWN: link açılmadı / kadr oxunmadı / vaxt bitdi -> keçilmir (cari linkdə səs gedir).
 * Pleyer yoxlama bitən kimi bağlanır (zəif TV box-da ikinci dekoder uzun qalmır). Yalnız UI thread-indən çağırılır.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class BackupStaleProbe(private val context: Context, private val container: ViewGroup) {
    enum class Result { MOVING, STATIC, UNKNOWN }

    private companion object {
        const val W = 32
        const val H = 18
        const val SAMPLE_MS = 1_000L
        const val STATIC_SAMPLES = 8
        const val STATIC_TOL = 0.3
        const val MOTION_TOL = 1.5
        const val DARK_MAX = 16
        // Link açılması + 8 nümunə üçün ümumi vaxt həddi.
        const val TOTAL_MS = 25_000L
    }

    private val ui = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var texture: TextureView? = null
    private var done: ((Result) -> Unit)? = null
    private var generation = 0
    private val hist = ArrayList<ByteArray>()
    private var bitmap: Bitmap? = null
    private val px = IntArray(W * H)

    val running: Boolean get() = done != null

    fun start(url: String, ua: String?, ref: String?, onResult: (Result) -> Unit) {
        cancel()
        val gen = ++generation
        done = onResult
        hist.clear()
        try {
            val tv = TextureView(context).apply {
                // Görünməzdir (alpha demək olar 0), toxunuşu/fokusu tutmur; alpha 0 olsaydı TextureView çəkilməzdi.
                alpha = 0.01f
                isClickable = false
                isFocusable = false
                importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            container.addView(tv, 0, ViewGroup.LayoutParams(64, 36))
            texture = tv
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    if (gen == generation) startPlayer(tv, url, ua, ref, gen)
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            ui.postDelayed({ if (gen == generation) finish(Result.UNKNOWN) }, TOTAL_MS)
        } catch (e: Throwable) {
            finish(Result.UNKNOWN)
        }
    }

    private fun startPlayer(tv: TextureView, url: String, ua: String?, ref: String?, gen: Int) {
        try {
            val http = OkHttpDataSource.Factory(StreamHttp.client)
                .setUserAgent(ua?.takeIf { it.isNotBlank() } ?: STREAM_DEFAULT_UA)
            ref?.takeIf { it.isNotBlank() }?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
            val item = MediaItem.Builder().setUri(url)
                .apply { if (url.lowercase().contains("m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8) }
                .build()
            val p = ExoPlayer.Builder(context).setMediaSourceFactory(DefaultMediaSourceFactory(http)).build()
            player = p
            p.volume = 0f
            // Səs trekə ehtiyac yoxdur: səs dekoderi/AudioTrack açılmır (əsas yayımın səsinə toxunmur).
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_AUDIO, true).build()
            p.setVideoTextureView(tv)
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    if (gen == generation) finish(Result.UNKNOWN)
                }
            })
            p.setMediaItem(item)
            p.playWhenReady = true
            p.prepare()
            ui.postDelayed(object : Runnable {
                override fun run() {
                    if (gen != generation) return
                    sample(tv)
                    if (gen == generation) ui.postDelayed(this, SAMPLE_MS)
                }
            }, SAMPLE_MS)
        } catch (e: Throwable) {
            finish(Result.UNKNOWN)
        }
    }

    private fun sample(tv: TextureView) {
        val p = player ?: return
        // Kadr çəkilməyibsə (hələ buferlənir / yalnız səs) nümunə götürülmür.
        if (p.playbackState != Player.STATE_READY || !p.isPlaying || p.videoSize.width <= 0) return
        val bmp = bitmap ?: Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { bitmap = it }
        val ok = runCatching { tv.getBitmap(bmp) }.getOrNull() != null
        if (!ok) return
        bmp.getPixels(px, 0, W, 0, 0, W, H)
        val luma = ByteArray(W * H)
        var max = 0
        for (i in px.indices) {
            val c = px[i]
            val y = (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8
            luma[i] = y.toByte()
            if (y > max) max = y
        }
        if (max < DARK_MAX) { hist.clear(); return } // qara/oxunmayan kadr saymılmır
        hist.add(luma)
        val n = hist.size
        // Hərəkət: ardıcıl nümunələr arasında aydın fərq -> görüntü canlıdır.
        if (n >= 2 && diff(hist[n - 1], hist[n - 2]) > MOTION_TOL) { finish(Result.MOVING); return }
        if (n >= STATIC_SAMPLES) {
            val last = hist[n - 1]
            var same = true
            for (i in n - STATIC_SAMPLES until n - 1) if (diff(last, hist[i]) > STATIC_TOL) { same = false; break }
            finish(if (same) Result.STATIC else Result.MOVING)
        }
    }

    private fun diff(a: ByteArray, b: ByteArray): Double {
        var s = 0
        for (i in a.indices) s += abs((a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF))
        return s.toDouble() / a.size
    }

    private fun finish(r: Result) {
        val cb = done ?: return
        teardown()
        cb(r)
    }

    private fun teardown() {
        generation++
        done = null
        ui.removeCallbacksAndMessages(null)
        runCatching { player?.release() }
        player = null
        texture?.let { runCatching { container.removeView(it) } }
        texture = null
        bitmap?.recycle()
        bitmap = null
        hist.clear()
    }

    /** Yoxlama nəticəsiz dayandırılır (kanal dəyişdi və s.). */
    fun cancel() {
        if (done != null || player != null || texture != null) teardown()
    }
}
