package az.mehdi.iptvplayer

import android.graphics.Bitmap
import android.os.Handler
import android.view.PixelCopy
import android.view.SurfaceView
import kotlin.math.abs

/**
 * Statik (donmuş / dəyişməyən şəkil) və təkrarlanan (eyni kadrların dövr etməsi) görüntünü tapır.
 *
 * Hər saniyə video səthindən (PixelCopy) 32x18 boz miniatür götürülür və son ~25 saniyənin miniatürləri saxlanır:
 *  - statik: son [STATIC_SAMPLES] miniatür (~7 s) praktiki eynidirsə (8 miniatür = 7 s);
 *  - təkrar: son kadrlar L saniyə əvvəlkilərlə (L = 2..12) kifayət qədər uzun (max(5, L) s) eynidirsə və arada hərəkət varsa.
 * Tapılanda [onStale] çağırılır. Pleyer dayanıbsa/buferləyirsə/pauzadadırsa ([canSample] false) tarixçə təmizlənir.
 * Qara/oxunmayan kadrlar (bəzi cihazlarda PixelCopy qara qaytarır) və PixelCopy xətaları saymılmır; 5 ardıcıl xətadan sonra detektor özünü söndürür.
 */
class StaleDetector(
    private val view: SurfaceView,
    private val ui: Handler,
    private val canSample: () -> Boolean,
    private val onStale: (String) -> Unit
) {
    private companion object {
        const val W = 32
        const val H = 18
        const val SAMPLE_MS = 1_000L
        const val STATIC_SAMPLES = 8
        const val STATIC_TOL = 0.3
        const val REPEAT_TOL = 1.0
        const val MOTION_MIN = 1.5
        const val MIN_LAG = 2
        const val MAX_LAG = 12
        const val MIN_PROOF = 5
        const val HISTORY = 2 * MAX_LAG + MIN_PROOF
        const val DARK_MAX = 16
        const val MAX_FAILS = 5
    }

    private val hist = ArrayDeque<ByteArray>()
    private var bitmap: Bitmap? = null
    private val px = IntArray(W * H)
    private var running = false
    private var generation = 0
    private var fails = 0

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            sample()
            if (running) ui.postDelayed(this, SAMPLE_MS)
        }
    }

    /** Yayım oynamağa başlayanda çağırılır. */
    fun start() {
        stop()
        running = true
        fails = 0
        ui.postDelayed(tick, SAMPLE_MS)
    }

    fun stop() {
        running = false
        generation++
        ui.removeCallbacks(tick)
        hist.clear()
    }

    /** Yenidən qoşulma və s.: köhnə kadrlar müqayisədən çıxarılır. */
    fun reset() {
        generation++
        hist.clear()
    }

    fun release() {
        stop()
        bitmap?.recycle()
        bitmap = null
    }

    private fun sample() {
        if (!canSample()) { hist.clear(); return }
        if (view.width <= 0 || view.height <= 0 || !view.holder.surface.isValid) { hist.clear(); return }
        val bmp = bitmap ?: Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { bitmap = it }
        val gen = generation
        try {
            PixelCopy.request(view, bmp, PixelCopy.OnPixelCopyFinishedListener { result ->
                if (!running || gen != generation) return@OnPixelCopyFinishedListener
                if (result == PixelCopy.SUCCESS) { fails = 0; onFrame(bmp) } else fail("PixelCopy=$result")
            }, ui)
        } catch (e: Throwable) {
            fail(e.javaClass.simpleName)
        }
    }

    private fun fail(why: String) {
        hist.clear()
        if (++fails >= MAX_FAILS) {
            android.util.Log.w("IPTV-STALE", "Kadr oxunmur ($why): statik/təkrar yoxlama söndürüldü")
            running = false
            ui.removeCallbacks(tick)
        }
    }

    private fun onFrame(bmp: Bitmap) {
        if (!canSample()) { hist.clear(); return }
        bmp.getPixels(px, 0, W, 0, 0, W, H)
        val luma = ByteArray(W * H)
        var max = 0
        for (i in px.indices) {
            val c = px[i]
            val y = (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8
            luma[i] = y.toByte()
            if (y > max) max = y
        }
        // Qara/oxunmayan kadr: həqiqətən qara ekran da ola bilər, amma cihazda PixelCopy qara verə bilər; saymırıq.
        if (max < DARK_MAX) { hist.clear(); return }
        hist.addLast(luma)
        while (hist.size > HISTORY) hist.removeFirst()
        check()
    }

    private fun diff(a: ByteArray, b: ByteArray): Double {
        var s = 0
        for (i in a.indices) s += abs((a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF))
        return s.toDouble() / a.size
    }

    private fun check() {
        val n = hist.size
        if (n >= STATIC_SAMPLES) {
            val last = hist[n - 1]
            var same = true
            for (i in n - STATIC_SAMPLES until n - 1) if (diff(last, hist[i]) > STATIC_TOL) { same = false; break }
            if (same) { fire("statik görüntü"); return }
        }
        for (lag in MIN_LAG..MAX_LAG) {
            val proof = maxOf(MIN_PROOF, lag)
            val need = proof + lag
            if (n < need) break
            var rep = true
            for (i in 0 until proof) if (diff(hist[n - 1 - i], hist[n - 1 - i - lag]) > REPEAT_TOL) { rep = false; break }
            if (!rep) continue
            var motion = false
            for (i in n - need until n - 1) if (diff(hist[i], hist[i + 1]) > MOTION_MIN) { motion = true; break }
            if (motion) { fire("təkrarlanan görüntü (${lag} s dövr)"); return }
        }
    }

    private fun fire(reason: String) {
        hist.clear()
        onStale(reason)
    }
}
