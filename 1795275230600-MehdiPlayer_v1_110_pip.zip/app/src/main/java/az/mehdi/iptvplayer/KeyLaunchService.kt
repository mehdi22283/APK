package az.mehdi.iptvplayer

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Əlçatımlılıq xidməti: pultun 4001 kodlu düyməsi basılanda tətbiq açılır, 4056 kodlu düymə tətbiqi açıb nömrə panelini
 * göstərir (tətbiq fonda/bağlı olsa da; artıq açıqdırsa panel açılıb-bağlanır).
 */
class KeyLaunchService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val numpad = event.keyCode == NUMPAD_TRIGGER || event.scanCode == NUMPAD_TRIGGER
        if (!numpad && event.keyCode != TRIGGER && event.scanCode != TRIGGER) return super.onKeyEvent(event)
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            runCatching {
                startActivity(Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    if (numpad) putExtra(MainActivity.EXTRA_NUMPAD, true)
                })
            }
        }
        return true // düymə başqa tətbiqə keçməsin
    }

    companion object {
        const val TRIGGER = 4001
        const val NUMPAD_TRIGGER = 4056
    }
}
