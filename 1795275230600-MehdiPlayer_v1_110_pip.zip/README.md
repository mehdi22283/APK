# Mehdi Player (IPTVPlayer) — Media3

Android TV və telefon/planşet üçün IPTV pleyer. Yeganə pleyer: **Media3 1.11.1** (ExoPlayer, OkHttp ilə; MediaCodec + **FFmpeg** dekoderləri). Versiya: **1.110** (versionCode 110). Əlaqə: Mehdi Mustafayev, 070 862 74 18 (tətbiqdə Ayarlar → Məlumat).

Texniki qərarların və hər versiyanın ətraflı qeydləri: `PLAYBACK_OPTIMIZATION.md`.

## Tez baxış
- Playlist: `https://m3u8.mehdimyev.workers.dev/` (keşlənir), kanal qrupları, axtarış, nömrə ilə keçid, EPG.
- Link açılmasa / donarsa / statik olarsa **ehtiyat linklər** (yoda.az, canlitv.com, playlist) avtomatik və ya əl ilə işə düşür.
- Çık-çık səs və donan görüntü üçün dekoder və bufer özü-özünə düzəlir, rejim kanal üzrə yadda qalır.
- Universal APK: `armeabi-v7a` + `arm64-v8a`, minSdk 24 (Android 7.0).

## İdarəetmə

### TV pultu (yayım ekranı)
| Düymə | İş |
|---|---|
| Sol / Sağ, CH−/CH+, Əvvəlki/Növbəti | əvvəlki / növbəti kanal; basıb saxlayanda sürətli keçid |
| Rəqəmlər | kanal nömrəsi (avtomatik açılır; OK gözləmədən açır) |
| **OK** (qısa) | ümumi kanal siyahısı (qruplar + kanallar); düymə buraxılanda açılır |
| **OK** (basıb saxla, ≥ 0,7 s) | **ehtiyat linkə keçid** (növbəti link; hər basışda ardıcıllıqda irəli) |
| Yuxarı / Menu | sürətli kanal paneli (yuxarı/aşağı qrup, sol/sağ kanal, OK aç, Geri bağla) |
| Aşağı / Axtarış | kanal axtarışı + klaviatura |
| Play / Pause | dayandır / davam |
| GUIDE | cari kanalın proqram cədvəli (EPG) |
| INFO | kanal məlumatı zolağı |
| Mikrofon / Assistant | səs axtarışı (az-AZ), sistem düyməni tətbiqə ötürəndə |
| Geri (qısa) | məlumat zolağı → ikinci Geri kanal siyahısı; açıq pəncərələri bağlayır |
| **Geri** (basıb saxla, ≥ 0,7 s) | **HW ↔ SW** dekoder, kanal üzrə yadda qalır |
| **4001** kodlu düymə | tətbiqi açır |
| **4056** kodlu düymə | **nömrə panelini** açır / bağlayır (tətbiq bağlı olsa da açılır) |

4001 və 4056 üçün Əlçatımlılıq xidməti (`KeyLaunchService`) aktiv olmalıdır. İlk açılışda ayarlar səhifəsi açılır; `adb shell pm grant az.mehdi.iptvplayer android.permission.WRITE_SECURE_SETTINGS` verilsə özü aktiv olur. 4056 xidmət olmadan da, tətbiq açıq ikən işləyir (düymə birbaşa tətbiqə gəlirsə).

### Kanal siyahısı və Ayarlar
- Solda qruplar, sağda kanallar. Sol kənar sütundan Sol düymə qruplara qaytarır, qruplardan Sağ düymə kanallara keçir; Sol/Sağ basıb saxlamaq kanallar arasında sürətlə gəzdirir.
- Qrupların altında **⚙️ Ayarlar**: *Kanalların Yerini Dəyiş* (seçilən qrupda sıra, `Reorder.kt`, yadda qalır, sıfırlama var) və **ℹ️ Məlumat** (əlaqə + tam istifadə qaydası, `AboutDialog.kt`; pultda yuxarı/aşağı ilə sürüşür).

### Telefon / planşet (toxunma)
- Videoya **tək toxunuş**: yuxarıda siyahı, 123 (rəqəm paneli), 🎤, 🔍, kanal zolağı və proqram cədvəli düymələri; sağ yuxarıda ikinci cərgədə **↻ Ehtiyat link** və **HW/SW**. 4 s sonra gizlənir.
- **İki dəfə toxunuş**: pauza / davam. **Mərkəzi basıb saxla**: HW ↔ SW.
- **Sağa/sola sürüşdür**: əvvəlki / növbəti kanal. **Sağ yarıda yuxarı/aşağı**: səs; **sol yarıda**: parlaqlıq.
- Siyahı və proqram cədvəlində ✕ düyməsi; sistem "geri" jesti də işləyir.

### Axtarış və nömrə
- Hərf yazdıqca nəticələr dinamik yenilənir: əvvəl adı həmin hərflə başlayanlar, sonra söz başlayanlar, sonra içində olanlar. Azərbaycan hərfləri (ə, ı, ö, ü, ş, ç, ğ) latın qarşılığı ilə də tapılır. Nömrə yazmaq da işləyir. Enter birinci nəticəni açır.
- **Ekran rəqəm paneli** (telefon və 4056): 0–9, ⌫, ✓. TV pultunda yön düymələri panelin düymələri arasında hərəkət edir (kənardan əks tərəfə dövr edir), OK fokuslanmış düyməni basır; pult rəqəmləri də işləyir. Nömrə yuxarı sağda göstərilir, 10 s hərəkətsizlikdən sonra panel bağlanır (hər düymə basışında yenilənir).
- **Səs axtarışı**: "Xəzər TV" → kanal açılır (Həzər/Hazar/Khazar, kiril yazılış, 1–2 hərf səhvi uyğunlaşdırılır). Dinləmə zamanı səs müvəqqəti söndürülür.

## Kanal açılışı və avtomatik bərpa
- Link birbaşa Media3-ə verilir; HTTP 4xx/5xx və ya qoşulma xətasında dərhal növbəti link (yoxdursa "Kanal İşləmir"). Hər link üçün **5 s**: bu müddətdə açılmasa növbəti linkə keçilir (`LINK_WAIT_MS`).
- İşləyən kanal qırılsa/donsa avtomatik yenidən qoşulur: vaxt 5 s donarsa, bufer 20 s dolmursa (`STALL_*`). Buferlənmədə pleyer qaldığı yerdən davam edir. Şəbəkə kəsilib qayıdanda kanal dərhal bərpa olunur.
- **Çık-çık səs / donan görüntü** (`Media3Engine`): səs underrun-ları və atılan kadrlar izlənir; addım-addım: 1) səs FFmpeg-lə, 2) bufer səviyyəsi +1, 3) səs və video FFmpeg-lə (TV-də video FFmpeg-ə yalnız dekoder tam açılmasa keçir). AVC/AAC üçün `NO_TUNNEL` rejimi (tunneling olmadan). Ən çox 3 düzəliş; işləyən rejim kanal üzrə yadda qalır (`DecoderMemory`).
- **Ağıllı bufer** (`BufferMemory`): 2 dəqiqədə 3 buferlənmə → səviyyə +1; 20 dəqiqə buferlənmə yoxdursa −1; kanal üzrə yadda qalır.
- MP2/MP1 səsi həmişə FFmpeg dekoderi ilə açılır. HLS aşkarlanması `.m3u8` ilə bitməyən linkləri də tutur; format səhv təxmin olunsa bir dəfə tərsi sınanır.
- Son kanal link, ad, qrup və tvg-id ilə saxlanılır; playlistdə link dəyişsə də tapılır. `App.kt` tutulmayan xətada tətbiqi yenidən açır (15 s-də təkrar çökərsə açmır).

## Ehtiyat linklər
Playlistdəki link problemli olanda növbəti mənbələr (`Backup.kt`, `MainActivity`):
- **yoda.az**: kanalın səhifəsi gizli WebView-da açılır, tokenli `.m3u8` tutulur. Token IP və User-Agent-ə bağlıdır, link bu cihazda alınır və eyni UA/Referer ilə oynadılır. Token 30 dəq yaşayır: oynayan yayım dayanmadan 28-ci dəqiqədə fonda yenilənir.
- **canlitv.com**: `assets/canlitv_channels.txt` siyahısındakı kanallar (`Ad | səhifə | az/tr`), səhifədən `.m3u8` tutulur.
- Tutulmuş linklər keşlənir (`LinkCache`, hər biri 30 dəq) və kanala qayıdanda dərhal açılır; link qırılsa keş silinir, ən çox 3 dəfə yenilənir.
- Ad uyğunlaşdırması: HD/FHD/TR, mötərizə içi və "TV" sözü atılır; əvvəl bütün ad, sonra sondan söz-söz qısaldılır ("Kanal D HD TR Kanka" → "Kanal D"). "ATV" = Türkiyə, "ATV Azad" = Azərbaycan. Real, İdman, Space, Dünya, MTV yalnız Azərbaycan kontekstində Azərbaycan kanalı sayılır.

**Açılış sırası** (kodda `Backup.kt`):
- Real TV, İdman TV: yoda.az → playlist → canlitv.com.
- Mədəniyyət, Space, MTV, APA TV, Biznes TV, Qafqaz TV, Naxçıvan TV, Kanal 35: canlitv səhifəsi varsa canlitv.com → playlist → yoda.az, yoxdursa yoda.az → playlist.
- Türkiyə kanalları: playlist → canlitv.com.
- Digərləri: playlist → yoda.az (səhifəsi varsa) → canlitv.com.

**Əsas linkə qayıdış**: kanal ehtiyatda oynayanda problemli əsas link fonda yoxlanır (`MainLinkProbe`, yalnız OkHttp, ikinci dekoder yoxdur): 10 s yoxlama, aralıq 60 s-dən 10 dəq-yə qədər artır; düzəlibsə ona qayıdılır.

## Statik və təkrarlanan görüntü
`StaleDetector.kt`: hər saniyə video səthindən 32×18 boz miniatür (PixelCopy).
- **Statik**: son 8 miniatür (~7 s) eynidirsə (hədd 0.3).
- **Loop**: son kadrlar 2–12 s əvvəlkilərlə eyni və arada hərəkət varsa. Daha uzun dövrlər (məsələn 1–2 dəq) aşkarlanmır.
- Qara/oxunmayan kadrlar və PixelCopy xətaları saymılmır; 5 ardıcıl xətada detektor özünü söndürür. Buferlənmə və pauzada yoxlama dayanır.
- Tapılanda **səs yoxdursa** dərhal növbəti linkə keçilir.
- **Səs gedirsə** (məs. musiqi kanalında sabit şəkil): `BackupStaleProbe.kt` növbəti linki fonda səssiz, görünməz TextureView-da (səs treki söndürülmüş) ≤ 25 s açıb baxır. Orada görüntü dəyişirsə keçilir; orada da statikdirsə, link açılmayıbsa və ya kadr oxunmayıbsa keçilmir, cari linkdə səs davam edir. Bu yoxlamadan sonra həmin oynatma üçün detektor yenidən işləmir.

## TV (TCL 65C6K / Google TV) və dekoder
- Video `SurfaceView` + `MediaCodec` (hardware); şəkil mühərriki (AiPQ, MEMC, local dimming, Dolby Vision IQ) TV-nin öz işidir. Tunneled playback TV-də həmişə açıqdır (yalnız hardware rejimində). Video kadrı tətbiqdə böyüdülmür (`SCALE_TO_FIT`).
- Media3-ün kadr tezliyi keçidi **söndürülüb**; ekran Hz-i sistemin seçimidir. Çıxış 4K-dan aşağıdırsa eyni Hz-də 4K rejim istənir (`TvProfile.uhdModeId`, `applyUhdOutput`).
- HDR: TV dəstəkləyirsə pəncərə rəng rejimi həmişə HDR (HDR10/HDR10+/HLG/Dolby Vision SDR-ə endirilmir).
- `TvProfile`: TV aşkarlanması, RAM, maksimum Hz, HDR növləri icra zamanı oxunur (`IPTV-TV` log teqi). Bufer: RAM ≥ 2,2 GB olan TV-də 48 MB / 30 s, digərlərində 24 MB / 20 s; `largeHeap`.
- **Dolby/DTS passthrough** (`AudioPassthrough.kt`): cihaz AC3/E-AC3/DTS/DTS-HD/TrueHD-ni qəbul edirsə dekod edilmədən ötürülür (məlumat sətrində `PT`); əks halda FFmpeg PCM-ə çevirir.
- Məlumat zolağı: `nömrə.ad ölçü ad bufer qrup` (məs. `1.AZTV HD 🟢 Hamısı`); proqram dekoderdə `SW`, HDR varsa sonda (`FHD HDR10`).
- **Watch Next** (`WatchNext.kt`): kanal 20 s izlənəndən sonra Android TV ana ekranının "Continue watching" cərgəsinə yazılır (ən çox 5); playlistin ilk kanalları da sıra ilə yazılır. Kartı seçəndə kanal açılır.

## EPG və loqolar
- EPG: `iptvx.one` mənbəyi, `Epg.kt`. Playlist adları XML kanallarına HD/TR/boşluq/diakritikdən asılı olmadan bağlanır; əl ilə əlaqələr `EPG_ALIASES`-dədir (cbc-sport, ictimai-tv, muztv, kanal-7-hd-tr, show-hd-tr, star-tv-hd-tr, tv8-tr, tv85-tr, trt-* və s.). Proqram təsviri 160 simvolla məhduddur.
- Kanal loqoları `Logos.kt`, loqosuz kanallar üçün `LogoPlaceholder.kt`.

## Quraşdırma və imza
- `app/mehdi-release.jks` (alias `mehdi`) **sabit imza açarıdır**: `release` və `debug` eyni açarla imzalanır, ona görə yeniləmə köhnə versiyanın üstünə silmədən quraşdırılır. Parollar `app/build.gradle.kts`-dədir.
- **Açarı və parolu saxlayın.** İtirilsə, yeni açarla imzalanan versiya köhnənin üstünə düşməz. Repo public olmamalıdır (açar repodadır) və ya açar CI secret-inə köçürülməlidir.
- Hər yeni quraşdırma üçün `versionCode` əvvəlkindən böyük olmalıdır.
- Hər iki build növü R8 kod kiçiltmə və resurs kiçiltmə ilə işləyir (`proguard-rules.pro`: native/JNI sinifləri, NextLib, Media3 qaydaları), `isDebuggable = false`.
- Ayrıca imza açarı olmayan köhnə (debug açarı ilə imzalanmış) quraşdırmanı bir dəfə silib yenidən quraşdırmaq lazımdır.

```bash
gradle assembleRelease --no-daemon   # və ya assembleDebug (eyni açarla imzalanır)
```

## Toolchain
JDK 17, Gradle 8.14.3 (CI), AGP 8.11.1, Kotlin 2.2.21 (NextLib Kotlin 2.2 ilə yığılıb), compileSdk 36, targetSdk 35, minSdk 24, core library desugaring. OkHttp 4.12.0. FFmpeg dekoderləri: `io.github.anilbeesetti:nextlib-media3ext:1.11.1-0.16.0` (NextLib, **GPL-3.0**; versiya adı `<Media3>-<NextLib>`, Media3 ilə eyni saxlanmalıdır). Əvvəlki mpv və VLC silinib. Maven Central güzgüsü `settings.gradle.kts`-də (CI-da 429 xətası üçün ehtiyat).

## Fayllar
- `MainActivity.kt` — ekran, siyahı, axtarış, pult/toxunma, ehtiyat link ardıcıllığı; `Adapters.kt`, `ChannelRow.kt` — siyahı elementləri.
- `Engines.kt` — `PlayerManager` (bərpa, watchdog, ağıllı bufer); `Media3Engine.kt` — mühərrik (OkHttp, dekoder rejimləri, keyfiyyət nəzarəti).
- `StaleDetector.kt` — statik/loop; `BackupStaleProbe.kt` — ehtiyatın səssiz yoxlanması; `MainLinkProbe.kt` — əsas linkin şəbəkə yoxlaması.
- `Backup.kt` — yoda.az / canlitv.com resolver-ləri, açılış sırası, `LinkCache`.
- `Data.kt` — playlist, `Channel`; `Epg.kt`, `Logos.kt`, `LogoPlaceholder.kt`, `Reorder.kt` (sıra), `BufferMemory.kt`, `DecoderMemory.kt` — kanal üzrə yaddaşlar.
- `TvProfile.kt`, `AudioPassthrough.kt`, `WatchNext.kt`, `VoiceSearch.kt`, `KeyLaunchService.kt`, `AboutDialog.kt`, `App.kt`.

## Loglar
`adb logcat -s IPTV-PLAYER IPTV-MEDIA3 IPTV-BACKUP IPTV-STALE IPTV-TV IPTV-PASSTHROUGH`

## Versiya qeydləri (qısa)
- **1.110**: versiya nömrəsi koda uyğunlaşdırıldı (build/README əvvəl 1.102 göstərirdi, kod 1.106+ idi); telefonda **PiP** düyməsi (toxunma idarəetməsində, sağ yuxarı ikinci cərgə). 1.103–1.109 üçün ayrıca qeyd saxlanmayıb.
- **1.102**: rəqəm panelində pult yön düymələri ilə hərəkət (1, 5 seç → ✓ təsdiqlə).
- **1.101**: 4056 düyməsi nömrə panelini açır/bağlayır.
- **1.100**: telefonda "↻ Ehtiyat link" və "HW/SW" düymələri.
- **1.99**: pultda OK basıb saxlamaq ehtiyat linkə keçir; Ayarlar → Məlumat.
- **1.98**: sabit imza açarı və `release`; statik görüntü + səs olanda (musiqi kanalı) ehtiyat linkin fonda səssiz yoxlanması; AFR və 60 Hz sabitləməsi silinib.
- **1.92–1.95**: statik/loop həddləri dəqiqləşdirildi, buferlənmə vaxt aşımı 20 s, Ayarlar düyməsi.
- **1.47**: virtual pult silindi, Əlçatımlılıq xidməti (4001) əlavə olundu. **1.44**: rəngli düymələr silindi.
- Daha əvvəlkilər: `PLAYBACK_OPTIMIZATION.md`.
