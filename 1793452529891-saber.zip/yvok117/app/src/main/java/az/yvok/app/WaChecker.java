package az.yvok.app;

import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.util.ArrayList;

/**
 * Nömrənin Whatsapp-ı olub-olmadığını Whatsapp-ı AÇMADAN yoxlayır.
 * Üsul: Whatsapp özü kontaktları sinxronlaşdırır və Whatsapp-lı nömrələrə kontakt bazasında
 * «vnd.com.whatsapp.profile» sətri yazır. Nömrə kontaktlarda yoxdursa müvəqqəti kontakt yaradılır,
 * Whatsapp-ın sinxronunu gözlənilir, nəticədən sonra müvəqqəti kontakt silinir.
 */
public class WaChecker {
    public interface Callback { void onResult(String state); }   // "yes" | "no"

    private static final String TMP_NAME = "__yvok_wa_check__";
    private static final String[] MIMES = {
            "vnd.android.cursor.item/vnd.com.whatsapp.profile",
            "vnd.android.cursor.item/vnd.com.whatsapp.w4b.profile"
    };
    private static final long MAX_WAIT_MS = 10000, STEP_MS = 1000;

    /** phone9 — 9 rəqəm, 0 olmadan (məs. 551234567) */
    public static void check(final Context ctx, final String phone9, final Callback cb) {
        new Thread(() -> {
            String state = "no";
            long rawId = -1;
            try {
                cleanup(ctx);                                   // əvvəlki yarımçıq müvəqqəti kontaktlar
                if (hasWa(ctx, phone9)) { cb.onResult("yes"); return; }
                rawId = insertTemp(ctx, phone9);
                long t0 = System.currentTimeMillis();
                while (System.currentTimeMillis() - t0 < MAX_WAIT_MS) {
                    Thread.sleep(STEP_MS);
                    if (hasWa(ctx, phone9)) { state = "yes"; break; }
                }
            } catch (Throwable e) {
                state = "no";
            } finally {
                try { cleanup(ctx); } catch (Throwable ignore) { }
            }
            cb.onResult(state);
        }, "wa-check").start();
    }

    private static boolean hasWa(Context ctx, String p9) {
        String jid = "994" + p9 + "@s.whatsapp.net";
        ContentResolver cr = ctx.getContentResolver();
        for (String mime : MIMES) {
            try (Cursor c = cr.query(ContactsContract.Data.CONTENT_URI, new String[]{ContactsContract.Data._ID},
                    ContactsContract.Data.MIMETYPE + "=? AND " + ContactsContract.Data.DATA1 + "=?",
                    new String[]{mime, jid}, null)) {
                if (c != null && c.getCount() > 0) return true;
            } catch (Throwable ignore) { }
        }
        return false;
    }

    private static long insertTemp(Context ctx, String p9) throws Exception {
        ArrayList<ContentProviderOperation> ops = new ArrayList<>();
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build());
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, TMP_NAME).build());
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, "+994" + p9)
                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build());
        android.content.ContentProviderResult[] r = ctx.getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
        return ContentUris.parseId(r[0].uri);
    }

    /** Adı __yvok_wa_check__ olan bütün müvəqqəti kontaktları silir */
    private static void cleanup(Context ctx) {
        ContentResolver cr = ctx.getContentResolver();
        ArrayList<Long> ids = new ArrayList<>();
        try (Cursor c = cr.query(ContactsContract.Data.CONTENT_URI, new String[]{ContactsContract.Data.RAW_CONTACT_ID},
                ContactsContract.Data.MIMETYPE + "=? AND " + ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME + "=?",
                new String[]{ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE, TMP_NAME}, null)) {
            while (c != null && c.moveToNext()) ids.add(c.getLong(0));
        } catch (Throwable ignore) { }
        for (long id : ids) {
            try {
                Uri u = ContentUris.withAppendedId(ContactsContract.RawContacts.CONTENT_URI, id)
                        .buildUpon().appendQueryParameter(ContactsContract.CALLER_IS_SYNCADAPTER, "true").build();
                cr.delete(u, null, null);
            } catch (Throwable ignore) { }
        }
    }
}
