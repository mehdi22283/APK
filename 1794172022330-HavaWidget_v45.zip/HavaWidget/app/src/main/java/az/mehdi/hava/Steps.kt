package az.mehdi.hava

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import java.time.LocalDate
import java.util.Locale

object Steps {
    private fun p(c: Context) = c.getSharedPreferences("steps", Context.MODE_PRIVATE)

    /** Sensor dəyəri (açılışdan bəri addımlar) -> bu günün addımları */
    fun onSensor(c: Context, raw: Float): Int {
        val p = p(c)
        val today = LocalDate.now(BAKU).toString()
        var base = p.getFloat("base", raw)
        var offset = p.getInt("offset", 0)
        if (p.getString("day", "") != today) {
            base = raw
            offset = 0
        } else if (raw < p.getFloat("lastRaw", raw)) { // telefon yenidən başladılıb
            offset = p.getInt("steps", 0)
            base = 0f
        }
        val steps = offset + (raw - base).toInt()
        // dəyişiklik yoxdursa yazma (batareya/yaddaş)
        if (p.getString("day", "") == today && p.getInt("steps", -1) == steps && p.getFloat("lastRaw", -1f) == raw) return steps
        p.edit().putString("day", today).putFloat("base", base).putInt("offset", offset)
            .putFloat("lastRaw", raw).putInt("steps", steps).apply()
        return steps
    }

    fun get(c: Context): Int {
        val p = p(c)
        return if (p.getString("day", "") == LocalDate.now(BAKU).toString()) p.getInt("steps", 0) else 0
    }

    /** Boy sabitdir: 180 sm */
    @Suppress("UNUSED_PARAMETER")
    fun height(c: Context): Int = 180

    // addım uzunluğu ≈ boy × 0.415
    fun km(c: Context): Double = get(c) * height(c) * 0.415 / 100000.0
    fun kmText(c: Context): String = String.format(Locale.US, "%.2f km", km(c))
    fun stepsText(c: Context): String = String.format(Locale.US, "%,d", get(c)).replace(',', ' ')
}

/**
 * Addımları aparat sayğacı (TYPE_STEP_COUNTER) özü sayır — tətbiq işləməsə də sayır.
 * Ona görə fon xidməti və bildiriş lazım deyil: dəyər yalnız lazım olanda (00:00, tətbiq açılanda,
 * telefon yenidən başlayanda) bir dəfə oxunur və dərhal buraxılır.
 */
object StepReader {
    /** Dəyəri bir dəfə oxuyur (arxa plan thread-dən çağırın). Maks. 3 san. gözləyir. */
    fun readBlocking(c: Context) {
        if (!Scheduler.hasActivityPerm(c)) return
        val sm = c.getSystemService(SensorManager::class.java) ?: return
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return
        val latch = java.util.concurrent.CountDownLatch(1)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                Steps.onSensor(c, e.values[0])
                latch.countDown()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        try {
            if (sm.registerListener(l, s, SensorManager.SENSOR_DELAY_NORMAL, 0)) latch.await(3, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        } finally {
            try { sm.unregisterListener(l) } catch (e: Exception) { }
        }
    }

    /** Tətbiq ekranda olarkən canlı izləmə; geri qaytarılan funksiya izləməni dayandırır */
    fun watch(c: Context, onChange: () -> Unit): () -> Unit {
        if (!Scheduler.hasActivityPerm(c)) return {}
        val sm = c.getSystemService(SensorManager::class.java) ?: return {}
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return {}
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                Steps.onSensor(c, e.values[0])
                onChange()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        try { sm.registerListener(l, s, SensorManager.SENSOR_DELAY_UI, 0) } catch (e: Exception) { return {} }
        return { try { sm.unregisterListener(l) } catch (e: Exception) { } }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.start(c)
        Midnight.schedule(c)
        RainAlert.schedule(c) // keşdəki proqnozdan yağış xəbərdarlığı yenidən qurulsun
        WeatherWidget.refresh(c) // yeniləmədən dərhal sonra vidcet köhnə görünüşdə qalmasın
        Scheduler.now(c) // addımı da oxuyur və hava məlumatını yeniləyir
    }
}
