(function(code){
  var S = window.__yS;
  if (!S || S.code !== code) { S = window.__yS = { code: code, filled: false, clicked: false, polls: 0, field: null }; }
  S.polls++;
  function vis(el){ var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function fire(el){
    var r = el.getBoundingClientRect();
    var o = {bubbles:true, cancelable:true, view:window, clientX:r.left+r.width/2, clientY:r.top+r.height/2};
    ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){
      try { var E = (n.indexOf('pointer')===0 && window.PointerEvent) ? PointerEvent : MouseEvent; el.dispatchEvent(new E(n, o)); } catch(e){}
    });
    try { el.click(); } catch(e){}
  }
  function leaf(re){
    var els = [].slice.call(document.querySelectorAll('body *'));
    for (var i=0; i<els.length; i++){
      var e = els[i];
      if (e.children.length > 0 || !vis(e)) continue;
      if (re.test(((e.innerText||e.textContent)+'').trim())) return e;
    }
    return null;
  }
  function textAfter(re){
    var l = leaf(re);
    if (!l) return '';
    var lt = ((l.innerText||l.textContent)+'').trim();
    var p = l;
    for (var d=0; d<4 && p; d++){
      p = p.parentElement; if (!p) break;
      var t = ((p.innerText||'')+'').replace(lt,'').replace(/\s+/g,' ').trim();
      if (t) return t;
    }
    return '';
  }
  function amountVal(){
    var l = leaf(/^məbləğ\s*\(azn\)\s*:?$/i);
    if (!l) return '';
    var p = l;
    for (var d=0; d<5 && p; d++){
      p = p.parentElement; if (!p) break;
      var ins = p.querySelectorAll('input');
      for (var i=0; i<ins.length; i++){
        var v = (ins[i].value||'').trim();
        if (/^-?\d+([.,]\d+)?$/.test(v)) return v;
      }
      if (ins.length) return '';
    }
    return '';
  }
  function findBtn(){
    var ft = S.field ? S.field.getBoundingClientRect().top : 0;
    var els = [].slice.call(document.querySelectorAll('button,a,span,div,p,label,input[type=submit],input[type=button]')).filter(function(e){
      if (!vis(e)) return false;
      var t = ((e.innerText||e.value||'')+'').trim().toLowerCase();
      return t === 'axtar' && e.getBoundingClientRect().top >= ft - 5;
    });
    if (els.length) {
      var e0 = els[els.length-1];
      for (var q=0; q<els.length; q++){ if (els[q].tagName==='BUTTON' || els[q].tagName==='INPUT'){ e0 = els[q]; break; } }
      var c = e0.closest ? e0.closest('button,a,[role=button],[onclick]') : null;
      return c || e0;
    }
    var btns = [].slice.call(document.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a.btn,a[class*=btn],div[class*=btn]')).filter(vis);
    var words = ['axtar','search','yoxla','tap','göstər','sorğu'];
    for (var w=0; w<words.length; w++) for (var j=0; j<btns.length; j++){
      var t2 = ((btns[j].innerText||btns[j].value||btns[j].getAttribute('aria-label')||'')+'').toLowerCase();
      if (t2.indexOf(words[w]) >= 0) return btns[j];
    }
    for (var j2=0; j2<btns.length; j2++) if ((btns[j2].type||'') === 'submit') return btns[j2];
    var p = S.field;
    for (var d=0; d<5 && p; d++){
      p = p.parentElement; if (!p) break;
      var bs = [].slice.call(p.querySelectorAll('button,input[type=submit]')).filter(vis);
      if (bs.length) return bs[bs.length-1];
    }
    return btns.length ? btns[btns.length-1] : null;
  }
  var out = { payer:'', yvok:'', amount:'', nf:false, st:'' };
  if (!S.filled) {
    var inputs = [].slice.call(document.querySelectorAll('input')).filter(function(i){
      var t = (i.type||'text').toLowerCase();
      if (i.readOnly || i.disabled || !vis(i)) return false;
      if (!(t==='text'||t==='search'||t==='tel'||t==='number')) return false;
      if ((i.placeholder||'').toLowerCase().indexOf('axtar') >= 0) return false;
      if (i.closest && i.closest('[class*=searchContainer]')) return false;
      if ((i.value||'').trim().toLowerCase() === 'yvök') return false;
      return true;
    });
    if (!inputs.length) { out.st = 'wait'; return JSON.stringify(out); }
    var f = inputs[inputs.length-1];
    S.field = f;
    var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
    f.focus(); setter.call(f, code);
    ['keydown','input','keyup','change'].forEach(function(n){
      try { f.dispatchEvent(n.indexOf('key')===0 ? new KeyboardEvent(n,{key:'0',bubbles:true}) : new Event(n,{bubbles:true})); } catch(e){}
    });
    S.filled = true; out.st = 'filled';
    return JSON.stringify(out);
  }
  out.payer = textAfter(/^ödəyən\s*:$/i);
  out.yvok = textAfter(/^yvök\s*:$/i);
  out.amount = amountVal();
  if (out.payer && out.amount) { out.st = 'result'; return JSON.stringify(out); }
  if (!S.clicked) {
    var b = findBtn();
    if (!b) { out.st = 'nobtn'; return JSON.stringify(out); }
    if (b.disabled) { try { S.field.dispatchEvent(new Event('input',{bubbles:true})); } catch(e){} out.st = 'btndis'; return JSON.stringify(out); }
    S.clicked = true; S.clickPoll = S.polls;
    fire(b);
    out.st = 'clicked';
    return JSON.stringify(out);
  }
  // "tapılmadı" xəbərdarlığı yalnız düymə basıldıqdan bir neçə sorğu sonra yoxlanılır
  if (S.polls - S.clickPoll >= 6) {
    var bt = ((document.body && document.body.innerText) || '');
    if (/tapılmad[ıi]|tapılmay[ıi]b|mövcud deyil|məlumat yoxdur|düzgün deyil/i.test(bt)) out.nf = true;
  }
  out.st = 'waiting';
  return JSON.stringify(out);
})('__CODE__')
