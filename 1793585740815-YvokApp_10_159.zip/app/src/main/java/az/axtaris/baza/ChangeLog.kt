package az.axtaris.baza

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject

/**
 * Bazadakı dəyişikliklərin tarixçəsi (geri alma yoxdur). Qeydlər avtomatik Supabase-ə göndərilir, digər cihazda da görünür.
 * Borc yenilənmələri jurnala düşmür.
 */
object ChangeLog {
    class Entry(val id: Long, val ts: Long, val descr: String)

    /** Jurnalda izlənən edits.db cədvəlləri və xana sayları */
    private val TABLES = arrayOf("edits" to 5, "imp_sheets" to 4, "imp_rows" to 4, "renames" to 4, "added" to 4,
        "added_rows" to 4, "deleted_rows" to 3, "deleted_cats" to 3, "moved_cats" to 5)

    @JvmStatic
    fun ensure(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS deleted_cats(kind TEXT, a TEXT, b TEXT, PRIMARY KEY(kind, a, b))")
        db.execSQL("CREATE TABLE IF NOT EXISTS moved_cats(kind TEXT, a TEXT, b TEXT, c TEXT, d TEXT, PRIMARY KEY(kind, a, b))")
        db.execSQL("CREATE TABLE IF NOT EXISTS change_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, descr TEXT, diff TEXT)")
    }

    @JvmStatic
    fun snapshot(db: SQLiteDatabase): HashMap<String, HashSet<String>> {
        val m = HashMap<String, HashSet<String>>()
        for ((t, n) in TABLES) {
            val set = HashSet<String>()
            try {
                db.rawQuery("SELECT * FROM $t", null).use { c ->
                    while (c.moveToNext()) {
                        val a = JSONArray()
                        for (i in 0 until n) {
                            if (c.getType(i) == Cursor.FIELD_TYPE_INTEGER) a.put(c.getLong(i)) else a.put(c.getString(i) ?: "")
                        }
                        set.add(a.toString())
                    }
                }
            } catch (e: Exception) { }
            m[t] = set
        }
        return m
    }

    /** Əvvəlki snapshot ilə indiki arasında fərq varsa jurnala yazır. true - yazıldı */
    @JvmStatic
    fun record(db: SQLiteDatabase, descr: String, before: HashMap<String, HashSet<String>>): Boolean {
        try {
            ensure(db)
            val after = snapshot(db)
            val diff = JSONObject()
            for ((t, _) in TABLES) {
                val b = before[t] ?: HashSet()
                val a = after[t] ?: HashSet()
                val added = JSONArray(); val removed = JSONArray()
                for (r in a) if (!b.contains(r)) added.put(JSONArray(r))
                for (r in b) if (!a.contains(r)) removed.put(JSONArray(r))
                if (added.length() > 0 || removed.length() > 0) diff.put(t, JSONObject().put("add", added).put("del", removed))
            }
            if (diff.length() == 0) return false
            db.execSQL("INSERT INTO change_log(ts, descr, diff) VALUES(?,?,?)", arrayOf<Any>(System.currentTimeMillis(), descr, diff.toString()))
            db.execSQL("DELETE FROM change_log WHERE id NOT IN (SELECT id FROM change_log ORDER BY id DESC LIMIT 300)")
            PendingChanges.syncSoon()   // «Dəyişikliklər»dəki yeni qeyd avtomatik Supabase-ə göndərilir
            return true
        } catch (e: Exception) { return false }
    }

    @JvmStatic
    fun list(db: SQLiteDatabase): List<Entry> {
        val l = ArrayList<Entry>()
        try {
            ensure(db)
            db.rawQuery("SELECT id, ts, descr FROM change_log ORDER BY id DESC", null).use { c ->
                while (c.moveToNext()) l.add(Entry(c.getLong(0), c.getLong(1), c.getString(2) ?: ""))
            }
        } catch (e: Exception) { }
        return l
    }

    @JvmStatic
    fun clear(db: SQLiteDatabase) { try { db.execSQL("DELETE FROM change_log") } catch (e: Exception) { } }
}
