package az.mehdi.iptvplayer

import android.app.Activity
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

/** Ayarlar → Məlumat: əlaqə və tətbiqin istifadə qaydası. Pultda yuxarı/aşağı düymələri mətni sürüşdürür. */
object AboutDialog {
    private const val TEXT = """Əlaqə: 070 862 74 18
Mehdi Mustafayev

━━━━━━━━━━━━━━━━━━
TV PULTU (yayım ekranı)
━━━━━━━━━━━━━━━━━━
• Sol / Sağ (və ya CH−/CH+, əvvəlki/növbəti): əvvəlki / növbəti kanal. Basıb saxlasan kanallar sürətlə keçir.
• Rəqəm düymələri: kanal nömrəsini yığ, kanal özü açılır. OK bassan gözləmədən açılır.
• OK (qısa basış): ümumi kanal siyahısı (solda qruplar, sağda kanallar).
• OK (basıb saxla, ~0,7 s): ehtiyat linkə keçid. Kanal donubsa, görüntü statikdirsə və ya açılmırsa istifadə et. Hər basıb saxlamada ardıcıllıqdakı növbəti link açılır (yoda.az, canlitv.com, playlist). Növbəti link yoxdursa bu barədə mesaj çıxır.
• Yuxarı (və ya Menu): sürətli kanal paneli. Panelde yuxarı/aşağı qrupu, sol/sağ kanalı dəyişir, OK kanalı açır, Geri bağlayır.
• Aşağı (və ya pultun axtarış düyməsi): kanal axtarışı və klaviatura. Hərf yazdıqca nəticələr çıxır, Enter birinci nəticəni açır, nəticəyə OK kanalı açır.
• Play / Pause: yayımı dayandırır / davam etdirir.
• GUIDE: cari kanalın proqram cədvəli (EPG).
• INFO: kanal məlumatı zolağı.
• Mikrofon / Assistant düyməsi: səs ilə axtarış (məs. "Xəzər TV" de, kanal açılır). Sistem düyməni tətbiqə ötürəndə işləyir.
• Geri (qısa): əvvəl alt məlumat zolağı, ikinci Geri kanal siyahısı. Açıq pəncərələr (axtarış, panel, EPG) Geri ilə bağlanır.
• Geri (basıb saxla, ~0,7 s): kanalın dekoderini HW ↔ SW dəyişir. Şəkil/səs problemi olanda sına. Seçim kanal üzrə yadda qalır.
• 4001 kodlu düymə: tətbiqi açır (yalnız Əlçatımlılıq xidməti aktivdirsə).
• 4056 kodlu düymə: nömrə panelini açır (tətbiq bağlı olsa da açılır, panel açıqdırsa bağlayır). Nömrəni yığıb kanalı tapırsan. Bağlı tətbiqdə işləməsi üçün Əlçatımlılıq xidməti aktiv olmalıdır.

━━━━━━━━━━━━━━━━━━
KANAL SİYAHISI
━━━━━━━━━━━━━━━━━━
• Soldakı qruplardan birini seç, sağda kanalları gör. Sol kənar sütundan Sol düyməsi qruplara qaytarır, qruplardan Sağ düyməsi kanallara keçir.
• Sol/Sağ düyməsini basıb saxlamaq kanallar arasında sürətlə gəzdirir.
• Qrupların altında "⚙️ Ayarlar" düyməsi var: "Kanalların Yerini Dəyiş" seçilmiş qrupda kanalların sırasını dəyişir, "Məlumat" bu səhifəni açır.

━━━━━━━━━━━━━━━━━━
TELEFON / PLANŞET (toxunma)
━━━━━━━━━━━━━━━━━━
• Videoya tək toxunuş: yuxarıda kanallar siyahısı, axtarış (🔍), rəqəm paneli (123) və proqram cədvəli düymələri çıxır, 4 s sonra gizlənir.
• Sağ yuxarıda "↻ Ehtiyat link" düyməsi: növbəti (ehtiyat) linkə keçir (pultda OK basıb saxlamaq kimi). "HW/SW" düyməsi: dekoderi dəyişir (pultda Geri basıb saxlamaq kimi).
• İki dəfə toxunuş: pauza / davam.
• Ekranın mərkəzini basıb saxla: HW ↔ SW.
• Sağa / sola sürüşdür: əvvəlki / növbəti kanal.
• Sağ yarıda yuxarı/aşağı sürüşdür: səs. Sol yarıda: ekran parlaqlığı.
• Siyahı və proqram cədvəlində sağ yuxarıdakı ✕ düyməsi bağlayır.

━━━━━━━━━━━━━━━━━━
AVTOMATİK İŞLƏYƏNLƏR
━━━━━━━━━━━━━━━━━━
• Playlistdəki link açılmasa, tətbiq ehtiyat linkə (yoda.az, canlitv.com) özü keçir. Hər link üçün 5 saniyə gözlənilir.
• Görüntü ~7 saniyə dəyişmirsə (statik) və ya qısa dövrlə təkrarlanırsa (loop), növbəti linkə keçilir. Musiqi kanalında görüntü sabit, səs isə gedirsə, ehtiyat link fonda səssiz yoxlanır və orada da sabitdirsə keçilmir.
• Yayım donsa və ya qırılsa kanal özü yenidən qoşulur. Çık-çık səs və donan görüntü üçün dekoder və bufer avtomatik dəyişir, işləyən rejim kanal üzrə yadda qalır.
• Şəbəkə kəsilib qayıdanda kanal özü bərpa olunur.
• Son izlədiyin kanal tətbiq yenidən açılanda özü açılır.
• Android TV ana ekranında "Watch Next" cərgəsində son izlənən kanallar görünür."""

    fun show(activity: Activity) {
        val pad = (20 * activity.resources.displayMetrics.density).toInt()
        val tv = TextView(activity).apply {
            text = TEXT
            textSize = 16f
            setLineSpacing(0f, 1.15f)
            setPadding(pad, pad, pad, pad)
        }
        // Fokuslana bilən ScrollView: pultda yuxarı/aşağı düymələri mətni sürüşdürür.
        val sv = ScrollView(activity).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ScrollView.FOCUS_AFTER_DESCENDANTS
            addView(tv)
        }
        val d = AlertDialog.Builder(activity)
            .setTitle("ℹ️ Məlumat")
            .setView(sv)
            .setNegativeButton("Bağla", null)
            .create()
        d.show()
        sv.requestFocus()
    }
}
