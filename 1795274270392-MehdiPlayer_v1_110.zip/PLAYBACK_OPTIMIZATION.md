# Oynatma konfiqurasiyası (2 GB RAM TV box) — Media3

## Açılış
Pleyer yalnız Media3-dür. Link OkHttp ilə açılır; açılmazdan əvvəl HTTP 4xx/5xx cavabı alınarsa təkrar cəhd olmadan dərhal xəta verilir (`FastFailPolicy`). OkHttp vaxtları: qoşulma 5 s, oxuma 6 s. Ayrıca vaxt aşımı sayğacı və geri sayım yoxdur; yüklənmə zamanı yalnız status mətni və nöqtələr göstərilir.

| Vəziyyət | Davranış |
|---|---|
| Yeni kanal | Media3 bir dəfə açır; xəta olarsa ehtiyat link (yoda.az) və ya "Kanal İşləmir" |
| İşləyən kanal qırılıb/donub | avtomatik yenidən qoşulma (dərhal) |
| Əvvəl işləmiş kanal, açılmasa | xəta göstərilmir, hər 2 s-dən bir avtomatik təkrar yoxlanılır |
| Codec heç bir dekoderdə dəstəklənmir | "Kanal İşləmir" |

Qeyd: Media3 rtsp/rtmp/srt açmır (bu modullar əlavə edilməyib); udp:// `DefaultDataSource` ilə cəhd olunur.

## Çık-çık səs / donan görüntü (özü həll edir)
`Media3Engine` `AnalyticsListener` ilə izləyir: səs underrun (AudioTrack boşalır) və atılmış video kadrlar. Oynamağa başladıqdan 4 s sonra, 10 s pəncərədə 3 underrun və ya cəmi 60 atılmış kadr olarsa kanal problemli sayılır (`UNDERRUN_LIMIT`, `DROPPED_FRAMES_LIMIT`, `QUALITY_WINDOW_MS`, `QUALITY_GRACE_MS`).

Düzəliş addımları (hər biri kanalı yenidən açır, ən çox `MAX_HEALS` = 3):
1. Səs problemidirsə və rejim NORMAL isə: səs FFmpeg dekoderi ilə, video MediaCodec ilə (`AUDIO_FFMPEG`).
2. Kanalın bufer səviyyəsi +1 (`BufferMemory`-də saxlanır).
3. Səs və video FFmpeg dekoderləri əvvəl (`ALL_FFMPEG`).

Video problemidirsə (atılan kadrlar) 1-ci addım atlanır. Kanalın düzgün açıldığı rejim `DecoderMemory`-də (`decoder_memory_v1`) saxlanır, kanal növbəti dəfə birbaşa həmin rejimlə başlayır. Dekoder açılmasa/dekodlama xətası olsa kanal bir dəfə `ALL_FFMPEG` ilə təkrar açılır.

## Media3 codec-ləri
- **Renderer-lər:** `ModeRenderersFactory` (`NextRenderersFactory`): NORMAL = MediaCodec əvvəl, çatışmasa FFmpeg; AUDIO_FFMPEG = səs üçün FFmpeg əvvəl; ALL_FFMPEG = səs və video üçün FFmpeg əvvəl.
- **MPEG-TS:** `FLAG_DETECT_ACCESS_UNITS`, `FLAG_ALLOW_NON_IDR_KEYFRAMES`, `FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS` (HLS və düz .ts).
- Canlı yayımda yetişmə sürətləndirməsi söndürülüb (`min/maxPlaybackSpeed = 1`). HLS-də köhnə seqmentlər silinibsə (`BEHIND_LIVE_WINDOW`) canlı yerə keçilir.

## Avtomatik bərpa (`PlayerManager`)
- Watchdog hər 1 s yoxlayır; istifadəçi pauza edibsə bərpa işləmir.
- Buferlənmə zamanı kanal yenidən qoşulmur, pleyer qaldığı yerdən davam edir; bufer 20 s-dən uzun dolmursa və ya görüntü 5 s donursa yenidən qoşulur.

## Ağıllı bufer (kanal başına)
`BufferMemory.kt` → `BufferProfile`:

| Səviyyə | Başlama | Buferlənmədən sonra davam |
|---|---|---|
| 0 (normal) | 1 s | 2,5 s |
| 1 (orta) | 2 s | 6 s |
| 2 (böyük) | 3 s | 12 s |

Kanal 2 dəqiqədə 3 dəfə buferlənərsə səviyyə +1 olur və kanal linki üzrə saxlanır; 20 dəqiqə buferlənmədən işləyərsə −1. Keyfiyyət düzəlişi də səviyyəni qaldıra bilər. Yeni səviyyə növbəti açılışdan tətbiq olunur. Ehtiyat (yoda.az tokenli) linklərdə səviyyə və rejim saxlanmır.

## Playlist linki dəyişəndə
İzlənən kanalın linki yeni playlistdə dəyişibsə, kanal yeni linklə avtomatik yenidən açılır. Son kanal link, ad, qrup və tvg-id ilə saxlanılır.

## v1.35 — MP2 səsi, donma və qırılma
- MP2/MP1 səsli kanal: MediaCodec əvəzinə səs FFmpeg dekoderi ilə açılır (kanal üzrə yadda qalır).
- Səs dekoder/AudioTrack xətası → özünü düzəltmə zənciri işə düşür.
- Video donması (səs gedir, kadr çəkilmir, 5 s): dekoder yenidən açılır → bufer ↑ → (TV deyilsə) FFmpeg video.
- Yayımın vaxtı 2 dəqiqədə 2 dəfə donarsa: səs FFmpeg-ə (passthrough yoxdursa) və ya bufer ↑.
- Yayım işləyərkən yükləmə xətasında 6 təkrar cəhd (qısa şəbəkə kəsilməsi kanalı yenidən qoşmur).

## v1.81 — SW keçidi (v1.84-də ləğv edildi)
Avtomatik SW keçidləri v1.84-də silindi (bax aşağıda).

## v1.83 — Əsas link ↔ ehtiyat link
- Playlist (əsas) link açılmayanda / statik-loop olanda ehtiyat linkə (yoda.az → canlitv.com) keçiləndə bu `LinkCache`-də `mainbad:<md5>` kimi yazılır (30 dəq, ehtiyat linkin tokeni qədər).
- Kanal növbəti dəfə açılanda işarə və keşdə ehtiyat link varsa, kanal birbaşa ehtiyat linklə açılır (5 s gözləmə yoxdur).
- Ehtiyat link oynayanda əsas link fonda `MainLinkProbe` ilə 10 s yoxlanır (OkHttp; pleyer/dekoder istifadə olunmur): düz axında fasiləsiz bayt axını, HLS-də playlist irəliləməsi + seqment yüklənməsi. Uğursuzdursa 60 s-dən bir təkrar.
- Yoxlama uğurlu olanda yayım dayanmadan əsas linkə qayıdılır (`swapLink`), keşdəki işarə silinir. Əsas link açılmasa 5 s-dən sonra yenə ehtiyata keçilir.
- Qayıdışdan 2 dəqiqə ərzində yenə ehtiyata keçilərsə yoxlama aralığı ikiqat artır (maks. 10 dəq).
- Qeyd: yoxlama şəbəkə səviyyəlidir; əsas linkin məzmun loop-u/statik olması bu yolla tapılmır, belə hal qayıdışdan sonra `StaleDetector` ilə yenə tapılıb ehtiyata keçilir.

## v1.84 — SW yalnız əl ilə
Avtomatik SW (FFmpeg) keçidlərinin hamısı silindi: çık-çık səs / atılan kadr düzəlişində SW addımları, dəstəklənməyən codec və dekoder xətasında FFmpeg-ə keçid, tez-tez uzun buferlənmə, 10 s açılış gecikməsi, HW-yə qayıdış məntiqi və `CodecSupport.kt`. Keyfiyyət problemində yalnız bufer səviyyəsi qalxır; TV-də donmada tunneling söndürülə bilər (hardware qalır).
Normal rejimdə FFmpeg yalnız cihaz dekoderi olmayan codec üçün Media3-ün öz ehtiyatıdır (rejim dəyişmir).

Əl ilə SW ↔ HW (kanal üzrə yadda saxlanır, `DecoderMemory` → `decoder_memory_v5`; köhnə avtomatik qeydlər atıldı):
- Pult: Geri düyməsini basıb saxlamaq (≥ 0,7 s) (v1.91; əvvəl 3 ardıcıl Geri).
- Telefon: ekranın mərkəzini (ortadakı 50% × 50%) basıb saxlamaq (v1.91; əvvəl 3 ardıcıl toxunuş). Pauzadadırsa pauza götürülür.
Hər dəfə rejim dəyişir (HW → SW → HW) və ekranda "SW"/"HW" göstərilir.

## v1.86 — audio dekoder xətasında səs FFmpeg
Cihazın audio dekoderi var, amma açılmırsa (`DECODER_INIT_FAILED`/`QUERY_FAILED`), dekodlama xətası (`DECODING_FAILED`) və ya `AUDIO_TRACK_INIT_FAILED` olarsa kanal yalnız səs FFmpeg dekoderi ilə (`AUDIO_FFMPEG`) yenidən açılır, video hardware qalır (ən çox 3 düzəliş). Oynayandan sonra rejim kanal üzrə yadda saxlanır. Əl ilə toggle `AUDIO_FFMPEG`-də HW-yə qaytarır.

## v1.87 — MP2 səsi həmişə FFmpeg
Seçilmiş səs treki MP2 (`audio/mpeg-L2`) və ya MP1 olarsa kanal treklər məlum olan kimi səs FFmpeg dekoderi (`AUDIO_FFMPEG`) ilə yenidən açılır, video hardware qalır. Rejim kanal üzrə yadda saxlanır (növbəti açılışda birbaşa). MP2 kanalında əl ilə toggle HW-yə qaytarmır, `ALL_FFMPEG` ↔ `AUDIO_FFMPEG` arasında dəyişir.

## v1.90 — bufer, əsas link yoxlaması, şəbəkə bərpası
- **Bufer müddəti:** minimum 15 s; maksimum TV ≥ 2,2 GB RAM-da 30 s, digər cihazlarda 20 s (`TvProfile.minBufferMs/maxBufferMs`). Bayt həddi dəyişməyib (TV 48 MB, digər 24 MB): 4K axında müddətdən əvvəl bayt həddi işləyir.
- **`MainLinkProbe`:** düz axında minimum sürət 20 KB/s → 100 KB/s (~800 kbit/s). HLS-də seqment yüklənməsi seqmentin müddətinin 0,8 hissəsindən tez bitməlidir (real vaxtdan sürətli); boğulmuş əsas link "sağlam" sayılmır.
- **Şəbəkə bərpası (`PlayerManager`):** `registerDefaultNetworkCallback` ilə şəbəkə kəsilib qayıdanda (və ya Wi-Fi ↔ Ethernet dəyişəndə) 0,8 s sonra kanal dərhal yenidən qoşulur: düşmüş kanalın 2 s təkrar cəhdi gözlənilmir, buferlənmədə ilişmiş yayım 30 s gözləmədən təzədən başlayır. Bufer boşalmayıbsa və yayım normal gedirsə toxunulmur; pauza və arxa planda işləmir. Yeni icazə: `ACCESS_NETWORK_STATE`.
- **Kod:** `MainActivity.kt`-dən `Adapters.kt` ayrıldı (`safeHandler`, `CLOCK_FMT`, `setTextIfChanged`, `pop`, `ChannelAdapter`, `GroupAdapter`, `ProgAdapter`); davranış dəyişməyib. `versionCode 90`, `versionName 1.90`, README sinxronlaşdırıldı.

## v1.91 — SW ↔ HW jesti
Pultda Geri düyməsini ≥ 0,7 s basıb saxlamaq, telefonda ekranın mərkəzini basıb saxlamaq rejimi dəyişir (HW → SW → HW, kanal üzrə yadda saxlanır, ekranda "SW"/"HW"). Geri düyməsi saxlanılandan sonra buraxılanda adi Geri əməliyyatı işləmir; qısa Geri əvvəlki kimidir (məlumat zolağı → kanal siyahısı). Axtarış açıqdırsa Geri saxlamaq işləmir. Köhnə 3 ardıcıl Geri / 3 toxunuş silindi.

## v1.92 — statik / loop aşkarlanması
- `StaleDetector.kt`: statik üçün nümunə sayı 6 → 8 (~7 s), fərq həddi 0.5 → 0.3 (yanlış keçid azalır); loop dövr aralığı 2–10 s → 2–12 s. Digər dəyərlər dəyişməyib (nümunə 1 s, oxşarlıq 1.0, min. hərəkət 1.5, qara kadr 16, 5 xəta limiti).
- README-dəki "~7 s" / dövr aralığı kodla uyğunlaşdırıldı. `versionCode 92`, `versionName 1.92`.

## v1.93 — buferlənmə vaxt aşımı
- `Engines.kt`: `STALL_BUFFERING_MS` 30 s → **20 s** (bufer 20 s-dən uzun dolmursa kanal yenidən qoşulur). `versionCode 93`, `versionName 1.93`.

## v1.95 — ekran 60 Hz, Ayarlar düyməsi
- v1.94-dəki AFR (`Afr.kt`, fps hesablanması, açar düyməsi) tam silindi. Media3-ün kadr tezliyi keçidi OFF qalır.
- TV-də ekran Hz-i 60-a sabit (`TvProfile.mode60Id`): 24/25/50 fps yayımlar 60 Hz-də göstərilir.
- Qrupların altında "⚙️ Ayarlar" düyməsi → "⚙️ Kanalların Yerini Dəyiş". `versionCode 95`, `versionName 1.95`.

## v1.97–v1.98 — AFR və 60 Hz sabitləməsi silindi
- v1.97: AFR-ın bütün kodu silindi (`Afr.kt`, fps oxunması, `onVideoFrameRate`, Ayarlar-dakı AFR düyməsi).
- v1.98: 60 Hz sabitləməsi (`TvProfile.mode60Id`) də silindi. Ekran Hz-i sistemin seçimidir, yalnız 4K tələbi (`uhdModeId`) qalır. Media3-ün kadr tezliyi keçidi OFF qalır. `versionCode 98`, `versionName 1.98`.

## v1.98 — sabit imza açarı və release
- `app/mehdi-release.jks` (alias `mehdi`) ilə `signingConfigs.mehdi`; həm `release`, həm `debug` eyni açarla imzalanır, yeniləmə silmədən köhnənin üstünə quraşdırılır. `release`: R8 + resurs kiçiltmə, `isDebuggable=false`. Açarı itirməyin.

## v1.98 — statik görüntü + səs (musiqi kanalı)
- `Media3Engine.hasAudio()`: pleyer oynayır, səs treki seçilib, səs bağlı deyil.
- Statik tapılanda səs gedirsə (`onStaleWithAudio`) dərhal keçid olmur: `MainActivity.checkBackupSilently()` növbəti linki (keçid ardıcıllığı ilə eyni) fonda tapır (keş / yoda.az / canlitv), `BackupStaleProbe.kt` onu səssiz, səs treki söndürülmüş, görünməz TextureView-da ≤25 s açıb ~8 saniyə baxır.
- Nəticə: görüntü dəyişir → keçilir; ehtiyatda da statik / açılmadı / kadr oxunmadı → keçilmir, cari linkdə səs davam edir. Səs yoxdursa köhnə davranış (dərhal keçid).
- Qeyd: keçilməyəndə həmin oynatma üçün statik detektor yenidən işləmir (kanal yenidən açılanda qayıdır).

## v1.99 — OK basıb saxla + Məlumat
- Pultda OK **qısa** basış (düymə buraxılanda) kanal siyahısını açır; OK **basıb saxlama** (≥ 0,7 s, `OK_HOLD_MS`) əl ilə növbəti (ehtiyat) linkə keçir (`manualBackupSwitch` → `advanceToNextLink`). Növbəti link yoxdursa mesaj çıxır.
- Ayarlar → "ℹ️ Məlumat" (`AboutDialog.kt`): əlaqə (Mehdi Mustafayev, 070 862 74 18) və tam istifadə qaydası; pultda yuxarı/aşağı ilə sürüşür.

## v1.100 — telefon düymələri
- Toxunma idarəetməsində (videoya toxunanda) sağ yuxarıda ikinci cərgə: "↻ Ehtiyat link" (`manualBackupSwitch`) və "HW/SW" (`toggleSoftwareDecoder`). Pultdakı OK basıb saxlama və Geri basıb saxlama ilə eyni funksiyalar. `versionCode 100`, `versionName 1.100`.

## v1.101 — 4056 düyməsi: nömrə paneli
- Pultun 4056 kodlu düyməsi nömrə panelini açır (açıqdırsa bağlayır): `KeyLaunchService` (tətbiq bağlı/fonda olsa da, `MainActivity.EXTRA_NUMPAD`) və `MainActivity.dispatchKeyEvent` (`NUMPAD_KEY`, xidmət söndürülübsə). Digər pəncərələr (axtarış, panel, siyahı, EPG) bağlanır. `versionCode 101`, `versionName 1.101`.

## v1.102 — rəqəm paneli: pult yön düymələri
- Panel açıq ikən (`numPadShown()`) yön düymələri düymələr (4×3) arasında hərəkət edir (`handleNumPadKey`, kənardan dövr), OK fokuslanmış düyməni basır; başlanğıc fokus "5". Fokus göstəricisi: mavi fon + böyümə. Hər basışda 10 s bağlanma taymeri yenilənir. `dispatchKeyEvent`-də digər pult məntiqindən (OK → siyahı, yuxarı → panel) əvvəl işləyir. `versionCode 102`, `versionName 1.102`.
