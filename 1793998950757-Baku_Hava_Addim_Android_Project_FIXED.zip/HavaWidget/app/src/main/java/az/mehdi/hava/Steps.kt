package az.mehdi.hava

import android.app.Notification
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.app.NotificationManager
import java.time.LocalDate
import java.util.Locale

object Steps {
    private fun p(c: Context) = c.getSharedPreferences("steps", Context.MODE_PRIVATE)

    /** Sensor dəyəri (açılışdan bəri addımlar) -> bu günün addımları */
    fun onSensor(c: Context, raw: Float): Int {
        val p = p(c)
        val today = LocalDate.now(BAKU).toString()
        var base = p.getFloat("base", raw)
        var offset = p.getInt("offset", 0)
        if (p.getString("day", "") != today) {
            base = raw
            offset = 0
        } else if (raw < p.getFloat("lastRaw", raw)) { // telefon yenidən başladılıb
            offset = p.getInt("steps", 0)
            base = 0f
        }
        val steps = offset + (raw - base).toInt()
        p.edit().putString("day", today).putFloat("base", base).putInt("offset", offset)
            .putFloat("lastRaw", raw).putInt("steps", steps).apply()
        return steps
    }

    fun get(c: Context): Int {
        val p = p(c)
        return if (p.getString("day", "") == LocalDate.now(BAKU).toString()) p.getInt("steps", 0) else 0
    }

    fun height(c: Context): Int = p(c).getInt("height", 180)
    fun setHeight(c: Context, v: Int) = p(c).edit().putInt("height", v).apply()

    // addım uzunluğu ≈ boy × 0.415
    fun km(c: Context): Double = get(c) * height(c) * 0.415 / 100000.0
    fun kmText(c: Context): String = String.format(Locale.US, "%.2f km", km(c))
    fun stepsText(c: Context): String = String.format(Locale.US, "%,d", get(c)).replace(',', ' ')
}

class StepService : Service(), SensorEventListener {
    private var lastWidget = 0L
    private var lastSteps = -1

    override fun onCreate() {
        super.onCreate()
        Notif.channels(this)
        val n: Notification = Notif.stepNotif(this)
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        else startForeground(1, n)
        val sm = getSystemService(SensorManager::class.java)
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL) else stopSelf()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val steps = Steps.onSensor(this, e.values[0])
        if (steps != lastSteps) {
            lastSteps = steps
            getSystemService(NotificationManager::class.java).notify(1, Notif.stepNotif(this))
            val t = SystemClock.elapsedRealtime()
            if (t - lastWidget > 15000) {
                lastWidget = t
                WeatherWidget.refresh(this)
            }
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        getSystemService(SensorManager::class.java).unregisterListener(this)
        super.onDestroy()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.start(c)
        Scheduler.now(c)
        Scheduler.startSteps(c)
        WeatherWidget.refresh(c)
    }
}
