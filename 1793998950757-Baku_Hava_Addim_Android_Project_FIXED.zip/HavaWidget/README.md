# Bakı Hava (HavaWidget)
- Bakı: bu gün + 7 gün, hər gün üçün yağış ehtimalı (Open-Meteo, API açarı lazım deyil)
- "3 saat sonra yağış yağacaq" tipli proqnoz — tətbiqdə, widgetdə və bildirişdə
- Yağış / qar / tufan / güclü külək xəbərdarlığı (bildiriş), səhər proqnozu
- Addımölçən + km (boyunuza görə), widgetdə də görünür
- Widget: ana ekran → uzun bas → Widgetlər → Bakı Hava (və ya tətbiqdəki "widget əlavə et" düyməsi)

Build: layihəni GitHub-a yükləyin → Actions → "Build APK" → artifact: HavaWidget-apk
