package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.SurfaceView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.metadata.MetadataOutput
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import androidx.media3.exoplayer.video.VideoRendererEventListener
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** Playlist/manifest sorğularında istifadə olunan standart User-Agent (kanalın öz UA-sı yoxdursa). */
internal const val STREAM_DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"

/** Media3 üçün HTTP müştərisi (OkHttp): vaxtı keçmiş/özü imzalı sertifikatlı IPTV serverləri üçün sertifikat yoxlaması söndürülüb. */
private object StreamHttp {
    val client: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val b = OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .protocols(listOf(Protocol.HTTP_1_1))
            .followRedirects(true)
            .followSslRedirects(true)
            .hostnameVerifier { _, _ -> true }
        runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            b.sslSocketFactory(ctx.socketFactory, trustAll)
        }
        b.build()
    }
}

/**
 * Dekoder rejimi ([DecoderMode]) üzrə renderer-lər:
 *  NORMAL — MediaCodec əvvəl, dəstəkləmirsə FFmpeg; ALL_FFMPEG — səs və video üçün FFmpeg əvvəl;
 *  AUDIO_FFMPEG — səs FFmpeg (proqram) dekoderi ilə, video isə MediaCodec ilə (çık-çık səsin əsas həlli).
 */
@androidx.annotation.OptIn(UnstableApi::class)
private class ModeRenderersFactory(
    private val context: Context,
    private val mode: DecoderMode
) : RenderersFactory {
    private fun make(ffmpegFirst: Boolean): RenderersFactory = NextRenderersFactory(context)
        .setExtensionRendererMode(
            if (ffmpegFirst) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
            else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
        )
        .setEnableDecoderFallback(true)

    override fun createRenderers(
        eventHandler: Handler,
        videoRendererEventListener: VideoRendererEventListener,
        audioRendererEventListener: AudioRendererEventListener,
        textRendererOutput: TextOutput,
        metadataRendererOutput: MetadataOutput
    ): Array<Renderer> {
        fun build(f: RenderersFactory) = f.createRenderers(
            eventHandler, videoRendererEventListener, audioRendererEventListener, textRendererOutput, metadataRendererOutput
        )
        return when (mode) {
            DecoderMode.NORMAL, DecoderMode.NO_TUNNEL -> build(make(false))
            DecoderMode.ALL_FFMPEG -> build(make(true))
            DecoderMode.AUDIO_FFMPEG -> {
                val base = build(make(false)).filter { it.trackType != C.TRACK_TYPE_AUDIO }
                val audio = build(make(true)).filter { it.trackType == C.TRACK_TYPE_AUDIO }
                (base + audio).toTypedArray()
            }
        }
    }
}

/**
 * Yeganə mühərrik: Media3 (ExoPlayer, OkHttp). http/https (m3u8, mpd, ts, mp4 ...) və Media3-ün özü açan sxemlər.
 *
 * Kanal açılanda yeganə yoxlama OkHttp-dir: HTTP 4xx/5xx və ya qoşulma xətası dərhal xəta verir (yeni cəhd və vaxt aşımı sayğacı yoxdur).
 *
 * Çık-çık səs və donan görüntü özü-özünə həll olunur ([poorQuality]): səs underrun-ları və atılan video kadrlar izlənir,
 * problem olarsa kanal addım-addım yenidən açılır: (1) səs FFmpeg dekoderi ilə, (2) daha böyük bufer, (3) səs+video FFmpeg.
 * Kömək edən rejim kanal üzrə yadda saxlanır ([DecoderMemory]); bufer səviyyəsi PlayerManager-də saxlanır.
 * Bütün çağırışlar yalnız əsas (UI) thread-dədir.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class Media3Engine(
    context: Context,
    private val view: SurfaceView,
    private val callback: PlayerCallback
) {
    companion object {
        private const val TAG = "IPTV-MEDIA3"
        private const val DEFAULT_UA = STREAM_DEFAULT_UA

        // Keyfiyyət nəzarəti ("çık-çık" səs və donan görüntü): oynamağa başladıqdan sonra bu müddət (ms) ölçülmür,
        // çünki açılışda bir-iki underrun/atılmış kadr normaldır.
        private const val QUALITY_GRACE_MS = 4_000L
        // Pəncərə (ms): bu müddətdə hədd aşılarsa kanal problemli sayılır.
        private const val QUALITY_WINDOW_MS = 10_000L
        // Pəncərədə səs underrun sayı (AudioTrack boşalır = çık-çık səs).
        private const val UNDERRUN_LIMIT = 3
        // Pəncərədə atılmış video kadrların cəmi (görüntü donması / titrəməsi).
        private const val DROPPED_FRAMES_LIMIT = 60
        // Bir kanalın açılışında ən çox neçə dəfə özü-özünə düzəliş edilir (sonsuz döngü olmasın).
        private const val MAX_HEALS = 3
        // Səs davam edir, amma video kadrları bu müddət (ms) ərzində çəkilmirsə: video dekoder donub.
        private const val VIDEO_FREEZE_MS = 5_000L
        // Yayım işləyərkən (artıq oynayıb) yükləmə xətasında təkrar cəhd sayı: qısa şəbəkə qırılması kanalı yıxmasın.
        private const val LIVE_RETRY_COUNT = 6

        // MPEG-TS (IPTV-də ən çox rast gəlinən): AUD olmayan H.264, non-IDR açar kadrlar, HDMV DTS səsi.
        private const val TS_FLAGS =
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS

        // İcra zamanı dekoder xətaları: FFmpeg-i MediaCodec-dən əvvəl qoymaq kömək edə bilər.
        private fun isDecoderRuntimeError(code: Int): Boolean = when (code) {
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED -> true
            else -> false
        }
    }

    private val appContext = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())
    private val memory = DecoderMemory(context)

    private var player: ExoPlayer? = null
    // Hazırkı player hansı dekoder rejimi / bufer səviyyəsi ilə qurulub; yeni açılış hansı ilə başlayır.
    private var playerMode = DecoderMode.NORMAL
    private var playerLevel = 0
    private var mode = DecoderMode.NORMAL
    private var bufLevel = 0
    // false: ehtiyat (yoda.az tokenli) link — rejim yadda saxlanmır.
    private var persist = true
    private var heals = 0
    private var ua: String? = null
    private var ref: String? = null
    private var released = false
    private var generation = 0
    private var url: String? = null
    private var playing = false
    private var buffering = false
    private var lastBufferingAt = 0L
    private var firstFrame = false
    // Açılmış video dekoderinin adı (TV-də hardware/proqram yolunu göstərmək üçün).
    private var videoDecoder = ""
    private var hasVideoGroup = false
    private var tracksKnown = false
    // Dolby/DTS passthrough: AudioTrack kodlaşdırması PCM deyilsə səs dekod edilmədən TV-yə ötürülür (etiket: AC3, EAC3, DTS ...).
    private var passthroughLabel = ""
    // Keyfiyyət nəzarəti: underrun vaxtları və atılmış kadrlar (vaxt, say).
    private var playingAt = 0L
    private val underrunTimes = ArrayDeque<Long>()
    private val droppedEvents = ArrayDeque<Pair<Long, Int>>()
    private val speed = SpeedMeter()
    // Video donma nəzarəti (səs gedir, görüntü donur): dekoderin çəkdiyi kadr sayğacı izlənir.
    private var videoFreezes = 0
    private var wdCount = -1
    private var wdAt = 0L
    private var wdFlowing = false
    // Pleyer-in özü yox, yayımın donması (PlayerManager xəbər verir): təkrarlanarsa dekoder/bufer eskalasiyası.
    private val freezeTimes = ArrayDeque<Long>()

    /** Açılmazdan əvvəl HTTP 4xx/5xx cavabı alınarsa təkrar cəhd olmadan dərhal xəta (OkHttp yoxlaması). */
    private inner class FastFailPolicy : DefaultLoadErrorHandlingPolicy(1) {
        // Yayım artıq işləyirsə, seqment/axın xətasında daha çox təkrar cəhd (qısa şəbəkə kəsilməsi kanalı yenidən qoşmasın).
        override fun getMinimumLoadableRetryCount(dataType: Int): Int =
            if (playing) LIVE_RETRY_COUNT else super.getMinimumLoadableRetryCount(dataType)

        override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long {
            val e = loadErrorInfo.exception
            if (!playing && e is HttpDataSource.InvalidResponseCodeException && e.responseCode >= 400) return C.TIME_UNSET
            return super.getRetryDelayMsFor(loadErrorInfo)
        }
    }

    private val listener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            if (!isCurrent()) return
            var v = 0; var vOk = false; var a = 0; var aOk = false
            for (g in tracks.groups) {
                when (g.type) {
                    C.TRACK_TYPE_VIDEO -> { v++; if (g.isSupported(false)) vOk = true }
                    C.TRACK_TYPE_AUDIO -> { a++; if (g.isSupported(false)) aOk = true }
                }
            }
            if (v + a == 0) return // treklər hələ məlum deyil
            hasVideoGroup = v > 0
            tracksKnown = true
            // MP2/MP1 səs: cihazın MediaCodec dekoderi çık-çık edir → əvvəldən FFmpeg səs dekoderi ilə açılır.
            if (switchMp2ToFfmpeg()) return
            if ((v > 0 && !vOk) || (a > 0 && !aOk)) {
                val what = if (v > 0 && !vOk) "video" else "səs"
                failNow("Media3: $what codec-i dəstəklənmir")
                return
            }
            maybeMarkPlaying()
        }

        override fun onRenderedFirstFrame() {
            if (!isCurrent()) return
            firstFrame = true
            maybeMarkPlaying()
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (!isCurrent()) return
            when (state) {
                Player.STATE_BUFFERING -> if (playing && !buffering) {
                    buffering = true
                    lastBufferingAt = SystemClock.elapsedRealtime()
                    callback.onBuffering(true)
                }
                Player.STATE_READY -> {
                    if (buffering) { buffering = false; callback.onBuffering(false) }
                    if (!playing && switchMp2ToFfmpeg()) return
                    maybeMarkPlaying()
                    if (!playing) scheduleStartCheck()
                }
                Player.STATE_ENDED -> failNow("Yayım bitdi")
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            if (!isCurrent()) return
            Log.w(TAG, "Xəta: ${error.errorCodeName}", error)
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                // HLS: bufer uzun donub, köhnə seqmentlər serverdən silinib: yeganə çıxış canlı yayımın cari yerinə keçməkdir.
                player?.let { it.seekToDefaultPosition(); it.prepare() }
                return
            }
            // Dekoder açılmadı/dekodlama xətası: bir dəfə FFmpeg dekoderləri əvvəl ilə yenidən açılır.
            val u = url
            if (u != null && isDecoderRuntimeError(error.errorCode) && mode != DecoderMode.ALL_FFMPEG && heals < MAX_HEALS) {
                mode = DecoderMode.ALL_FFMPEG
                heals++
                Log.w(TAG, "Media3: ${error.errorCodeName} → FFmpeg dekoderləri əvvəl ilə təkrar cəhd")
                restart(u)
                return
            }
            // Format səhv təxmin edilib (HLS əvəzinə TS/AAC və ya əksinə): bir dəfə tərs format ilə təkrar cəhd.
            if (u != null && !formatRetried && (
                    error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED)
            ) {
                formatRetried = true
                val wasHls = formatOverride ?: looksHls(u.lowercase())
                formatOverride = !wasHls
                Log.w(TAG, "Media3: ${error.errorCodeName} → ${if (wasHls) "progressive" else "HLS"} formatı ilə təkrar cəhd")
                restart(u)
                return
            }
            failNow("Media3: ${error.errorCodeName}")
        }
    }

    private val analytics = object : AnalyticsListener {
        override fun onVideoDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long
        ) {
            videoDecoder = decoderName
            Log.i(TAG, "Video dekoder: $decoderName (proqram=${TvProfile.isSoftwareDecoder(decoderName)})")
        }

        override fun onAudioTrackInitialized(eventTime: AnalyticsListener.EventTime, audioTrackConfig: AudioSink.AudioTrackConfig) {
            if (!isCurrent()) return
            val enc = audioTrackConfig.encoding
            passthroughLabel = if (AudioPassthrough.isPassthroughEncoding(enc)) AudioPassthrough.label(enc) else ""
            Log.i(TAG, "AudioTrack kodlaşdırması=$enc passthrough=${passthroughLabel.ifEmpty { "yox (PCM)" }}")
        }

        override fun onAudioUnderrun(
            eventTime: AnalyticsListener.EventTime,
            bufferSize: Int,
            bufferSizeMs: Long,
            elapsedSinceLastFeedMs: Long
        ) {
            if (!isCurrent() || !playing) return
            val now = SystemClock.elapsedRealtime()
            if (now - playingAt < QUALITY_GRACE_MS) return
            underrunTimes.addLast(now)
            while (underrunTimes.isNotEmpty() && now - underrunTimes.first() > QUALITY_WINDOW_MS) underrunTimes.removeFirst()
            if (underrunTimes.size >= UNDERRUN_LIMIT) poorQuality(true, "səs keyfiyyəti aşağıdır (underrun)")
        }

        // Səs dekoderi və ya AudioTrack xətası (çık-çık səsin ikinci əlaməti: underrun olmadan da baş verir).
        override fun onAudioCodecError(eventTime: AnalyticsListener.EventTime, audioCodecError: Exception) {
            Log.w(TAG, "Səs dekoder xətası", audioCodecError)
            if (!isCurrent() || !playing) return
            poorQuality(true, "səs dekoder xətası")
        }

        override fun onAudioSinkError(eventTime: AnalyticsListener.EventTime, audioSinkError: Exception) {
            Log.w(TAG, "AudioTrack xətası", audioSinkError)
            if (!isCurrent() || !playing) return
            poorQuality(true, "AudioTrack xətası")
        }

        override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
            if (!isCurrent() || !playing) return
            val now = SystemClock.elapsedRealtime()
            if (now - playingAt < QUALITY_GRACE_MS) return
            droppedEvents.addLast(now to droppedFrames)
            while (droppedEvents.isNotEmpty() && now - droppedEvents.first().first > QUALITY_WINDOW_MS) droppedEvents.removeFirst()
            if (droppedEvents.sumOf { it.second } >= DROPPED_FRAMES_LIMIT) poorQuality(false, "video keyfiyyəti aşağıdır (atılan kadrlar)")
        }
    }

    private fun isMpegLowLayer(f: Format?): Boolean {
        val m = f?.sampleMimeType ?: return false
        return m == MimeTypes.AUDIO_MPEG_L2 || m == MimeTypes.AUDIO_MPEG_L1
    }

    /**
     * MP2 (MPEG Layer II) / MP1 səsli kanal: bir çox TV box/TV-nin MediaCodec MP2 dekoderi səsi çık-çık verir
     * (underrun sayılmır, ona görə [poorQuality] tutmur) və səs saatı donduğu üçün görüntü də donur.
     * Hazırkı rejim NORMAL-dırsa, kanal dərhal səs FFmpeg dekoderi ilə yenidən açılır (heal limiti yeyilmir);
     * rejim kanal üzrə yadda saxlanır ([DecoderMemory]) – növbəti dəfə yenidən açılma olmur.
     * true qaytarırsa kanal yenidən açılır, çağıran davam etməməlidir.
     */
    private fun switchMp2ToFfmpeg(): Boolean {
        val u = url ?: return false
        if (released || mode != DecoderMode.NORMAL) return false
        val p = player ?: return false
        var found = isMpegLowLayer(p.audioFormat)
        if (!found) {
            for (g in p.currentTracks.groups) {
                if (g.type != C.TRACK_TYPE_AUDIO || !g.isSelected) continue
                for (i in 0 until g.length) if (isMpegLowLayer(g.getTrackFormat(i))) found = true
            }
        }
        if (!found) return false
        mode = DecoderMode.AUDIO_FFMPEG
        Log.w(TAG, "Media3: MP2/MP1 səs aşkarlandı → səs FFmpeg dekoderi ilə təkrar açılır")
        restart(u)
        return true
    }

    /**
     * Səs çık-çık edir və ya görüntü donur: kanal özü-özünə addım-addım düzəldilir.
     *  - səs problemi və rejim NORMAL: səs dekoderi FFmpeg olur (MediaCodec səs dekoderinin xətaları aradan qalxır);
     *  - sonra: kanalın bufer səviyyəsi bir pillə qalxır (PlayerManager yadda saxlayır);
     *  - sonra: səs və video FFmpeg dekoderləri.
     * Hər düzəlişdən sonra kanal yenidən açılır; ən çox [MAX_HEALS] dəfə.
     */
    private fun poorQuality(audioProblem: Boolean, reason: String) {
        underrunTimes.clear()
        droppedEvents.clear()
        val u = url ?: return
        if (released || heals >= MAX_HEALS) return
        val action = when {
            audioProblem && mode == DecoderMode.NORMAL -> { mode = DecoderMode.AUDIO_FFMPEG; "səs FFmpeg dekoderi ilə" }
            bufLevel < BufferProfile.MAX_LEVEL -> { bufLevel++; callback.onBufferLevel(bufLevel); "bufer səviyyəsi $bufLevel" }
            // TV-də video proqram (FFmpeg) dekoderinə keçirilmir: TV-nin hardware şəkil yolu (AI upscaling, HDR, MEMC) itərdi,
            // 4K-nı CPU dekod edə də bilməz. Dekoder tam açılmasa onPlayerError ayrıca ALL_FFMPEG-ə keçir.
            mode != DecoderMode.ALL_FFMPEG && !TvProfile.of(appContext).isTv -> { mode = DecoderMode.ALL_FFMPEG; "səs+video FFmpeg dekoderləri ilə" }
            else -> return
        }
        heals++
        Log.w(TAG, "Media3 $reason → $action təkrar açılır ($heals/$MAX_HEALS)")
        restart(u)
    }

    /**
     * PlayerManager: yayımın vaxtı 5 s donub və kanal yenidən qoşulacaq. Eyni kanal 2 dəqiqədə 2 dəfə donarsa,
     * səbəb dekoder/səs saatıdır: passthrough yoxdursa səs FFmpeg-ə keçir, əks halda bufer səviyyəsi qalxır.
     * (Yenidən qoşulmanı PlayerManager özü edir; burada yalnız növbəti açılışın parametrləri dəyişir.)
     */
    fun onFrozen() {
        if (released || url == null) return
        val now = SystemClock.elapsedRealtime()
        freezeTimes.addLast(now)
        while (freezeTimes.isNotEmpty() && now - freezeTimes.first() > 120_000L) freezeTimes.removeFirst()
        if (freezeTimes.size < 2) return
        freezeTimes.clear()
        when {
            mode == DecoderMode.NORMAL && passthroughLabel.isEmpty() -> mode = DecoderMode.AUDIO_FFMPEG
            mode == DecoderMode.NORMAL && TvProfile.of(appContext).isTv -> mode = DecoderMode.NO_TUNNEL
            bufLevel < BufferProfile.MAX_LEVEL -> { bufLevel++; callback.onBufferLevel(bufLevel) }
            else -> return
        }
        Log.w(TAG, "Media3: təkrar donma → rejim=$mode bufer=$bufLevel")
    }

    /** Səs gedir, amma video kadrları çəkilmir (dekoder donub): kanal addım-addım yenidən açılır. */
    private fun watchVideo(gen: Int) {
        ui.postDelayed({
            if (released || generation != gen || !playing) return@postDelayed
            checkVideoFlow()
            watchVideo(gen)
        }, 1_000L)
    }

    private fun checkVideoFlow() {
        val p = player ?: return
        val now = SystemClock.elapsedRealtime()
        if (!hasVideoGroup || !p.playWhenReady || p.playbackState != Player.STATE_READY || buffering) { wdAt = now; return }
        val c = p.videoDecoderCounters
        if (c == null) { wdAt = now; return }
        c.ensureUpdated()
        val n = c.renderedOutputBufferCount
        // n < wdCount: yeni dekoder (sayğac sıfırlanıb).
        if (wdCount < 0 || n < wdCount) { wdCount = n; wdAt = now; return }
        if (n - wdCount >= 5) wdFlowing = true
        if (n != wdCount) { wdCount = n; wdAt = now; return }
        // Yalnız kadrların əvvəl normal axdığı yayımda (az kadrlı statik şəkilli kanallar səhv sayılmasın).
        if (wdFlowing && now - wdAt >= VIDEO_FREEZE_MS) { wdAt = now; videoFrozen() }
    }

    private fun videoFrozen() {
        val u = url ?: return
        if (released || ++videoFreezes > 4) return
        val action = when {
            videoFreezes == 1 -> "dekoder yenidən açılır"
            // TV: tunneled playback səs gedə-gedə görüntünü dondura bilər → əvvəl tunneling söndürülür.
            mode == DecoderMode.NORMAL && TvProfile.of(appContext).isTv -> { mode = DecoderMode.NO_TUNNEL; "tunneling olmadan" }
            bufLevel < BufferProfile.MAX_LEVEL -> { bufLevel++; callback.onBufferLevel(bufLevel); "bufer səviyyəsi $bufLevel" }
            // Son çarə (TV daxil): AVC/AAC üçün FFmpeg proqram dekoderləri (VLC kimi). Dekoder tam açılmasa onPlayerError də bura keçir.
            mode != DecoderMode.ALL_FFMPEG -> { mode = DecoderMode.ALL_FFMPEG; "səs+video FFmpeg" }
            else -> "dekoder yenidən açılır"
        }
        Log.w(TAG, "Media3: görüntü donub (səs gedir) → $action ($videoFreezes)")
        restart(u)
    }

    // Açılış donması: player READY-dir, video qrupu var, amma ilk kadr 5 s-də çəkilmir (tunneled/hardware dekoder "açılmır").
    private var startCheckGen = -1

    private fun scheduleStartCheck() {
        val gen = generation
        if (startCheckGen == gen) return
        startCheckGen = gen
        ui.postDelayed({
            if (released || generation != gen || playing) return@postDelayed
            val p = player ?: return@postDelayed
            if (p.playbackState != Player.STATE_READY || !hasVideoGroup || firstFrame) return@postDelayed
            val u = url ?: return@postDelayed
            if (heals >= MAX_HEALS) return@postDelayed
            val action = when {
                mode == DecoderMode.NORMAL && TvProfile.of(appContext).isTv -> { mode = DecoderMode.NO_TUNNEL; "tunneling olmadan" }
                mode != DecoderMode.ALL_FFMPEG -> { mode = DecoderMode.ALL_FFMPEG; "səs+video FFmpeg" }
                else -> return@postDelayed
            }
            heals++
            Log.w(TAG, "Media3: ilk kadr gəlmir → $action təkrar açılır ($heals/$MAX_HEALS)")
            restart(u)
        }, 5_000L)
    }

    /** Eyni linki cari rejim/bufer səviyyəsi ilə növbəti döngədə yenidən açır (köhnə player-in gecikmiş hadisələri ignor edilir). */
    private fun restart(u: String) {
        val gen = ++generation
        playing = false
        ui.post { if (!released && url == u && generation == gen) start(u) }
    }

    private fun isCurrent(): Boolean {
        val p = player ?: return false
        return !released && url != null && p.currentMediaItem?.mediaId == generation.toString()
    }

    /** Player-i buraxır (video səthi də azad edilir); rejim dəyişəndə yenisi qurulur. */
    private fun discardPlayer() {
        val p = player ?: return
        // Əvvəl sahibliyi buraxırıq ki, heç bir yerdə iki player eyni anda "cari" sayılmasın.
        player = null
        // Köhnə player tam susdurulur və dayandırılır, yalnız bundan sonra release olunur:
        // yeni player köhnənin səsi/dekoderi/səthi hələ açıq ikən qurulmasın.
        runCatching { p.removeListener(listener) }
        runCatching { p.removeAnalyticsListener(analytics) }
        runCatching { p.volume = 0f; p.playWhenReady = false }
        runCatching { p.stop(); p.clearMediaItems() }
        runCatching { p.clearVideoSurfaceView(view) }
        runCatching { p.release() }
    }

    private fun ensurePlayer(): ExoPlayer {
        if (player != null && (playerMode != mode || playerLevel != bufLevel)) discardPlayer()
        player?.let { return it }
        playerMode = mode
        playerLevel = bufLevel
        // Cihazın birbaşa (passthrough) oynada bildiyi Dolby/DTS formatları loqa yazılır.
        AudioPassthrough.caps(appContext)
        // Bufer həddi cihazın RAM-ına görə: 3 GB-lı TV-də (TCL 65C6K) 48 MB (4K axınlar), digər cihazlarda 24 MB.
        // Başlama/davam həddi kanalın bufer səviyyəsindən asılıdır.
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 20_000, BufferProfile.startMs(bufLevel), BufferProfile.rebufferMs(bufLevel))
            .setTargetBufferBytes(TvProfile.targetBufferBytes(appContext))
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        // Tunneled playback TV-də həmişə açıqdır (yalnız hardware dekoder rejimində): video/səs TV-nin öz hardware yoluna verilir
        // (A/V sinxron, şəkil mühərriki, Dolby/DTS passthrough). FFmpeg rejimlərində (proqram dekoder) tunneling mümkün deyil.
        val selector = androidx.media3.exoplayer.trackselection.DefaultTrackSelector(appContext)
        selector.parameters = selector.buildUponParameters()
            .setTunnelingEnabled(mode == DecoderMode.NORMAL && TvProfile.of(appContext).isTv)
            // Ən yüksək keyfiyyət: çox keyfiyyətli (HLS/DASH) kanallarda həmişə ən yüksək dəstəklənən variant (2K/4K) seçilir,
            // ekran ölçüsü (viewport) həddi götürülür ki, TV 1080p-yə qurulubsa belə 4K variant seçilə bilsin.
            .setForceHighestSupportedBitrate(true)
            .setViewportSize(Int.MAX_VALUE, Int.MAX_VALUE, true)
            .build()
        val p = ExoPlayer.Builder(appContext, ModeRenderersFactory(appContext, mode))
            .setLoadControl(load)
            .setTrackSelector(selector)
            .build()
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            false
        )
        // TV: yayımın kadr tezliyinə (24/25/30/50/60 fps) görə ekran rejimi həmişə uyğunlaşdırılır; keçid yalnız fasiləsiz
        // (qara ekransız) mümkündürsə edilir. 144 Hz panelli TCL 65C6K-də 24 fps → 144 (6x), 48 → 144, 30/60 → 120, 25/50 → 100 Hz kimi
        // tam misli rejimlər seçilir: kadr atlama/judder olmur.
        // v1.71: TCL 144 Hz rejimində kadr tezliyi keçidi (24/25/50 → 144 və s.) şəkil sistemini yenidən qurub ekranı ~0.5 s qaraldırdı.
        // Ona görə söndürülüb: panel sabit 144 Hz-də qalır. Əvvəlki davranış üçün OFF əvəzinə ONLY_IF_SEAMLESS yazın.
        p.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF)
        p.addListener(listener)
        p.addAnalyticsListener(analytics)
        player = p
        return p
    }

    private fun maybeMarkPlaying() {
        if (playing || url == null) return
        val p = player ?: return
        if (p.playbackState != Player.STATE_READY) return
        // Görüntülü yayım: ilk kadr çəkilib; yalnız səs (radio): video qrupu yoxdur.
        if (!(firstFrame || (tracksKnown && !hasVideoGroup))) return
        if (switchMp2ToFfmpeg()) return
        playing = true
        playingAt = SystemClock.elapsedRealtime()
        underrunTimes.clear()
        droppedEvents.clear()
        // Səs dekoderinin girişi (real format) bəzən ilk kadrdan bir qədər sonra məlum olur: MP2 gec aşkarlanarsa yenə düzəldilir.
        if (mode == DecoderMode.NORMAL) {
            val gen = generation
            ui.postDelayed({ if (!released && generation == gen && playing && switchMp2ToFfmpeg()) Log.i(TAG, "MP2 gec aşkarlandı") }, 1_500L)
        }
        if (hasVideoGroup) watchVideo(generation)
        // Kanal bu rejimdə açıldı: növbəti dəfə birbaşa bu rejimlə başlayır.
        if (persist) url?.let { memory.remember(it, mode) }
        callback.onPlaying()
    }

    private fun failNow(message: String) {
        playing = false
        callback.onFailed(message)
    }

    fun play(newUrl: String, ua: String?, ref: String?, level: Int = 0, persist: Boolean = true) {
        if (released) return
        this.bufLevel = level.coerceIn(0, BufferProfile.MAX_LEVEL)
        this.ua = ua
        this.ref = ref
        this.persist = persist
        // Yeni kanal: yadda saxlanmış rejim; təkrar qoşulmada (eyni link) cari rejim saxlanır.
        if (newUrl != url) {
            formatOverride = null
            formatRetried = false
            mode = if (persist) memory.mode(newUrl) else DecoderMode.NORMAL
            heals = 0
            videoFreezes = 0
            freezeTimes.clear()
        }
        start(newUrl)
    }

    // HLS / progressive formatı: link .m3u8 ilə bitmirsə (tokenli, .php, /hls/ ...) avtomatik aşkarlanır; səhv çıxsa bir dəfə tərsi cəhd edilir.
    private var formatOverride: Boolean? = null   // true = HLS, false = progressive (MPEG-TS, AAC/ADTS, MP3, MP2 ...)
    private var formatRetried = false

    private fun looksHls(low: String): Boolean =
        low.contains("m3u8") || low.contains("/hls/") || low.contains("/hls?") ||
            low.contains("type=hls") || low.contains("format=hls") || low.contains("output=hls")

    private fun start(newUrl: String) {
        if (released) return
        val g = ++generation
        url = newUrl
        playing = false
        buffering = false
        firstFrame = false
        videoDecoder = ""
        passthroughLabel = ""
        hasVideoGroup = false
        tracksKnown = false
        speed.reset()
        underrunTimes.clear()
        droppedEvents.clear()
        wdCount = -1; wdAt = SystemClock.elapsedRealtime(); wdFlowing = false
        try {
            val p = ensurePlayer()
            // Kadrı kəsmə; SurfaceView sahəsinə uyğun miqyasla.
            p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            // Qaralma düzəlişi: foreground mode dekoderi stop()/mənbə dəyişəndə buraxmır (yeni mənbə eyni formatdadırsa
            // MediaCodec təkrar istifadə olunur, SurfaceView son kadrı saxlayır).
            runCatching { p.setForegroundMode(true) }
            // "İsti" yenidən qoşulma (token yenilənməsi, donma, statik görüntü və s.): player artıq işləyir/buferləyir.
            // Bu halda stop()+clearMediaItems() ÇAĞIRILMIR: onlar dekoderi buraxıb səthi ~0.5 s qaraldırdı.
            // Mənbə birbaşa dəyişdirilir, son kadr yeni kadr gələnə qədər ekranda qalır.
            val warm = p.playbackState != Player.STATE_IDLE && p.currentMediaItem != null
            if (!warm) {
                p.stop()
                p.clearMediaItems()
            }
            val http = OkHttpDataSource.Factory(StreamHttp.client)
                .setUserAgent(ua?.takeIf { it.isNotBlank() } ?: DEFAULT_UA)
            ref?.takeIf { it.isNotBlank() }?.let {
                val h = mutableMapOf("Referer" to it)
                // canlitv.com ehtiyat linki: XezerTV kimi Referer ilə yanaşı Origin də göndərilir.
                if (it.startsWith("https://canlitv.com")) h["Origin"] = "https://canlitv.com"
                http.setDefaultRequestProperties(h)
            }
            val low = newUrl.lowercase()
            val hls = formatOverride ?: looksHls(low)
            val item = MediaItem.Builder()
                .setUri(newUrl)
                .setMediaId(g.toString())
                // Buferlənmədən sonra canlı yayımın sonuna yetişmək üçün sürətləndirmə YOXDUR: qaldığı yerdən 1x ilə davam edir.
                .setLiveConfiguration(
                    MediaItem.LiveConfiguration.Builder()
                        .setMinPlaybackSpeed(1f)
                        .setMaxPlaybackSpeed(1f)
                        .build()
                )
                .apply {
                    when {
                        hls -> setMimeType(MimeTypes.APPLICATION_M3U8)
                        low.contains(".mpd") -> setMimeType(MimeTypes.APPLICATION_MPD)
                    }
                }
                .build()
            val ds = DefaultDataSource.Factory(appContext, http)
            val src = if (hls) {
                HlsMediaSource.Factory(ds)
                    .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, false))
                    .setAllowChunklessPreparation(true)
                    .setLoadErrorHandlingPolicy(FastFailPolicy())
                    .createMediaSource(item)
            } else {
                // Progressive: MPEG-TS, ADTS/LATM AAC, MPEG audio (MP3/MP2) radio və s.; format məzmundan aşkarlanır.
                DefaultMediaSourceFactory(ds, DefaultExtractorsFactory().setTsExtractorFlags(TS_FLAGS))
                    .setLoadErrorHandlingPolicy(FastFailPolicy())
                    .createMediaSource(item)
            }
            if (!warm) p.setVideoSurfaceView(view)
            p.setMediaSource(src)
            p.prepare()
            p.playWhenReady = true
        } catch (t: Throwable) {
            Log.e(TAG, "Media3 başladılmadı", t)
            ui.post { if (!released && g == generation && url != null) failNow("Media3 işə düşmədi") }
        }
    }

    fun stop() {
        generation++
        url = null
        playing = false
        buffering = false
        player?.let { runCatching { it.stop(); it.clearMediaItems() } }
    }

    fun stopForBackground() {
        // Fonda dekoder tutulmasın (2 GB RAM-lı TV box).
        player?.let { runCatching { it.setForegroundMode(false) } }
        stop()
    }

    fun togglePause() {
        val p = player ?: return
        if (released || !playing) return
        p.playWhenReady = !p.playWhenReady
    }

    /** Oynatma mövqeyi (ms); yayım donanda dəyişmir. Naməlum: -1. */
    fun position(): Long {
        val p = player ?: return -1L
        return if (!playing) -1L else p.currentPosition
    }

    fun stats(): PlayerStats? {
        val p = player ?: return null
        if (released || !playing) return null
        val now = SystemClock.elapsedRealtime()
        val level = when {
            buffering -> 2
            now - lastBufferingAt < 12_000L -> 1
            else -> 0
        }
        val bps = speed.sample(uidRxBytes(), now)
        val vb = p.videoFormat?.bitrate ?: -1
        val ab = p.audioFormat?.bitrate ?: -1
        val trackBr = if (vb > 0) (vb + maxOf(ab, 0)).toLong() else 0L
        val br = if (trackBr > 0) trackBr else bps
        val size = p.videoSize
        val vf = p.videoFormat
        val hdr = when {
            vf?.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION -> "DV"
            vf?.colorInfo?.colorTransfer == C.COLOR_TRANSFER_ST2084 -> "HDR10"
            vf?.colorInfo?.colorTransfer == C.COLOR_TRANSFER_HLG -> "HLG"
            else -> ""
        }
        val path = if (videoDecoder.isNotBlank() && TvProfile.isSoftwareDecoder(videoDecoder)) "SW" else "" // HW yazılmır
        // Dolby/DTS dekod edilmədən ötürülürsə format adı + PT (məs. "AC3 PT").
        val pt = if (passthroughLabel.isNotEmpty()) "$passthroughLabel PT" else ""
        val tag = listOf(path, hdr, pt).filter { it.isNotEmpty() }.joinToString(" ")
        return PlayerStats(size.width, size.height, p.totalBufferedDuration, level, bps, "", br, tag)
    }

    fun release() {
        if (released) return
        released = true
        generation++
        url = null
        discardPlayer()
    }
}
