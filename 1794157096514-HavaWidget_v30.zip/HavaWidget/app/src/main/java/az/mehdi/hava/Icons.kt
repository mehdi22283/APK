package az.mehdi.hava

import android.content.Context

/** Tətbiqin öz vektor ikonları (res/drawable/ic_*.xml). size: "s"=11dp, ""=14dp, "l"=20dp, "xl"=26dp */
object Ic {
    fun id(c: Context, name: String, size: String = ""): Int =
        c.resources.getIdentifier("ic_$name" + if (size.isEmpty()) "" else "_$size", "drawable", c.packageName)
}
