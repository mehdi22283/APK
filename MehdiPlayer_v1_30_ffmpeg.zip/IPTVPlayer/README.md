# IPTVPlayer — Media3 → mpv → VLC

Birinci pleyer **Media3 1.11.1** (ExoPlayer, http/https; MediaCodec + **FFmpeg** dekoderləri), codec dəstəklənməyəndə **dərhal mpv**-yə keçilir (mpv-android build-i: `libmpv.so`, `libplayer.so`, `libmv*.so`/`libmw*.so`). Üçüncü ehtiyat pleyer: **VLC** (libVLC 3.6.0). Versiya: **1.30** (versionCode 30).

## Media3 + FFmpeg (v1.30)
- Media3 **1.9.4 → 1.11.1** (ən son stabil; 1.12.0 hələ beta).
- FFmpeg dekoderləri: `io.github.anilbeesetti:nextlib-media3ext:1.11.1-0.16.0` (NextLib, **GPL-3.0**). Versiya adı `<Media3>-<NextLib>` formatındadır, Media3 versiyası ilə eyni saxlanmalıdır.
  - Səs: Vorbis, Opus, FLAC, ALAC, MP3, AAC, AC3, EAC3, DTS, MLP, TrueHD, AMR-NB/WB, PCM a-law/mu-law.
  - Video: H.264, HEVC, VP8, VP9 (FFmpeg), AV1 (dav1d).
- `Media3Engine.ensurePlayer()` → `NextRenderersFactory` + `EXTENSION_RENDERER_MODE_ON`: əvvəl MediaCodec (aparat), dəstəkləmirsə FFmpeg (proqram). NextLib-in son versiyasında rejimin standart dəyəri `OFF`-dur, ona görə açıq təyin olunur.
- MediaCodec dekoderi açılmasa / dekodlama uğursuz olsa (`DECODER_INIT_FAILED`, `DECODER_QUERY_FAILED`, `DECODING_FAILED`, `AUDIO_TRACK_INIT_FAILED`) eyni link **bir dəfə** `PREFER` rejimində (FFmpeg əvvəl) yenidən açılır; işləsə link bu sessiyada birbaşa `PREFER` ilə başlayır. FFmpeg də açmasa → mpv.
- Kotlin **2.0.21 → 2.2.21**: NextLib Kotlin 2.2 ilə yığılıb, köhnə kompilyator onun metadatasını oxuya bilmir.
- **Native kitabxana toqquşması həll olunub:** NextLib öz FFmpeg-ini `libavcodec.so`, `libavformat.so`, `libavutil.so`, `libswscale.so`, `libswresample.so` adları ilə gətirir; mpv-nin eyni adlı faylları ilə APK-da toqquşardı. Buna görə mpv-nin FFmpeg kitabxanaları (fayl adı, SONAME və `NEEDED` qeydləri eyni uzunluqlu adlarla) dəyişdirilib: `libav*` → `libmv*`, `libsw*` → `libmw*` (`libmvcodec.so`, `libmvformat.so`, `libmvutil.so`, `libmvfilter.so`, `libmvdevice.so`, `libmwscale.so`, `libmwresample.so`). `libmpv.so` və `libplayer.so` yeni adlara bağlıdır. mpv-android build-ini yenidən götürəndə eyni dəyişiklik təkrar tətbiq olunmalıdır.

## Pleyer ardıcıllığı
Kanal açılmazdan əvvəl serverə qısa sorğu göndərilir ("Server yoxlanılır", 5 s). 404/403/5xx və ya qoşulma xətası alınarsa mpv yoxlanmır, kanal işləmir sayılır (ehtiyat link prosesi başlaya bilər).

Sonra mpv ilə:
- **Yeni kanal:** 3 cəhd, hər biri 8 s (`PlayerManager.MPV_TIMEOUT_MS`, `NEW_ATTEMPTS`).
- **İşləyən kanal qırılıb/donub:** avtomatik yenidən qoşulma, 2 cəhd.
- Hamısı açmasa "Kanal İşləmir" göstərilir (və ya yoda.az ehtiyat link prosesi başlayır).

mpv-nin bütün cəhdləri uğursuz olarsa **VLC** (2 cəhd, hər biri 6 s) yoxlanır; o da açmasa "Kanal İşləmir".
Kanal VLC ilə açılıbsa növbəti dəfə birbaşa VLC ilə başlayır (`PlayerMemory`: `v`).

Alt məlumat zolağında pleyer işarəsi: 💙 Media3, 💜 mpv, 🧡 VLC.

## mpv necə qoşulub
- `app/src/main/jniLibs/armeabi-v7a/` — APK-dan götürülmüş native kitabxanalar (libmpv, libplayer, libmvcodec, libmvformat, libmvfilter, libmvutil, libmvdevice, libmwscale, libmwresample, libc++_shared). FFmpeg kitabxanaları NextLib ilə toqquşmasın deyi yenidən adlandırılıb (yuxarıya bax).
- `app/src/main/java/is/xyz/mpv/MPVLib.kt` — JNI körpüsü. **Paket və sinif adı (`is.xyz.mpv.MPVLib`) dəyişdirilməməlidir**, çünki `libplayer.so` bu ada bağlıdır.
- `app/src/main/java/az/mehdi/iptvplayer/MpvEngine.kt` — mühərrik (seçimlər, hadisələr, səth, loadfile/stop/pause).
- `app/src/main/java/az/mehdi/iptvplayer/Engines.kt` — `PlayerManager` (cəhdlər, avtomatik bərpa, watchdog, ilkin server sorğusu).
- `app/src/main/assets/cacert.pem` — mpv üçün CA faylı (TLS yoxlaması IPTV serverləri üçün söndürülüb: `tls-verify=no`).

Ətraflı: `PLAYBACK_OPTIMIZATION.md`.

## 2 GB RAM TV box
Kiçik bufer (mpv demuxer 24 MB / 20 s), `largeHeap`, yalnız `armeabi-v7a`. Dekoder: əvvəl MediaCodec (`mediacodec`, sonra `mediacodec-copy`), açılmasa proqram dekoderi.

## Toolchain
- JDK 17, Gradle 8.14.3 (CI), AGP 8.9.1, Kotlin 2.2.21
- compileSdk 36, targetSdk 33, minSdk 24 (Android 7.0), core library desugaring
- OkHttp 4.12.0 (yalnız playlist/EPG/ilkin sorğu üçün)

## Debug APK
```bash
gradle assembleDebug --no-daemon
```
Debug imza ilə qalır, amma `isDebuggable = false`.

## TV pultu: kanal paneli
Pultda yuxarı düymə ilə açılan kanal dəyişmə paneli avtomatik vaxt bitiminə görə bağlanmır. Panel geri düyməsi ilə, toxunuşla bağlandıqda və ya kanal seçildikdə bağlanır.

## Telefon / planşet idarəetməsi (toxunma)
- Videoya **tək toxunuş**: yuxarıda kanallar siyahısı, kanal zolağı və proqram cədvəli düymələri çıxır (4 s sonra gizlənir). Alt EPG zolağı kanal dəyişəndə çıxır və 4 s sonra gizlənir.
- **İki dəfə toxunuş**: pauza / davam.
- **Sağa/sola sürüşdür**: əvvəlki / növbəti kanal.
- **Sağ yarıda yuxarı/aşağı sürüşdür**: səs; **sol yarıda**: ekran parlaqlığı.
- Kanallar siyahısı və proqram cədvəlində sağ yuxarıda ✕ düyməsi var; sistem "geri" jesti də işləyir.
- TV pultu işləməyə davam edir (pult düyməsi basılanda toxunma düymələri gizlənir).

## Playlist mənbəsi
Yalnız `m3u8.mehdimyev.workers.dev` playlisti istifadə olunur (`Data.kt` → `PLAYLIST_URL`). Keş faylı `playlist_mehdimyev.m3u`-dur; köhnə mənbədən qalan `playlist.m3u` ilk açılışda silinir. Yükləmə alınmasa təkrar cəhdlər 8 s, 20 s, 45 s, 90 s, 180 s fasilə ilə aparılır.

## Son kanal
Son izlənən kanal link, ad, qrup və tvg-id ilə saxlanılır. Playlistdə linki dəyişsə də, tətbiq yenidən açılanda kanal ad/qrup və ya tvg-id ilə tapılıb açılır.

## mpv sabitliyi
mpv prosesdə tək nüsxədir. `loadfile` / `stop` / `pause` əmrləri tək `mpv-ctl` thread-ində ardıcıl icra olunur; kanal sürətlə dəyişəndə köhnəlmiş əmrlər atlanır (generation nömrəsi). Video səthi hazır olmadan `loadfile` verilmir (səth gələnə qədər gözləyir). `App.kt`-dəki təhlükəsizlik toru tutulmayan Java/Kotlin xətasında tətbiqi avtomatik yenidən açır (15 s-də təkrar çökərsə açmır).

## EPG əl ilə əlaqələndirmə
`Epg.kt` → `EPG_ALIASES`: cbc-sport, ictimai-tv, muztv, kanal-7-hd-tr, show-hd-tr, star-tv-hd-tr, tv8-tr, tv85-tr, trt-1/2/3-hd, trt-avaz, trt-cocuk-tr, trt-haber-hd, trt-muzik-tr, trt-spor-yild-tr, trt-turk-tr, trt4k-tr, dmax-tr XML kanalları playlistdəki uyğun adlarla (hd/tr/boşluq/diakritikdən asılı olmayaraq) bağlanır. EPG-də proqram təsviri 160 simvolla məhduddur.

## Ehtiyat link (yoda.az)
Playlistdəki link mpv ilə açılmasa, tətbiq kanalın **yoda.az** səhifəsini gizli WebView-da açır, səhifənin pleyerinin göndərdiyi tokenli `.m3u8` linkini tutur və pleyerə verir (`Backup.kt`).
- Yalnız playlistdə **"Azərbaycan"** qrupunda olan 19 kanal üçün: AZTV, MƏDƏNİYYƏT TV, İDMAN TV, BİZNES TV, BAKU TV, APA TV, REAL TV, ARB 24 HD, ARB GÜNƏŞ HD, ARB, İCTİMAİ TV, SPACE TV, ATV, XƏZƏR TV HD, DÜNYA TV HD, NAXÇIVAN TV, KANAL 35, QAFQAZ TV, EL TV. Kanal adı normallaşdırılaraq (diakritik, boşluq, sondakı HD atılır) `Backup.PAGES` cədvəli ilə uyğunlaşdırılır; Türkiyə qrupundakı eyni adlı kanallara toxunulmur.
- Token IP və User-Agent-ə bağlıdır: link bu cihazda alınır, oynatma eyni User-Agent və Referer ilə aparılır (mpv: `user-agent` və `referrer`).
- Ardıcıllıq: playlist linki → mpv cəhdləri → (hamısı açmasa) yoda.az-dan tokenli link → mpv. Ehtiyat link sonradan qırılsa (məs. token bitsə) link yenidən alınır (ardıcıl 3 cəhd; işləyəndə sayğac sıfırlanır).
- Ehtiyat linkdə `.m3u8` sorğusu tapılmasa 20 s sonra "Kanal İşləmir" göstərilir. Loglar: `adb logcat -s IPTV-BACKUP`.
- WebView yalnız lazım olanda yaradılır, şəkil yükləmə söndürülüb, iş bitən kimi yaddaşdan silinir; render prosesi ölərsə tətbiq çökmür.

### Apa TV: əvvəl yoda.az
Apa TV (`Backup.YODA_FIRST`) əksinə açılır: **yoda.az tokenli link → mpv**; link alınmasa və ya işləməsə **playlistdəki link** ehtiyat kimi açılır. yoda linki işləyib sonradan qırılsa (token bitsə) əvvəl yenilənir, alınmasa playlistə keçilir. Digər kanallar əvvəlki qaydadadır.

Loglar: `adb logcat -s IPTV-MPV IPTV-PLAYER`.

## Kanal nömrəsi (v1.26)
- **Ekran rəqəm paneli** (telefon/planşet): videoya toxun → yuxarıda `123` düyməsi → 0–9, ⌫ (sil), ✓ (aç). Nömrə yuxarı sağda göstərilir, 10 san hərəkətsizlikdən sonra panel bağlanır. Geri düyməsi/videoya toxunuş də bağlayır. Pult rəqəmləri əvvəlki kimi işləyir.
