package az.mehdi.hava

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Widget üçün: növbəti 24 saatın temperatur əyrisi + yağış ehtimalı sütunları (Bitmap) */
object WidgetChart {
    private const val W = 960
    private const val H = 280

    private fun text(size: Float, col: Int, bold: Boolean, align: Paint.Align): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            color = col
            textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setShadowLayer(4f, 1f, 1f, Color.argb(204, 0, 0, 0))
        }

    private fun fill(col: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col
        style = Paint.Style.FILL
    }

    fun draw(w: Weather, n: Int): Bitmap? {
        if (n < 0) return null
        val end = min(w.hours.size - 1, n + 24)
        val m = end - n + 1
        if (m < 4) return null
        val hrs = w.hours.subList(n, end + 1)

        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)

        val left = 44f
        val right = W - 44f
        val tTop = 78f
        val tBot = 164f
        val rBase = 226f
        val rMax = 42f
        val dx = (right - left) / (m - 1)

        var tmin = hrs.minOf { it.temp }
        var tmax = hrs.maxOf { it.temp }
        if (tmax - tmin < 4.0) {
            val mid = (tmax + tmin) / 2.0
            tmin = mid - 2.0
            tmax = mid + 2.0
        }
        fun xOf(i: Int): Float = left + i * dx
        fun yOf(t: Double): Float = (tBot - ((t - tmin) / (tmax - tmin)) * (tBot - tTop)).toFloat()

        val orange = Color.parseColor("#FFB74D")
        val blue = Color.parseColor("#4FC3F7")

        // başlıq + izah
        cv.drawText("Növbəti 24 saat", left, 34f, text(26f, Color.WHITE, true, Paint.Align.LEFT))
        val lg = text(22f, Color.parseColor("#CFD8DC"), false, Paint.Align.LEFT)
        val t1 = "temperatur"
        val t2 = "yağış %"
        val x2 = right - lg.measureText(t2)
        cv.drawText(t2, x2, 34f, lg)
        val sq = x2 - 26f
        cv.drawRect(sq, 19f, sq + 16f, 35f, fill(blue))
        val x1 = sq - 26f - lg.measureText(t1)
        cv.drawText(t1, x1, 34f, lg)
        cv.drawCircle(x1 - 16f, 27f, 8f, fill(orange))

        // gecə yarısı xətti
        val midP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(60, 255, 255, 255)
            strokeWidth = 2f
        }
        hrs.forEachIndexed { i, h ->
            if (i > 0 && h.time.substring(11, 13) == "00") cv.drawLine(xOf(i), tTop - 24f, xOf(i), rBase, midP)
        }

        // yağış sütunları
        val barP = Paint(Paint.ANTI_ALIAS_FLAG)
        val bw = dx * 0.55f
        hrs.forEachIndexed { i, h ->
            val bh = max(2f, h.prob.coerceIn(0, 100) / 100f * rMax)
            barP.color = Color.argb(70 + h.prob.coerceIn(0, 100) * 185 / 100, 79, 195, 247)
            cv.drawRoundRect(xOf(i) - bw / 2, rBase - bh, xOf(i) + bw / 2, rBase, 3f, 3f, barP)
        }
        cv.drawLine(left - 10f, rBase, right + 10f, rBase, Paint().apply {
            color = Color.argb(90, 255, 255, 255)
            strokeWidth = 2f
        })

        // temperatur əyrisi
        val xs = FloatArray(m) { xOf(it) }
        val ys = FloatArray(m) { yOf(hrs[it].temp) }
        val line = Path()
        line.moveTo(xs[0], ys[0])
        for (i in 1 until m) {
            val cx = (xs[i - 1] + xs[i]) / 2f
            line.cubicTo(cx, ys[i - 1], cx, ys[i], xs[i], ys[i])
        }
        val area = Path(line)
        area.lineTo(xs[m - 1], tBot + 14f)
        area.lineTo(xs[0], tBot + 14f)
        area.close()
        val areaP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(0f, tTop, 0f, tBot + 14f, Color.argb(110, 255, 183, 77), Color.argb(0, 255, 183, 77), Shader.TileMode.CLAMP)
        }
        cv.drawPath(area, areaP)
        cv.drawPath(line, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            strokeCap = Paint.Cap.ROUND
            color = orange
        })

        // nöqtələr, temperatur və saat yazıları (hər 3 saatdan bir)
        val tp = text(24f, Color.WHITE, true, Paint.Align.CENTER)
        val rp = text(19f, Color.parseColor("#81D4FA"), true, Paint.Align.CENTER)
        val hp = text(20f, Color.parseColor("#CFD8DC"), false, Paint.Align.CENTER)
        val dotIn = fill(Color.WHITE)
        val dotOut = fill(orange)
        for (i in 0 until m step 3) {
            val h = hrs[i]
            cv.drawCircle(xs[i], ys[i], if (i == 0) 11f else 8f, dotOut)
            cv.drawCircle(xs[i], ys[i], if (i == 0) 6f else 4f, dotIn)
            cv.drawText("${h.temp.roundToInt()}°", xs[i], ys[i] - 18f, tp)
            if (h.prob >= 10) {
                val bh = max(2f, h.prob.coerceIn(0, 100) / 100f * rMax)
                cv.drawText("${h.prob}%", xs[i], rBase - bh - 7f, rp)
            }
            cv.drawText(if (i == 0) "indi" else h.time.substring(11, 16), xs[i], rBase + 32f, hp)
        }
        val small = Bitmap.createScaledBitmap(bmp, 640, 187, true)
        if (small !== bmp) bmp.recycle()
        return small
    }
}
