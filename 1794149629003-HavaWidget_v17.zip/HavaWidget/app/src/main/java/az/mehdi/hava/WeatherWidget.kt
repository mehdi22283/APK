package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.view.View
import android.widget.RemoteViews
import kotlin.math.roundToInt

class WeatherWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        Scheduler.start(context)
        Midnight.schedule(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Scheduler.start(context)
        Midnight.schedule(context)
        refresh(context)
        if (WeatherApi.ageMin(context) > 10) Scheduler.now(context)
    }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return
            m.updateAppWidget(ids, build(c))
        }

        private val INFO_IDS = intArrayOf(R.id.w_i1, R.id.w_i2, R.id.w_i3, R.id.w_i4, R.id.w_i5, R.id.w_i6)
        private val DETAIL_IDS = intArrayOf(R.id.w_wear, R.id.w_windl, R.id.w_humid, R.id.w_moon, R.id.w_sun)

        /** Mətnin solunda ikon göstərir (sol ikon: ad + ölçü) */
        private fun left(c: Context, rv: RemoteViews, id: Int, text: CharSequence, icon: String, size: String) {
            rv.setTextViewText(id, text)
            rv.setTextViewCompoundDrawables(id, Ic.id(c, icon, size), 0, 0, 0)
            rv.setViewVisibility(id, View.VISIBLE)
        }

        private fun build(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val w = WeatherApi.cached(c)
            val n = w?.nowIndex() ?: -1
            rv.setTextViewText(R.id.w_date, T.dateLine())
            left(c, rv, R.id.w_word, Daily.word(c), "bulb", "s")
            left(c, rv, R.id.w_proverb, Daily.proverb(c), "book", "s")
            rv.removeAllViews(R.id.w_days)
            rv.removeAllViews(R.id.w_hours)
            INFO_IDS.forEach { rv.setViewVisibility(it, View.GONE) }
            DETAIL_IDS.forEach { rv.setViewVisibility(it, View.GONE) }
            rv.setViewVisibility(R.id.w_chart, View.GONE)

            // Ay fazası internet olmadan da hesablanır
            val mi = Moon.info()
            left(c, rv, R.id.w_moon,
                "Ay: ${mi.name}, ${mi.illum}% işıqlanma · Dolunay ${Moon.inText(mi.nextFull)} · Yeni ay ${Moon.inText(mi.nextNew)}",
                mi.icon, "s")

            if (w == null || n < 0) {
                rv.setTextViewText(R.id.w_title, "Yenilənir…")
                rv.setTextViewCompoundDrawables(R.id.w_title, 0, 0, 0, 0)
                rv.setTextViewText(R.id.w_outlook, "İnternet bağlantısı olanda məlumat yüklənəcək")
                rv.setTextViewCompoundDrawables(R.id.w_outlook, 0, 0, 0, 0)
            } else {
                val h = w.hours[n]
                left(c, rv, R.id.w_title, "${h.temp.roundToInt()}°  ${T.desc(h.code)}", T.iconName(h.code), "xl")
                val o = w.outlook()
                left(c, rv, R.id.w_outlook, o?.text ?: "", T.kindIcon(o?.kind), "")
                w.widgetInfo(n).forEachIndexed { r, row ->
                    row.take(3).forEachIndexed { i, p -> left(c, rv, INFO_IDS[r * 3 + i], p.second, p.first, "s") }
                }

                // növbəti 16 saat (2 saat addımla)
                (1..8).map { n + it * 2 }.filter { it < w.hours.size }.forEach { i ->
                    val hh = w.hours[i]
                    val r = RemoteViews(c.packageName, R.layout.widget_hour)
                    r.setTextViewText(R.id.h_time, hh.time.substring(11, 16))
                    r.setImageViewResource(R.id.h_icon, Ic.id(c, T.iconName(hh.code), "xl"))
                    r.setTextViewText(R.id.h_temp, "${hh.temp.roundToInt()}°")
                    r.setTextViewText(R.id.h_rain, "${hh.prob}%")
                    r.setTextViewCompoundDrawables(R.id.h_rain, Ic.id(c, "drop", "s"), 0, 0, 0)
                    rv.addView(R.id.w_hours, r)
                }

                val days = w.upcomingDays()
                days.forEachIndexed { i, d ->
                    val r = RemoteViews(c.packageName, R.layout.widget_day)
                    r.setTextViewText(R.id.d_name, if (i == 0) "Bu gün" else T.dayName(d.date))
                    r.setImageViewResource(R.id.d_icon, Ic.id(c, T.iconName(d.code), "xl"))
                    r.setTextViewText(R.id.d_max, "${d.max.roundToInt()}°")
                    r.setTextViewText(R.id.d_min, "${d.min.roundToInt()}°")
                    r.setTextViewText(R.id.d_rain, "${d.prob}%")
                    r.setTextViewCompoundDrawables(R.id.d_rain, Ic.id(c, "drop", "s"), 0, 0, 0)
                    r.setTextViewText(R.id.d_hours, "${w.precipHours(d)} saat")
                    r.setTextViewCompoundDrawables(R.id.d_hours, Ic.id(c, "clock", "s"), 0, 0, 0)
                    val frame = when (d.frameKind()) {
                        "qar" -> R.drawable.frame_snow
                        "yağış" -> R.drawable.frame_rain
                        "külək" -> R.drawable.frame_wind
                        else -> R.drawable.frame_none
                    }
                    r.setInt(R.id.d_box, "setBackgroundResource", frame)
                    rv.addView(R.id.w_days, r)
                }

                // 24 saatlıq temperatur + yağış qrafiki
                try {
                    WidgetChart.draw(w, n)?.let {
                        rv.setImageViewBitmap(R.id.w_chart, it)
                        rv.setViewVisibility(R.id.w_chart, View.VISIBLE)
                    }
                } catch (e: Exception) {
                }

                // geyim məsləhəti
                val wa = Wear.now(w, n)
                left(c, rv, R.id.w_wear, "Geyim (${wa.headline}): ${wa.short}", "shirt", "s")

                // Xəzri / Gilavar və ya cari külək
                val we = w.windEvent()
                left(c, rv, R.id.w_windl, we?.text ?: WindInfo.detail(h.wind, h.dir), "wind", "s")

                // rütubət + hava keyfiyyəti
                val air = ArrayList<String>()
                if (!h.hum.isNaN()) air.add("Rütubət ${h.hum.roundToInt()}%")
                w.aqi?.let {
                    air.add("AQI ${it.us} (${T.aqiLevel(it.us)})")
                    air.add("PM2.5 ${it.pm25.roundToInt()}")
                    air.add("PM10 ${it.pm10.roundToInt()}")
                }
                if (air.isNotEmpty()) left(c, rv, R.id.w_humid, air.joinToString(" · "), "drop", "s")

                // gün uzunluğu
                w.dayLight()?.let { dl ->
                    val parts = listOfNotNull("Gün ${dl.lenText}", dl.remaining, dl.diffText)
                    left(c, rv, R.id.w_sun, parts.joinToString(" · "), "sunrise", "s")
                }
            }
            left(c, rv, R.id.w_steps, Steps.stepsText(c), "steps", "")
            left(c, rv, R.id.w_km, Steps.kmText(c), "ruler", "")
            val hr = Heart.last(c)
            rv.setTextViewText(R.id.w_heart, if (hr == null) "Ölç" else "${hr.second}\n${Heart.timeText(hr.first)}")
            rv.setTextViewCompoundDrawables(R.id.w_heart, 0, Ic.id(c, "heart", "l"), 0, 0)
            rv.setOnClickPendingIntent(R.id.w_root, Notif.open(c))
            rv.setOnClickPendingIntent(R.id.w_heart, Heart.open(c))
            return rv
        }
    }
}
