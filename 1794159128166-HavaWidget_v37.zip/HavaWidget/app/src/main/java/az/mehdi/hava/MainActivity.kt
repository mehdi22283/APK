package az.mehdi.hava

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0F1B2A")
    private val CARD = Color.parseColor("#1B2B3F")
    private val GREY = Color.parseColor("#90A4AE")
    private val BLUE = Color.parseColor("#4FC3F7")
    private val YELLOW = Color.parseColor("#FFD54F")
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private var stepsView: TextView? = null
    private var kmView: TextView? = null
    private var stopSteps: (() -> Unit)? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        sv.addView(root)
        setContentView(sv)
        Scheduler.start(this)
        Midnight.schedule(this)
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        render()
        Thread { StepReader.readBlocking(this); runOnUiThread { updateSteps() } }.start()
        stopSteps = StepReader.watch(this) { runOnUiThread { updateSteps() } }
        if (WeatherApi.ageMin(this) > 15) fetch()
    }

    override fun onPause() {
        stopSteps?.invoke()
        stopSteps = null
        super.onPause()
    }

    private fun fetch() {
        Thread {
            val w = WeatherApi.refresh(this)
            WeatherWidget.refresh(this)
            if (w != null) Alerts.check(this, w)
            runOnUiThread {
                if (w != null) render()
                else Toast.makeText(this, "İnternet yoxdur, məlumat yenilənmədi", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        Scheduler.now(this)
    }

    // ---------- UI ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** res/drawable/ic_<ad>.xml ikonunu verilən dp ölçüsündə qaytarır */
    private fun ic(name: String, size: Int): Drawable {
        val d = resources.getDrawable(Ic.id(this, name), theme).mutate()
        val px = dp(size)
        d.setBounds(0, 0, px, px)
        return d
    }

    private fun TextView.icon(name: String, size: Int, pad: Int = 6) {
        setCompoundDrawablesRelative(ic(name, size), null, null, null)
        compoundDrawablePadding = dp(pad)
        gravity = android.view.Gravity.CENTER_VERTICAL
    }

    private fun label(s: String, sp: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false, parent: LinearLayout = root, icon: String? = null): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        if (icon != null) t.icon(icon, (sp * 1.2f).toInt(), (sp / 2).toInt().coerceAtLeast(4))
        parent.addView(t)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(CARD)
        bg.cornerRadius = dp(16).toFloat()
        c.background = bg
        c.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        root.addView(c, lp)
        return c
    }

    private fun section(s: String) {
        val t = label(s, 14f, GREY, true)
        t.setPadding(0, dp(16), 0, 0)
    }

    private fun row(p: LinearLayout, a: String, b: String, c: String, d: String, hi: Boolean, bIcon: String? = null, dIcon: String? = null) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(0, dp(5), 0, dp(5))
        fun cell(s: String, wt: Float, col: Int, bold: Boolean, icon: String? = null) {
            val t = TextView(this)
            t.text = s
            t.textSize = 13f
            t.setTextColor(col)
            if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
            if (icon != null) t.icon(icon, 18, 5)
            r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, wt))
        }
        cell(a, 2.1f, GREY, false)
        cell(b, 3.6f, Color.WHITE, false, bIcon)
        cell(c, 2.0f, Color.WHITE, true)
        cell(d, 1.7f, if (hi) BLUE else GREY, hi, dIcon)
        p.addView(r)
    }

    private fun button(caption: String, icon: String? = null, onClick: () -> Unit) {
        val b = Button(this)
        b.text = caption
        if (icon != null) {
            b.setCompoundDrawablesRelative(ic(icon, 20), null, null, null)
            b.compoundDrawablePadding = dp(8)
            b.setPadding(dp(24), 0, dp(24), 0)
        }
        b.setOnClickListener { onClick() }
        root.addView(b)
    }

    private fun render() {
        root.removeAllViews()
        stepsView = null
        kmView = null
        val w = WeatherApi.cached(this)
        val n = w?.nowIndex() ?: -1
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = android.view.Gravity.CENTER_VERTICAL
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        label("Bakı", 14f, GREY, true, head).layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val rb = ImageView(this)
        rb.setImageResource(Ic.id(this, "refresh", "xl"))
        rb.scaleType = ImageView.ScaleType.FIT_CENTER
        rb.setPadding(dp(9), dp(9), dp(9), dp(9))
        val rbBg = GradientDrawable()
        rbBg.shape = GradientDrawable.OVAL
        rbBg.setColor(CARD)
        rbBg.setStroke(dp(2), BLUE)
        rb.background = rbBg
        rb.contentDescription = "Yenilə"
        rb.setOnClickListener { fetch() }
        head.addView(rb, LinearLayout.LayoutParams(dp(44), dp(44)))
        if (w == null || n < 0) {
            label("Məlumat yüklənir…", 18f, Color.WHITE, true)
        } else {
            val h = w.hours[n]
            label("${h.temp.roundToInt()}°", 56f, Color.WHITE, true, icon = T.iconName(h.code))
            label("${T.desc(h.code)}", 16f)
            w.infoParts(n).forEach { label(it.second, 15f, GREY, icon = it.first) }

            val o = w.outlook()
            if (o != null) label(o.text, 17f, YELLOW, true, card(), T.kindIcon(o.kind))

            // ---- Geyim məsləhəti ----
            val wear = Wear.now(w, n)
            section("Geyim məsləhəti")
            val wc = card()
            label(wear.headline, 17f, YELLOW, true, wc, "shirt")
            wear.lines.forEach { l -> label(l.second, 14f, Color.WHITE, false, wc, l.first).setPadding(0, dp(6), 0, 0) }

            // ---- Külək ----
            section("Külək · Xəzri və Gilavar")
            val wd = card()
            label(WindInfo.detail(h.wind, h.dir), 15f, Color.WHITE, true, wd, "wind")
            val we = w.windEvent()
            if (we != null) label(we.text, 14f, YELLOW, true, wd, "wind").setPadding(0, dp(6), 0, 0)
            val wk = WindInfo.named(h.wind, h.dir) ?: we?.kind
            label(if (wk != null) WindInfo.note(wk) else WindInfo.INTRO, 13f, GREY, false, wd).setPadding(0, dp(6), 0, 0)

            section("Növbəti saatlar")
            val hc = card()
            listOf(1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 21, 24).filter { n + it < w.hours.size }.forEach {
                val x = w.hours[n + it]
                val wn = WindInfo.named(x.wind, x.dir)
                val wTxt = if (wn != null) "\n${WindInfo.title(wn)} ${x.wind.roundToInt()} km/saat" else ""
                row(hc, x.time.substring(11, 16), T.desc(x.code) + "\nYağıntı: ${fmtMm(x.mm)} — ${mmLabel(x.mm)}" + wTxt, "${x.temp.roundToInt()}°", "${x.prob}%", x.prob >= 50, T.iconName(x.code), "drop")
            }

            section("Bu gün və növbəti 7 gün")
            val dc = card()
            w.upcomingDays().forEachIndexed { i, d ->
                val name = if (i == 0) "Bu gün" else "${T.dayName(d.date)} ${d.date.substring(8, 10)}.${d.date.substring(5, 7)}"
                row(dc, name, "${T.desc(d.code)}\nYağıntı: ${w.precipHours(d)} saat\nMiqdar: ${fmtMm(d.mm)} — ${mmLabel(d.mm)}\n${WindInfo.label(d.wind, d.dir)}", "${d.max.roundToInt()}°/${d.min.roundToInt()}°", "${d.prob}%", d.prob >= 50, T.iconName(d.code), "drop")
            }
        }

        if (w != null && n >= 0) {
            section("Növbəti günlər üçün geyim")
            val gc = card()
            w.upcomingDays().forEachIndexed { i, d ->
                val nm = if (i == 0) "Bu gün" else "${T.dayName(d.date)} ${d.date.substring(8, 10)}.${d.date.substring(5, 7)}"
                label("$nm: ${Wear.forDay(w, d)}", 13f, Color.WHITE, false, gc, "shirt").setPadding(0, dp(4), 0, dp(4))
            }
        }
        renderSky(w)

        section("Addımölçən")
        val sc = card()
        stepsView = label("", 26f, Color.WHITE, true, sc, "steps")
        kmView = label("", 18f, BLUE, true, sc, "ruler")
        val sm = getSystemService(SensorManager::class.java)
        if (sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null) {
            label("Bu cihazda addımölçən sensoru yoxdur", 13f, GREY, false, sc)
        }
        updateSteps()

        section("Ürək döyüntüsü")
        val heartCard = card()
        val lastHr = Heart.last(this)
        label(
            if (lastHr == null) "Hələ ölçülməyib" else "${lastHr.second} döyüntü/dəq  ·  ${Heart.timeText(lastHr.first)}",
            20f, Color.WHITE, true, heartCard, "heart"
        )
        label("Barmağı arxa kameranın və flaşın üzərinə qoyaraq ölçün", 13f, GREY, false, heartCard)

        val gap = TextView(this)
        gap.height = dp(12)
        root.addView(gap)
        button("Ürək döyüntüsünü ölç", "heart") { startActivity(Intent(this, HeartActivity::class.java).putExtra("auto", true)) }
        button("Ana ekrana widget əlavə et", "plus") { pinWidget() }
    }

    private fun renderSky(w: Weather?) {
        section("Ay və gün uzunluğu")
        val mi = Moon.info()
        val mc = card()
        label("${mi.name} · ${mi.illum}% işıqlanıb", 18f, Color.WHITE, true, mc, mi.icon)
        label("Ayın yaşı: ${mi.age.roundToInt()} gün", 14f, GREY, false, mc).setPadding(0, dp(4), 0, 0)
        label("Növbəti dolunay: ${Moon.fmt(mi.nextFull)} (${Moon.inText(mi.nextFull)})", 14f, Color.WHITE, false, mc, "moon4").setPadding(0, dp(6), 0, 0)
        label("Növbəti yeni ay: ${Moon.fmt(mi.nextNew)} (${Moon.inText(mi.nextNew)})", 14f, Color.WHITE, false, mc, "moon0").setPadding(0, dp(6), 0, 0)
        val dl = w?.dayLight() ?: return
        val sc = card()
        label("Gün doğur ${dl.sunrise}  ·  batır ${dl.sunset}", 15f, Color.WHITE, true, sc, "sunrise")
        label("Gün uzunluğu: ${dl.lenText}", 15f, Color.WHITE, false, sc, "clock").setPadding(0, dp(6), 0, 0)
        dl.diffText?.let { label(it, 13f, GREY, false, sc).setPadding(0, dp(4), 0, 0) }
        label(dl.remaining, 14f, YELLOW, true, sc, "sunset").setPadding(0, dp(6), 0, 0)
        label(dl.solstice, 13f, GREY, false, sc).setPadding(0, dp(4), 0, 0)
    }

    private fun updateSteps() {
        stepsView?.text = "${Steps.stepsText(this)} addım"
        kmView?.text = "Bu gün ${Steps.kmText(this)} gəzdiniz"
    }

    private fun pinWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) {
            m.requestPinAppWidget(ComponentName(this, WeatherWidget::class.java), null, null)
        } else {
            Toast.makeText(this, "Ana ekranda boş yerə uzun basın → Widgetlər → Bakı Hava", Toast.LENGTH_LONG).show()
        }
    }
}
