package az.mehdi.hava

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import java.util.concurrent.atomic.AtomicBoolean
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.RemoteViews
import kotlin.math.roundToInt

class WeatherWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        Scheduler.start(context)
        Midnight.schedule(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACT_REFRESH) { spinAndRefresh(context, goAsync()); return }
        super.onReceive(context, intent)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Scheduler.start(context)
        Midnight.schedule(context)
        ChargeAlert.arm(context)
        refresh(context)
    }

    companion object {
        const val ACT_REFRESH = "az.mehdi.hava.WIDGET_REFRESH"

        /** Eyni ikon: iki dairəvi ox, deg dərəcə fırlanmış (120 px kvadrat) */
        fun refreshBitmap(deg: Float): Bitmap {
            val px = 120
            val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = px * 0.085f
                strokeCap = Paint.Cap.ROUND
                setShadowLayer(4f, 1f, 1f, Color.parseColor("#CC000000"))
            }
            val fill = Paint(p).apply { style = Paint.Style.FILL }
            val cx = px / 2f
            val r = px * 0.30f
            cv.rotate(deg, cx, cx)
            val rect = RectF(cx - r, cx - r, cx + r, cx + r)
            for (start in floatArrayOf(200f, 20f)) {
                val sweep = 125f
                cv.drawArc(rect, start, sweep, false, p)
                // ox ucu: qövsün sonunda saat əqrəbi istiqamətində üçbucaq
                val a = Math.toRadians((start + sweep).toDouble())
                val ex = cx + r * Math.cos(a).toFloat()
                val ey = cx + r * Math.sin(a).toFloat()
                val tx = -Math.sin(a).toFloat()
                val ty = Math.cos(a).toFloat()
                val nx = Math.cos(a).toFloat()
                val ny = Math.sin(a).toFloat()
                val h = px * 0.17f
                val path = Path()
                path.moveTo(ex + tx * h, ey + ty * h)
                path.lineTo(ex + nx * h * 0.8f, ey + ny * h * 0.8f)
                path.lineTo(ex - nx * h * 0.8f, ey - ny * h * 0.8f)
                path.close()
                cv.drawPath(path, fill)
            }
            return b
        }

        private fun refreshIntent(c: Context): PendingIntent =
            PendingIntent.getBroadcast(
                c, 7, Intent(c, WeatherWidget::class.java).setAction(ACT_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        /** İkona basanda: ox fırlanır, bu arada hava yenilənir; bitəndə vidcet tam yenidən çəkilir */
        fun spinAndRefresh(c: Context, pr: BroadcastReceiver.PendingResult?) {
            Thread {
                try {
                    val m = AppWidgetManager.getInstance(c)
                    val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
                    val done = AtomicBoolean(false)
                    Thread {
                        try {
                            StepReader.readBlocking(c)
                            val w = WeatherApi.refresh(c)
                            if (w != null) Alerts.check(c, w)
                        } catch (e: Throwable) { }
                        done.set(true)
                    }.start()
                    var deg = 0f
                    var frames = 0
                    // ən azı 1 tam dövrə (12 kadr), ən çoxu ~8 saniyə
                    while ((!done.get() || frames < 12) && frames < 80) {
                        deg = (deg + 30f) % 360f
                        try {
                            val part = RemoteViews(c.packageName, R.layout.widget)
                            part.setImageViewBitmap(R.id.w_refresh, refreshBitmap(deg))
                            m.partiallyUpdateAppWidget(ids, part)
                        } catch (e: Throwable) { }
                        Thread.sleep(100)
                        frames++
                    }
                    if (!done.get()) Scheduler.now(c) // 8 saniyədə bitmədisə, WorkManager tamamlasın
                    refresh(c)
                } finally {
                    try { pr?.finish() } catch (e: Throwable) { }
                }
            }.start()
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return
            val rv = try { build(c) } catch (e: Throwable) {
                // yükləmə xətası vidceti boş/"yüklənə bilmir" qoymasın: sadə ehtiyat görünüş
                RemoteViews(c.packageName, R.layout.widget).apply {
                    setTextViewText(R.id.w_title, "Yenilənir…")
                    setOnClickPendingIntent(R.id.w_root, Notif.open(c))
                }
            }
            try { m.updateAppWidget(ids, rv) } catch (e: Throwable) { }
        }


        private val INFO_IDS = intArrayOf(R.id.w_i1, R.id.w_i2, R.id.w_i3, R.id.w_i4, R.id.w_i5, R.id.w_i6)

        private val T_IDS = intArrayOf(R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5, R.id.w_t6,
            R.id.w_t7, R.id.w_t8)

        /** Saatlıq xana mətni: saat / temperatur / yağış % (ikon yuxarıda, ayrıca) */
        private fun hourText(time: String, temp: Int, prob: Int, mm: Double, snow: Double): CharSequence {
            val sb = SpannableStringBuilder()
            fun add(t: String, size: Float, color: Int, bold: Boolean) {
                val s = sb.length
                sb.append(t)
                val f = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                sb.setSpan(RelativeSizeSpan(size), s, sb.length, f)
                sb.setSpan(ForegroundColorSpan(color), s, sb.length, f)
                if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, f)
            }
            add(time, 1.0f, Color.parseColor("#CFD8DC"), false)
            sb.append("\n")
            add("$temp°", 1.2f, Color.WHITE, true)
            sb.append("\n")
            add("$prob%", 0.9f, Color.parseColor("#4FC3F7"), true)
            sb.append("\n")
            add(fmtPrecip(mm, snow), 0.8f, Color.parseColor("#81D4FA"), false)
            sb.append("\n")
            add(precipShort(mm, snow), 0.75f, Color.parseColor("#B3E5FC"), false)
            return sb
        }

        /** Mətnin solunda ikon göstərir (sol ikon: ad + ölçü) */
        private fun left(c: Context, rv: RemoteViews, id: Int, text: CharSequence, icon: String, size: String) {
            rv.setTextViewText(id, text)
            rv.setTextViewCompoundDrawables(id, Ic.id(c, icon, size), 0, 0, 0)
            rv.setViewVisibility(id, View.VISIBLE)
        }

        private fun build(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val w = WeatherApi.cached(c)
            val n = w?.nowIndex() ?: -1
            rv.setTextViewText(R.id.w_dm, T.dayMonth())
            rv.setTextViewText(R.id.w_wd, T.weekday())
            left(c, rv, R.id.w_word, Daily.word(c), "bulb", "s")
            left(c, rv, R.id.w_proverb, Daily.proverb(c), "book", "s")
            rv.removeAllViews(R.id.w_days)
            INFO_IDS.forEach { rv.setViewVisibility(it, View.GONE) }
            rv.setViewVisibility(R.id.w_wear, View.GONE)
            if (w == null || n < 0) {
                rv.setTextViewText(R.id.w_title, "Yenilənir…")
                rv.setTextViewCompoundDrawables(R.id.w_title, 0, 0, 0, 0)
                rv.setTextViewText(R.id.w_outlook, "İnternet bağlantısı olanda məlumat yüklənəcək")
                rv.setTextViewCompoundDrawables(R.id.w_outlook, 0, 0, 0, 0)
            } else {
                val h = w.hours[n]
                left(c, rv, R.id.w_title, "${h.temp.roundToInt()}°  ${T.desc(h.code)}", T.iconName(h.code), "xl")
                val o = w.outlook()
                left(c, rv, R.id.w_outlook, o?.text ?: "", T.kindIcon(o?.kind), "")
                // geyim: hər sətir öz emojisi ilə — 👕 Üst, 👖 Alt, 👟 Ayaqqabı (mətn kəsilmədən tam)
                val emoji = listOf("👕", "👖", "👟")
                val wear = Wear.now(w, n).lines.take(3).mapIndexed { i, l -> "${emoji[i]} ${l.second}" }.joinToString("\n")
                rv.setTextViewText(R.id.w_wear, wear)
                rv.setTextViewCompoundDrawables(R.id.w_wear, 0, 0, 0, 0)
                rv.setViewVisibility(R.id.w_wear, View.VISIBLE)
                w.widgetInfo(n).forEachIndexed { r, row ->
                    row.take(3).forEachIndexed { i, p ->
                        left(c, rv, INFO_IDS[r * 3 + i], p.second, p.first, "s")
                        val sec = when (p.first) { "thermo" -> "wear"; "sunrise", "sunset" -> "sky"; "wind", "clear", "leaf", "drop" -> p.first; else -> "top" }
                        rv.setOnClickPendingIntent(INFO_IDS[r * 3 + i], Notif.openSection(c, sec))
                    }
                }
                // növbəti 8 saat: tək sətirdə
                for (j in 1..8) {
                    val idx = n + j
                    if (idx >= w.hours.size) break
                    val hh = w.hours[idx]
                    val id = T_IDS[j - 1]
                    rv.setTextViewText(id, hourText(hh.time.substring(11, 16), hh.temp.roundToInt(), hh.prob, hh.mm, hh.snow))
                    rv.setTextViewCompoundDrawables(id, 0, Ic.id(c, T.iconName(hh.code), "l"), 0, 0)
                    rv.setOnClickPendingIntent(id, Notif.openSection(c, "hours"))
                }
                w.upcomingDays().forEachIndexed { i, d ->
                    val r = RemoteViews(c.packageName, R.layout.widget_day)
                    r.setTextViewText(R.id.d_name, if (i == 0) "Bu gün" else T.dayName(d.date))
                    r.setImageViewResource(R.id.d_icon, Ic.id(c, T.iconName(d.code), "xl"))
                    r.setTextViewText(R.id.d_max, "${d.max.roundToInt()}°")
                    r.setTextViewText(R.id.d_min, "${d.min.roundToInt()}°")
                    r.setTextViewText(R.id.d_rain, "${d.prob}%")
                    r.setTextViewCompoundDrawables(R.id.d_rain, Ic.id(c, "drop", "s"), 0, 0, 0)
                    r.setTextViewText(R.id.d_mm, fmtPrecip(d.mm, d.snow) + "\n" + precipShort(d.mm, d.snow))
                    r.setTextViewText(R.id.d_hours, "${w.precipHours(d)} saat")
                    r.setTextViewCompoundDrawables(R.id.d_hours, Ic.id(c, "clock", "s"), 0, 0, 0)
                    val frame = when (d.frameKind()) {
                        "qar" -> R.drawable.frame_snow
                        "yağış" -> R.drawable.frame_rain
                        "külək" -> R.drawable.frame_wind
                        else -> R.drawable.frame_none
                    }
                    r.setInt(R.id.d_box, "setBackgroundResource", frame)
                    r.setOnClickPendingIntent(R.id.d_box, Notif.openSection(c, "days"))
                    rv.addView(R.id.w_days, r)
                }
            }
            left(c, rv, R.id.w_steps, Steps.stepsText(c), "steps", "")
            left(c, rv, R.id.w_km, Steps.kmText(c), "ruler", "")
            val hr = Heart.last(c)
            rv.setTextViewText(R.id.w_heart, if (hr == null) "❤️ Ölç" else "❤️ ${hr.second}")
            rv.setImageViewBitmap(R.id.w_refresh, refreshBitmap(0f))
            rv.setOnClickPendingIntent(R.id.w_refresh, refreshIntent(c))
            rv.setOnClickPendingIntent(R.id.w_root, Notif.open(c))
            rv.setOnClickPendingIntent(R.id.w_title, Notif.openSection(c, "top"))
            rv.setOnClickPendingIntent(R.id.w_outlook, Notif.openSection(c, "outlook"))
            rv.setOnClickPendingIntent(R.id.w_wear, Notif.openSection(c, "wear"))
            rv.setOnClickPendingIntent(R.id.w_steps, Notif.openSection(c, "steps"))
            rv.setOnClickPendingIntent(R.id.w_km, Notif.openSection(c, "steps"))
            rv.setOnClickPendingIntent(R.id.w_heart, Heart.open(c))
            return rv
        }
    }
}
