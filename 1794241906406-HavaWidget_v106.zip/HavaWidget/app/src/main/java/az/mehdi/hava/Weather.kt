package az.mehdi.hava

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.roundToInt

val BAKU: ZoneId = ZoneId.of("Asia/Baku")
private val HOUR_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH")

data class Hour(val time: String, val temp: Double, val code: Int, val prob: Int, val wind: Double, val feels: Double = Double.NaN, val uv: Double = Double.NaN, val dir: Double = Double.NaN, val hum: Double = Double.NaN, val mm: Double = 0.0, val snow: Double = 0.0, val press: Double = Double.NaN, val vis: Double = Double.NaN, val dew: Double = Double.NaN, val gust: Double = Double.NaN)
data class Day(val date: String, val code: Int, val max: Double, val min: Double, val prob: Int, val wind: Double, val sunrise: String = "", val sunset: String = "", val uvMax: Double = Double.NaN, val precipH: Int = -1, val dir: Double = Double.NaN, val mm: Double = 0.0, val snow: Double = 0.0, val gust: Double = Double.NaN) {
    /** Widgetdə çərçivə üçün: "qar" (ağ), "yağış" (göy), "külək" (boz) — heç biri yoxdursa null. Üstünlük: qar > yağış > külək */
    fun frameKind(): String? = when {
        code in 71..77 || code == 85 || code == 86 -> "qar"
        code in 51..67 || code in 80..82 || code >= 95 || prob >= 70 -> "yağış"
        wind >= 40 -> "külək"
        else -> null
    }
}
data class Aqi(val us: Int, val pm25: Double, val pm10: Double, val dust: Double = Double.NaN)
data class Sea(val wave: Double, val dir: Double, val period: Double, val sst: Double, val max24: Double)
data class M15(val time: String, val mm: Double, val snow: Double)
class RainEp(val start: LocalDateTime, val end: LocalDateTime, val mm: Double, val snow: Double, val ongoing: Boolean, val toEnd: Boolean)
data class Outlook(val text: String, val kind: String?, val inHours: Int, val ongoing: Boolean, val key: String)

data class Weather(val hours: List<Hour>, val days: List<Day>, val aqi: Aqi? = null, val m15: List<M15> = emptyList(), val sea: Sea? = null) {

    private fun isPrecip(code: Int) = code in 51..67 || code in 71..77 || code in 80..86 || code >= 95

    /** Günün neçə saatında yağıntı (yağış/qar) olacaq */
    fun precipHours(d: Day): Int =
        if (d.precipH >= 0) d.precipH else hours.count { it.time.startsWith(d.date) && isPrecip(it.code) }

    fun nowIndex(): Int {
        val k = LocalDateTime.now(BAKU).format(HOUR_FMT)
        return hours.indexOfFirst { it.time.startsWith(k) }
    }

    fun upcomingDays(): List<Day> {
        val t = LocalDate.now(BAKU).toString()
        return days.filter { it.date >= t }.take(8)
    }

    /** yağış / qar / tufan / külək — yoxdursa null */
    fun kindOf(h: Hour, lenient: Boolean): String? = when {
        h.code >= 95 -> "tufan"
        h.code in 71..77 || h.code == 85 || h.code == 86 -> "qar"
        h.code in 51..67 || h.code in 80..82 -> "yağış"
        lenient && h.prob >= 70 -> "yağış"
        h.wind >= 40 -> "külək"
        else -> null
    }

    /** "saat 14:00" (sabahdırsa "sabah saat 02:00"); cap=true olanda cümlə əvvəli üçün böyük hərflə */
    private fun at(i: Int, cap: Boolean = false): String {
        val t = hours[i].time
        val tomorrow = t.take(10) != LocalDate.now(BAKU).toString()
        val hhmm = t.substring(11, 16)
        val pre = if (tomorrow) (if (cap) "Sabah saat" else "sabah saat") else (if (cap) "Saat" else "saat")
        return "$pre $hhmm"
    }

    private fun tempNote(n: Int): String {
        if (n + 3 >= hours.size) return ""
        val d = (hours[n + 3].temp - hours[n].temp).roundToInt()
        if (abs(d) < 3) return ""
        val sign = if (d > 0) "+" else ""
        return " ${at(n + 3, true)}-da hava ${if (d > 0) "isinəcək" else "soyuyacaq"}: ${hours[n + 3].temp.roundToInt()}° ($sign$d°)."
    }

    /** "saat 14:00" / "sabah saat 02:00" — dəqiqəlik məlumatın vaxtı üçün */
    private fun atTime(t: LocalDateTime, cap: Boolean = false): String {
        val tomorrow = t.toLocalDate() != LocalDate.now(BAKU)
        val pre = if (tomorrow) (if (cap) "Sabah saat" else "sabah saat") else (if (cap) "Saat" else "saat")
        return "$pre ${t.format(DateTimeFormatter.ofPattern("HH:mm"))}"
    }

    /** 15 dəqiqəlik məlumat var və gələcəyi əhatə edir */
    private fun m15Ok(): Boolean {
        if (m15.isEmpty()) return false
        val lastT = try { LocalDateTime.parse(m15.last().time) } catch (e: Exception) { return false }
        return lastT.isAfter(LocalDateTime.now(BAKU))
    }

    fun outlook(): Outlook? {
        val n = nowIndex()
        if (n < 0) return null
        val limit = minOf(24, hours.size - 1 - n)
        val note = tempNote(n)
        val now = LocalDateTime.now(BAKU)
        // Yağış/qar vaxtları 15 dəqiqəlik məlumatdan götürülür ki, göy mətnlə (dəqiq yağıntı) üst-üstə düşsün
        val useP = m15Ok()
        val ep = if (useP) rainEpisodes().firstOrNull() else null
        fun kd(h: Hour, lenient: Boolean): String? =
            if (!useP) kindOf(h, lenient) else when {
                h.code >= 95 -> "tufan"
                h.wind >= 40 -> "külək"
                else -> null
            }

        val cur = kd(hours[n], false)
        if (ep != null && ep.ongoing && cur != "tufan") {
            val k = if (ep.snow >= 0.1) "qar" else "yağış"
            val t = if (ep.toEnd) "${T.now(k)}, növbəti 24 saat davam edəcək." else "${T.now(k)}, ${atTime(ep.end)}-da ${T.end(k)}."
            val tm = hours[n].time
            return Outlook(t + note, k, 0, true, "$k@now@${tm.take(10)}-${tm.substring(11, 13).toInt() / 6}")
        }
        if (cur != null) {
            val k = (1..limit).firstOrNull { kd(hours[n + it], false) != cur }
            val t = if (k != null) "${T.now(cur)}, ${at(n + k)}-da ${T.end(cur)}." else "${T.now(cur)}, növbəti 24 saat davam edəcək."
            val tm = hours[n].time
            return Outlook(t + note, cur, 0, true, "$cur@now@${tm.take(10)}-${tm.substring(11, 13).toInt() / 6}")
        }
        val k = (1..limit).firstOrNull { kd(hours[n + it], true) != null }
        val kTime = k?.let { try { LocalDateTime.parse(hours[n + it].time) } catch (e: Exception) { null } }
        if (ep != null && !ep.ongoing && (k == null || kTime == null || !kTime.isBefore(ep.start))) {
            val kp = if (ep.snow >= 0.1) "qar" else "yağış"
            val endTxt = if (ep.toEnd) "" else ", ${atTime(ep.end)}-da ${T.end(kp)}"
            val inH = (java.time.Duration.between(now, ep.start).toMinutes() / 60).toInt().coerceAtLeast(0)
            return Outlook("${atTime(ep.start, true)}-da ${T.future(kp)}$endTxt.$note", kp, inH, false, "$kp@${ep.start}")
        }
        if (k != null) {
            val kk = kd(hours[n + k], true)!!
            val e = (k + 1..limit).firstOrNull { kd(hours[n + it], true) != kk }
            val endTxt = if (e != null) ", ${at(n + e)}-da ${T.end(kk)}" else ""
            return Outlook("${at(n + k, true)}-da ${T.future(kk)}$endTxt.$note", kk, k, false, "$kk@${hours[n + k].time}")
        }
        return Outlook("Növbəti 24 saat ərzində yağış, qar və tufan gözlənilmir.$note", null, 99, false, "none")
    }

    /** 15 dəqiqəlik məlumatdan yağıntı/qar epizodları (indidən sonrakı) */
    fun rainEpisodes(): List<RainEp> {
        if (m15.isEmpty()) return emptyList()
        val now = LocalDateTime.now(BAKU)
        val slots = try {
            m15.map { Triple(LocalDateTime.parse(it.time), it.mm, it.snow) }.filter { it.first.isAfter(now) }
        } catch (e: Exception) { return emptyList() }
        fun wet(t: Triple<LocalDateTime, Double, Double>) = t.second >= 0.1 || t.third >= 0.1
        val out = ArrayList<RainEp>()
        var i = 0
        while (i < slots.size) {
            if (wet(slots[i])) {
                var j = i
                while (j + 1 < slots.size && wet(slots[j + 1])) j++
                out.add(RainEp(slots[i].first.minusMinutes(15), slots[j].first,
                    (i..j).sumOf { slots[it].second }, (i..j).sumOf { slots[it].third }, i == 0, j == slots.size - 1))
                i = j + 1
            } else i++
        }
        return out
    }

    /** 15 dəqiqəlik məlumatla dəqiq yağıntı mətni (növbəti 24 saat); məlumat yoxdursa null */
    fun preciseRain(): String? {
        if (m15.isEmpty()) return null
        val now = LocalDateTime.now(BAKU)
        val lastT = try { LocalDateTime.parse(m15.last().time) } catch (e: Exception) { return null }
        if (!lastT.isAfter(now)) return null
        val e = rainEpisodes().firstOrNull() ?: return "Növbəti 24 saat ərzində yağıntı gözlənilmir."
        val what = if (e.snow >= 0.1) "Qar" else "Yağıntı"
        val amt = "${fmtPrecip(e.mm, e.snow)} (${precipLabel(e.mm, e.snow)})"
        val hm = DateTimeFormatter.ofPattern("HH:mm")
        if (e.ongoing) {
            if (e.toEnd) return "$what davam edir və növbəti 24 saat dayanmayacaq (≈ $amt)."
            val left = java.time.Duration.between(now, e.end).toMinutes()
            return "$what davam edir, ${datText(durText(left))} dayanacaq (${e.end.format(hm)}).\nQalan miqdar ≈ $amt"
        }
        val startMin = java.time.Duration.between(now, e.start).toMinutes()
        val head = if (startMin <= 0) "$what indi başlayır" else "$what ${datText(durText(startMin))} başlayacaq (${e.start.format(hm)})"
        val lenMin = java.time.Duration.between(e.start, e.end).toMinutes()
        val tail = if (e.toEnd) "növbəti saatlarda dayanmayacaq" else "təxminən ${durText(lenMin)} davam edəcək (${e.end.format(hm)}-dək)"
        return "$head, $tail.\nMiqdar ≈ $amt"
    }

    /** Növbəti 24 saatda ən güclü ani külək; məlumat yoxdursa null */
    fun gustNote(): String? {
        val n = nowIndex()
        if (n < 0) return null
        val limit = minOf(24, hours.size - 1 - n)
        var best = -1
        var bv = -1.0
        for (k in 0..limit) {
            val g = hours[n + k].gust
            if (!g.isNaN() && g > bv) { bv = g; best = k }
        }
        if (best < 0) return null
        val when_ = if (best == 0) "indi" else at(n + best)
        return "Növbəti 24 saatda ən güclü ani külək: ${bv.roundToInt()} km/s (${gustLevel(bv)}), $when_${if (best == 0) "" else "-da"}."
    }

    /** Duman: indi və ya növbəti 24 saatda (kod 45/48 və ya görünmə < 1 km); yoxdursa null */
    fun fogNote(): String? {
        val n = nowIndex()
        if (n < 0) return null
        val limit = minOf(24, hours.size - 1 - n)
        fun fog(h: Hour) = h.code == 45 || h.code == 48 || (!h.vis.isNaN() && h.vis < 1000)
        if (fog(hours[n])) {
            val k = (1..limit).firstOrNull { !fog(hours[n + it]) }
            return if (k != null) "Hazırda duman var, ${at(n + k)}-da dağılacaq." else "Hazırda duman var, növbəti 24 saat davam edə bilər."
        }
        val k = (1..limit).firstOrNull { fog(hours[n + it]) } ?: return null
        val e = (k + 1..limit).firstOrNull { !fog(hours[n + it]) }
        val minVis = (k..(e ?: (limit + 1)) - 1).map { hours[n + it].vis }.filter { !it.isNaN() }.minOrNull()
        val vt = if (minVis != null) ", görünmə ~${visText(minVis)}" else ""
        val et = if (e != null) ", ${at(n + e)}-da dağılacaq" else ""
        return "${at(n + k, true)}-da duman gözlənilir$vt$et."
    }

    private fun today(): Day? = days.firstOrNull { it.date == LocalDate.now(BAKU).toString() }

    private fun sunParts(): List<Pair<String, String>> {
        val d = today()
        val out = ArrayList<Pair<String, String>>()
        if (d != null && d.sunrise.length >= 16) out.add("sunrise" to d.sunrise.substring(11, 16))
        if (d != null && d.sunset.length >= 16) out.add("sunset" to d.sunset.substring(11, 16))
        return out
    }

    /** Tətbiq üçün: (ikon adı, mətn) siyahısı */
    fun infoParts(n: Int): List<Pair<String, CharSequence>> {
        val h = hours[n]
        val out = ArrayList<Pair<String, CharSequence>>()
        if (!h.feels.isNaN()) out.add("thermo" to "Hiss ${h.feels.roundToInt()}°")
        out.add("wind" to WindInfo.label(h.wind, h.dir))
        if (!h.gust.isNaN()) out.add("wind" to "Ani külək: ${h.gust.roundToInt()} km/s (${gustLevel(h.gust)})")
        if (!h.uv.isNaN()) {
            val mx = today()?.uvMax
            val tail = if (mx != null && !mx.isNaN()) " · bu gün maks. ${mx.roundToInt()}" else ""
            out.add("clear" to "UV ${h.uv.roundToInt()} (${T.uvLevel(h.uv)})$tail")
        }
        aqi?.let { out.add("leaf" to "Hava keyfiyyəti: ${T.aqiLevel(it.us)}") }
        aqi?.let { if (!it.dust.isNaN()) out.add("warn" to "Toz: ${it.dust.roundToInt()} µg/m³ (${dustLevel(it.dust)})") }
        if (!h.press.isNaN()) {
            val now = h.press * 0.750062
            var t = "Təzyiq: ${now.roundToInt()} mm civə sütunu"
            if (n + 3 < hours.size && !hours[n + 3].press.isNaN()) {
                val d = (hours[n + 3].press - h.press) * 0.750062
                t += when {
                    d <= -3 -> " · sürətlə düşür (hava dəyişkənliyi ola bilər)"
                    d <= -1 -> " · düşür"
                    d >= 3 -> " · sürətlə artır"
                    d >= 1 -> " · artır"
                    else -> " · sabit"
                }
            }
            out.add("cloud" to t)
        }
        if (!h.hum.isNaN()) out.add("drop" to "Rütubət: ${h.hum.roundToInt()}% (${humLevel(h.hum)})")
        if (!h.dew.isNaN()) out.add("drizzle" to "Şeh nöqtəsi: ${h.dew.roundToInt()}° (${dewLevel(h.dew)})")
        if (!h.vis.isNaN()) out.add("fog" to "Görünmə: ${visText(h.vis)} (${visLevel(h.vis)})")
        out.addAll(sunParts())
        today()?.let { out.add("clock" to "Bu gün yağıntı: ${precipHours(it)} saat") }
        return out
    }

    /** Widget üçün 3 sıra (hər birində 3): 1) hiss/külək/hava keyfiyyəti  2) gün çıxır/batır/rütubət  3) təzyiq/duman(görünmə)/yağıntı saatı */
    fun widgetInfo(n: Int): List<List<Pair<String, CharSequence>>> {
        val h = hours[n]
        val l1 = ArrayList<Pair<String, CharSequence>>()
        if (!h.feels.isNaN()) l1.add("thermo" to "${h.feels.roundToInt()}°")
        l1.add("wind" to WindInfo.label(h.wind, h.dir))
        aqi?.let { l1.add("leaf" to T.aqiLevel(it.us)) }
        val l2 = ArrayList<Pair<String, CharSequence>>(sunParts())
        if (!h.hum.isNaN()) l2.add("drop" to "${h.hum.roundToInt()}%")
        val l3 = ArrayList<Pair<String, CharSequence>>()
        if (!h.press.isNaN()) l3.add("cloud" to "${(h.press * 0.750062).roundToInt()} mm")
        if (!h.vis.isNaN()) l3.add("fog" to visText(h.vis))
        today()?.let { l3.add("clock" to "${precipHours(it)} saat") }
        return listOf(l1, l2, l3)
    }

    /** Növbəti 3, 6, 9, 12 saat: (saat, hava kodu, temperatur) */
    fun hourItems(n: Int): List<Triple<String, Int, Int>> =
        listOf(3, 6, 9, 12).filter { n + it < hours.size }.map {
            val h = hours[n + it]
            Triple(h.time.substring(11, 16), h.code, h.temp.roundToInt())
        }
}

object T {
    private val AY = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr", "oktyabr", "noyabr", "dekabr")
    private val GUN = listOf("bazar ertəsi", "çərşənbə axşamı", "çərşənbə", "cümə axşamı", "cümə", "şənbə", "bazar")

    /** məs: 7 noyabr 2026, şənbə */
    fun dateLine(): String {
        val d = LocalDate.now(BAKU)
        return "${d.dayOfMonth} ${AY[d.monthValue - 1]} ${d.year}, ${GUN[d.dayOfWeek.value - 1]}"
    }

    /** məs: 8 Noyabr */
    fun dayMonth(): String {
        val d = LocalDate.now(BAKU)
        return "${d.dayOfMonth} ${AY[d.monthValue - 1].replaceFirstChar { it.uppercase() }}"
    }

    /** məs: Bazar */
    fun weekday(): String = GUN[LocalDate.now(BAKU).dayOfWeek.value - 1].replaceFirstChar { it.uppercase() }

    fun desc(c: Int): String = when (c) {
        0 -> "Aydın"
        1 -> "Əsasən aydın"
        2 -> "Az buludlu"
        3 -> "Buludlu"
        45, 48 -> "Dumanlı"
        51, 53, 55 -> "Çiskin"
        56, 57 -> "Dondurucu çiskin"
        61 -> "Yüngül yağış"
        63 -> "Yağış"
        65 -> "Güclü yağış"
        66, 67 -> "Dondurucu yağış"
        71 -> "Yüngül qar"
        73 -> "Qar"
        75 -> "Güclü qar"
        77 -> "Qar dənələri"
        80 -> "Yüngül leysan"
        81 -> "Leysan"
        82 -> "Güclü leysan"
        85, 86 -> "Qar leysanı"
        95 -> "Tufan"
        in 96..99 -> "Dolulu tufan"
        else -> "—"
    }

    /** Hava kodu → res/drawable/ic_<ad>.xml */
    fun iconName(c: Int): String = when (c) {
        0 -> "clear"
        1 -> "mostly"
        2 -> "partly"
        3 -> "cloud"
        45, 48 -> "fog"
        in 51..57 -> "drizzle"
        in 61..67 -> "rain"
        in 71..77 -> "snow"
        in 80..82 -> "rain"
        85, 86 -> "flake"
        in 95..99 -> "storm"
        else -> "thermo"
    }

    /** Xəbərdarlıq növü → ikon adı */
    fun kindIcon(k: String?): String = when (k) {
        "yağış" -> "rain"
        "qar" -> "snow"
        "tufan" -> "storm"
        "külək" -> "wind"
        else -> "check"
    }

    /** Vidcet üçün qısa UV səviyyəsi */
    fun uvWidget(v: Double): String = if (v >= 11) "ekstremal" else uvLevel(v)

    fun uvLevel(v: Double): String = when {
        v < 3 -> "aşağı"
        v < 6 -> "orta"
        v < 8 -> "yüksək"
        v < 11 -> "çox yüksək"
        else -> "həddindən artıq"
    }

    fun aqiLevel(v: Int): String = when {
        v <= 50 -> "yaxşı"
        v <= 100 -> "orta"
        v <= 150 -> "zəif"
        v <= 200 -> "pis"
        v <= 300 -> "çox pis"
        else -> "təhlükəli"
    }

    fun dayName(date: String): String =
        listOf("B.e.", "Ç.a.", "Çər", "C.a.", "Cümə", "Şən", "Baz")[LocalDate.parse(date).dayOfWeek.value - 1]

    fun now(k: String): String = when (k) {
        "yağış" -> "Hazırda yağış yağır"
        "qar" -> "Hazırda qar yağır"
        "tufan" -> "Hazırda tufan var"
        else -> "Hazırda güclü külək əsir"
    }

    fun end(k: String): String = when (k) {
        "yağış" -> "yağış kəsiləcək"
        "qar" -> "qar kəsiləcək"
        "tufan" -> "tufan keçəcək"
        else -> "külək səngiyəcək"
    }

    fun future(k: String): String = when (k) {
        "yağış" -> "yağış yağacaq"
        "qar" -> "qar yağacaq"
        "tufan" -> "tufan olacaq"
        else -> "güclü külək əsəcək"
    }
}

/** Yağıntı miqdarı: 0 → "0 mm", 1-dən az → 1 rəqəm, qalanı tam */
fun fmtMm(v: Double): String {
    val x = if (v.isNaN() || v < 0) 0.0 else v
    return when {
        x < 0.05 -> "0 mm"
        x < 10 -> String.format(java.util.Locale.US, "%.1f mm", x)
        else -> "${Math.round(x)} mm"
    }
}

/** Qar (sm) */
fun fmtSnow(cm: Double): String {
    val x = if (cm.isNaN() || cm < 0) 0.0 else cm
    return if (x < 10) String.format(java.util.Locale.US, "%.1f sm", x) else "${Math.round(x)} sm"
}

fun snowLabel(cm: Double): String = when {
    cm < 0.1 -> "Qar yoxdur"
    cm <= 1 -> "Çox zəif qar"
    cm <= 3 -> "Zəif qar"
    cm <= 7 -> "Mülayim qar"
    cm <= 15 -> "Güclü qar"
    cm <= 30 -> "Çox güclü qar"
    else -> "Həddindən artıq qar"
}

/** Qar varsa sm, yoxsa mm */
fun fmtPrecip(mm: Double, snow: Double): String = if (snow >= 0.1) fmtSnow(snow) else fmtMm(mm)
fun precipLabel(mm: Double, snow: Double): String = if (snow >= 0.1) snowLabel(snow) else mmLabel(mm)
fun precipShort(mm: Double, snow: Double): String = if (snow >= 0.1) (if (snow > 30) "Həddən artıq qar" else snowLabel(snow)) else mmShort(mm)
fun precipAmt(mm: Double, snow: Double): String = if (snow >= 0.1) "${fmtSnow(snow)} qar" else fmtMm(mm)

fun durText(m: Long): String {
    val x = m.coerceAtLeast(1)
    val h = x / 60
    val r = x % 60
    return when {
        h == 0L -> "$r dəqiqə"
        r == 0L -> "$h saat"
        else -> "$h saat $r dəqiqə"
    }
}
fun datText(s: String) = s + (if (s.endsWith("dəqiqə")) "yə" else "a")

fun visText(m: Double): String = when {
    m >= 10000 -> "${(m / 1000).roundToInt()} km"
    m >= 1000 -> String.format(java.util.Locale.US, "%.1f km", m / 1000)
    else -> "${(m / 10).roundToInt() * 10} m"
}
fun visLevel(m: Double): String = when {
    m >= 10000 -> "Yaxşı"
    m >= 5000 -> "Normal"
    m >= 1000 -> "Dumanlıq"
    else -> "Sıx duman"
}
fun gustLevel(g: Double): String = when {
    g < 30 -> "Zəif"
    g < 50 -> "Orta"
    g < 65 -> "Güclü"
    g < 90 -> "Çox güclü"
    else -> "Fırtına gücündə"
}

fun compassName(deg: Double): String {
    if (deg.isNaN()) return "—"
    val names = listOf("Şimal", "Şimal-Şərq", "Şərq", "Cənub-Şərq", "Cənub", "Cənub-Qərb", "Qərb", "Şimal-Qərb")
    return names[(((deg % 360) + 360) % 360 / 45.0 + 0.5).toInt() % 8]
}
fun fmtWave(m: Double): String = String.format(java.util.Locale.US, "%.1f m", m)
fun waveLevel(m: Double): String = when {
    m < 0.1 -> "Sakit"
    m < 0.5 -> "Zəif dalğalı"
    m < 1.25 -> "Mülayim dalğalı"
    m < 2.5 -> "Güclü dalğalı"
    m < 4 -> "Çox dalğalı"
    else -> "Tufan dalğası"
}
fun seaTempLevel(t: Double): String = when {
    t < 12 -> "Çox soyuq"
    t < 16 -> "Soyuq"
    t < 20 -> "Sərin"
    t < 24 -> "Mülayim"
    else -> "İsti"
}

fun humLevel(h: Double): String = when {
    h < 30 -> "Quru"
    h < 60 -> "Normal"
    h < 75 -> "Nəm"
    else -> "Çox nəm"
}
fun dewLevel(d: Double): String = when {
    d < 10 -> "Quru, rahat"
    d < 16 -> "Rahat"
    d < 18 -> "Bir az nəm"
    d < 21 -> "Nəm, yorucu"
    d < 24 -> "Çox nəm, boğucu"
    else -> "Həddindən artıq boğucu"
}
fun dustLevel(d: Double): String = when {
    d < 20 -> "Az"
    d < 50 -> "Orta"
    d < 100 -> "Çox"
    d < 200 -> "Yüksək"
    else -> "Çox yüksək"
}

/** Yağıntı miqdarının izahı (tam) */
fun mmLabel(v: Double): String {
    val x = if (v.isNaN() || v < 0) 0.0 else v
    return when {
        x < 0.05 -> "Yağıntı yoxdur"
        x <= 2 -> "Çox zəif"
        x <= 5 -> "Zəif"
        x <= 10 -> "Mülayim"
        x <= 20 -> "Güclü"
        x <= 50 -> "Çox güclü"
        else -> "Həddindən artıq intensiv"
    }
}

/** Vidcet üçün qısa izah */
fun mmShort(v: Double): String = if (v.isNaN() || v < 0.05) "Yoxdur" else if (v > 50) "Həddindən artıq" else mmLabel(v)

object WeatherApi {
    // Open-Meteo (pulsuz, API açarı lazım deyil); koordinat seçilmiş yerdən (Locations) götürülür.
    // Vaxt zonası həmişə Asia/Baku-dur — bütün saatlar Bakı vaxtı ilə göstərilir.
    private fun ll(p: Place) = "latitude=${p.lat}&longitude=${p.lon}"

    private fun forecastUrl(p: Place) =
        "https://api.open-meteo.com/v1/forecast?" + ll(p) +
        "&hourly=temperature_2m,weather_code,precipitation_probability,wind_speed_10m,apparent_temperature,uv_index,wind_direction_10m,relative_humidity_2m,precipitation,snowfall,pressure_msl,visibility,dew_point_2m,wind_gusts_10m" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset,uv_index_max,precipitation_hours,wind_direction_10m_dominant,precipitation_sum,snowfall_sum,wind_gusts_10m_max" +
        "&minutely_15=precipitation,snowfall&forecast_minutely_15=96&timezone=Asia%2FBaku&forecast_days=8&wind_speed_unit=kmh"

    // Bakı üçün Xəzər (Bakı körfəzi) dəniz nöqtəsi; digər yerlər üçün öz koordinatı (daxili ərazidə məlumat olmur, bölmə gizlənir)
    private fun seaUrl(p: Place): String {
        val pt = if (Locations.isBaku(p)) "latitude=40.33&longitude=49.92" else ll(p)
        return "https://marine-api.open-meteo.com/v1/marine?$pt" +
            "&current=wave_height,wave_direction,wave_period,sea_surface_temperature&hourly=wave_height&forecast_days=2&timezone=Asia%2FBaku"
    }

    private fun aqiUrl(p: Place) =
        "https://air-quality-api.open-meteo.com/v1/air-quality?" + ll(p) +
        "&current=us_aqi,pm2_5,pm10,dust&timezone=Asia%2FBaku"

    private fun download(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun parse(s: String): Weather {
        val o = JSONObject(s)
        val h = o.getJSONObject("hourly")
        val t = h.getJSONArray("time")
        val tt = h.getJSONArray("temperature_2m")
        val tc = h.getJSONArray("weather_code")
        val tp = h.getJSONArray("precipitation_probability")
        val tw = h.getJSONArray("wind_speed_10m")
        val ta = h.optJSONArray("apparent_temperature")
        val tu = h.optJSONArray("uv_index")
        val tdir = h.optJSONArray("wind_direction_10m")
        val thum = h.optJSONArray("relative_humidity_2m")
        val tmm = h.optJSONArray("precipitation")
        val tsn = h.optJSONArray("snowfall")
        val tpr = h.optJSONArray("pressure_msl")
        val tvi = h.optJSONArray("visibility")
        val tdw = h.optJSONArray("dew_point_2m")
        val tgu = h.optJSONArray("wind_gusts_10m")
        val hours = (0 until t.length()).map {
            Hour(t.getString(it), tt.optDouble(it, 0.0), tc.optInt(it), tp.optInt(it), tw.optDouble(it, 0.0),
                ta?.optDouble(it, Double.NaN) ?: Double.NaN,
                tu?.optDouble(it, Double.NaN) ?: Double.NaN,
                tdir?.optDouble(it, Double.NaN) ?: Double.NaN,
                thum?.optDouble(it, Double.NaN) ?: Double.NaN,
                tmm?.optDouble(it, 0.0) ?: 0.0,
                tsn?.optDouble(it, 0.0) ?: 0.0,
                tpr?.optDouble(it, Double.NaN) ?: Double.NaN,
                tvi?.optDouble(it, Double.NaN) ?: Double.NaN,
                tdw?.optDouble(it, Double.NaN) ?: Double.NaN,
                tgu?.optDouble(it, Double.NaN) ?: Double.NaN)
        }
        val d = o.getJSONObject("daily")
        val dt = d.getJSONArray("time")
        val dc = d.getJSONArray("weather_code")
        val dmax = d.getJSONArray("temperature_2m_max")
        val dmin = d.getJSONArray("temperature_2m_min")
        val dp = d.getJSONArray("precipitation_probability_max")
        val dw = d.getJSONArray("wind_speed_10m_max")
        val dsr = d.optJSONArray("sunrise")
        val dss = d.optJSONArray("sunset")
        val dum = d.optJSONArray("uv_index_max")
        val dph = d.optJSONArray("precipitation_hours")
        val ddir = d.optJSONArray("wind_direction_10m_dominant")
        val dmm = d.optJSONArray("precipitation_sum")
        val dsn = d.optJSONArray("snowfall_sum")
        val dgu = d.optJSONArray("wind_gusts_10m_max")
        val days = (0 until dt.length()).map {
            Day(dt.getString(it), dc.optInt(it), dmax.optDouble(it, 0.0), dmin.optDouble(it, 0.0), dp.optInt(it), dw.optDouble(it, 0.0),
                dsr?.optString(it, "") ?: "", dss?.optString(it, "") ?: "",
                dum?.optDouble(it, Double.NaN) ?: Double.NaN,
                if (dph == null || dph.isNull(it)) -1 else Math.round(dph.optDouble(it, -1.0)).toInt(),
                ddir?.optDouble(it, Double.NaN) ?: Double.NaN,
                dmm?.optDouble(it, 0.0) ?: 0.0,
                dsn?.optDouble(it, 0.0) ?: 0.0,
                dgu?.optDouble(it, Double.NaN) ?: Double.NaN)
        }
        val m15 = ArrayList<M15>()
        o.optJSONObject("minutely_15")?.let { m ->
            val mt = m.optJSONArray("time")
            val mp = m.optJSONArray("precipitation")
            val ms = m.optJSONArray("snowfall")
            if (mt != null && mp != null) for (i in 0 until mt.length()) m15.add(M15(mt.getString(i), mp.optDouble(i, 0.0), ms?.optDouble(i, 0.0) ?: 0.0))
        }
        return Weather(hours, days, null, m15)
    }

    fun parseSea(s: String): Sea? = try {
        val o = JSONObject(s)
        val cur = o.getJSONObject("current")
        val wv = cur.optDouble("wave_height", Double.NaN)
        val st = cur.optDouble("sea_surface_temperature", Double.NaN)
        if (wv.isNaN() && st.isNaN()) null
        else {
            var mx = Double.NaN
            val h = o.optJSONObject("hourly")
            val ht = h?.optJSONArray("time")
            val hv = h?.optJSONArray("wave_height")
            val ct = cur.optString("time", "")
            if (ht != null && hv != null && ct.length >= 13) {
                var i = 0
                while (i < ht.length() && !ht.getString(i).startsWith(ct.substring(0, 13))) i++
                var k = i
                while (k < ht.length() && k < i + 24) {
                    val v = hv.optDouble(k, Double.NaN)
                    if (!v.isNaN() && (mx.isNaN() || v > mx)) mx = v
                    k++
                }
            }
            Sea(wv, cur.optDouble("wave_direction", Double.NaN), cur.optDouble("wave_period", Double.NaN), st, mx)
        }
    } catch (e: Exception) {
        null
    }

    private fun prefs(c: Context) = c.getSharedPreferences("hava", Context.MODE_PRIVATE)

    fun parseAqi(s: String): Aqi? = try {
        val cur = JSONObject(s).getJSONObject("current")
        if (cur.isNull("us_aqi")) null
        else Aqi(cur.getInt("us_aqi"), cur.optDouble("pm2_5", 0.0), cur.optDouble("pm10", 0.0), cur.optDouble("dust", Double.NaN))
    } catch (e: Exception) {
        null
    }

    /** Yer dəyişəndə köhnə yerin məlumatı qalmasın deyə keşi təmizləyir */
    fun clearCache(c: Context) {
        prefs(c).edit().remove("json").remove("aqi").remove("sea").remove("ts").apply()
    }

    /** Məlumat yenilənəndə (tətbiqdə də, arxa planda da) qısa bildiriş */
    private fun toast(c: Context, text: String) {
        val app = c.applicationContext
        Handler(Looper.getMainLooper()).post {
            try { Toast.makeText(app, text, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
        }
    }

    fun refresh(c: Context): Weather? = try {
        val loc = Locations.current(c)
        val s = download(forecastUrl(loc))
        var w = parse(s)
        // yükləmə zamanı yer dəyişdirilibsə, köhnə yerin məlumatı yazılmır
        if (Locations.current(c) != loc) throw IllegalStateException("yer dəyişdi")
        prefs(c).edit().putString("json", s).putLong("ts", System.currentTimeMillis()).apply()
        try { RainAlert.schedule(c) } catch (e: Exception) { }
        // AQI ayrıca yüklənir; alınmasa köhnə dəyər qalır, hava yenilənməsi pozulmur
        // AQI və dəniz məlumatı tez dəyişmir: eyni yer üçün 3 saatdan tez-tez yenidən yüklənmir (batareya/trafik)
        val lk = "${loc.lat},${loc.lon}"
        fun stale(k: String): Boolean {
            val pr = prefs(c)
            return pr.getString(k + "_loc", "") != lk || System.currentTimeMillis() - pr.getLong(k + "_ts", 0L) > 3 * 3600_000L
        }
        if (stale("aqi")) try {
            val a = download(aqiUrl(loc))
            if (parseAqi(a) != null && Locations.current(c) == loc)
                prefs(c).edit().putString("aqi", a).putString("aqi_loc", lk).putLong("aqi_ts", System.currentTimeMillis()).apply()
        } catch (e: Exception) {
        }
        if (stale("sea")) try {
            val sj = download(seaUrl(loc))
            if (Locations.current(c) == loc) {
                if (parseSea(sj) != null) prefs(c).edit().putString("sea", sj).apply()
                else prefs(c).edit().remove("sea").apply()
                prefs(c).edit().putString("sea_loc", lk).putLong("sea_ts", System.currentTimeMillis()).apply()
            }
        } catch (e: Exception) {
        }
        w = w.copy(aqi = prefs(c).getString("aqi", null)?.let { parseAqi(it) }, sea = prefs(c).getString("sea", null)?.let { parseSea(it) })
        // proqnoz yoxlaması: sabahın proqnozu saxlanır, keçmiş günlərin real dəyəri müqayisə üçün yüklənir
        try { Verify.record(c, w, loc); Verify.fetchActual(c, loc) } catch (e: Exception) { }
        toast(c, "Məlumat yeniləndi · ${LocalDateTime.now(BAKU).format(DateTimeFormatter.ofPattern("HH:mm"))}")
        w
    } catch (e: Exception) {
        null
    }

    fun cached(c: Context): Weather? =
        prefs(c).getString("json", null)?.let {
            try { parse(it).copy(aqi = prefs(c).getString("aqi", null)?.let { a -> parseAqi(a) }, sea = prefs(c).getString("sea", null)?.let { a -> parseSea(a) }) } catch (e: Exception) { null }
        }

    fun ageMin(c: Context): Long {
        val ts = prefs(c).getLong("ts", 0L)
        return if (ts == 0L) Long.MAX_VALUE else (System.currentTimeMillis() - ts) / 60000
    }
}
