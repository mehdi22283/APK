package az.mehdi.hava

import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

data class Place(val name: String, val lat: Double, val lon: Double, val gps: Boolean)

/** Saxlanmış yerlər siyahısı (Bakı həmişə ilk standart yerdir), seçilmiş yer, GPS ilə cari yerin tapılması */
object Locations {
    val BAKI = Place("Bakı", 40.427565, 49.822425, false)
    private const val MAX = 10

    private fun p(c: Context) = c.getSharedPreferences("places", Context.MODE_PRIVATE)

    fun all(c: Context): List<Place> {
        val s = p(c).getString("list", null) ?: return listOf(BAKI)
        val out = ArrayList<Place>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Place(o.getString("n"), o.getDouble("la"), o.getDouble("lo"), o.optBoolean("g", false)))
            }
        } catch (e: Exception) { }
        return if (out.isEmpty()) listOf(BAKI) else out
    }

    private fun save(c: Context, list: List<Place>, sel: Int) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("n", it.name).put("la", it.lat).put("lo", it.lon).put("g", it.gps)) }
        p(c).edit().putString("list", a.toString()).putInt("sel", sel).apply()
    }

    fun selected(c: Context): Int = p(c).getInt("sel", 0).coerceIn(0, all(c).size - 1)

    fun current(c: Context): Place = all(c)[selected(c)]

    fun isBaku(pl: Place) = abs(pl.lat - BAKI.lat) < 0.2 && abs(pl.lon - BAKI.lon) < 0.2

    fun select(c: Context, idx: Int): Boolean {
        val l = all(c)
        if (idx !in l.indices || idx == selected(c)) return false
        save(c, l, idx)
        return true
    }

    /** Yeni yer əlavə edir və seçir; eyni yerə (~1 km) təkrar GPS əlavəsi köhnəni yeniləyir */
    fun add(c: Context, pl: Place) {
        val l = all(c).toMutableList()
        val same = l.indexOfFirst { abs(it.lat - pl.lat) < 0.01 && abs(it.lon - pl.lon) < 0.01 }
        val idx: Int
        if (same >= 0) {
            l[same] = pl
            idx = same
        } else {
            if (l.size >= MAX) l.removeAt(l.indexOfFirst { it.gps }.takeIf { it >= 0 } ?: (l.size - 1))
            l.add(pl)
            idx = l.size - 1
        }
        save(c, l, idx)
    }

    /** Yeri silir. Sonuncu yer silinmir. Seçilmiş yer dəyişibsə true qaytarır */
    fun remove(c: Context, idx: Int): Boolean {
        val l = all(c).toMutableList()
        if (l.size <= 1 || idx !in l.indices) return false
        val sel = selected(c)
        l.removeAt(idx)
        val ns = when {
            idx < sel -> sel - 1
            idx == sel -> 0
            else -> sel
        }
        save(c, l, ns.coerceIn(0, l.size - 1))
        return idx == sel
    }

    /** GPS/şəbəkə ilə cari yeri tapır (icazə verilməlidir). Nəticə əsas axında qaytarılır; tapılmasa null */
    fun locate(c: Context, cb: (Location?) -> Unit) {
        val lm = c.getSystemService(LocationManager::class.java)
        val providers = try { lm.getProviders(true) } catch (e: Exception) { emptyList<String>() }
        if (providers.isEmpty()) { cb(null); return }
        var done = false
        val ls = ArrayList<LocationListener>()
        fun finish(l: Location?) {
            if (done) return
            done = true
            ls.forEach { try { lm.removeUpdates(it) } catch (e: Exception) { } }
            cb(l)
        }
        providers.filter { it != LocationManager.PASSIVE_PROVIDER }.forEach { pv ->
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) { finish(loc) }
                @Deprecated("köhnə API üçün")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
                override fun onProviderEnabled(provider: String) { }
                override fun onProviderDisabled(provider: String) { }
            }
            try {
                lm.requestLocationUpdates(pv, 0L, 0f, l, Looper.getMainLooper())
                ls.add(l)
            } catch (e: Exception) { }
        }
        // 20 saniyəyə yeni nəticə gəlməsə, ən son məlum yer götürülür
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done) {
                val last = providers.mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
                finish(last)
            }
        }, 20000)
    }

    /** Koordinata görə ad (bloklayır — arxa axında çağırın); tapılmasa koordinat mətni */
    @Suppress("DEPRECATION")
    fun nameFor(c: Context, lat: Double, lon: Double): String {
        try {
            if (Geocoder.isPresent()) {
                val a = Geocoder(c, Locale("az")).getFromLocation(lat, lon, 1)?.firstOrNull()
                val n = a?.subLocality ?: a?.locality ?: a?.subAdminArea ?: a?.adminArea
                if (!n.isNullOrBlank()) return n
            }
        } catch (e: Exception) { }
        return String.format(Locale.US, "Cari yer (%.2f, %.2f)", lat, lon)
    }
}
