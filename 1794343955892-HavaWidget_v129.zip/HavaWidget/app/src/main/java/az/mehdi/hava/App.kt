package az.mehdi.hava

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.SystemClock

class App : Application() {
    @Volatile private var lastScreenRead = 0L

    override fun onCreate() {
        super.onCreate()
        // Ekran yanan / kilid açılan kimi addım sayı dərhal yenilənir (proses canlıdırsa; yoxsa 3 dəqiqəlik siqnal edir)
        try {
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent?) {
                    if (!StepTicker.hasWidget(c)) return
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastScreenRead < 10_000L) return
                    lastScreenRead = now
                    Thread {
                        StepReader.readBlocking(c)
                        WeatherWidget.refreshSteps(c)
                    }.start()
                }
            }
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(r, f)
        } catch (e: Exception) { }
    }
}
