package az.mehdi.hava

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorEventListener2
import android.os.SystemClock
import android.hardware.SensorManager
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Locale

object Steps {
    private fun p(c: Context) = c.getSharedPreferences("steps", Context.MODE_PRIVATE)

    /** Sensor dəyəri (açılışdan bəri addımlar) -> bu günün addımları. Paralel çağırışlar qarışmasın deyə sinxrondur */
    @Synchronized
    fun onSensor(c: Context, raw: Float): Int {
        val p = p(c)
        val today = LocalDate.now(BAKU).toString()
        val prev = p.getString("day", "") ?: ""
        val lastRaw = p.getFloat("lastRaw", -1f)
        var base = p.getFloat("base", raw)
        var offset = p.getInt("offset", 0)
        if (prev != today) {
            // yeni gün: keçən günün cəmini tarixçəyə yaz
            if (prev.isNotEmpty()) saveDay(p, prev, p.getInt("steps", 0))
            if (prev.isNotEmpty() && lastRaw >= 0f && raw >= lastRaw) {
                // son oxunuşdan indiyə qədər olan addımlar yeni günə yazılır (00:00 oxunuşu gecikibsə itməsin)
                base = lastRaw
                offset = 0
            } else {
                // telefon gecə yenidən başlayıb və ya ilk işə düşmə: sensor sıfırdan sayır
                base = if (prev.isNotEmpty()) 0f else raw
                offset = 0
            }
        } else if (lastRaw >= 0f && raw < lastRaw) { // telefon yenidən başladılıb: sensor sıfırlanıb
            offset = p.getInt("steps", 0)
            base = 0f
        }
        val steps = (offset + (raw - base).toInt()).coerceAtLeast(0)
        // dəyişiklik yoxdursa yazma (batareya/yaddaş)
        if (prev == today && p.getInt("steps", -1) == steps && lastRaw == raw) return steps
        p.edit().putString("day", today).putFloat("base", base).putInt("offset", offset)
            .putFloat("lastRaw", raw).putInt("steps", steps).apply()
        return steps
    }

    private fun hist(p: SharedPreferences): JSONObject =
        try { JSONObject(p.getString("hist", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    /** Günün cəmini tarixçəyə yazır (son 60 gün saxlanır) */
    private fun saveDay(p: SharedPreferences, day: String, steps: Int) {
        if (day.isEmpty() || steps < 0) return
        val h = hist(p)
        h.put(day, steps)
        val keys = h.keys().asSequence().sorted().toList()
        if (keys.size > 60) keys.take(keys.size - 60).forEach { h.remove(it) }
        p.edit().putString("hist", h.toString()).apply()
    }

    /** Son 7 gün (köhnədən yeniyə): (tarix, addım). Bu gün canlı dəyərdir; qeyd olunmayan gün 0 */
    fun week(c: Context): List<Pair<String, Int>> {
        val h = hist(p(c))
        val today = LocalDate.now(BAKU)
        return (6 downTo 0).map { i ->
            val ds = today.minusDays(i.toLong()).toString()
            ds to (if (i == 0) get(c) else h.optInt(ds, 0))
        }
    }

    fun get(c: Context): Int {
        val p = p(c)
        return if (p.getString("day", "") == LocalDate.now(BAKU).toString()) p.getInt("steps", 0) else 0
    }

    /** Boy sabitdir: 180 sm */
    @Suppress("UNUSED_PARAMETER")
    fun height(c: Context): Int = 180

    // addım uzunluğu ≈ boy × 0.415
    fun km(c: Context): Double = get(c) * height(c) * 0.415 / 100000.0
    fun kmText(c: Context): String = String.format(Locale.US, "%.2f km", km(c))
    fun stepsText(c: Context): String = String.format(Locale.US, "%,d", get(c)).replace(',', ' ')
}

/**
 * Addımları aparat sayğacı (TYPE_STEP_COUNTER) özü sayır — tətbiq işləməsə də sayır.
 * Ona görə fon xidməti və bildiriş lazım deyil: dəyər yalnız lazım olanda (00:00, tətbiq açılanda,
 * telefon yenidən başlayanda) bir dəfə oxunur və dərhal buraxılır.
 */
object StepReader {
    /**
     * Dəyəri bir dəfə oxuyur (arxa plan thread-dən çağırın). Maks. 3 san. gözləyir.
     * flush() sensorun yaddaşındakı ən son (təzə) dəyəri məcburi çıxarır — köhnə keş dəyəri oxunmur.
     */
    fun readBlocking(c: Context) {
        if (!Scheduler.hasActivityPerm(c)) return
        val sm = c.getSystemService(SensorManager::class.java) ?: return
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return
        val latch = java.util.concurrent.CountDownLatch(1)
        val l = object : SensorEventListener2 {
            override fun onSensorChanged(e: SensorEvent) {
                Steps.onSensor(c, e.values[0])
            }
            override fun onFlushCompleted(sensor: Sensor?) { latch.countDown() }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        try {
            if (sm.registerListener(l, s, SensorManager.SENSOR_DELAY_NORMAL, 0)) {
                val flushed = try { sm.flush(l) } catch (e: Exception) { false }
                // flush dəstəklənmirsə qısa gözlə ki, ilk hadisə gəlsin
                if (flushed) latch.await(3, java.util.concurrent.TimeUnit.SECONDS)
                else Thread.sleep(1200)
            }
        } catch (e: Exception) {
        } finally {
            try { sm.unregisterListener(l) } catch (e: Exception) { }
        }
    }

    /** Tətbiq ekranda olarkən canlı izləmə; geri qaytarılan funksiya izləməni dayandırır */
    fun watch(c: Context, onChange: () -> Unit): () -> Unit {
        if (!Scheduler.hasActivityPerm(c)) return {}
        val sm = c.getSystemService(SensorManager::class.java) ?: return {}
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return {}
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                Steps.onSensor(c, e.values[0])
                onChange()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        try { sm.registerListener(l, s, SensorManager.SENSOR_DELAY_UI, 0) } catch (e: Exception) { return {} }
        return { try { sm.unregisterListener(l) } catch (e: Exception) { } }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.start(c)
        Midnight.schedule(c)
        ChargeAlert.arm(c)
        RainAlert.schedule(c) // keşdəki proqnozdan yağış xəbərdarlığı yenidən qurulsun
        StepTicker.schedule(c)
        WeatherWidget.refresh(c) // yeniləmədən dərhal sonra vidcet köhnə görünüşdə qalmasın
    }
}

/**
 * Vidcetdəki addım sayı canlı yenilənsin deyə: hər 3 dəqiqədən bir (səssiz, oyatmayan) siqnal.
 * ELAPSED_REALTIME (WAKEUP deyil) — ekran sönükkən telefonu oyatmır, batareya işlətmir;
 * ekranı açan kimi vaxtı keçmiş siqnal dərhal işləyir və addım sayı yenilənir.
 */
object StepTicker {
    private const val REQ = 302
    private const val INTERVAL_MS = 3 * 60_000L

    private fun pi(c: Context): PendingIntent =
        PendingIntent.getBroadcast(c, REQ, Intent(c, StepTickReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun hasWidget(c: Context): Boolean = try {
        AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, WeatherWidget::class.java)).isNotEmpty()
    } catch (e: Exception) { false }

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        try {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + INTERVAL_MS, pi(c))
        } catch (e: Exception) { }
    }

    fun cancel(c: Context) {
        try { c.getSystemService(AlarmManager::class.java)?.cancel(pi(c)) } catch (e: Exception) { }
    }
}

class StepTickReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        if (!StepTicker.hasWidget(c)) { StepTicker.cancel(c); return }
        StepTicker.schedule(c) // növbəti dövrə dərhal qurulur (proses ölsə də zəncir qırılmasın)
        val pr = goAsync()
        Thread {
            try {
                StepReader.readBlocking(c)
                WeatherWidget.refreshSteps(c)
            } finally {
                pr.finish()
            }
        }.start()
    }
}
