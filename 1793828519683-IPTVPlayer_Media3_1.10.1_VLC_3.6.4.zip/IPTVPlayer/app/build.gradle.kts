import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "az.mehdi.iptvplayer"
    compileSdk = 36

    defaultConfig {
        applicationId = "az.mehdi.iptvplayer"
        minSdk = 24
        targetSdk = 33
        versionCode = 20
        versionName = "1.19"

        // 2 GB RAM TV box: yalnız 32-bit ARM (arm64 cihazlar da 32-bit tətbiqi açır). APK kiçilir.
        ndk { abiFilters += listOf("armeabi-v7a") }
    }

    buildTypes {
        // Debug imza ilə qalır, amma debuggable söndürülür: TV box-da ART tam optimallaşdırma ilə işləyir.
        debug {
            isDebuggable = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Android 7.1 (API 25) üçün java.time və yeni Java API-lərini uyğunlaşdırır.
        isCoreLibraryDesugaringEnabled = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // java.time API-ləri API 26-dan aşağı Android versiyalarında da işləsin.
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Əsas mühərrik: Media3 ExoPlayer 1.10.1 (compileSdk 36, AGP 8.13 tələb edir). Dəstəklənməyən codec olsa VLC-yə keçilir.
    implementation("androidx.media3:media3-exoplayer:1.10.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.10.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.10.1")
    implementation("androidx.media3:media3-exoplayer-smoothstreaming:1.10.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.10.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.10.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Ehtiyat mühərrik: VLC (libVLC 3.6.4, armeabi-v7a 32-bit daxildir), əvvəl hardware, sonra software.
    implementation("org.videolan.android:libvlc-all:3.6.4")
}
