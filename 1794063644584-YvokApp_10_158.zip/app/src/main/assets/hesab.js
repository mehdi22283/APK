(function(){
  var t=(document.body&&document.body.innerText)||'';
  var lines=t.split('\n').map(function(s){return s.trim();}).filter(function(s){return s.length>0;});
  function find(re){
    for(var i=lines.length-1;i>=0;i--){
      if(re.test(lines[i])){
        var rest=lines[i].replace(re,'').replace(/^[\s:\-–]+/,'').trim();
        if(rest) return rest;
        if(i+1<lines.length && !/^(abonent|yv[öo]k|balans)/i.test(lines[i+1])) return lines[i+1];
      }
    }
    return '';
  }
  var bodyText=(document.body&&document.body.innerText)||'';
  if(!window.__hbBaseLines){
    window.__hbBaseLines={};
    bodyText.split('\n').forEach(function(l){window.__hbBaseLines[l.trim()]=1;});
  }
  if(!window.__tried){
    var btns=document.querySelectorAll('button, input[type=submit], a.btn');
    for(var j=0;j<btns.length;j++){
      var bt=(btns[j].innerText||btns[j].value||'').trim();
      if(/^(davam|yoxla|axtar|sorğu|göstər|növbəti)/i.test(bt) && !btns[j].disabled){
        window.__tried=true; btns[j].click(); break;
      }
    }
  }
  var nf=false;
  if(window.__tried){
    var current=(document.body&&document.body.innerText)||'';
    var ls=current.split('\n');
    for(var k=0;k<ls.length;k++){
      var line=ls[k].trim();
      if(line && !window.__hbBaseLines[line] && /tapılmad[ıi]|tapılmay[ıi]b|mövcud deyil|məlumat yoxdur|düzgün deyil/i.test(line)){nf=true;break;}
    }
  }
  // Vergi sətirləri: sətir adı ("Bələdiyyə torpaq vergisi:Binəqədi bələdiyyəsi"), balans "+24" (0 borc) və ya "-72" (72 borc), sonra "AZN"
  var items=[];
  var sgn=/^([+\-−–])\s*(\d[\d\s.,]*)$/;
  var seen={};
  for(var q=0;q<lines.length;q++){
    var mm=lines[q].match(sgn);
    if(!mm) continue;
    var label='';
    for(var r=q-1;r>=0&&r>=q-4;r--){
      var L=lines[r];
      if(sgn.test(L)||/^azn$/i.test(L)||/^davam/i.test(L)||/^balans$/i.test(L)||/ödəniş xidmətinin/i.test(L)) continue;
      if(/[A-Za-zƏəİıÖöÜüŞşÇçĞğ]{3}/.test(L)){ label=L; break; }
    }
    if(!label) continue;
    label=label.split(':')[0].trim();
    var num=parseFloat(mm[2].replace(/\s+/g,'').replace(',','.'));
    var val=(mm[1]==='+')?0:num;
    var line=label+': '+val+' AZN';
    if(!seen[line]){ seen[line]=1; items.push(line); }
  }
  var balansVal=find(/^balans\b/i);
  if(items.length && !/^[+\-−–]?\s*\d/.test(balansVal)){
    var tot=0; items.forEach(function(x){ var n=x.match(/(\d[\d.]*)\s*AZN$/); if(n) tot+=parseFloat(n[1]); });
    balansVal = tot>0 ? '-'+tot : '+0';   // "-" borc, "+" artıq ödəniş
  }
  return JSON.stringify({
    items:items,
    abonent:find(/^abonent\b/i),
    yvok:find(/^yv[öo]k\b/i),
    balans:balansVal,
    nf:nf
  });
})()
