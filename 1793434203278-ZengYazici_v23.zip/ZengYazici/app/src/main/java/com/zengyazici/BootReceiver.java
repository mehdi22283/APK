package com.zengyazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon yenidən başlayanda yalnız xatırlatma alarmlarını bərpa edir. Yazı xidməti burada başlamır. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try { Notes.rescheduleAll(c); } catch (Throwable e) { RecService.log("Xatırlatmalar: " + e); }
    }
}
