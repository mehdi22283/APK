package com.zengyazici;

import android.content.Context;
import android.content.SharedPreferences;
import io.github.muntashirakon.adb.AdbStream;

/**
 * Qoşulma ardıcıllığı (hər addımın vaxt limiti var, heç nə sonsuz asılı qalmır):
 * 1) 127.0.0.1:5555 (lokal, Wi-Fi-dan asılı deyil)
 * 2) Wireless debugging (mDNS ilə cari port, sonra saxlanmış IP/port)
 * Wireless ilə qoşulandan sonra adbd-yə "tcpip:5555" göndərilir və tətbiq lokal rejimə keçir.
 */
public class Conn {
    public static volatile String mode = "";

    private static void sleep(long ms) { try { Thread.sleep(ms); } catch (Exception e) { } }

    /** m.connect(host, port) çağırışını vaxt limiti ilə icra edir. */
    private static boolean connect(final AdbMgr m, final String host, final int port, long ms) {
        Thread t = new Thread(() -> {
            try { m.connect(host, port); } catch (Throwable e) { RecService.log("connect " + host + ":" + port + " — " + e); }
        });
        t.setDaemon(true);
        t.start();
        try { t.join(ms); } catch (Exception e) { }
        if (t.isAlive()) RecService.log("connect " + host + ":" + port + " — vaxt aşımı (" + ms / 1000 + " san)");
        return m.isConnected();
    }

    private static boolean local(AdbMgr m) {
        boolean ok = connect(m, "127.0.0.1", 5555, 12000);
        if (ok) mode = "lokal";
        return ok;
    }

    /** Wireless qoşulu olanda adbd-ni TCP 5555 rejiminə keçirib lokala qoşulur. */
    private static void upgrade(final AdbMgr m) {
        Thread t = new Thread(() -> {
            try {
                AdbStream s = m.openStream("tcpip:5555");
                sleep(500);
                try { s.close(); } catch (Throwable e) { }
            } catch (Throwable e) {
                RecService.log("tcpip: " + e);
            }
        });
        t.setDaemon(true);
        t.start();
        try { t.join(6000); } catch (Exception e) { }
        sleep(3000);
        try { m.disconnect(); } catch (Throwable e) { }
        for (int i = 0; i < 3; i++) {
            if (local(m)) { RecService.log("Lokal ADB aktiv (127.0.0.1:5555) — Wi-Fi lazım deyil"); return; }
            sleep(1500);
        }
        RecService.log("Lokal rejim alınmadı; Wireless istifadə olunacaq");
    }

    /** Zəng zamanı sürətli yol: yalnız 127.0.0.1:5555 (tcpip ilə açılmış lokal ADB). Wi-Fi və Wireless debugging lazım deyil. */
    public static synchronized void ensureLocal(Context c) throws Exception {
        AdbMgr m = AdbMgr.get(c);
        if (m.isConnected()) return;
        if (connect(m, "127.0.0.1", 5555, 5000)) { mode = "lokal"; return; }
        throw new Exception("Lokal ADB (5555) aktiv deyil");
    }

    public static boolean hasWifi(Context c) {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.Network n = cm.getActiveNetwork();
            android.net.NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            return nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI);
        } catch (Throwable e) { return false; }
    }

    public static synchronized void ensure(Context c) throws Exception {
        AdbMgr m = AdbMgr.get(c);
        if (m.isConnected()) return;
        SharedPreferences p = c.getSharedPreferences("cfg", 0);

        if (local(m)) return;

        String[] f = Nsd.findOnce(c, "_adb-tls-connect._tcp", 4000);
        if (f != null) {
            int fp = Integer.parseInt(f[1]);
            String h0 = f[0].contains(":") ? "127.0.0.1" : f[0];
            for (String host : new String[]{h0, "127.0.0.1"}) {
                if (connect(m, host, fp, 10000)) {
                    SharedPreferences.Editor ed = p.edit().putInt("port", fp);
                    if (host.contains(".") && !host.equals("127.0.0.1")) ed.putString("ip", host);
                    ed.apply();
                    mode = "wireless";
                    upgrade(m);
                    if (!m.isConnected()) reconnectWireless(c, m, host, fp);
                    if (m.isConnected()) return;
                    throw new Exception("ADB qoşulmadı");
                }
            }
        } else {
            RecService.log("mDNS: Wireless debugging xidməti tapılmadı");
        }

        String ip = p.getString("ip", "");
        int port = p.getInt("port", 0);
        if (!ip.isEmpty() && port > 0 && connect(m, ip, port, 10000)) {
            mode = "wireless";
            upgrade(m);
            if (!m.isConnected()) reconnectWireless(c, m, ip, port);
            if (m.isConnected()) return;
        }
        throw new Exception("ADB qoşulmadı. Wireless debugging açıq və cütləşmə edilmiş olmalıdır (lokal rejim üçün bir dəfə).");
    }

    private static void reconnectWireless(Context c, AdbMgr m, String host, int port) {
        String[] f = Nsd.findOnce(c, "_adb-tls-connect._tcp", 3000);
        int p = f != null ? Integer.parseInt(f[1]) : port;
        if (connect(m, host, p, 10000)) mode = "wireless";
    }
}
