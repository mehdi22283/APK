package az.mehdi.hava

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.Locale
import kotlin.math.abs

/**
 * Proqnoz yoxlaması: hər gün "sabah" üçün verilən son proqnoz saxlanır,
 * həmin gün keçəndən sonra Open-Meteo-nun həmin günə dair real (təhlil) məlumatı ilə müqayisə olunur.
 * Yoxlama: maksimum temperatur ±2°, minimum temperatur ±2°, yağış (olub / olmayıb).
 */
object Verify {
    data class Rec(
        val date: String, val fMax: Double, val fMin: Double, val fProb: Int, val fMm: Double,
        val aMax: Double, val aMin: Double, val aMm: Double
    ) {
        val maxOk get() = abs(fMax - aMax) <= 2.0
        val minOk get() = abs(fMin - aMin) <= 2.0
        val fRain get() = fProb >= 50 || fMm >= 1.0
        val aRain get() = aMm >= 0.5
        val rainOk get() = fRain == aRain
        val okCount get() = (if (maxOk) 1 else 0) + (if (minOk) 1 else 0) + (if (rainOk) 1 else 0)
    }

    private const val KEEP = 30
    private fun p(c: Context) = c.getSharedPreferences("verify", Context.MODE_PRIVATE)
    private fun key(pl: Place) = String.format(Locale.US, "%.2f_%.2f", pl.lat, pl.lon)

    private fun load(c: Context, pl: Place): JSONObject =
        try { JSONObject(p(c).getString(key(pl), "{}")!!) } catch (e: Exception) { JSONObject() }

    private fun save(c: Context, pl: Place, o: JSONObject) {
        // yalnız son KEEP gün saxlanır
        val keys = ArrayList<String>()
        o.keys().forEach { keys.add(it) }
        keys.sortDescending()
        keys.drop(KEEP).forEach { o.remove(it) }
        p(c).edit().putString(key(pl), o.toString()).apply()
    }

    /** Sabahın proqnozunu saxlayır (bu günə aid köhnə qeydlər dəyişmir) */
    fun record(c: Context, w: Weather, pl: Place) {
        val tomorrow = LocalDate.now(BAKU).plusDays(1).toString()
        val d = w.days.firstOrNull { it.date == tomorrow } ?: return
        val o = load(c, pl)
        o.put(tomorrow, JSONObject().put("fmax", d.max).put("fmin", d.min).put("fprob", d.prob).put("fmm", d.mm))
        save(c, pl, o)
    }

    /** Keçmiş günlərin real dəyərlərini yükləyir (3 saatda bir dəfədən çox yox) */
    fun fetchActual(c: Context, pl: Place) {
        val pr = p(c)
        if (System.currentTimeMillis() - pr.getLong("ts_" + key(pl), 0L) < 3 * 3600_000L) return
        val u = "https://api.open-meteo.com/v1/forecast?latitude=${pl.lat}&longitude=${pl.lon}" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&past_days=7&forecast_days=1&timezone=Asia%2FBaku"
        val conn = URL(u).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        val s = conn.inputStream.bufferedReader().use { it.readText() }
        val d = JSONObject(s).getJSONObject("daily")
        val t = d.getJSONArray("time")
        val mx = d.getJSONArray("temperature_2m_max")
        val mn = d.getJSONArray("temperature_2m_min")
        val pm = d.getJSONArray("precipitation_sum")
        val today = LocalDate.now(BAKU).toString()
        val o = load(c, pl)
        for (i in 0 until t.length()) {
            val day = t.getString(i)
            if (day >= today || !o.has(day) || mx.isNull(i) || mn.isNull(i)) continue
            o.getJSONObject(day).put("amax", mx.getDouble(i)).put("amin", mn.getDouble(i)).put("amm", if (pm.isNull(i)) 0.0 else pm.getDouble(i))
        }
        save(c, pl, o)
        pr.edit().putLong("ts_" + key(pl), System.currentTimeMillis()).apply()
    }

    /** Real dəyəri məlum olan son günlər (yeni → köhnə) */
    fun results(c: Context, pl: Place, max: Int = 7): List<Rec> {
        val o = load(c, pl)
        val keys = ArrayList<String>()
        o.keys().forEach { keys.add(it) }
        keys.sortDescending()
        return keys.mapNotNull { k ->
            val j = o.getJSONObject(k)
            if (!j.has("amax")) null
            else Rec(k, j.getDouble("fmax"), j.getDouble("fmin"), j.getInt("fprob"), j.getDouble("fmm"),
                j.getDouble("amax"), j.getDouble("amin"), j.getDouble("amm"))
        }.take(max)
    }
}
