package az.mehdi.hava

import android.content.Context
import java.time.LocalDate

/** Günün sözü və atalar sözü — res/raw/gunun_sozu.txt və res/raw/atalar_sozu.txt (hər sətir bir cümlə, 365 sətir) */
object Daily {
    private var words: List<String>? = null
    private var proverbs: List<String>? = null

    private fun load(c: Context, res: Int): List<String> = try {
        c.resources.openRawResource(res).bufferedReader(Charsets.UTF_8).use { r ->
            r.readLines().map { it.trim() }.filter { it.isNotEmpty() }
        }
    } catch (e: Exception) {
        emptyList()
    }

    /** İlin neçənci günüdür (Bakı vaxtı ilə), 0-dan başlayır */
    private fun index(size: Int): Int {
        if (size == 0) return 0
        return (LocalDate.now(BAKU).dayOfYear - 1) % size
    }

    fun word(c: Context): String {
        val l = words ?: load(c, R.raw.gunun_sozu).also { words = it }
        return if (l.isEmpty()) "" else l[index(l.size)]
    }

    fun proverb(c: Context): String {
        val l = proverbs ?: load(c, R.raw.atalar_sozu).also { proverbs = it }
        return if (l.isEmpty()) "" else l[index(l.size)]
    }
}
