package az.mehdi.hava

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.Duration
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Yağış/qar başlamazdan ~30 dəq əvvəl bildiriş.
 * Yaddaşdakı (keşdəki) 15 dəqiqəlik proqnozdan istifadə edir və AlarmManager ilə qurulur,
 * ona görə internet olmadan da işləyir.
 */
object RainAlert {
    private const val LEAD = 30L

    private fun pending(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 200, Intent(c, RainReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun nextEpisode(c: Context): RainEp? {
        val w = WeatherApi.cached(c) ?: return null
        val done = c.getSharedPreferences("alerts", Context.MODE_PRIVATE).getString("rain_done", "")
        val now = LocalDateTime.now(BAKU)
        return w.rainEpisodes().firstOrNull { !it.ongoing && it.start.isAfter(now) && it.start.toString() != done }
    }

    fun schedule(c: Context) {
        try {
            val am = c.getSystemService(AlarmManager::class.java)
            val ep = nextEpisode(c)
            if (ep == null) {
                am.cancel(pending(c))
                return
            }
            val now = LocalDateTime.now(BAKU)
            var fire = ep.start.minusMinutes(LEAD)
            if (!fire.isAfter(now)) fire = now.plusSeconds(5)
            val ms = fire.atZone(BAKU).toInstant().toEpochMilli()
            val pi = pending(c)
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
                }
            } catch (e: Exception) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
            }
        } catch (e: Exception) {
        }
    }

    fun fire(c: Context) {
        try {
            val ep = nextEpisode(c)
            if (ep != null) {
                val now = LocalDateTime.now(BAKU)
                val mins = Duration.between(now, ep.start).toMinutes()
                if (mins <= LEAD + 5) {
                    val snow = ep.snow >= 0.1
                    val what = if (snow) "Qar" else "Yağıntı"
                    val hm = DateTimeFormatter.ofPattern("HH:mm")
                    val lead = if (mins <= 0) "$what indi başlayır" else "$what ${datText(durText(mins))} başlayacaq (${ep.start.format(hm)})"
                    val len = durText(Duration.between(ep.start, ep.end).toMinutes())
                    val tail = if (ep.toEnd) "uzun müddət davam edə bilər" else "təxminən $len davam edəcək"
                    val advice = if (snow) "İsti geyinin." else "Çətir götürün."
                    Notif.post(c, 14, "alert", if (snow) "Qar başlayır" else "Yağış başlayır",
                        "$lead, $tail. Miqdar ≈ ${fmtPrecip(ep.mm, ep.snow)} — ${precipLabel(ep.mm, ep.snow)}. $advice")
                    c.getSharedPreferences("alerts", Context.MODE_PRIVATE).edit().putString("rain_done", ep.start.toString()).apply()
                }
            }
        } catch (e: Exception) {
        }
        schedule(c)
    }
}

class RainReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        RainAlert.fire(c)
    }
}
