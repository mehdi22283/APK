package az.mehdi.hava

import android.content.Context
import android.os.BatteryManager
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/**
 * Şarj sessiyası: telefon şarja qoşulandan ayrılana qədər.
 * Başlanğıc/son faiz, müddət, əlavə olunan mAh və orta güc saxlanılır.
 * Fon xidməti yoxdur: yeniləmə ChargeAlert yoxlamalarında (şarj zamanı seyrək) və tətbiq açıq olanda baş verir.
 * Ayrılma ən çoxu bir yoxlama aralığı gec bilinir, ona görə bitmə vaxtı "sonuncu dəfə şarjda görünən an"dır.
 */
object ChargeSession {
    private fun p(c: Context) = c.getSharedPreferences("chargesession", Context.MODE_PRIVATE)
    private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
    private val DM_HM: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM HH:mm")

    /** Batareyada qalan yük (mAh), oxuna bilmirsə -1 */
    private fun mah(c: Context): Long = try {
        val v = c.getSystemService(BatteryManager::class.java).getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        if (v > 0) (if (v >= 50_000L) v / 1000 else v) else -1L
    } catch (e: Throwable) { -1L }

    @Synchronized
    fun update(c: Context) {
        try {
            val now = System.currentTimeMillis()
            val sp = p(c)
            val start = sp.getLong("start", 0L)
            if (Battery.pluggedIn(c)) {
                val pct = Battery.percent(c)
                if (start == 0L) {
                    sp.edit()
                        .putLong("start", now).putLong("seen", now)
                        .putInt("start_pct", pct).putInt("end_pct", pct)
                        .putLong("start_mah", mah(c)).putLong("end_mah", mah(c))
                        .putLong("full_at", if (Battery.full(c)) now else 0L)
                        .putFloat("w_sum", 0f).putInt("w_n", 0).putLong("w_at", 0L)
                        .apply()
                    return
                }
                val seen = sp.getLong("seen", now)
                val oldPct = sp.getInt("end_pct", pct)
                val full = Battery.full(c)
                // tez-tez yazmamaq üçün: faiz dəyişməyibsə ən çox 15 saniyədə bir
                if (now - seen < 15_000L && pct == oldPct && !(full && sp.getLong("full_at", 0L) == 0L)) return
                val e = sp.edit().putLong("seen", now)
                if (pct >= 0) e.putInt("end_pct", pct)
                val m = mah(c)
                if (m > 0) e.putLong("end_mah", m)
                if (full && sp.getLong("full_at", 0L) == 0L) e.putLong("full_at", now)
                if (now - sp.getLong("w_at", 0L) >= 20_000L) {
                    Battery.speedW(c)?.let { w ->
                        e.putFloat("w_sum", sp.getFloat("w_sum", 0f) + w.toFloat())
                            .putInt("w_n", sp.getInt("w_n", 0) + 1).putLong("w_at", now)
                    }
                }
                e.apply()
            } else if (start != 0L) {
                // şarjdan ayrılıb: sessiyanı bağla
                val seen = sp.getLong("seen", now)
                val e = sp.edit()
                if (seen - start >= 60_000L) { // 1 dəqiqədən qısa (boş kontakt) sessiyalar yazılmır
                    e.putLong("last_start", start).putLong("last_end", seen)
                        .putInt("last_start_pct", sp.getInt("start_pct", -1)).putInt("last_end_pct", sp.getInt("end_pct", -1))
                        .putLong("last_start_mah", sp.getLong("start_mah", -1L)).putLong("last_end_mah", sp.getLong("end_mah", -1L))
                        .putLong("last_full_at", sp.getLong("full_at", 0L))
                        .putFloat("last_w_sum", sp.getFloat("w_sum", 0f)).putInt("last_w_n", sp.getInt("w_n", 0))
                }
                e.putLong("start", 0L).apply()
            }
        } catch (e: Throwable) { }
    }

    private fun hm(ms: Long): String = Instant.ofEpochMilli(ms).atZone(BAKU).format(HM)

    private fun stamp(ms: Long): String {
        val d = Instant.ofEpochMilli(ms).atZone(BAKU)
        return if (d.toLocalDate() == LocalDate.now(BAKU)) d.format(HM) else d.format(DM_HM)
    }

    private fun detail(sPct: Int, ePct: Int, sMah: Long, eMah: Long, wSum: Float, wN: Int): String {
        val parts = ArrayList<String>()
        if (sPct >= 0 && ePct >= 0) {
            val d = ePct - sPct
            parts.add("$sPct% → $ePct% (" + (if (d >= 0) "+" else "") + d + "%)")
        }
        if (sMah > 0 && eMah > sMah) parts.add("+${eMah - sMah} mAh")
        if (wN > 0) parts.add("orta " + String.format(java.util.Locale.US, "%.1f", wSum / wN) + " W")
        return parts.joinToString(" • ")
    }

    /** Keçən vaxt: dəqiqə ilə; 60-dan çoxdursa saat/dəqiqə də yanında */
    private fun elapsed(ms: Long): String {
        val m = (ms / 60_000L).coerceAtLeast(0L)
        return "⏱ Keçən vaxt: $m dəq" + (if (m >= 60) " (" + durText(m) + ")" else "")
    }

    /** Batareya kartında göstərmək üçün sətirlər: cari sessiya (şarjdadırsa) və ya sonuncu sessiya */
    fun lines(c: Context): List<String> {
        val sp = p(c)
        val now = System.currentTimeMillis()
        val start = sp.getLong("start", 0L)
        val out = ArrayList<String>()
        if (start != 0L && Battery.pluggedIn(c)) {
            val fullAt = sp.getLong("full_at", 0L)
            val endForDur = if (fullAt > 0L) fullAt else now
            out.add("🔌 Şarj sessiyası: " + stamp(start) + (if (fullAt > 0L) " – " + hm(fullAt) + " (tam doldu)" else "-dən"))
            val d = detail(sp.getInt("start_pct", -1), Battery.percent(c).let { if (it >= 0) it else sp.getInt("end_pct", -1) },
                sp.getLong("start_mah", -1L), mah(c).let { if (it > 0) it else sp.getLong("end_mah", -1L) },
                sp.getFloat("w_sum", 0f), sp.getInt("w_n", 0))
            if (d.isNotEmpty()) out.add(d)
            out.add(elapsed(endForDur - start))
            return out
        }
        val ls = sp.getLong("last_start", 0L)
        if (ls == 0L) {
            out.add("🔌 Şarj sessiyası: hələ qeyd yoxdur (şarja qoşulanda başlayır)")
            return out
        }
        val le = sp.getLong("last_end", ls)
        val lf = sp.getLong("last_full_at", 0L)
        val upto = if (lf > 0L) lf else le
        out.add("🔌 Son şarj sessiyası: " + stamp(ls) + " – " + hm(le) + (if (lf > 0L) " (100%-ə: ${hm(lf)})" else ""))
        val d = detail(sp.getInt("last_start_pct", -1), sp.getInt("last_end_pct", -1),
            sp.getLong("last_start_mah", -1L), sp.getLong("last_end_mah", -1L),
            sp.getFloat("last_w_sum", 0f), sp.getInt("last_w_n", 0))
        if (d.isNotEmpty()) out.add(d)
        out.add(elapsed(upto - ls))
        return out
    }
}
