package az.mehdi.hava

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Locale

object Steps {
    private fun p(c: Context) = c.getSharedPreferences("steps", Context.MODE_PRIVATE)

    /** Sensor dəyəri (açılışdan bəri addımlar) -> bu günün addımları */
    fun onSensor(c: Context, raw: Float): Int {
        val p = p(c)
        val today = LocalDate.now(BAKU).toString()
        var base = p.getFloat("base", raw)
        var offset = p.getInt("offset", 0)
        val prev = p.getString("day", "") ?: ""
        if (prev != today) {
            // yeni gün: keçən günün cəmini tarixçəyə yaz (00:00-a yaxın oxunubsa sensor dəyəri, yoxsa sonuncu saxlanmış dəyər)
            if (prev.isNotEmpty()) {
                val nowT = LocalDateTime.now(BAKU)
                val fromRaw = offset + (raw - base).toInt()
                val total = if (nowT.hour == 0 && nowT.minute < 30 && raw >= p.getFloat("lastRaw", raw)) fromRaw else p.getInt("steps", 0)
                saveDay(p, prev, total)
            }
            base = raw
            offset = 0
        } else if (raw < p.getFloat("lastRaw", raw)) { // telefon yenidən başladılıb
            offset = p.getInt("steps", 0)
            base = 0f
        }
        val steps = offset + (raw - base).toInt()
        // dəyişiklik yoxdursa yazma (batareya/yaddaş)
        if (p.getString("day", "") == today && p.getInt("steps", -1) == steps && p.getFloat("lastRaw", -1f) == raw) return steps
        p.edit().putString("day", today).putFloat("base", base).putInt("offset", offset)
            .putFloat("lastRaw", raw).putInt("steps", steps).apply()
        return steps
    }

    private fun hist(p: SharedPreferences): JSONObject =
        try { JSONObject(p.getString("hist", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    /** Günün cəmini tarixçəyə yazır (son 60 gün saxlanır) */
    private fun saveDay(p: SharedPreferences, day: String, steps: Int) {
        if (day.isEmpty() || steps < 0) return
        val h = hist(p)
        h.put(day, steps)
        val keys = h.keys().asSequence().sorted().toList()
        if (keys.size > 60) keys.take(keys.size - 60).forEach { h.remove(it) }
        p.edit().putString("hist", h.toString()).apply()
    }

    /** Son 7 gün (köhnədən yeniyə): (tarix, addım). Bu gün canlı dəyərdir; qeyd olunmayan gün 0 */
    fun week(c: Context): List<Pair<String, Int>> {
        val h = hist(p(c))
        val today = LocalDate.now(BAKU)
        return (6 downTo 0).map { i ->
            val ds = today.minusDays(i.toLong()).toString()
            ds to (if (i == 0) get(c) else h.optInt(ds, 0))
        }
    }

    fun get(c: Context): Int {
        val p = p(c)
        return if (p.getString("day", "") == LocalDate.now(BAKU).toString()) p.getInt("steps", 0) else 0
    }

    /** Boy sabitdir: 180 sm */
    @Suppress("UNUSED_PARAMETER")
    fun height(c: Context): Int = 180

    // addım uzunluğu ≈ boy × 0.415
    fun km(c: Context): Double = get(c) * height(c) * 0.415 / 100000.0
    fun kmText(c: Context): String = String.format(Locale.US, "%.2f km", km(c))
    fun stepsText(c: Context): String = String.format(Locale.US, "%,d", get(c)).replace(',', ' ')
}

/**
 * Addımları aparat sayğacı (TYPE_STEP_COUNTER) özü sayır — tətbiq işləməsə də sayır.
 * Ona görə fon xidməti və bildiriş lazım deyil: dəyər yalnız lazım olanda (00:00, tətbiq açılanda,
 * telefon yenidən başlayanda) bir dəfə oxunur və dərhal buraxılır.
 */
object StepReader {
    /** Dəyəri bir dəfə oxuyur (arxa plan thread-dən çağırın). Maks. 3 san. gözləyir. */
    fun readBlocking(c: Context) {
        if (!Scheduler.hasActivityPerm(c)) return
        val sm = c.getSystemService(SensorManager::class.java) ?: return
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return
        val latch = java.util.concurrent.CountDownLatch(1)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                Steps.onSensor(c, e.values[0])
                latch.countDown()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        try {
            if (sm.registerListener(l, s, SensorManager.SENSOR_DELAY_NORMAL, 0)) latch.await(3, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        } finally {
            try { sm.unregisterListener(l) } catch (e: Exception) { }
        }
    }

    /** Tətbiq ekranda olarkən canlı izləmə; geri qaytarılan funksiya izləməni dayandırır */
    fun watch(c: Context, onChange: () -> Unit): () -> Unit {
        if (!Scheduler.hasActivityPerm(c)) return {}
        val sm = c.getSystemService(SensorManager::class.java) ?: return {}
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return {}
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                Steps.onSensor(c, e.values[0])
                onChange()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        try { sm.registerListener(l, s, SensorManager.SENSOR_DELAY_UI, 0) } catch (e: Exception) { return {} }
        return { try { sm.unregisterListener(l) } catch (e: Exception) { } }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.start(c)
        Midnight.schedule(c)
        ChargeAlert.arm(c)
        RainAlert.schedule(c) // keşdəki proqnozdan yağış xəbərdarlığı yenidən qurulsun
        WeatherWidget.refresh(c) // yeniləmədən dərhal sonra vidcet köhnə görünüşdə qalmasın
    }
}
