package az.mehdi.hava

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.ceil

/** Saatlıq yağıntı (mm) sütun qrafiki. Qar olan saatlar ağ rənglə. */
class PrecipChart(ctx: Context, private val hrs: List<Hour>, private val blue: Int, private val grey: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (150 * d).toInt())
    }

    private fun niceMax(m: Double): Double = when {
        m <= 1.0 -> 1.0
        m <= 2.0 -> 2.0
        m <= 5.0 -> 5.0
        m <= 10.0 -> 10.0
        m <= 20.0 -> 20.0
        else -> ceil(m / 10.0) * 10.0
    }

    private fun fmt(v: Double, mx: Double): String =
        if (mx <= 2.0) String.format(java.util.Locale.US, "%.1f", v) else String.format(java.util.Locale.US, "%.0f", v)

    override fun onDraw(c: Canvas) {
        val n = hrs.size
        if (n == 0) return
        val left = 34 * d
        val right = width - 4 * d
        val top = 16 * d
        val bottom = height - 18 * d
        val mx = niceMax(hrs.maxOf { it.mm })
        p.textSize = 10 * d
        // tor xətləri və ox yazıları
        for (f in listOf(0.0, 0.5, 1.0)) {
            val y = (bottom - (bottom - top) * f).toFloat()
            p.color = Color.argb(60, 255, 255, 255)
            p.strokeWidth = 1f
            c.drawLine(left, y, right, y, p)
            p.color = grey
            p.textAlign = Paint.Align.RIGHT
            c.drawText(fmt(mx * f, mx), left - 4 * d, y + 4 * d, p)
        }
        val slot = (right - left) / n
        val bw = slot * 0.7f
        var peak = 0
        for (i in 0 until n) if (hrs[i].mm > hrs[peak].mm) peak = i
        for (i in 0 until n) {
            val h = hrs[i]
            val x = left + slot * i + (slot - bw) / 2
            if (h.mm > 0) {
                var hg = ((bottom - top) * (h.mm / mx)).toFloat()
                if (hg < 2 * d) hg = 2 * d
                p.color = if (h.snow >= 0.1) Color.parseColor("#ECEFF1") else blue
                c.drawRect(x, bottom - hg, x + bw, bottom, p)
            }
            if (i % 3 == 0) {
                p.color = grey
                p.textAlign = Paint.Align.CENTER
                c.drawText(h.time.substring(11, 13), x + bw / 2, bottom + 13 * d, p)
            }
        }
        if (hrs[peak].mm >= 0.1) {
            val h = hrs[peak]
            val x = left + slot * peak + slot / 2
            val hg = ((bottom - top) * (h.mm / mx)).toFloat().coerceAtLeast(2 * d)
            p.color = Color.WHITE
            p.textAlign = Paint.Align.CENTER
            c.drawText(String.format(java.util.Locale.US, "%.1f", h.mm), x.coerceIn(left + 8 * d, right - 8 * d), bottom - hg - 3 * d, p)
        }
    }
}

/** Son 7 gün addım sütun qrafiki: bu gün parlaq, əvvəlki günlər tünd rənglə */
class StepsChart(ctx: Context, private val days: List<Pair<String, Int>>, private val today: Int, private val past: Int, private val grey: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (160 * d).toInt())
    }

    private fun group(v: Int): String = String.format(java.util.Locale.US, "%,d", v).replace(',', ' ')

    override fun onDraw(c: Canvas) {
        val n = days.size
        if (n == 0) return
        val left = 4 * d
        val right = width - 4 * d
        val top = 20 * d
        val bottom = height - 20 * d
        val mx = (days.maxOf { it.second }.coerceAtLeast(1000)).toDouble()
        val slot = (right - left) / n
        val bw = slot * 0.62f
        p.strokeWidth = 1f
        p.color = Color.argb(60, 255, 255, 255)
        c.drawLine(left, bottom, right, bottom, p)
        p.textSize = 9 * d
        for (i in 0 until n) {
            val (date, v) = days[i]
            val x = left + slot * i + (slot - bw) / 2
            val last = i == n - 1
            if (v > 0) {
                val hg = ((bottom - top) * (v / mx)).toFloat().coerceAtLeast(2 * d)
                p.color = if (last) today else past
                c.drawRect(x, bottom - hg, x + bw, bottom, p)
                p.color = if (last) Color.WHITE else grey
                p.textAlign = Paint.Align.CENTER
                c.drawText(group(v), x + bw / 2, bottom - hg - 4 * d, p)
            }
            p.color = if (last) Color.WHITE else grey
            p.textAlign = Paint.Align.CENTER
            p.textSize = 10 * d
            c.drawText(if (last) "Bu gün" else T.dayName(date), x + bw / 2, bottom + 14 * d, p)
            p.textSize = 9 * d
        }
    }
}
