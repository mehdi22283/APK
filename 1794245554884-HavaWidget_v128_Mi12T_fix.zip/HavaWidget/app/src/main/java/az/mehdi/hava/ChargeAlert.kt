package az.mehdi.hava

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters

/**
 * Telefon 100%-ə çatanda kilidli/ekranı sönülü olanda alarm kimi çalır, açıq olanda yalnız səssiz bildiriş verir. Açıb-bağlamaq olar.
 * Fon xidməti yoxdur: şarja qoşulanda WorkManager bir dəfə oyanır, sonra yalnız seyrək
 * (1-10 dəq) yoxlama siqnalı qurulur və şarj bitəndə/ayrılanda özü dayanır.
 */
object ChargeAlert {
    private fun p(c: Context) = c.getSharedPreferences("chargealert", Context.MODE_PRIVATE)
    fun enabled(c: Context) = p(c).getBoolean("on", true)

    /** Yalnız 100% səsini açır/bağlayır; şarj sessiyası izləməsi (ChargeSession) həmişə işləyir */
    fun setEnabled(c: Context, on: Boolean) {
        p(c).edit().putBoolean("on", on).apply()
        arm(c)
    }

    /** Şarja qoşulanda işə düşəcək bir dəfəlik iş qurur */
    fun arm(c: Context, name: String = "chargewatch") {
        try {
            val req = OneTimeWorkRequestBuilder<ChargeWatchWorker>()
                .setConstraints(Constraints.Builder().setRequiresCharging(true).build()).build()
            WorkManager.getInstance(c).enqueueUniqueWork(name, ExistingWorkPolicy.KEEP, req)
        } catch (e: Exception) { }
    }

    private fun pending(c: Context): PendingIntent =
        PendingIntent.getBroadcast(c, 300, Intent(c, ChargeReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun cancelAlarm(c: Context) {
        try { c.getSystemService(AlarmManager::class.java).cancel(pending(c)) } catch (e: Exception) { }
    }

    private fun schedule(c: Context, ms: Long) {
        try {
            c.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + ms, pending(c))
        } catch (e: Exception) { }
    }

    /** viaWorker: iş özü işləyərkən yenisini eyni adla qurmaq olmur, ona görə ikinci ad işlədilir */
    fun check(c: Context, viaWorker: Boolean = false) {
        ChargeSession.update(c) // şarj sessiyası: başlanğıc / gedişat / bitmə
        val pr = p(c)
        if (!Battery.pluggedIn(c)) {
            // şarjdan ayrılıb: yeni şarj sessiyasını gözlə
            pr.edit().putBoolean("played", false).apply()
            cancelAlarm(c)
            arm(c, if (viaWorker) "chargewatch_b" else "chargewatch")
            return
        }
        if (Battery.full(c)) {
            if (!pr.getBoolean("played", false)) {
                pr.edit().putBoolean("played", true).apply()
                if (enabled(c)) { if (locked(c)) play(c) else notifyOnly(c) } // açıqdırsa: yalnız səssiz bildiriş
                schedule(c, 10 * 60_000L) // ayrılıb-ayrılmadığını seyrək yoxla
            } else {
                schedule(c, 10 * 60_000L)
            }
        } else {
            if (Battery.percent(c) in 0..97) pr.edit().putBoolean("played", false).apply() // yeni sessiya
            val rem = Battery.remainingMs(c)
            val wait = if (rem != null && rem > 0) (rem / 2).coerceIn(60_000L, 10 * 60_000L) else 3 * 60_000L
            schedule(c, wait)
        }
    }

    /** Telefon kilidlidir və ya ekran sönülüdür (açıq istifadədə deyil) */
    private fun locked(c: Context): Boolean = try {
        c.getSystemService(KeyguardManager::class.java).isKeyguardLocked || !c.getSystemService(PowerManager::class.java).isInteractive
    } catch (e: Exception) { true }

    const val ACT_STOP = "az.mehdi.hava.CHARGE_STOP"

    /**
     * Alarm kimi: bildiriş səsi ALARM səs kanalında, təkrarlanaraq (FLAG_INSISTENT) çalır —
     * səssiz rejimdə də eşidilir. Səsi sistem özü çaldığı üçün tətbiq prosesi lazım deyil.
     * 60 saniyədən sonra və ya bildirişə toxunanda/"Dayandır" düyməsində dayanır.
     */
    fun play(c: Context) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val ch = NotificationChannel("full_alarm", "Şarj 100% alarmı", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(uri, attrs)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 500, 300, 500)
            nm.createNotificationChannel(ch)
            val stop = PendingIntent.getBroadcast(c, 301, Intent(c, ChargeReceiver::class.java).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(c, "full_alarm")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Şarj tamamlandı")
                .setContentText("Batareya 100%-dir, şarjı ayıra bilərsiniz.")
                .setCategory(Notification.CATEGORY_ALARM)
                .setContentIntent(Notif.open(c))
                .setDeleteIntent(stop)
                .setAutoCancel(true)
                .setTimeoutAfter(60_000L)
                .addAction(Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), "Dayandır", stop).build())
                .build()
            n.flags = n.flags or Notification.FLAG_INSISTENT
            nm.notify(20, n)
        } catch (e: Exception) { }
    }

    /** Telefon açıq istifadədədir: səssiz, lakin ekranda görünən bildiriş */
    private fun notifyOnly(c: Context) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel("full_info", "Şarj 100% bildirişi", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
            val n = Notification.Builder(c, "full_info")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Şarj tamamlandı")
                .setContentText("Batareya 100%-dir, şarjı ayıra bilərsiniz.")
                .setContentIntent(Notif.open(c))
                .setAutoCancel(true)
                .build()
            nm.notify(20, n)
        } catch (e: Exception) { }
    }

    fun stop(c: Context) {
        try { c.getSystemService(NotificationManager::class.java).cancel(20) } catch (e: Exception) { }
    }
}

class ChargeWatchWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        ChargeAlert.check(applicationContext, viaWorker = true)
        return Result.success()
    }
}

class ChargeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        if (i?.action == ChargeAlert.ACT_STOP) { ChargeAlert.stop(c); return }
        ChargeAlert.check(c)
    }
}
