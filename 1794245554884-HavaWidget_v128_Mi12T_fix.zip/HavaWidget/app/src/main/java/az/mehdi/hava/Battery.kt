package az.mehdi.hava

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import kotlin.math.roundToInt

/** Şarj vəziyyəti: şarjda olub-olmama və 100%-ə qalan vaxt */
object Battery {
    /** Telefon hazırda şarja taxılıdır? */
    fun charging(c: Context): Boolean = try {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        i != null && (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 ||
            i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING)
    } catch (e: Exception) { false }

    /**
     * Vidcetdəki şarj göstəricisi üçün:
     *  null  — göstərmə (şarjda deyil və ya artıq 100%)
     *  -1    — şarjdadır, amma qalan vaxt hələ bilinmir
     *  > 0   — 100%-ə qalan millisaniyə (Androidin computeChargeTimeRemaining dəyəri)
     */
    fun remainingMs(c: Context): Long? {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return null
            val pct = (level * 100f / scale).roundToInt()
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            when {
                status == BatteryManager.BATTERY_STATUS_FULL || (plugged && pct >= 100) -> null
                status == BatteryManager.BATTERY_STATUS_CHARGING || plugged -> {
                    val bm = c.getSystemService(BatteryManager::class.java)
                    var ms = -1L
                    if (Build.VERSION.SDK_INT >= 28) ms = bm.computeChargeTimeRemaining()
                    // yalnız Androidin öz təxmini; vermirsə (-1) vidcetdə "⚡ …" göstərilir
                    if (ms > 0) ms.coerceAtLeast(60_000L) else -1L
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Şarj gücü vatla (təxmini): cari cərəyan × gərginlik. Oxuna bilmirsə null */
    fun speedW(c: Context): Double? {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            val raw = Math.abs(c.getSystemService(BatteryManager::class.java).getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            if (mv <= 0 || raw == 0L) {
                null
            } else {
                // əksər cihazlar mikroamper verir; bəziləri miliamper (kiçik rəqəm) — ona görə yoxlanılır
                val amps = if (raw >= 20_000L) raw / 1_000_000.0 else raw / 1000.0
                amps * mv / 1000.0
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Tətbiqdə yenilə düyməsinin altında göstərmək üçün: iki sətir (güc, 100%-ə qalan dəqiqə). Şarjda deyilsə null */
    fun appLines(c: Context): List<String>? {
        val rem = remainingMs(c) ?: return null
        val out = ArrayList<String>()
        speedW(c)?.let { out.add("⚡ ${String.format(java.util.Locale.US, "%.1f", it)} W") }
        out.add(if (rem > 0) "100%-ə ${(rem / 60000).coerceAtLeast(1)} dəq" else "100%-ə … dəq")
        return out
    }

    private fun sticky(c: Context): Intent? =
        try { c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (e: Exception) { null }

    fun pluggedIn(c: Context): Boolean = (sticky(c)?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0

    fun percent(c: Context): Int {
        val i = sticky(c) ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (l < 0 || sc <= 0) -1 else (l * 100f / sc).roundToInt()
    }

    /** Şarjdadır və 100%-dir */
    fun full(c: Context): Boolean {
        val i = sticky(c) ?: return false
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        return plugged && (i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_FULL || percent(c) >= 100)
    }

    class Health(val status: String, val tempC: Double?, val volt: Double?, val cycles: Int?, val sohPct: Int?, val capMah: Int?)

    /** Batareya sağlamlığı: Androidin verdiyi qədər (bəzi telefonlar faiz və dövr sayını vermir) */
    fun health(c: Context): Health? {
        val i = sticky(c) ?: return null
        val status = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Yaxşı"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Həddindən artıq qızıb"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Sıradan çıxıb"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Gərginlik yüksəkdir"
            BatteryManager.BATTERY_HEALTH_COLD -> "Çox soyuqdur"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Naməlum nasazlıq"
            else -> "Məlum deyil"
        }
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        var cycles: Int? = null
        var soh: Int? = null
        val bm = c.getSystemService(BatteryManager::class.java)
        if (Build.VERSION.SDK_INT >= 34) {
            val cc = i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)
            if (cc > 0) cycles = cc
            try {
                val s = bm.getIntProperty(10) // BATTERY_PROPERTY_STATE_OF_HEALTH (compileSdk 34-də adı görünmür)
                if (s in 1..100) soh = s
            } catch (e: Exception) { }
        }
        // təxmini cari tutum: qalan yük / faiz (20%-dən aşağıda dəqiq deyil)
        var cap: Int? = null
        try {
            val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            val pct = percent(c)
            if (counter > 0 && pct >= 20) {
                val mah = (if (counter >= 50_000L) counter / 1000.0 else counter.toDouble()) * 100.0 / pct
                if (mah in 500.0..30000.0) cap = mah.roundToInt()
            }
        } catch (e: Exception) { }
        return Health(status, if (t == Int.MIN_VALUE) null else t / 10.0, if (mv > 0) mv / 1000.0 else null, cycles, soh, cap)
    }

    /** nowMah: indiki yük (batareyada qalan mAh); fullMah: cari tam tutum (təxmini); designMah: pasport tutumu (oxuna bilmirsə null) */
    class Cap(val nowMah: Int?, val fullMah: Int?, val designMah: Int?) {
        /** cari tam tutum / pasport tutumu, faizlə */
        val healthPct: Int? get() = if (fullMah != null && designMah != null && designMah > 0) (fullMah * 100f / designMah).roundToInt().coerceAtMost(100) else null
    }

    fun capacity(c: Context): Cap {
        var now: Int? = null
        var full: Int? = null
        try {
            val bm = c.getSystemService(BatteryManager::class.java)
            val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            if (counter > 0) {
                val mah = if (counter >= 50_000L) counter / 1000.0 else counter.toDouble()
                now = mah.roundToInt()
                val pct = percent(c)
                if (pct >= 10) {
                    val f = mah * 100.0 / pct
                    if (f in 500.0..30000.0) full = f.roundToInt()
                }
            }
        } catch (e: Exception) { }
        return Cap(now, full, designCapacity(c))
    }

    /** Pasport tutumu: Androidin daxili PowerProfile-dan (bəzi telefonlarda bağlıdır — onda null) */
    private fun designCapacity(c: Context): Int? = try {
        val cls = Class.forName("com.android.internal.os.PowerProfile")
        val pp = cls.getConstructor(Context::class.java).newInstance(c)
        val v = (cls.getMethod("getBatteryCapacity").invoke(pp) as Number).toDouble()
        if (v in 500.0..30000.0) v.roundToInt() else null
    } catch (e: Throwable) { null }

    // ---------- "Real" batareya məlumatları (batareya kartı üçün) ----------
    private fun sysfsLong(vararg paths: String): Long? {
        for (path in paths) {
            try {
                val t = java.io.File(path).readText().trim()
                val v = t.toLongOrNull()
                if (v != null && v > 0) return v
            } catch (e: Throwable) { }
        }
        return null
    }

    private fun toMah(raw: Long): Double = if (raw >= 50_000L) raw / 1000.0 else raw.toDouble()

    /** remainMah: qalan yük; fullMah: real tam tutum; designMah: dizayn (pasport) tutumu */
    class Real(val sysPct: Int, val remainMah: Int?, val fullMah: Int?, val designMah: Int?, val cycles: Int?) {
        val realPct: Double? get() = if (remainMah != null && fullMah != null && fullMah > 0) remainMah * 100.0 / fullMah else null
        val capPct: Double? get() = if (fullMah != null && designMah != null && designMah > 0) fullMah * 100.0 / designMah else null
        val cyclesLeft: Int? get() = cycles?.let { (500 - it).coerceAtLeast(0) }
    }

    fun real(c: Context): Real {
        val pct = percent(c)
        var remain: Int? = null
        try {
            val counter = c.getSystemService(BatteryManager::class.java).getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            if (counter > 0) remain = toMah(counter).roundToInt()
        } catch (e: Exception) { }
        // real tam tutum: əvvəl sistem faylından (dəqiq), olmadıqda qalan yük ÷ faiz
        var full: Int? = sysfsLong("/sys/class/power_supply/battery/charge_full", "/sys/class/power_supply/bms/charge_full")?.let { toMah(it).roundToInt() }
        if (full == null && remain != null && pct >= 10) full = (remain * 100.0 / pct).roundToInt()
        if (full != null && full !in 500..30000) full = null
        var design: Int? = sysfsLong("/sys/class/power_supply/battery/charge_full_design", "/sys/class/power_supply/bms/charge_full_design")?.let { toMah(it).roundToInt() }
        if (design == null) design = designCapacity(c)
        if (design != null && design !in 500..30000) design = null
        var cycles: Int? = sysfsLong("/sys/class/power_supply/battery/cycle_count", "/sys/class/power_supply/bms/cycle_count")?.toInt()
        if (cycles == null && Build.VERSION.SDK_INT >= 34) {
            val cc = sticky(c)?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) ?: -1
            if (cc > 0) cycles = cc
        }
        return Real(pct, remain, full, design, cycles)
    }

    private fun comma(v: Double, d: Int): String = String.format(java.util.Locale.US, "%." + d + "f", v).replace('.', ',')
    fun fmtPct(v: Double): String = comma(v, 1) + "%"

    /** Hər saniyə yenilənən üç sətir: cərəyan • güc, gərginlik, temperatur */
    fun liveText(c: Context): String {
        val i = sticky(c)
        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        var cur = "Cərəyan: —"
        try {
            val raw = Math.abs(c.getSystemService(BatteryManager::class.java).getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            if (raw > 0) {
                val ma = if (raw >= 20_000L) raw / 1000.0 else raw.toDouble()
                cur = "Cərəyan: ${ma.roundToInt()} mA" + if (mv > 0) " • Güc: ${comma(ma / 1000.0 * mv / 1000.0, 2)} W" else ""
            }
        } catch (e: Exception) { }
        return cur + "\n" +
            "Gərginlik: " + (if (mv > 0) "$mv mV" else "—") + "\n" +
            "Temperatur: " + (if (t == Int.MIN_VALUE) "—" else comma(t / 10.0, 1) + "°C")
    }

    /** Android 14+: BATTERY_PROPERTY_MANUFACTURING_DATE=11, BATTERY_PROPERTY_FIRST_USAGE_DATE=12 (epoch) */
    private fun batteryDate(c: Context, id: Int): Long? {
        if (Build.VERSION.SDK_INT < 34) return null
        return try {
            val v = c.getSystemService(BatteryManager::class.java).getLongProperty(id)
            if (v <= 0L || v == Long.MIN_VALUE) null else if (v < 100_000_000_000L) v * 1000L else v
        } catch (e: Exception) { null }
    }
    fun batteryFirstUse(c: Context): Long? = batteryDate(c, 12)
    fun batteryManufactured(c: Context): Long? = batteryDate(c, 11)

    /** Telefonun ilk istifadəsi (təxmini): quraşdırılmış sistem tətbiqlərinin ilk işə düşmə günü (ən çox təkrarlanan gün) */
    fun phoneFirstUse(c: Context): Long? {
        val sp = c.getSharedPreferences("battery", Context.MODE_PRIVATE)
        val cached = sp.getLong("phone_first", 0L)
        if (cached > 0L) return cached
        val res = try {
            val list = c.packageManager.getInstalledPackages(0)
            val min = 1420070400000L // 2015-01-01
            val sys = list.filter { (it.applicationInfo?.flags ?: 0) and android.content.pm.ApplicationInfo.FLAG_SYSTEM != 0 && it.firstInstallTime > min }
            if (sys.size >= 20) {
                sys.groupBy { it.firstInstallTime / 86_400_000L }.maxByOrNull { it.value.size }?.value?.minOf { it.firstInstallTime }
            } else list.filter { it.firstInstallTime > min }.minOfOrNull { it.firstInstallTime }
        } catch (e: Exception) { null }
        if (res != null) sp.edit().putLong("phone_first", res).apply()
        return res
    }

    // ---------- Boşalma proqnozu ----------
    private fun drainPrefs(c: Context) = c.getSharedPreferences("drain", Context.MODE_PRIVATE)

    private fun readSamples(sp: android.content.SharedPreferences): MutableList<Pair<Long, Int>> {
        val out = ArrayList<Pair<Long, Int>>()
        for (part in (sp.getString("s", "") ?: "").split(",")) {
            val a = part.split(":")
            if (a.size == 2) {
                val t = a[0].toLongOrNull(); val v = a[1].toIntOrNull()
                if (t != null && v != null) out.add(t to v)
            }
        }
        return out
    }

    /**
     * Şarjda olmayanda faiz nümunələri yığır (faiz dəyişəndə və ya 5 dəqiqədən bir, son 3 saat).
     * Şarja qoşulanda nümunələr silinir. Tətbiq açıq olanda və vidcet yenilənəndə çağırılır.
     */
    @Synchronized
    fun drainUpdate(c: Context) {
        try {
            val sp = drainPrefs(c)
            if (pluggedIn(c)) { if (!sp.getString("s", "").isNullOrEmpty()) sp.edit().remove("s").apply(); return }
            val pct = percent(c)
            if (pct < 0) return
            val now = System.currentTimeMillis()
            val list = readSamples(sp)
            val last = list.lastOrNull()
            if (last != null && now >= last.first && pct == last.second && now - last.first < 5 * 60_000L) return
            if (last != null && (pct > last.second || now < last.first)) list.clear() // faiz artıb / saat dəyişib: yenidən başla
            list.add(now to pct)
            list.removeAll { now - it.first > 3 * 3_600_000L }
            if (list.isEmpty()) list.add(now to pct)
            sp.edit().putString("s", list.joinToString(",") { "${it.first}:${it.second}" }).apply()
        } catch (e: Throwable) { }
    }

    private fun fmtLeft(hours: Double): String {
        val m = (hours * 60).roundToInt().coerceAtLeast(1)
        val d = m / 1440
        val h = (m % 1440) / 60
        val mm = m % 60
        return when {
            d > 0 -> "$d gün $h saat"
            h > 0 -> "$h saat $mm dəq"
            else -> "$mm dəq"
        }
    }

    /** Sağ sütunda göstərmək üçün: qalan vaxt, təxmini bitmə saatı, sürət (%/saat) */
    fun drainText(c: Context): String {
        val head = "Boşalma proqnozu: "
        if (pluggedIn(c)) return head + "şarjdadır"
        val pct = percent(c)
        if (pct < 0) return head + "—"
        val now = System.currentTimeMillis()
        var rate: Double? = null // %/saat
        val list = readSamples(drainPrefs(c))
        val first = list.firstOrNull()
        if (first != null) {
            val hrs = (now - first.first) / 3_600_000.0
            val drop = first.second - pct
            if (hrs >= 10 / 60.0 && drop >= 2) rate = drop / hrs
        }
        var hoursLeft: Double? = null
        var viaCurrent = false
        if (rate != null && rate > 0.05) {
            hoursLeft = pct / rate
        } else {
            // kifayət qədər nümunə yoxdur: anlıq cərəyanla təxmin
            try {
                val bm = c.getSystemService(BatteryManager::class.java)
                val raw = Math.abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
                val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
                if (raw > 0 && counter > 0) {
                    val ma = if (raw >= 20_000L) raw / 1000.0 else raw.toDouble()
                    hoursLeft = toMah(counter) / ma
                    rate = pct / hoursLeft
                    viaCurrent = true
                }
            } catch (e: Throwable) { }
        }
        if (hoursLeft == null || rate == null || hoursLeft <= 0 || hoursLeft > 24 * 30) return head + "hesablanır… (bir neçə dəqiqə lazımdır)"
        val until = java.time.Instant.ofEpochMilli(now + (hoursLeft * 3_600_000).toLong()).atZone(BAKU)
        val whenTxt = if (until.toLocalDate() == java.time.LocalDate.now(BAKU)) until.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
            else until.format(java.time.format.DateTimeFormatter.ofPattern("dd.MM HH:mm"))
        return head + "~" + fmtLeft(hoursLeft) + " (təxminən $whenTxt-a qədər)\n" +
            "Sürət: " + comma(rate, 1) + "%/saat" + if (viaCurrent) " (anlıq cərəyanla)" else ""
    }

    fun fmtDate(ms: Long): String = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.US).format(java.util.Date(ms))
}
