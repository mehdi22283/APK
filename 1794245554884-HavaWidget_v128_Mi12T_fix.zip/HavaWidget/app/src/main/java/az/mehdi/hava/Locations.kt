package az.mehdi.hava

import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

data class Place(val name: String, val lat: Double, val lon: Double, val gps: Boolean, val main: Boolean = false)

/** Yerlər: əsas məkan (GPS ilə tapılır, ilk standart Bakı), əlavə məkanlar (xəritədən seçilir), seçilmiş yer */
object Locations {
    val BAKI = Place("Bakı", 40.427565, 49.822425, false, true)
    private const val MAX = 10

    private fun p(c: Context) = c.getSharedPreferences("places", Context.MODE_PRIVATE)

    fun all(c: Context): List<Place> {
        val s = p(c).getString("list", null) ?: return listOf(BAKI)
        val out = ArrayList<Place>()
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Place(o.getString("n"), o.getDouble("la"), o.getDouble("lo"), o.optBoolean("g", false), o.optBoolean("m", false)))
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) return listOf(BAKI)
        if (out.none { it.main }) {
            // köhnə versiyadan keçid: ilk GPS olmayan yer əsas məkan sayılır
            val mi = out.indexOfFirst { !it.gps }.takeIf { it >= 0 } ?: 0
            out[mi] = out[mi].copy(main = true, gps = false)
        }
        return out
    }

    private fun save(c: Context, list: List<Place>, sel: Int) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("n", it.name).put("la", it.lat).put("lo", it.lon).put("g", it.gps).put("m", it.main)) }
        p(c).edit().putString("list", a.toString()).putInt("sel", sel).apply()
    }

    fun selected(c: Context): Int = p(c).getInt("sel", 0).coerceIn(0, all(c).size - 1)

    fun current(c: Context): Place = all(c)[selected(c)]

    fun isBaku(pl: Place) = abs(pl.lat - BAKI.lat) < 0.2 && abs(pl.lon - BAKI.lon) < 0.2

    fun select(c: Context, idx: Int): Boolean {
        val l = all(c)
        if (idx !in l.indices || idx == selected(c)) return false
        save(c, l, idx)
        return true
    }

    /** GPS ilə tapılan yer ƏSAS məkan olur (siyahının başında, seçilir); köhnə əsas məkan əvəz olunur */
    fun setMain(c: Context, pl: Place) {
        val l = all(c).toMutableList()
        l.removeAll { it.main || (abs(it.lat - pl.lat) < 0.01 && abs(it.lon - pl.lon) < 0.01) }
        l.add(0, pl.copy(gps = true, main = true))
        while (l.size > MAX) {
            val r = l.indexOfLast { !it.main }
            if (r < 0) break
            l.removeAt(r)
        }
        save(c, l, 0)
    }

    /** Xəritədən seçilən yer ƏLAVƏ məkan kimi əlavə olunur (seçim dəyişmir); eyni yerə (~1 km) təkrar əlavə köhnəni yeniləyir */
    fun add(c: Context, pl: Place) {
        val l = all(c).toMutableList()
        var sel = selected(c)
        val g = pl.copy(gps = false, main = false)
        val same = l.indexOfFirst { abs(it.lat - g.lat) < 0.01 && abs(it.lon - g.lon) < 0.01 }
        if (same >= 0) {
            if (!l[same].main) l[same] = g
            save(c, l, sel)
            return
        }
        if (l.size >= MAX) {
            val r = l.indexOfFirst { !it.main }
            if (r >= 0) {
                l.removeAt(r)
                if (r < sel) sel-- else if (r == sel) sel = l.indexOfFirst { it.main }.coerceAtLeast(0)
            }
        }
        l.add(g)
        save(c, l, sel.coerceIn(0, l.size - 1))
    }

    /** Əlavə yeri silir. Əsas məkan silinmir (yalnız GPS ilə yenilənərək dəyişir). Seçilmiş yer dəyişibsə true qaytarır */
    fun remove(c: Context, idx: Int): Boolean {
        val l = all(c).toMutableList()
        if (l.size <= 1 || idx !in l.indices || l[idx].main) return false
        val sel = selected(c)
        l.removeAt(idx)
        val ns = when {
            idx < sel -> sel - 1
            idx == sel -> l.indexOfFirst { it.main }.coerceAtLeast(0)
            else -> sel
        }
        save(c, l, ns.coerceIn(0, l.size - 1))
        return idx == sel
    }

    /** GPS/şəbəkə ilə cari yeri tapır (icazə verilməlidir). Nəticə əsas axında qaytarılır; tapılmasa null */
    fun locate(c: Context, cb: (Location?) -> Unit) {
        val lm = c.getSystemService(LocationManager::class.java)
        val providers = try { lm.getProviders(true) } catch (e: Exception) { emptyList<String>() }
        if (providers.isEmpty()) { cb(null); return }
        var done = false
        val ls = ArrayList<LocationListener>()
        fun finish(l: Location?) {
            if (done) return
            done = true
            ls.forEach { try { lm.removeUpdates(it) } catch (e: Exception) { } }
            cb(l)
        }
        providers.filter { it != LocationManager.PASSIVE_PROVIDER }.forEach { pv ->
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) { finish(loc) }
                @Deprecated("köhnə API üçün")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
                override fun onProviderEnabled(provider: String) { }
                override fun onProviderDisabled(provider: String) { }
            }
            try {
                lm.requestLocationUpdates(pv, 0L, 0f, l, Looper.getMainLooper())
                ls.add(l)
            } catch (e: Exception) { }
        }
        // 20 saniyəyə yeni nəticə gəlməsə, ən son məlum yer götürülür
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done) {
                val last = providers.mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
                finish(last)
            }
        }, 20000)
    }

    /** Koordinata görə ad (bloklayır — arxa axında çağırın); tapılmasa koordinatsız ümumi ad */
    @Suppress("DEPRECATION")
    fun nameFor(c: Context, lat: Double, lon: Double, fallback: String = "Cari yer"): String {
        try {
            if (Geocoder.isPresent()) {
                val a = Geocoder(c, Locale("az")).getFromLocation(lat, lon, 1)?.firstOrNull()
                val n = a?.subLocality ?: a?.locality ?: a?.subAdminArea ?: a?.adminArea
                if (!n.isNullOrBlank()) return n
            }
        } catch (e: Exception) { }
        return fallback
    }
}
