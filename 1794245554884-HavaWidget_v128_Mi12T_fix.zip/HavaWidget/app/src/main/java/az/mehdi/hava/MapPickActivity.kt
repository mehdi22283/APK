package az.mehdi.hava

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File

/** Xəritədən məkan seçmə (OpenStreetMap, açar tələb etmir). Toxunulan nöqtə əlavə məkan kimi qaytarılır */
class MapPickActivity : Activity() {
    private lateinit var map: MapView
    private lateinit var ok: Button
    private var marker: Marker? = null
    private var picked: GeoPoint? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")

        val root = FrameLayout(this)
        map = MapView(this)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(11.0)
        val cur = Locations.current(this)
        map.controller.setCenter(GeoPoint(cur.lat, cur.lon))
        val recv = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean { place(p); return true }
            override fun longPressHelper(p: GeoPoint): Boolean { place(p); return true }
        }
        map.overlays.add(MapEventsOverlay(recv))
        root.addView(map, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setBackgroundColor(Color.parseColor("#E6000000"))
        bar.setPadding(dp(14), dp(10), dp(14), dp(12))
        val hint = TextView(this)
        hint.text = "Xəritədə məkana toxunun"
        hint.setTextColor(Color.WHITE)
        hint.textSize = 14f
        hint.gravity = Gravity.CENTER
        bar.addView(hint)
        ok = Button(this)
        ok.text = "Bu yeri əlavə məkan et"
        ok.isEnabled = false
        ok.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#1E88E5"))
        bg.cornerRadius = dp(10).toFloat()
        ok.background = bg
        ok.setOnClickListener {
            val p = picked ?: return@setOnClickListener
            setResult(RESULT_OK, Intent().putExtra("lat", p.latitude).putExtra("lon", p.longitude))
            finish()
        }
        bar.addView(ok, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = dp(8) })
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun place(p: GeoPoint) {
        val m = marker ?: Marker(map).also {
            it.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            marker = it
            map.overlays.add(it)
        }
        m.position = p
        picked = p
        ok.isEnabled = true
        map.invalidate()
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { map.onPause(); super.onPause() }
    override fun onDestroy() { map.onDetach(); super.onDestroy() }
}
