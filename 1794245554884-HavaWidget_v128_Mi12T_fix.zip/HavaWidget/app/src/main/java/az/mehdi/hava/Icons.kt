package az.mehdi.hava

import android.content.Context

/** Tətbiqin öz vektor ikonları. Kiçik variant yoxdursa, standart ikon istifadə olunur. */
object Ic {
    fun id(c: Context, name: String, size: String = ""): Int {
        val sizedName = "ic_" + name + if (size.isEmpty()) "" else "_" + size
        val sized = c.resources.getIdentifier(sizedName, "drawable", c.packageName)
        if (sized != 0) return sized
        return c.resources.getIdentifier("ic_$name", "drawable", c.packageName)
    }
}
