package az.mehdi.iptvplayer

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build

/**
 * Cihazın öz (MediaCodec) dekoderləri bu codec-i dəstəkləyirmi? FFmpeg nəzərə alınmır.
 * Video üçün hardware-accelerated dekoder tələb olunur, səs üçün istənilən cihaz dekoderi kifayətdir.
 * Nəticələr mime üzrə keşlənir.
 */
object CodecSupport {
    private val videoCache = HashMap<String, Boolean>()
    private val audioCache = HashMap<String, Boolean>()

    private fun decoders(mime: String): List<MediaCodecInfo> = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
            !info.isEncoder && info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
        }
    }.getOrDefault(emptyList())

    private fun isHardware(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= 29) return info.isHardwareAccelerated && !info.isSoftwareOnly
        val n = info.name.lowercase()
        return !(n.startsWith("omx.google.") || n.startsWith("c2.android.") || n.startsWith("c2.google.") || n.contains(".sw."))
    }

    fun hasHardwareVideo(mime: String): Boolean = videoCache.getOrPut(mime.lowercase()) { decoders(mime).any { isHardware(it) } }

    fun hasDeviceAudio(mime: String): Boolean = audioCache.getOrPut(mime.lowercase()) { decoders(mime).isNotEmpty() }
}
