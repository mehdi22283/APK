package az.mehdi.iptvplayer

import android.content.Context
import java.security.MessageDigest

/**
 * Kanalın hansı dekoder rejimində təmiz oynadığını yadda saxlayır (kanal linki → rejim).
 * Çık-çık səs / donan görüntü bir dəfə həll olunandan sonra kanal növbəti dəfə birbaşa düzgün rejimlə açılır.
 * Yalnız UI thread-i. Açar linkin qısa MD5-idir; ehtiyat (yoda.az tokenli) linklər saxlanmır.
 */
enum class DecoderMode(val code: Char) {
    /** Cihazın MediaCodec dekoderləri; dəstəkləmədikdə FFmpeg. */
    NORMAL('n'),
    /** Səs FFmpeg (proqram) dekoderi ilə, video MediaCodec ilə. Səsdəki çık-çıkı həll edir. */
    AUDIO_FFMPEG('a'),
    /** Hardware dekoderlər, amma tunneled playback OLMADAN (TV-də bəzi AVC/AAC yayımları tunneling ilə donur/açılmır). */
    NO_TUNNEL('t'),
    /** Həm səs, həm video FFmpeg dekoderləri əvvəl. */
    ALL_FFMPEG('f');

    companion object {
        fun of(code: Char?): DecoderMode = entries.firstOrNull { it.code == code } ?: NORMAL
    }
}

class DecoderMemory(context: Context) {
    private companion object {
        const val PREFS = "decoder_memory_v3"
        const val MAX_ENTRIES = 4_000
    }

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val cache = HashMap<String, String>()

    init {
        runCatching {
            for ((k, v) in prefs.all) if (v is String) cache[k] = v
            if (cache.size > MAX_ENTRIES) { cache.clear(); prefs.edit().clear().apply() }
        }
    }

    private fun key(url: String): String {
        val d = MessageDigest.getInstance("MD5").digest(url.trim().toByteArray())
        val sb = StringBuilder(16)
        for (i in 0 until 8) sb.append(String.format("%02x", d[i]))
        return sb.toString()
    }

    fun mode(url: String): DecoderMode = DecoderMode.of(cache[key(url)]?.firstOrNull())

    fun remember(url: String, mode: DecoderMode) {
        val k = key(url)
        if (mode == DecoderMode.NORMAL) {
            if (cache.remove(k) != null) runCatching { prefs.edit().remove(k).apply() }
            return
        }
        val nv = mode.code.toString()
        if (cache[k] == nv) return
        cache[k] = nv
        runCatching { prefs.edit().putString(k, nv).apply() }
    }
}
