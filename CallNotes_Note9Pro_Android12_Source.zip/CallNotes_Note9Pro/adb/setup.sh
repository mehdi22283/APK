#!/usr/bin/env bash
set -euo pipefail
PKG="az.mehdi.callnotes"
SERVICE="$PKG/.WhatsappAccessibilityService"

if ! command -v adb >/dev/null 2>&1; then echo "XƏTA: adb tapılmadı. Android SDK Platform Tools quraşdır."; exit 1; fi
if ! adb get-state >/dev/null 2>&1; then echo "XƏTA: Telefon ADB ilə qoşulu deyil. USB debugging-i aktiv et və adb devices yoxla."; exit 1; fi

if [[ -n "${1:-}" ]]; then
  if [[ ! -f "$1" ]]; then echo "APK tapılmadı: $1"; exit 1; fi
  adb install -r "$1"
fi

echo "[1/5] Android icazələri verilir..."
adb shell pm grant "$PKG" android.permission.RECORD_AUDIO || true
adb shell pm grant "$PKG" android.permission.READ_PHONE_STATE || true
SDK="$(adb shell getprop ro.build.version.sdk | tr -d '\r')"
if [[ "$SDK" -ge 33 ]]; then adb shell pm grant "$PKG" android.permission.POST_NOTIFICATIONS || true; fi

echo "[2/5] Üstdə göstərmə icazəsi..."
adb shell appops set "$PKG" SYSTEM_ALERT_WINDOW allow || true

echo "[3/5] Arxa plan və batareya istisnası..."
adb shell cmd appops set "$PKG" RUN_IN_BACKGROUND allow || true
adb shell dumpsys deviceidle whitelist +"$PKG" || true

echo "[4/5] WhatsApp əlçatımlılıq xidməti aktiv edilir (mövcud xidmətlər saxlanılır)..."
CURRENT="$(adb shell settings get secure enabled_accessibility_services | tr -d '\r')"
case ":$CURRENT:" in
  *":$SERVICE:"*) NEW="$CURRENT" ;;
  *) if [[ -z "$CURRENT" || "$CURRENT" == "null" ]]; then NEW="$SERVICE"; else NEW="$CURRENT:$SERVICE"; fi ;;
esac
adb shell settings put secure enabled_accessibility_services "$NEW"
adb shell settings put secure accessibility_enabled 1

echo "[5/5] Tətbiq açılır..."
adb shell monkey -p "$PKG" 1 >/dev/null 2>&1 || true

echo
 echo "ADB quraşdırması tamamlandı. Tətbiqdə Telefon/WhatsApp avtomatik yazı seçimlərini ayrıca aktiv et."
echo "MIUI Autostart seçimini Təhlükəsizlik > İcazələr > Autostart bölməsində əl ilə aktiv et."
