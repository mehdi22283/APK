@echo off
setlocal EnableExtensions EnableDelayedExpansion
set PKG=az.mehdi.callnotes
set SERVICE=az.mehdi.callnotes/.WhatsappAccessibilityService
where adb >nul 2>nul || (echo ADB tapilmadi. Android SDK Platform Tools qurasdirin.& exit /b 1)
adb get-state >nul 2>nul || (echo Telefon ADB ile qosulu deyil.& exit /b 1)
if not "%~1"=="" adb install -r "%~1"
echo [1/5] Runtime icazeleri verilir...
adb shell pm grant %PKG% android.permission.RECORD_AUDIO
adb shell pm grant %PKG% android.permission.READ_PHONE_STATE
for /f %%a in ('adb shell getprop ro.build.version.sdk') do set SDK=%%a
if !SDK! GEQ 33 adb shell pm grant %PKG% android.permission.POST_NOTIFICATIONS
echo [2/5] Overlay icazesi...
adb shell appops set %PKG% SYSTEM_ALERT_WINDOW allow
echo [3/5] Arxa plan / batareya istisnasi...
adb shell cmd appops set %PKG% RUN_IN_BACKGROUND allow
adb shell dumpsys deviceidle whitelist +%PKG%
echo [4/5] WhatsApp accessibility aktiv edilir...
for /f "delims=" %%a in ('adb shell settings get secure enabled_accessibility_services') do set CURRENT=%%a
set NEW=!CURRENT!
echo !CURRENT!| findstr /c:"%SERVICE%" >nul || (if "!CURRENT!"=="null" (set NEW=%SERVICE%) else (set NEW=!CURRENT!:%SERVICE%))
adb shell settings put secure enabled_accessibility_services "!NEW!"
adb shell settings put secure accessibility_enabled 1
echo [5/5] Tətbiq acilir...
adb shell monkey -p %PKG% 1
 echo.
echo Tamamlandi. Tətbiqdə avtomatik yazı seçimlərini aktiv edin.
echo MIUI Autostart: Tehlukesizlik ^> Icazeler ^> Autostart bolmesinden el ile aktiv edin.
pause
