# CallNotes — Redmi Note 9 Pro / Android 12

Bu qovluq Android Studio üçün Gradle layihəsinin mənbə kodudur. APK bu mühitdə kompilyasiya edilməyib; layihəni Android Studio ilə və ya GitHub Actions workflow-u ilə build etmək mümkündür.

## Əsas funksiyalar

- Telefon zəngi başlayanda (OFFHOOK) avtomatik mikrofon yazısını başlatmaq, zəng bitəndə dayandırmaq.
- WhatsApp və WhatsApp Business zəng ekranını Accessibility Service ilə aşkarlamaq.
- Yazı zamanı daimi bildiriş və icazə verildikdə ekranda qırmızı üzən `YAZILIR / STOP` göstəricisi.
- AAC/M4A yazı faylları, yazı siyahısı, dinləmə, silmə və Android paylaşma menyusu ilə ixrac.
- Hər yazıya bağlı qeyd, həmçinin müstəqil ümumi qeydlər.
- Tarix/saat seçilən xatırlatmalar, bildiriş, tamamlandı/sil əməliyyatları.
- Telefon monitorinqinin cihaz açıldıqdan sonra yenidən başlaması üçün BOOT_COMPLETED receiver.
- ADB ilə runtime permission, overlay, batareya istisnası və WhatsApp əlçatımlılıq xidmətini qurmaq üçün `adb/setup.sh` və `adb/setup.bat`.

## Vacib audio məhdudiyyəti

Tətbiq `MediaRecorder.AudioSource.MIC` istifadə edir. Android 12-də adi, root-suz tətbiqə telefon zənginin uplink/downlink audio axınını oxumaq üçün ümumi açıq API verilmir. `VOICE_CALL`/`VOICE_UPLINK`/`VOICE_DOWNLINK` mənbələri sistem/imtiyazlı icazə tələb edə bilər. WhatsApp da öz zəng audio axınını adi tətbiqlərə açmır. Buna görə:

- Yazı faylı yaranır, amma bu, **hər iki tərəfin səsinin mütləq yazılması demək deyil**.
- Qarşı tərəfin səsini eşitmək üçün dinamikin aktiv olması və mikrofonun onu götürməsi lazım gələ bilər.
- Xiaomi ROM-u və zəng rejimi audio nəticəsinə təsir edir. Bu layihə iki tərəfli yazıya zəmanət vermir.
- WhatsApp ekranının aşkarlanması dil/UI versiyasına bağlıdır; zəng ekranı tanınmasa avtomatik start baş verməyə bilər.
- Android 12 arxa planda mikrofonlu foreground service başlatmağı məhdudlaşdıra bilər. Belə halda avtomatik start sistemi tərəfindən bloklana bilər; tətbiqi açıb icazələri yoxlamaq lazımdır.

Yazı yalnız görünən persistent notification və üzən idarəetmə ilə işləyəcək şəkildə qurulub. Zəng yazmazdan əvvəl qarşı tərəfi məlumatlandırın və yerli qanunlara əməl edin.

## Android Studio ilə build

1. ZIP-i çıxarın.
2. Android Studio-da `CallNotes_Note9Pro` qovluğunu **Open** edin.
3. Gradle JDK olaraq JDK 17 seçin.
4. Android SDK Platform 35 və Build Tools-u quraşdırın.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** seçin.
6. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Komanda sətri ilə: `gradle assembleDebug` (Gradle 8.7, JDK 17 və Android SDK tələb olunur).

## ADB quraşdırılması

1. Telefonda Developer options → USB debugging aktiv edin.
2. Telefonu USB ilə qoşun və kompüterdə `adb devices` ilə icazə verin.
3. Əvvəlcə APK build edin.
4. Linux/macOS: `bash adb/setup.sh app/build/outputs/apk/debug/app-debug.apk`
5. Windows: `adb\setup.bat app\build\outputs\apk\debug\app-debug.apk`

ADB skripti mövcud əlçatımlılıq xidmətlərini silmədən CallNotes xidmətini əlavə edir. Tətbiqdə hər iki avtomatik aşkarlama seçimi ilk quraşdırmada aktiv görünür; Ana səhifədə vəziyyətini yoxlayın. Telefon monitorinqi üçün `READ_PHONE_STATE` icazəsi lazımdır.

### MIUI Autostart

MIUI versiyaları arasında autostart idarəsi fərqlənir. Skript standart Android ADB icazələrini verir, lakin MIUI-nin xüsusi autostart qorumasını hər Note 9 Pro ROM-da avtomatik dəyişə bilmir. Telefonda:

**Təhlükəsizlik → İcazələr → Autostart → CallNotes → Aktiv**

Bundan əlavə, batareya optimallaşdırmasını istisna etmək tövsiyə olunur.

## GitHub Actions ilə APK

Layihəni GitHub repozitoriyasına yükləyin. `main`/`master` branch-ə push edildikdə və ya Actions bölməsindən `Android APK build` workflow-u manual başladıldıqda `CallNotes-debug-apk` adlı artifact yaranır.

## Paket məlumatı

- Application ID: `az.mehdi.callnotes`
- Minimum Android: 8.0 (API 26)
- Hədəf SDK: 32 (Android 12)
- Compile SDK: 35
- Java: 17
- Audio: AAC / MPEG-4 container (`.m4a`)
- Yazılar: tətbiqin daxili `files/recordings/` qovluğunda saxlanılır.
