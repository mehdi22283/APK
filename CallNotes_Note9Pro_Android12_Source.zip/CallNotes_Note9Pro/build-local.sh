#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle tapılmadı. Android Studio quraşdırın və ya Gradle 8.7-ni PATH-ə əlavə edin."
  exit 1
fi
gradle --version | head -n 8
gradle assembleDebug
mkdir -p output
cp app/build/outputs/apk/debug/app-debug.apk output/CallNotes-debug.apk
echo "APK: output/CallNotes-debug.apk"
