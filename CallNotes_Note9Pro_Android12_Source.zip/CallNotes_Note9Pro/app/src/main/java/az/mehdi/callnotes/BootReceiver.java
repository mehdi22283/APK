package az.mehdi.callnotes;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        if(context.getSharedPreferences("settings",Context.MODE_PRIVATE).getBoolean("auto_phone",true)) PhoneMonitorService.enable(context);
        AlarmManager alarms=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        long now=System.currentTimeMillis();
        for(AppDb.Reminder r:new AppDb(context).reminders()){
            if(r.done||r.triggerAt<=now)continue;
            Intent reminder=new Intent(context,ReminderReceiver.class);
            reminder.putExtra("id",(int)r.id); reminder.putExtra("title",r.title);
            PendingIntent pi=PendingIntent.getBroadcast(context,(int)r.id,reminder,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=23)alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,r.triggerAt,pi);
            else alarms.set(AlarmManager.RTC_WAKEUP,r.triggerAt,pi);
        }
    }
}
