package az.mehdi.callnotes;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingIndicatorService extends Service {
    private WindowManager wm; private android.view.View view;
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){ stopSelf(); return START_NOT_STICKY; }
        if(view!=null) return START_NOT_STICKY;
        String type=intent==null?"":intent.getStringExtra(RecorderService.EXTRA_TYPE);
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setGravity(Gravity.CENTER_VERTICAL); box.setPadding(14,8,10,8); box.setBackgroundColor(0xEE9B1825);
        TextView label=new TextView(this); label.setText("● YAZILIR  "+("PHONE".equals(type)?"Telefon":"WHATSAPP".equals(type)?"WhatsApp":"Manual")); label.setTextColor(0xFFFFFFFF); label.setTextSize(12); label.setPadding(0,0,12,0);
        Button stop=new Button(this); stop.setText("STOP"); stop.setTextSize(11); stop.setMinWidth(0); stop.setMinimumWidth(0); stop.setPadding(8,0,8,0); stop.setOnClickListener(v->RecorderService.stop(this));
        box.addView(label); box.addView(stop); view=box;
        int kind=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,kind,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END; p.x=12; p.y=120;
        try{wm.addView(view,p);}catch(Exception e){view=null;stopSelf();}
        return START_NOT_STICKY;
    }
    @Override public void onDestroy(){ if(wm!=null && view!=null){try{wm.removeView(view);}catch(Exception ignored){}} view=null; super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
