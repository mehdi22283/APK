package az.mehdi.callnotes;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

public class WhatsappAccessibilityService extends AccessibilityService {
    private boolean callSeen=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable delayedStop=()->{
        if(!isWhatsappCallScreen()){
            callSeen=false;
            RecorderService.stopIfType(this,"WHATSAPP");
        }
    };
    @Override protected void onServiceConnected(){
        AccessibilityServiceInfo info=getServiceInfo();
        info.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        info.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout=350; setServiceInfo(info);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null||event.getPackageName()==null)return;
        String pkg=event.getPackageName().toString();
        if(!pkg.equals("com.whatsapp")&&!pkg.equals("com.whatsapp.w4b")){
            if(callSeen){handler.removeCallbacks(delayedStop);handler.postDelayed(delayedStop,4500);}
            return;
        }
        boolean active=isWhatsappCallScreen();
        if(active){
            handler.removeCallbacks(delayedStop);
            callSeen=true;
            boolean enabled=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("auto_whatsapp",true);
            if(enabled) RecorderService.start(this,"WHATSAPP");
        }else if(callSeen){
            handler.removeCallbacks(delayedStop); handler.postDelayed(delayedStop,4500);
        }
    }
    private boolean isWhatsappCallScreen(){
        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return false;
        CharSequence packageName=root.getPackageName();
        if(packageName==null||(!packageName.toString().equals("com.whatsapp")&&!packageName.toString().equals("com.whatsapp.w4b")))return false;
        StringBuilder all=new StringBuilder(); collect(root,all,0);
        String s=all.toString().toLowerCase(Locale.ROOT);
        boolean hang=s.contains("end call")||s.contains("hang up")||s.contains("zəngi bitir")||s.contains("zengi bitir")||s.contains("zəngi sonlandır")||s.contains("bitir")||s.contains("finalizar chamada");
        int controls=0;
        if(s.contains("mute")||s.contains("səssiz")||s.contains("sessiz"))controls++;
        if(s.contains("speaker")||s.contains("dinamik"))controls++;
        if(s.contains("video")||s.contains("kamera"))controls++;
        if(s.contains("bluetooth"))controls++;
        return hang || controls>=2;
    }
    private void collect(AccessibilityNodeInfo n,StringBuilder b,int depth){
        if(n==null||depth>12)return;
        if(n.getText()!=null)b.append(' ').append(n.getText());
        if(n.getContentDescription()!=null)b.append(' ').append(n.getContentDescription());
        for(int i=0;i<n.getChildCount()&&i<80;i++)collect(n.getChild(i),b,depth+1);
    }
    @Override public void onInterrupt(){ }
}
