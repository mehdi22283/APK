package az.mehdi.callnotes;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    public static final String ACTION_START = "az.mehdi.callnotes.START_RECORDING";
    public static final String ACTION_STOP = "az.mehdi.callnotes.STOP_RECORDING";
    public static final String EXTRA_TYPE = "record_type";
    private static final String CHANNEL = "callnotes_recording";
    private static final int NOTIFICATION_ID = 4201;

    private MediaRecorder recorder;
    private long recordId = -1;
    private long startedAt;
    private String recordType = "MANUAL";
    private File outputFile;

    public static void start(Context context, String type) {
        Intent i = new Intent(context, RecorderService.class);
        i.setAction(ACTION_START); i.putExtra(EXTRA_TYPE, type);
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i); else context.startService(i);
        } catch (Exception ignored) { }
    }
    public static void stop(Context context) {
        Intent i = new Intent(context, RecorderService.class); i.setAction(ACTION_STOP);
        try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i); else context.startService(i); } catch (Exception ignored) { }
    }
    public static void stopIfType(Context context, String type) {
        String current=context.getSharedPreferences("state",MODE_PRIVATE).getString("record_type","");
        if (type.equals(current)) stop(context);
    }

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) { startForeground(NOTIFICATION_ID,buildNotification("Yazı dayandırılır…")); stopRecording(); return START_NOT_STICKY; }
        String type=intent.getStringExtra(EXTRA_TYPE); if(type!=null) recordType=type;
        if (recorder == null) beginRecording();
        return START_NOT_STICKY;
    }

    private void beginRecording() {
        Notification n=buildNotification("Yazı hazırlanır…");
        startForeground(NOTIFICATION_ID,n);
        try {
            File dir=new File(getFilesDir(),"recordings"); if(!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Qovluq yaradıla bilmədi");
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            outputFile=new File(dir, recordType.toLowerCase(Locale.ROOT)+"_"+stamp+".m4a");
            recorder=new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioSamplingRate(44100);
            recorder.setAudioEncodingBitRate(96000);
            recorder.setOutputFile(outputFile.getAbsolutePath());
            recorder.prepare(); recorder.start();
            startedAt=System.currentTimeMillis();
            recordId=new AppDb(this).addRecording(recordType,outputFile.getAbsolutePath(),startedAt);
            getSharedPreferences("state",MODE_PRIVATE).edit().putLong("record_id",recordId).putString("record_type",recordType).apply();
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID,buildNotification("Yazılır: "+label(recordType)+" — mikrofon"));
            if(Build.VERSION.SDK_INT<23 || Settings.canDrawOverlays(this)) {
                Intent overlay=new Intent(this,FloatingIndicatorService.class); overlay.putExtra(EXTRA_TYPE,recordType); startService(overlay);
            }
        } catch (Exception e) {
            releaseRecorder();
            stopForeground(true);
            stopSelf();
            android.util.Log.e("CallNotes","Recording start failed",e);
        }
    }

    private void stopRecording() {
        if(recorder!=null) {
            try { recorder.stop(); } catch(Exception ignored) { if(outputFile!=null && outputFile.exists()) outputFile.delete(); }
            releaseRecorder();
            if(recordId>0) new AppDb(this).finishRecording(recordId,System.currentTimeMillis()-startedAt);
        }
        getSharedPreferences("state",MODE_PRIVATE).edit().remove("record_id").remove("record_type").apply();
        try { stopService(new Intent(this,FloatingIndicatorService.class)); } catch(Exception ignored) { }
        stopForeground(true); stopSelf();
    }

    private void releaseRecorder() {
        if(recorder!=null){ try{recorder.reset();}catch(Exception ignored){} try{recorder.release();}catch(Exception ignored){} recorder=null; }
    }
    private String label(String type) { if("PHONE".equals(type)) return "Telefon zəngi"; if("WHATSAPP".equals(type)) return "WhatsApp zəngi"; return "Əl ilə yazı"; }
    private void createChannel() {
        if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel(CHANNEL,"Zəng yazısı",NotificationManager.IMPORTANCE_LOW); c.setDescription("Aktiv yazı zamanı daimi bildiriş"); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); }
    }
    private Notification buildNotification(String text) {
        Intent open=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(this,RecorderService.class); stop.setAction(ACTION_STOP);
        PendingIntent stopPi=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("CallNotes — yazı aktivdir").setContentText(text).setContentIntent(pi).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Dayandır",stopPi).build();
    }
    @Override public void onDestroy(){ if(recorder!=null) stopRecording(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
