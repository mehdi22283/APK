package az.mehdi.callnotes;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.InputStream;
import java.io.OutputStream;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private AppDb db;
    private LinearLayout root, content, nav;
    private final int blue=0xFF1769AA, dark=0xFF17212B, muted=0xFF617181;

    @Override public void onCreate(Bundle state){ super.onCreate(state); db=new AppDb(this); buildShell(); showHome(); }

    private void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFFF4F6F9);
        LinearLayout header=new LinearLayout(this); header.setPadding(18,15,18,12); header.setGravity(Gravity.CENTER_VERTICAL); header.setBackgroundColor(0xFFFFFFFF);
        TextView brand=new TextView(this); brand.setText("CallNotes"); brand.setTextSize(23); brand.setTypeface(null,Typeface.BOLD); brand.setTextColor(dark); header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView sub=new TextView(this); sub.setText("NOTE 9 PRO • ANDROID 12"); sub.setTextSize(10); sub.setTextColor(muted); header.addView(sub); root.addView(header);
        nav=new LinearLayout(this); nav.setPadding(6,5,6,5); nav.setBackgroundColor(0xFFFFFFFF);
        addNav("Ana səhifə",this::showHome); addNav("Yazılar",this::showRecordings); addNav("Qeydlər",this::showNotes); addNav("Xatırlatma",this::showReminders); addNav("Ayarlar",this::showSettings);
        root.addView(nav);
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16,14,16,26); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private void addNav(String title,Runnable action){ Button b=new Button(this); b.setText(title); b.setTextSize(10); b.setAllCaps(false); b.setPadding(2,3,2,3); nav.addView(b,new LinearLayout.LayoutParams(0,-2,1)); b.setOnClickListener(v->action.run()); }
    private TextView text(String value,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    private Button button(String title,Runnable action){ Button b=new Button(this); b.setText(title); b.setAllCaps(false); b.setOnClickListener(v->action.run()); return b; }
    private void line(){ View v=new View(this); v.setBackgroundColor(0xFFE1E6EC); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,1); p.topMargin=10;p.bottomMargin=10;content.addView(v,p); }
    private void card(String title,String body){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(15,13,15,13); box.setBackgroundColor(0xFFFFFFFF); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=10;content.addView(box,p);
        box.addView(text(title,16,dark,true)); TextView detail=text(body,13,muted,false); detail.setPadding(0,6,0,0); box.addView(detail);
    }
    private void clear(String heading){ content.removeAllViews(); if(heading!=null){content.addView(text(heading,21,dark,true)); TextView gap=text("",3,muted,false);content.addView(gap);} }

    private void showHome(){
        clear("Zəng qeydləri və xatırlatmalar");
        card("Qeydiyyat statusu","Telefon və WhatsApp zəngləri aşkarlananda mikrofon yazısı başlada bilər. Aktiv yazı zamanı ekranda qırmızı göstərici və daimi bildiriş görünür.");
        content.addView(button("İcazələri yoxla və ver",this::requestCorePermissions));
        content.addView(button("Əl ilə yazmağa başla",()->RecorderService.start(this,"MANUAL")));
        content.addView(button("Aktiv yazını dayandır",()->RecorderService.stop(this)));
        line();
        boolean p=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("auto_phone",true);
        boolean w=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("auto_whatsapp",true);
        CheckBox cp=new CheckBox(this);cp.setText("Telefon zənglərini avtomatik aşkarlayıb yaz");cp.setTextSize(14);cp.setChecked(p);content.addView(cp);cp.setOnCheckedChangeListener((v,checked)->{getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("auto_phone",checked).apply();if(checked){if(checkPermission(Manifest.permission.READ_PHONE_STATE))PhoneMonitorService.enable(this);else requestCorePermissions();}else PhoneMonitorService.disable(this);});
        CheckBox cw=new CheckBox(this);cw.setText("WhatsApp zənglərini avtomatik aşkarlayıb yaz");cw.setTextSize(14);cw.setChecked(w);content.addView(cw);cw.setOnCheckedChangeListener((v,checked)->{getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("auto_whatsapp",checked).apply();if(checked&&!isAccessibilityEnabled()){Toast.makeText(this,"CallNotes əlçatımlılıq xidmətini aktiv et",Toast.LENGTH_LONG).show();startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}});
        line();
        content.addView(text("Məhdudiyyət",16,dark,true));
        content.addView(text("Bu tətbiq Android-in icazə verdiyi MIC mikrofon mənbəyindən AAC faylı yaradır. Android 12-də adi tətbiqə telefon/WhatsApp zənginin qarşı tərəf səsini sistem səviyyəsində oxumaq icazəsi verilmir. Nəticə dinamikin səs səviyyəsindən və cihaz proqram təminatından asılıdır; iki tərəfli yazı zəmanəti yoxdur.",13,muted,false));
        content.addView(text("Yazıya başlamazdan əvvəl qarşı tərəfi məlumatlandır və yerli qanunlara əməl et.",13,0xFF9B2635,true));
        content.addView(button("Yazıları aç",this::showRecordings));
    }

    private void showRecordings(){
        clear("Yazılar");
        ArrayList<AppDb.Recording> rows=db.recordings();
        if(rows.isEmpty()){card("Hələ yazı yoxdur","Telefon və ya WhatsApp zəngi yazıldıqda burada görünəcək.");return;}
        for(AppDb.Recording r:rows){
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setPadding(13,11,13,11);item.setBackgroundColor(0xFFFFFFFF);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=9;content.addView(item,p);
            String type="PHONE".equals(r.type)?"Telefon":"WHATSAPP".equals(r.type)?"WhatsApp":"Əl ilə";
            item.addView(text(type+" • "+date(r.startedAt),15,dark,true));
            item.addView(text("Müddət: "+duration(r.durationMs)+"   •   "+new File(r.path).getName(),12,muted,false));
            LinearLayout actions=new LinearLayout(this);item.addView(actions);
            Button play=smallButton("Dinlə");play.setOnClickListener(v->playRecording(r));actions.addView(play);
            Button share=smallButton("Paylaş");share.setOnClickListener(v->shareRecording(r));actions.addView(share);
            Button note=smallButton("Qeyd əlavə et");note.setOnClickListener(v->noteDialog(r.id,null,null));actions.addView(note);
            Button reminder=smallButton("Xatırlatma");reminder.setOnClickListener(v->reminderDialog(null,"Zəngə aid: "+type));actions.addView(reminder);
            Button more=smallButton("⋮");more.setOnClickListener(v->recordingMenu(r));actions.addView(more);
        }
    }
    private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);b.setAllCaps(false);b.setPadding(3,0,3,0);return b;}
    private void recordingMenu(AppDb.Recording r){
        String[] opts={"Dinlə","Qeyd əlavə et","Xatırlatma yarat","Yazını sil"};
        new AlertDialog.Builder(this).setTitle("Yazı əməliyyatları").setItems(opts,(d,n)->{
            if(n==0)playRecording(r);else if(n==1)noteDialog(r.id,null,null);else if(n==2)reminderDialog(null,"Zəngə aid qeyd");else new AlertDialog.Builder(this).setMessage("Bu yazı və ona bağlı qeydlər silinsin?").setNegativeButton("Ləğv",null).setPositiveButton("Sil",(x,y)->{new File(r.path).delete();db.deleteRecording(r.id);showRecordings();}).show();
        }).show();
    }

    private void shareRecording(AppDb.Recording r){
        File src=new File(r.path); if(!src.exists()){Toast.makeText(this,"Audio faylı tapılmadı",Toast.LENGTH_SHORT).show();return;}
        if(Build.VERSION.SDK_INT<29){Toast.makeText(this,"Paylaşma üçün Android 10 və yuxarı tələb olunur",Toast.LENGTH_LONG).show();return;}
        try{
            ContentValues values=new ContentValues();
            values.put(MediaStore.Audio.Media.DISPLAY_NAME,src.getName());
            values.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mp4");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_MUSIC+"/CallNotes");
            values.put(MediaStore.MediaColumns.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IllegalStateException("MediaStore faylı yarada bilmədi");
            try(InputStream in=new java.io.FileInputStream(src);OutputStream out=getContentResolver().openOutputStream(uri)){
                if(out==null)throw new IllegalStateException("Fayl yazıla bilmədi");
                byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))>0)out.write(buffer,0,n);
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);getContentResolver().update(uri,ready,null,null);
            Intent send=new Intent(Intent.ACTION_SEND);send.setType("audio/mp4");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send,"Yazını paylaş"));
        }catch(Exception e){Toast.makeText(this,"Paylaşma alınmadı: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private void playRecording(AppDb.Recording r){
        File f=new File(r.path);if(!f.exists()){Toast.makeText(this,"Audio faylı tapılmadı",Toast.LENGTH_SHORT).show();return;}
        final MediaPlayer mp=new MediaPlayer();
        try{mp.setDataSource(f.getAbsolutePath());mp.prepare();}catch(Exception e){Toast.makeText(this,"Audio açıla bilmədi",Toast.LENGTH_SHORT).show();mp.release();return;}
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Yazıya qulaq as").setMessage(f.getName()).setPositiveButton("Dayandır",(a,b)->{try{if(mp.isPlaying())mp.stop();}catch(Exception ignored){}mp.release();}).setNegativeButton("Bağla",(a,b)->mp.release()).create();
        dialog.setOnShowListener(v->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("Dayandır");});dialog.show();
        mp.start();mp.setOnCompletionListener(m->{m.release();dialog.dismiss();});
    }

    private void showNotes(){
        clear("Ümumi qeydlər");content.addView(button("+ Yeni qeyd",()->noteDialog(null,null,null)));
        ArrayList<AppDb.Note> rows=db.notes();
        if(rows.isEmpty()){card("Qeyd yoxdur","Ümumi və ya zəngə bağlı qeydlər burada görünəcək.");return;}
        for(AppDb.Note n:rows){
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setPadding(13,10,13,10);item.setBackgroundColor(0xFFFFFFFF);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=8;content.addView(item,p);
            item.addView(text(n.title,15,dark,true));if(n.body!=null&&!n.body.isEmpty())item.addView(text(n.body,13,muted,false));
            item.addView(text(date(n.createdAt)+(n.recordingId==null?" • Ümumi qeyd":" • Zəng #"+n.recordingId),11,muted,false));
            LinearLayout row=new LinearLayout(this);item.addView(row);Button edit=smallButton("Düzəlt");edit.setOnClickListener(v->noteDialog(n.recordingId,n.id,n));row.addView(edit);Button del=smallButton("Sil");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Qeyd silinsin?").setNegativeButton("Xeyr",null).setPositiveButton("Sil",(a,b)->{db.deleteNote(n.id);showNotes();}).show());row.addView(del);
        }
    }
    private void noteDialog(Long recordingId,Long noteId,AppDb.Note existing){
        LinearLayout form=new LinearLayout(this);form.setPadding(18,6,18,0);form.setOrientation(LinearLayout.VERTICAL);
        EditText title=new EditText(this);title.setHint("Qeydin başlığı");if(existing!=null)title.setText(existing.title);form.addView(title);
        EditText body=new EditText(this);body.setHint("Ətraflı qeyd (istəyə görə)");body.setMinLines(3);body.setGravity(Gravity.TOP);if(existing!=null&&existing.body!=null)body.setText(existing.body);form.addView(body);
        new AlertDialog.Builder(this).setTitle(existing==null?(recordingId==null?"Yeni ümumi qeyd":"Zəngə aid qeyd"):"Qeydi düzəlt").setView(form).setNegativeButton("Ləğv",null).setPositiveButton("Yadda saxla",(d,w)->{
            String t=title.getText().toString().trim();if(t.isEmpty()){Toast.makeText(this,"Başlıq yaz",Toast.LENGTH_SHORT).show();return;}
            if(noteId==null)db.addNote(recordingId,t,body.getText().toString().trim());else db.updateNote(noteId,t,body.getText().toString().trim());
            if(recordingId!=null)showRecordings();else showNotes();
        }).show();
    }

    private void showReminders(){
        clear("Xatırlatmalar");content.addView(button("+ Yeni xatırlatma",()->reminderDialog(null,null)));
        ArrayList<AppDb.Reminder> rows=db.reminders();if(rows.isEmpty()){card("Xatırlatma yoxdur","Vaxtı çatanda bildiriş görünəcək.");return;}
        for(AppDb.Reminder r:rows){
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setPadding(13,10,13,10);item.setBackgroundColor(0xFFFFFFFF);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=8;content.addView(item,p);
            item.addView(text((r.done?"✓ ":"⏰ ")+r.title,15,dark,true));item.addView(text(date(r.triggerAt)+" • "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(r.triggerAt)),12,muted,false));
            LinearLayout row=new LinearLayout(this);item.addView(row);Button done=smallButton(r.done?"Tamamlanmayıb":"Tamamlandı");done.setOnClickListener(v->{db.setReminderDone(r.id,!r.done);showReminders();});row.addView(done);Button del=smallButton("Sil");del.setOnClickListener(v->{cancelReminder(r.id);db.deleteReminder(r.id);showReminders();});row.addView(del);
        }
    }
    private void reminderDialog(Long noteId,String suggested){
        EditText title=new EditText(this);title.setSingleLine(true);title.setHint("Xatırlatma mətni");if(suggested!=null)title.setText(suggested);
        Calendar c=Calendar.getInstance();c.add(Calendar.HOUR,1);
        new AlertDialog.Builder(this).setTitle("Xatırlatma yarat").setView(title).setNegativeButton("Ləğv",null).setPositiveButton("Vaxt seç",(d,w)->{
            String t=title.getText().toString().trim();if(t.isEmpty()){Toast.makeText(this,"Xatırlatma mətnini yaz",Toast.LENGTH_SHORT).show();return;}
            DatePickerDialog dp=new DatePickerDialog(this,(view,year,month,day)->{
                c.set(Calendar.YEAR,year);c.set(Calendar.MONTH,month);c.set(Calendar.DAY_OF_MONTH,day);
                new TimePickerDialog(this,(tv,hour,minute)->{c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis()){Toast.makeText(this,"Gələcək vaxt seç",Toast.LENGTH_SHORT).show();return;}long id=db.addReminder(noteId,t,c.getTimeInMillis());scheduleReminder(id,t,c.getTimeInMillis());showReminders();},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
            },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));dp.getDatePicker().setMinDate(System.currentTimeMillis()-1000);dp.show();
        }).show();
    }
    private void scheduleReminder(long id,String title,long when){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,ReminderReceiver.class);i.putExtra("id",(int)id);i.putExtra("title",title);
        PendingIntent pi=PendingIntent.getBroadcast(this,(int)id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else am.set(AlarmManager.RTC_WAKEUP,when,pi);
    }
    private void cancelReminder(long id){Intent i=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,(int)id,i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null)((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);}

    private void showSettings(){
        clear("Ayarlar və icazələr");
        content.addView(button("Mikrofon və telefon icazələri",this::requestCorePermissions));
        content.addView(button("Üstdə göstərmə icazəsi",()->{if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));else Toast.makeText(this,"Üstdə göstərmə artıq aktivdir",Toast.LENGTH_SHORT).show();}));
        content.addView(button("WhatsApp üçün əlçatımlılığı aç",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        content.addView(button("Batareya optimallaşdırmasını istisna et",()->{try{Intent i=new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception e){startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}}));
        content.addView(button("Telefon zəngi monitorinqini başlad",()->{if(checkPermission(Manifest.permission.READ_PHONE_STATE))PhoneMonitorService.enable(this);else requestCorePermissions();}));
        content.addView(button("Telefon monitorinqini dayandır",()->PhoneMonitorService.disable(this)));
        line();
        content.addView(text("Xiaomi / MIUI autostart",16,dark,true));
        content.addView(text("MIUI-də CallNotes üçün Təhlükəsizlik → İcazələr → Autostart bölməsindən avtomatik başlatmanı əl ilə aktiv et. ADB skripti tətbiq icazələrini, overlay və WhatsApp əlçatımlılığını quraşdırır, lakin MIUI-nin xüsusi autostart düyməsini hər ROM-da etibarlı şəkildə dəyişə bilmir.",13,muted,false));
        content.addView(text("WhatsApp əlçatımlılığı WhatsApp zəng ekranını aşkarlamaq üçündür. Bu xidmət bildiriş və yazı göstəricisini gizlətmir; yazı bildirişi və qırmızı üzən idarəetmə görünür.",13,muted,false));
    }

    private void requestCorePermissions(){
        ArrayList<String> req=new ArrayList<>();
        if(!checkPermission(Manifest.permission.RECORD_AUDIO))req.add(Manifest.permission.RECORD_AUDIO);
        if(!checkPermission(Manifest.permission.READ_PHONE_STATE))req.add(Manifest.permission.READ_PHONE_STATE);
        if(Build.VERSION.SDK_INT>=33&&!checkPermission(Manifest.permission.POST_NOTIFICATIONS))req.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!req.isEmpty())requestPermissions(req.toArray(new String[0]),90);
        else openOverlaySettingsIfNeeded();
    }
    private void openOverlaySettingsIfNeeded(){
        if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
    }
    private boolean checkPermission(String p){return Build.VERSION.SDK_INT<23||checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
    private boolean isAccessibilityEnabled(){
        String enabled=android.provider.Settings.Secure.getString(getContentResolver(),android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled!=null&&enabled.toLowerCase(Locale.ROOT).contains(getPackageName().toLowerCase(Locale.ROOT));
    }
    private String date(long ms){return new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date(ms));}
    private String duration(long ms){long s=ms/1000;return String.format(Locale.getDefault(),"%02d:%02d",s/60,s%60);}
    @Override protected void onResume(){
        super.onResume();
        if(getSharedPreferences("settings",MODE_PRIVATE).getBoolean("auto_phone",true) && checkPermission(Manifest.permission.READ_PHONE_STATE)) PhoneMonitorService.enable(this);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==90){
            if(getSharedPreferences("settings",MODE_PRIVATE).getBoolean("auto_phone",true) && checkPermission(Manifest.permission.READ_PHONE_STATE)) PhoneMonitorService.enable(this);
            if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this))openOverlaySettingsIfNeeded();
            showHome();
        }
    }
    @Override protected void onDestroy(){super.onDestroy();}
}
