package az.mehdi.callnotes;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

public class PhoneMonitorService extends Service {
    private TelephonyManager telephony; private PhoneStateListener listener;
    private static final String CHANNEL="callnotes_monitor";
    @Override public void onCreate(){ super.onCreate(); createChannel(); startForeground(4202,buildNotification());
        telephony=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
        listener=new PhoneStateListener(){
            @Override public void onCallStateChanged(int state,String incomingNumber){
                boolean enabled=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("auto_phone",true);
                if(state==TelephonyManager.CALL_STATE_OFFHOOK && enabled) RecorderService.start(PhoneMonitorService.this,"PHONE");
                else if(state==TelephonyManager.CALL_STATE_IDLE) RecorderService.stopIfType(PhoneMonitorService.this,"PHONE");
            }
        };
        try{telephony.listen(listener,PhoneStateListener.LISTEN_CALL_STATE);}catch(SecurityException e){stopSelf();}
    }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Zəng monitorinqi",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);} }
    private Notification buildNotification(){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.sym_call_incoming).setContentTitle("CallNotes aktivdir").setContentText("Telefon zənglərinin başlanması izlənir").setOngoing(true).build();
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(telephony!=null&&listener!=null){try{telephony.listen(listener,PhoneStateListener.LISTEN_NONE);}catch(Exception ignored){}}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    public static void enable(Context c){try{Intent i=new Intent(c,PhoneMonitorService.class);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}catch(Exception ignored){}}
    public static void disable(Context c){c.stopService(new Intent(c,PhoneMonitorService.class));}
}
