package az.mehdi.callnotes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class AppDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "callnotes.db";
    private static final int DB_VERSION = 1;

    public static class Recording {
        public long id, startedAt, durationMs;
        public String type, path;
    }
    public static class Note {
        public long id, createdAt;
        public Long recordingId;
        public String title, body;
    }
    public static class Reminder {
        public long id, triggerAt;
        public Long noteId;
        public String title;
        public boolean done;
    }

    public AppDb(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE recordings (_id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, path TEXT NOT NULL, started_at INTEGER NOT NULL, duration_ms INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE notes (_id INTEGER PRIMARY KEY AUTOINCREMENT, recording_id INTEGER, title TEXT NOT NULL, body TEXT, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE reminders (_id INTEGER PRIMARY KEY AUTOINCREMENT, note_id INTEGER, title TEXT NOT NULL, trigger_at INTEGER NOT NULL, done INTEGER DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public synchronized long addRecording(String type, String path, long started) {
        ContentValues v = new ContentValues(); v.put("type", type); v.put("path", path); v.put("started_at", started);
        return getWritableDatabase().insert("recordings", null, v);
    }
    public synchronized void finishRecording(long id, long duration) {
        ContentValues v = new ContentValues(); v.put("duration_ms", Math.max(0, duration));
        getWritableDatabase().update("recordings", v, "_id=?", new String[]{String.valueOf(id)});
    }
    public synchronized ArrayList<Recording> recordings() {
        ArrayList<Recording> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM recordings ORDER BY started_at DESC", null)) {
            while (c.moveToNext()) {
                Recording r = new Recording(); r.id=c.getLong(0); r.type=c.getString(1); r.path=c.getString(2); r.startedAt=c.getLong(3); r.durationMs=c.getLong(4); out.add(r);
            }
        }
        return out;
    }
    public synchronized void deleteRecording(long id) { getWritableDatabase().delete("recordings", "_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("notes", "recording_id=?", new String[]{String.valueOf(id)}); }

    public synchronized long addNote(Long recordingId, String title, String body) {
        ContentValues v = new ContentValues(); if (recordingId != null) v.put("recording_id", recordingId); else v.putNull("recording_id");
        v.put("title", title); v.put("body", body); v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("notes", null, v);
    }
    public synchronized void updateNote(long id, String title, String body) {
        ContentValues v = new ContentValues(); v.put("title", title); v.put("body", body);
        getWritableDatabase().update("notes", v, "_id=?", new String[]{String.valueOf(id)});
    }
    public synchronized ArrayList<Note> notes() {
        ArrayList<Note> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM notes ORDER BY created_at DESC", null)) {
            while (c.moveToNext()) { Note n=new Note(); n.id=c.getLong(0); n.recordingId=c.isNull(1)?null:c.getLong(1); n.title=c.getString(2); n.body=c.getString(3); n.createdAt=c.getLong(4); out.add(n); }
        }
        return out;
    }
    public synchronized void deleteNote(long id) { getWritableDatabase().delete("notes", "_id=?", new String[]{String.valueOf(id)}); getWritableDatabase().delete("reminders", "note_id=?", new String[]{String.valueOf(id)}); }

    public synchronized long addReminder(Long noteId, String title, long at) {
        ContentValues v = new ContentValues(); if (noteId != null) v.put("note_id", noteId); else v.putNull("note_id");
        v.put("title", title); v.put("trigger_at", at); v.put("done", 0);
        return getWritableDatabase().insert("reminders", null, v);
    }
    public synchronized ArrayList<Reminder> reminders() {
        ArrayList<Reminder> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM reminders ORDER BY done ASC, trigger_at ASC",null)) {
            while(c.moveToNext()){ Reminder r=new Reminder(); r.id=c.getLong(0); r.noteId=c.isNull(1)?null:c.getLong(1); r.title=c.getString(2); r.triggerAt=c.getLong(3); r.done=c.getInt(4)!=0; out.add(r); }
        }
        return out;
    }
    public synchronized void setReminderDone(long id, boolean done) { ContentValues v=new ContentValues(); v.put("done",done?1:0); getWritableDatabase().update("reminders",v,"_id=?",new String[]{String.valueOf(id)}); }
    public synchronized void deleteReminder(long id) { getWritableDatabase().delete("reminders","_id=?",new String[]{String.valueOf(id)}); }
}
