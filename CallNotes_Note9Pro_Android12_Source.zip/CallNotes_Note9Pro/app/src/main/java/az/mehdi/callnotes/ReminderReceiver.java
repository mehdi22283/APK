package az.mehdi.callnotes;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        String title=intent.getStringExtra("title"); if(title==null)title="Xatırlatma";
        if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("callnotes_reminders","Xatırlatmalar",NotificationManager.IMPORTANCE_HIGH);((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(c);}
        PendingIntent pi=PendingIntent.getActivity(context,0,new Intent(context,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"callnotes_reminders"):new Notification.Builder(context);
        Notification n=b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("CallNotes xatırladır").setContentText(title).setAutoCancel(true).setContentIntent(pi).build();
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(intent.getIntExtra("id",1),n);
    }
}
