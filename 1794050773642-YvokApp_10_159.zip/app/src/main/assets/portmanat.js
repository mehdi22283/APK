(function(code, requestId){
  // Portmanat axını: YVÖK-ü formaya yaz -> "Davam Et" ->
  // nəticəni oxu -> "Ödəniş üçün seçin" dropdown-unu aç -> borc məbləğini oxu.
  var S = window.__pS;
  if (!S || S.code !== code || S.requestId !== requestId) {
    S = window.__pS = {
      code: code, requestId: requestId, filled: false, clicked: false, got: false,
      selClicked: false, selAt: 0, selN: 0, clickAt: 0,
      fillAt: 0, clickAttempts: 0,
      inp: null, name: '', customer: '', lastAmount: ''
    };
  }
  var out = { st: '', name: '', customer: '', amount: '', nf: false, items: [] };
  var BT = null;
  function body(){ if (BT === null) BT = (document.body && document.body.innerText) || ''; return BT; }
  function txt(el){ return String(el && (el.innerText || el.textContent || el.value || '') || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim(); }
  function vis(el){
    if (!el || el.disabled || el.hidden) return false;
    var st = window.getComputedStyle ? getComputedStyle(el) : null;
    if (st && (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0')) return false;
    return !!((el.offsetParent !== null) || (el.getClientRects && el.getClientRects().length));
  }
  function norm(s){ return String(s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim().toLocaleLowerCase('az'); }
  function cleanCode(s){ return String(s || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); }
  function isCode(s){ return /^10011[A-Z0-9]{7}$/.test(cleanCode(s)); }
  function fire(el){
    if (!el) return;
    try { el.scrollIntoView({block:'center', inline:'nearest'}); } catch(e) {}
    try { el.focus(); } catch(e) {}
    var r = el.getBoundingClientRect ? el.getBoundingClientRect() : {left:0,top:0,width:0,height:0};
    var mo = { bubbles:true, cancelable:true, view:window, clientX:r.left+r.width/2, clientY:r.top+r.height/2 };
    ['pointerdown','mousedown','pointerup','mouseup'].forEach(function(n){
      try {
        var E = n.indexOf('pointer') === 0 && window.PointerEvent ? PointerEvent : MouseEvent;
        el.dispatchEvent(new E(n, mo));
      } catch(e) {}
    });
    // Bir dəfə klik et: click event-i ayrıca göndərib .click() da çağırmaq
    // dropdown-u dərhal yenidən bağlaya bilər.
    var didClick = false;
    try { if (typeof el.click === 'function') { el.click(); didClick = true; } } catch(e) {}
    if (!didClick) { try { el.dispatchEvent(new MouseEvent('click', mo)); } catch(e) {} }
  }
  function ownFieldHint(el){
    var a = [el && el.placeholder, el && el.getAttribute('aria-label'), el && el.name,
             el && el.id, el && el.title, el && el.getAttribute('data-testid')];
    try {
      if (el && el.id) {
        var lab = document.querySelector('label[for="' + String(el.id).replace(/"/g, '\\"') + '"]');
        if (lab) a.push(txt(lab));
      }
    } catch(e) {}
    return a.filter(Boolean).join(' ').toLowerCase();
  }
  function fieldHint(el){
    var a = [ownFieldHint(el)];
    try {
      if (el && el.id) {
        var lab = document.querySelector('label[for="' + String(el.id).replace(/"/g, '\\"') + '"]');
        if (lab) a.push(txt(lab));
      }
    } catch(e) {}
    try { if (el && el.parentElement) a.push(txt(el.parentElement).slice(0, 100)); } catch(e) {}
    return a.filter(Boolean).join(' ').toLowerCase();
  }
  function visibleFields(){
    return [].slice.call(document.querySelectorAll('input:not([type=hidden]), textarea, select')).filter(function(i){
      var type = String(i.type || '').toLowerCase();
      return vis(i) && !i.disabled && !i.readOnly && type !== 'button' && type !== 'submit' && type !== 'checkbox' && type !== 'radio';
    });
  }
  function findYvokInput(){
    var fields = visibleFields();
    var scored = fields.map(function(i){
      var h = fieldHint(i), score = 0;
      if (/yv[oö]k|vergi\s*(kod|n[oö]mr)|identifikasiya\s*n[oö]mr/i.test(h)) score += 100;
      if (/axtar|search|telefon|mobil|kart|məbləğ|mebleg|ad.?soyad|müştəri/i.test(h)) score -= 35;
      if (i.tagName === 'SELECT') score -= 10;
      return { el:i, score:score, top:i.getBoundingClientRect().top };
    }).sort(function(a,b){ return b.score-a.score || a.top-b.top; });
    if (scored.length && scored[0].score > 0) return scored[0].el;
    // Label ayrıca elementdədirsə, onu izləyən sahəni tap.
    var labs = [].slice.call(document.querySelectorAll('label,span,div,p,strong,b'));
    for (var j=0; j<labs.length; j++) {
      var l = labs[j], t = norm(txt(l));
      if (!vis(l) || l.children.length > 2 || !/^yv[oö]k\s*:?(\s*daxil edin)?$/i.test(t)) continue;
      var p = l;
      for (var d=0; d<4 && p; d++, p=p.parentElement) {
        var f = p.querySelector && p.querySelector('input:not([type=hidden]),textarea');
        if (f && vis(f) && !f.disabled && !f.readOnly) return f;
      }
    }
    // Son ehtiyat: formadakı ilk adi, görünən və redaktə edilən mətn sahəsi.
    return fields.filter(function(i){ return i.tagName !== 'SELECT'; })[0] || null;
  }
  function setVal(inp){
    if (!inp) return false;
    try { inp.scrollIntoView({block:'center', inline:'nearest'}); } catch(e) {}
    try { inp.focus(); } catch(e) {}
    // React/controlled input-lar üçün native value setter istifadə olunur; sadəcə inp.value yazmaq
    // React-in value tracker-ini yeniləməyə bilər.
    try { inp.dispatchEvent(new InputEvent('beforeinput', {bubbles:true, cancelable:true, inputType:'insertText', data:code})); } catch(e) {}
    var proto = inp.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var desc = Object.getOwnPropertyDescriptor(proto, 'value');
    try { if (desc && desc.set) desc.set.call(inp, code); else inp.value = code; } catch(e) { try { inp.value = code; } catch(ex) {} }
    try {
      inp.dispatchEvent(new InputEvent('input', {bubbles:true, cancelable:false, inputType:'insertText', data:code}));
    } catch(e) {
      try { inp.dispatchEvent(new Event('input', {bubbles:true, cancelable:false})); } catch(ex) {}
    }
    try { inp.dispatchEvent(new KeyboardEvent('keyup', {key:'0', bubbles:true, cancelable:true})); } catch(e) {}
    try { inp.dispatchEvent(new Event('change', {bubbles:true, cancelable:true})); } catch(e) {}
    return cleanCode(inp.value) === cleanCode(code);
  }
  function findAction(re){
    // Əvvəl real düymələr, daha sonra select/dropdown və sonda görünən mətn elementləri.
    var primary = [].slice.call(document.querySelectorAll('button,a,[role=button],input[type=submit],input[type=button],select,[role=combobox]'));
    for (var i=0; i<primary.length; i++) {
      var e = primary[i]; if (!vis(e)) continue;
      var t = norm(e.tagName === 'INPUT' ? (e.value || e.getAttribute('aria-label')) : (txt(e) || e.getAttribute('aria-label') || e.title));
      if (re.test(t)) return e;
      if (e.tagName === 'SELECT' && e.options && e.selectedIndex >= 0 && re.test(norm(e.options[e.selectedIndex].text))) return e;
    }
    var leaf = [].slice.call(document.querySelectorAll('div,span,p,label,strong,b,li'));
    for (var j=0; j<leaf.length; j++) {
      var x = leaf[j]; if (!vis(x) || x.children.length > 0) continue;
      var tx = norm(txt(x));
      if (tx && tx.length < 60 && re.test(tx)) {
        var c = x.closest && x.closest('button,a,[role=button],[onclick],.btn,[class*=btn]');
        return c || x;
      }
    }
    return null;
  }
  function bodyLabelValue(re){
    var lines = body().split(/\r?\n/).map(function(x){ return x.trim(); }).filter(Boolean);
    for (var i=0; i<lines.length; i++) {
      var line = lines[i], m = line.match(re);
      if (!m) continue;
      if (m[1] && m[1].trim()) return m[1].trim();
      for (var k=i+1; k<lines.length && k<=i+3; k++) {
        var n = lines[k].trim(); if (n && !/^müştəri(?:\s+adı)?\s*:?$/i.test(n)) return n;
      }
    }
    return '';
  }
  function nodeValue(el){
    if (!el) return '';
    var raw = txt(el), colon = raw.indexOf(':');
    if (colon >= 0 && raw.slice(colon+1).trim()) return raw.slice(colon+1).trim();
    var id = el.getAttribute && el.getAttribute('for');
    if (id) { var fi = document.getElementById(id); if (fi && txt(fi)) return txt(fi); }
    var p = el;
    for (var d=0; d<4 && p; d++, p=p.parentElement) {
      if (p.nextElementSibling) {
        var nx = p.nextElementSibling;
        var nv = txt(nx);
        if (nv && nv.length < 180 && !/^(müştəri(?:\s+adı)?|ödəniş üçün seçin)\s*:?$/i.test(nv)) return nv;
        var ni = nx.querySelector && nx.querySelector('input,textarea,select');
        if (ni && txt(ni)) return txt(ni);
      }
      var vals = p.querySelectorAll ? p.querySelectorAll('input:not([type=hidden]),textarea,select,[data-value]') : [];
      for (var z=0; z<vals.length; z++) {
        var v = txt(vals[z]);
        if (v && v !== code && v.length < 180 && !/^müştəri(?:\s+adı)?$/i.test(v)) return v;
      }
    }
    return '';
  }
  function labelValue(re){
    var direct = bodyLabelValue(re);
    if (direct) return direct;
    var els = [].slice.call(document.querySelectorAll('label,dt,th,td,strong,b,span,p,div,li'));
    var matches = [];
    for (var i=0; i<els.length; i++) {
      var e=els[i], t=txt(e);
      if (!vis(e) || !t || t.length > 90) continue;
      if (re.test(t)) matches.push({el:e, len:t.length, t:t});
    }
    matches.sort(function(a,b){ return a.len-b.len; });
    for (var j=0; j<matches.length; j++) {
      var got = nodeValue(matches[j].el);
      if (got) return got;
    }
    return '';
  }
  function amountsFromText(t){
    var re=/([-−–+]?\s*\d[\d\s.,]*)\s*(?:azn|₼)/ig, m, result=[];
    t = String(t || '');
    while ((m=re.exec(t))) {
      var a = m[1].replace(/[\s\u00a0]/g,'').replace(/[−–]/g,'-').replace(',', '.');
      if (a && !result.includes(a)) result.push(a);
    }
    return result;
  }
  function amountFieldValue(){
    var fields = [].slice.call(document.querySelectorAll('input:not([type=hidden]),textarea,select'));
    // Əvvəl yalnız Məbləğ (AZN) sahəsinə bağlı input-u axtarırıq.
    for (var i=0;i<fields.length;i++) {
      var f=fields[i]; if (!vis(f)) continue;
      var hint=ownFieldHint(f);
      if (!/məbləğ|mebleg|amount|borc/i.test(hint)) continue;
      var v=txt(f).replace(/[\s\u00a0]/g,'').replace(',', '.');
      if (/^[+−–-]?\d+(?:\.\d+)?$/.test(v)) return v.replace(/[−–]/g,'-');
    }
    // Label-in dərhal yanında, input-un value atributunda saxlanılan məbləğ.
    var l = [].slice.call(document.querySelectorAll('label,span,div,p,strong,b,td,th')).filter(function(e){
      return vis(e) && txt(e).length < 55 && /məbləğ\s*\(?\s*azn\s*\)?|mebleg\s*\(?\s*azn\s*\)?/i.test(txt(e));
    }).sort(function(a,b){ return txt(a).length-txt(b).length; });
    for (var j=0;j<l.length;j++) {
      var p=l[j];
      for (var d=0; d<4 && p; d++,p=p.parentElement) {
        var ins=p.querySelectorAll ? p.querySelectorAll('input:not([type=hidden]),textarea') : [];
        for (var k=0;k<ins.length;k++) {
          var x=txt(ins[k]).replace(/[\s\u00a0]/g,'').replace(',', '.');
          if (/^[+−–-]?\d+(?:\.\d+)?$/.test(x)) return x.replace(/[−–]/g,'-');
        }
      }
    }
    return '';
  }
  function listAmounts(){
    var result=[];
    // Açılmış dropdown və select option-larında göstərilən qiymətlər.
    var nodes=[].slice.call(document.querySelectorAll('option,li,[role=option],[role=listbox] *,[class*=dropdown] *,[class*=select] *,[class*=option] *'));
    for (var i=0;i<nodes.length;i++) {
      var e=nodes[i], t=txt(e); if (!t || t.length>160) continue;
      var vals=amountsFromText(t);
      vals.forEach(function(v){ if (!result.includes(v)) result.push(v); });
    }
    // Bəzi Portmanat seçimləri AZN mətnini input value-sunda saxlayır.
    var fields=[].slice.call(document.querySelectorAll('input,textarea,select'));
    for (var j=0;j<fields.length;j++) {
      var f=fields[j]; if (!vis(f)) continue;
      var hint=ownFieldHint(f), val=txt(f);
      if (/məbləğ|mebleg|amount|borc/i.test(hint)) {
        val=val.replace(/[\s\u00a0]/g,'').replace(',', '.');
        if (/^[+−–-]?\d+(?:\.\d+)?$/.test(val) && !result.includes(val)) result.push(val.replace(/[−–]/g,'-'));
      }
      if (f.tagName==='SELECT' && f.options) {
        for (var o=0;o<f.options.length;o++) {
          var ov=amountsFromText(txt(f.options[o]));
          ov.forEach(function(v){ if (!result.includes(v)) result.push(v); });
        }
      }
    }
    return result;
  }
  // "Ödəniş üçün seçin" siyahısında AZN olan TAM sətri götürürük:
  // məsələn «-24 AZN - 20000100 - Bələdiyyə torpaq vergisi».
  // Məbləği ayrıca göstərən daxili span-ları seçmirik; kod və təsvir də eyni sətirdə qalmalıdır.
  function listItems(){
    var result=[];
    var money=/[-−–+]?\s*\d[\d\s.,]*\s*(?:azn|₼)/ig;
    function isFullLine(t){
      if (!t || t.length>200) return false;
      var matches=t.match(money);
      if (!matches || matches.length!==1) return false;
      var rest=t.replace(/[-−–+]?\s*\d[\d\s.,]*\s*(?:azn|₼)/i,' ')
                .replace(/[\s:–—|_-]+/g,' ').trim();
      return /[A-Za-z\u00C0-\u024F]/.test(rest); // köhnə Android WebView-larla uyğunluq
    }
    function collect(nodes){
      var picked=[];
      nodes.forEach(function(e){
        var t=txt(e);
        if (!isFullLine(t)) return;
        // Eyni sətrin parent/child elementlərindən yalnız ən yuxarı bütöv sətri saxla.
        if (picked.some(function(x){ return x.el.contains(e); })) return;
        picked.push({el:e, text:t});
      });
      picked.forEach(function(x){ if (result.indexOf(x.text)<0) result.push(x.text); });
    }
    // Əvvəl semantik seçim elementləri: option, li və ya option sinifli sətirlər.
    collect([].slice.call(document.querySelectorAll('option,li,[role=option],[class*=option]')));
    // Sayt semantik option istifadə etmirsə, dropdown daxilindəki ən yaxın tam sətrləri tap.
    if (!result.length) {
      collect([].slice.call(document.querySelectorAll('[role=listbox] *,[class*=dropdown],[class*=dropdown] *,[class*=select],[class*=select] *,div,span,p')));
    }
    if (!result.length) body().split(/\r?\n/).forEach(function(t){
      t=String(t||'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
      if (isFullLine(t) && result.indexOf(t)<0) result.push(t);
    });
    var fields=[].slice.call(document.querySelectorAll('select'));
    fields.forEach(function(f){
      if (!f.options) return;
      for (var o=0;o<f.options.length;o++) {
        var t=txt(f.options[o]);
        if (isFullLine(t) && result.indexOf(t)<0) result.push(t);
      }
    });
    return result;
  }
  function foundNotFound(){
    return /tapılmad[ıi]|tapılmay[ıi]b|mövcud deyil|məlumat yoxdur|düzgün deyil|abonent\s+tapılmad/i.test(body());
  }

  // SPA/React səhifəsi tam yaranana qədər heç bir input-u səhvən seçmə.
  if (document.readyState === 'loading' || !document.body || !String(document.body.innerText || '').trim()) {
    out.st='load'; return JSON.stringify(out);
  }

  // 1. Hər yoxlamada sahəni təzədən tap: React sahəni yenidən render edərsə əvvəlki DOM elementi köhnəlir.
  var y = findYvokInput();
  if (!S.clicked) {
    if (!y) { S.filled=false; out.st='wait_input'; return JSON.stringify(out); }
    S.inp = y;
    if (cleanCode(y.value) !== cleanCode(code)) {
      // Uğursuz yazını hər 60 ms-də təkrar etmə; React-in əvvəlki renderini qəbul etməsi üçün vaxt ver.
      if (!S.fillAt || Date.now() - S.fillAt >= 300) {
        S.filled = setVal(y);
        S.fillAt = Date.now();
        out.st = S.filled ? 'filled' : 'fill_retry';
      } else out.st='fill_wait';
      return JSON.stringify(out);
    }
    S.filled = true;
    // Dəyərin React vəziyyətində də sabit qalması üçün yazılışdan sonra azı 350 ms gözlə.
    if (!S.fillAt) S.fillAt = Date.now();
    if (Date.now() - S.fillAt < 350) { out.st='filled_wait'; return JSON.stringify(out); }

    var b = findAction(/^davam\s*et(?:mək)?$/i);
    if (!b || b.disabled || b.getAttribute('aria-disabled') === 'true') {
      out.st='wait_continue'; return JSON.stringify(out);
    }
    // Ən vacib qoruma: hazırkı görünən sahədə dəqiq həmin YVÖK yoxlanmadan düyməyə toxunma.
    if (cleanCode(y.value) !== cleanCode(code)) { S.filled=false; out.st='verify_retry'; return JSON.stringify(out); }
    S.clicked=true; S.clickAttempts=1; S.clickAt=Date.now(); fire(b);
    out.st='clicked'; return JSON.stringify(out);
  }

  // 3. Müştəri/YVÖK məlumatları bəzən DOM mətni, bəzən input value-sunda olur.
  if (!S.got) {
    var a = labelValue(/^müştəri\s*adı\s*:?\s*(.*)$/i);
    var b2 = labelValue(/^müştəri(?!\s+adı)\s*:?\s*(.*)$/i);
    if (!a) a = bodyLabelValue(/^müştəri\s*adı\s*:?\s*(.*)$/i);
    if (!b2) b2 = bodyLabelValue(/^müştəri(?!\s+adı)\s*:?\s*(.*)$/i);
    var ca = cleanCode(a), cb = cleanCode(b2);
    if (isCode(a) && !isCode(b2)) { S.customer=a.trim(); S.name=b2.trim(); }
    else if (isCode(b2) && !isCode(a)) { S.customer=b2.trim(); S.name=a.trim(); }
    else if (a && b2) { S.customer=a.trim(); S.name=b2.trim(); }
    else if (a && !isCode(a)) { S.name=a.trim(); }
    else if (b2 && !isCode(b2)) { S.name=b2.trim(); }
    // Sayt yalnız bir sahəni qaytararsa, səhifədəki YVÖK sahəsi kodu təsdiqləmək üçün saxlanılır.
    if (S.name && isCode(S.name)) S.name='';
    if (S.name) {
      if (!S.customer && S.inp && cleanCode(S.inp.value) === cleanCode(code)) S.customer=code;
      S.got=true;
    }
  }
  out.name=S.name || '';
  out.customer=S.customer || '';

  // İlk klikdən sonra səhifə eyni formada qalıbsa bir dəfə yenidən cəhd et.
  // Nəticə/ödəniş mərhələsinə keçibsə YVÖK sahəsi və ya Davam Et düyməsi artıq tapılmayacaq.
  if (!S.name && Date.now() - S.clickAt >= 2800 && S.clickAttempts < 2) {
    var stillY = findYvokInput();
    var stillB = findAction(/^davam\s*et(?:mək)?$/i);
    if (stillY && cleanCode(stillY.value) === cleanCode(code) && stillB && !stillB.disabled
        && stillB.getAttribute('aria-disabled') !== 'true') {
      S.clickAttempts++; S.clickAt=Date.now(); fire(stillB);
      out.st='clicked_retry'; return JSON.stringify(out);
    }
  }

  // 4. "Ödəniş üçün seçin" seçimini aç; yalnız məlumat oxunur, ödəniş əməliyyatı edilmir.
  if (!S.selClicked) {
    var sb=findAction(/^ödəniş\s*üçün\s*seçin$/i);
    if (!sb) {
      if (Date.now()-S.clickAt > 2000 && foundNotFound()) out.nf=true;
      out.st='waiting'; return JSON.stringify(out);
    }
    S.selClicked=true; S.selAt=Date.now(); S.selN=1;
    fire(sb);
    out.st='selected'; return JSON.stringify(out);
  }

  // 5. Məbləği sahədən, seçim siyahısından və ya AZN ilə göstərilən nəticədən götür.
  var fieldAmount=amountFieldValue();
  var list=listAmounts();
  var fromText=amountsFromText(body());
  var aList=[];
  if (fieldAmount) aList.push(fieldAmount);
  list.forEach(function(x){ if (!aList.includes(x)) aList.push(x); });
  fromText.forEach(function(x){ if (!aList.includes(x)) aList.push(x); });
  if (aList.length) {
    out.amount=aList.join(' | ');
    out.items=listItems();
    S.lastAmount=out.amount;
    out.st='result';
    return JSON.stringify(out);
  }
  // Bəzi səhifələrdə klikdən sonra dropdown açılmaya bilər; bir neçə dəfə yenidən cəhd et.
  if (Date.now()-S.selAt >= 1800 && S.selN < 3) {
    var sb2=findAction(/^ödəniş\s*üçün\s*seçin$/i);
    if (sb2) {
      S.selN++; S.selAt=Date.now(); fire(sb2);
      out.st='selected'; return JSON.stringify(out);
    }
  }
  if (Date.now()-S.clickAt >= 2000 && foundNotFound()) out.nf=true;
  out.st='waiting';
  return JSON.stringify(out);
})('__CODE__','__REQ_ID__')
