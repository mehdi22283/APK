package az.mehdi.iptvplayer

import android.app.ActivityManager
import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.util.Log
import android.view.Display
import java.util.Locale

/**
 * TV (Google TV / Android TV) aşkarlanması və cihazın imkanları (TCL 65C6K: MediaTek MT9653, 3 GB RAM,
 * 4K@144 Hz, HDR10/HDR10+/HLG/Dolby Vision). Heç bir modelə sərt bağlı deyil: dəyərlər icra zamanı sistemdən oxunur.
 *
 * TV-nin şəkil mühərriki (AiPQ AI upscaling, MEMC, local dimming, Dolby Vision IQ) yalnız MediaCodec (hardware)
 * dekoderinin kadrlarını SurfaceView üzərindən aldığı halda işləyir; bu sinif həmin yolu qorumaq üçün qərarlara kömək edir.
 */
object TvProfile {
    private const val TAG = "IPTV-TV"

    class Info(
        val isTv: Boolean,
        val totalMemMb: Long,
        val maxRefreshHz: Float,
        val hdrTypes: List<String>
    ) {
        fun describe(): String =
            "TV=$isTv RAM=${totalMemMb}MB maxHz=${String.format(Locale.US, "%.0f", maxRefreshHz)} HDR=${hdrTypes.ifEmpty { listOf("yoxdur") }}"
    }

    @Volatile private var cached: Info? = null

    fun of(context: Context): Info {
        cached?.let { return it }
        val c = context.applicationContext
        val info = Info(
            isTv = detectTv(c),
            totalMemMb = totalMemMb(c),
            maxRefreshHz = maxRefresh(c),
            hdrTypes = hdrTypes(c)
        )
        cached = info
        Log.i(TAG, info.describe())
        return info
    }

    private fun detectTv(c: Context): Boolean {
        val ui = runCatching { (c.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager)?.currentModeType }.getOrNull()
        if (ui == Configuration.UI_MODE_TYPE_TELEVISION) return true
        val pm = c.packageManager
        return pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) || pm.hasSystemFeature("android.hardware.type.television")
    }

    private fun totalMemMb(c: Context): Long = runCatching {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        mi.totalMem / (1024L * 1024L)
    }.getOrDefault(0L)

    private fun display(c: Context): Display? = runCatching {
        (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
    }.getOrNull()

    private fun maxRefresh(c: Context): Float = runCatching {
        display(c)?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 60f
    }.getOrDefault(60f)

    /**
     * TV-nin yuxarı miqyaslaması (AiPQ AI upscaling) üçün: ekran çıxışı 4K-dan aşağıdırsa (məs. TV 1080p-yə qurulubsa)
     * eyni (ya ən yaxın) yenilənmə tezlikli 4K (≥2160p) rejimin id-si qaytarılır. Artıq 4K-dırsa və ya 4K rejim yoxdursa null.
     * Kadrı tətbiq özü böyütmür: video hardware qatda (SurfaceView) qalır, miqyaslamanı TV-nin şəkil mühərriki edir.
     */
    fun uhdModeId(c: Context): Int? = runCatching {
        val d = display(c) ?: return@runCatching null
        val cur = d.mode
        if (maxOf(cur.physicalWidth, cur.physicalHeight) >= 3840) return@runCatching null
        d.supportedModes
            .filter { maxOf(it.physicalWidth, it.physicalHeight) >= 3840 }
            .minByOrNull { Math.abs(it.refreshRate - cur.refreshRate) }
            ?.modeId
    }.getOrNull()

    @Suppress("DEPRECATION")
    private fun hdrTypes(c: Context): List<String> = runCatching {
        display(c)?.hdrCapabilities?.supportedHdrTypes?.map {
            when (it) {
                1 -> "DolbyVision"
                2 -> "HDR10"
                3 -> "HLG"
                4 -> "HDR10+"
                else -> "type$it"
            }
        } ?: emptyList()
    }.getOrDefault(emptyList())

    /**
     * Video bufer həddi (bayt). 4K IPTV axınları (25–50 Mbit/s) 24 MB-a yalnız ~4–8 s sığır;
     * ≥ ~2.2 GB RAM-lı TV-də (TCL 65C6K: 3 GB) 48 MB, digər cihazlarda əvvəlki 24 MB.
     */
    fun targetBufferBytes(c: Context): Int {
        val i = of(c)
        return if (i.isTv && i.totalMemMb >= 2_200L) 48 * 1024 * 1024 else 24 * 1024 * 1024
    }

    /** Proqram (CPU) video dekoderi? Belə dekoderin kadrları TV-nin hardware şəkil yolundan (AI upscaling, HDR) keçmir. */
    fun isSoftwareDecoder(name: String): Boolean {
        val n = name.lowercase(Locale.ROOT)
        return n.contains("ffmpeg") || n.contains("dav1d") || n.startsWith("c2.android.") || n.startsWith("omx.google.") ||
            n.contains("libgav1") || n.contains("software")
    }
}
