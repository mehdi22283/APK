package az.mehdi.iptvplayer

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.tvprovider.media.tv.PreviewChannel
import androidx.tvprovider.media.tv.PreviewChannelHelper
import androidx.tvprovider.media.tv.PreviewProgram
import androidx.tvprovider.media.tv.TvContractCompat

/**
 * Android TV / Google TV ana ekranı (launcher): "Mehdi Player" adlı kanal sətri.
 * Sətirdə playlistdəki kanallar (ən çox [MAX_ITEMS]) kart kimi görünür; karta basanda tətbiq açılır və həmin kanal oynadılır.
 * Playlist dəyişəndə sətir yenilənir (dəyişiklik yoxdursa toxunulmur). Sətir ilk dəfə yaradılanda sistem
 * "ana ekrana əlavə edilsin?" soruşa bilər. Yalnız TV cihazında və Android 8.0+ üzərində işləyir.
 */
object ChannelRow {
    private const val TAG = "IPTV-ROW"
    private const val PREFS = "channel_row"
    private const val KEY_ID = "channel_id"
    private const val KEY_SIG = "sig"
    private const val KEY_ASKED = "asked_id"
    private const val MAX_ITEMS = 100

    /** [onAskBrowsable]: yeni sətir ana ekranda görünən deyilsə, sistemdən icazə istəmək üçün (kanal id-si ilə) bir dəfə çağırılır. */
    fun publish(context: Context, channels: List<Channel>, onAskBrowsable: (Long) -> Unit) {
        if (Build.VERSION.SDK_INT < 26 || channels.isEmpty()) return
        val app = context.applicationContext
        if (!TvProfile.of(app).isTv) return
        val list = channels.take(MAX_ITEMS).toList()
        Thread {
            runCatching { publishNow(app, list, onAskBrowsable) }
                .onFailure { Log.w(TAG, "Kanal sətri yazılmadı: ${it.javaClass.simpleName}: ${it.message}") }
        }.apply { isDaemon = true; name = "iptv-row" }.start()
    }

    private fun channelExists(app: Context, id: Long): Boolean =
        runCatching {
            app.contentResolver.query(TvContractCompat.buildChannelUri(id), arrayOf(TvContractCompat.Channels._ID), null, null, null)
                ?.use { it.count > 0 } ?: false
        }.getOrDefault(false)

    private fun isBrowsable(app: Context, id: Long): Boolean =
        runCatching {
            app.contentResolver.query(TvContractCompat.buildChannelUri(id), arrayOf(TvContractCompat.Channels.COLUMN_BROWSABLE), null, null, null)
                ?.use { it.moveToFirst() && it.getInt(0) == 1 } ?: false
        }.getOrDefault(false)

    private fun iconBitmap(app: Context): Bitmap {
        val size = 160
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        ContextCompat.getDrawable(app, R.mipmap.ic_launcher)?.let { d ->
            d.setBounds(0, 0, size, size)
            d.draw(Canvas(b))
        }
        return b
    }

    @Synchronized
    private fun publishNow(app: Context, list: List<Channel>, onAskBrowsable: (Long) -> Unit) {
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val helper = PreviewChannelHelper(app)
        var id = prefs.getLong(KEY_ID, -1L)
        // İstifadəçi sətri ana ekrandan tamam silibsə yenidən yaradılır.
        if (id != -1L && !channelExists(app, id)) id = -1L
        if (id == -1L) {
            val ch = PreviewChannel.Builder()
                .setDisplayName("Mehdi Player")
                .setDescription("TV kanalları")
                .setAppLinkIntent(Intent(app, MainActivity::class.java))
                .setLogo(iconBitmap(app))
                .build()
            id = helper.publishChannel(ch)
            prefs.edit().putLong(KEY_ID, id).remove(KEY_SIG).apply()
            Log.i(TAG, "Kanal sətri yaradıldı (id=$id)")
        }
        if (!isBrowsable(app, id) && prefs.getLong(KEY_ASKED, -1L) != id) {
            prefs.edit().putLong(KEY_ASKED, id).apply()
            onAskBrowsable(id)
        }

        val sig = list.joinToString("\n") { "${it.group}|${it.name}|${it.url}|${it.logo.orEmpty()}" }.hashCode().toString() + ":" + list.size
        if (prefs.getString(KEY_SIG, null) == sig) return

        // Köhnə kartlar silinir, playlist sırası ilə yenidən yazılır.
        app.contentResolver.delete(TvContractCompat.buildPreviewProgramsUriForChannel(id), null, null)
        val banner = Uri.parse("android.resource://${app.packageName}/drawable/tv_banner")
        for (ch in list) {
            val open = Intent(app, MainActivity::class.java).apply {
                action = WatchNext.ACTION_PLAY
                putExtra(WatchNext.EXTRA_URL, ch.url)
                putExtra(WatchNext.EXTRA_NAME, ch.name)
                putExtra(WatchNext.EXTRA_GROUP, ch.group)
            }
            val logo = ch.logo?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val program = PreviewProgram.Builder()
                .setChannelId(id)
                .setType(TvContractCompat.PreviewPrograms.TYPE_CLIP)
                .setTitle(ch.name)
                .setDescription(ch.group)
                .setPosterArtUri(logo?.let { Uri.parse(it) } ?: banner)
                .setPosterArtAspectRatio(
                    if (logo != null) TvContractCompat.PreviewPrograms.ASPECT_RATIO_1_1
                    else TvContractCompat.PreviewPrograms.ASPECT_RATIO_16_9
                )
                .setInternalProviderId("${ch.group}|${ch.name}")
                .setIntentUri(Uri.parse(open.toUri(Intent.URI_INTENT_SCHEME)))
                .build()
            runCatching { helper.publishPreviewProgram(program) }
                .onFailure { Log.w(TAG, "Kart yazılmadı (${ch.name}): ${it.message}") }
        }
        prefs.edit().putString(KEY_SIG, sig).apply()
        Log.i(TAG, "Kanal sətri yeniləndi: ${list.size} kart")
    }
}
