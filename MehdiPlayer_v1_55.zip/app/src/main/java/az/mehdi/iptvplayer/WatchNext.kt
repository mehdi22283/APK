package az.mehdi.iptvplayer

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.tvprovider.media.tv.TvContractCompat
import androidx.tvprovider.media.tv.WatchNextProgram

/**
 * Android TV / Google TV ana ekranı: son izlənən kanallar "Watch Next" (Continue watching) cərgəsində görünür.
 * Kanal 20 saniyədən çox izlənəndə cərgəyə yazılır (sürətli dəyişmədə hər kanal yazılmır); ən çox [MAX_ITEMS] kanal saxlanılır.
 * Cərgədəki kartı seçəndə tətbiq açılır və həmin kanal oynadılır ([ACTION_PLAY]).
 * Yalnız TV cihazında və Android 8.0+ (API 26) üzərində işləyir; xəta olarsa oynatmaya təsir etmir.
 */
object WatchNext {
    private const val TAG = "IPTV-WATCHNEXT"
    const val ACTION_PLAY = "az.mehdi.iptvplayer.action.PLAY_CHANNEL"
    const val EXTRA_URL = "wn_url"
    const val EXTRA_NAME = "wn_name"
    const val EXTRA_GROUP = "wn_group"

    /** Kanal 20 s izlənəndən sonra cərgəyə yazılır. */
    const val DELAY_MS = 20_000L
    private const val MAX_ITEMS = 5
    private const val PREFS = "watch_next"
    private const val KEY_ITEMS = "items"

    /** Kanalı Watch Next cərgəsinə yazır/yeniləyir (arxa thread-də). */
    fun publish(context: Context, ch: Channel, playGroup: String?) {
        if (Build.VERSION.SDK_INT < 26) return
        val app = context.applicationContext
        if (!TvProfile.of(app).isTv) return
        Thread {
            runCatching { publishNow(app, ch, playGroup) }
                .onFailure { Log.w(TAG, "Watch Next yazılmadı: ${it.javaClass.simpleName}: ${it.message}") }
        }.apply { isDaemon = true; name = "iptv-watchnext" }.start()
    }

    // ---- Google TV ana səhifəsi: playlist sırası ----
    // Google TV üçüncü tərəf "preview channel" sətirlərini və vidjetləri ana ekranda göstərmir; yalnız "Watch Next"
    // (Continue watching) cərgəsi görünür. Playlistin ilk kanalları orada nömrə və playlist sırası ilə yazılır.
    const val ORDER_COUNT = 12
    private const val PREFS_ORDER = "watch_next_order"
    private const val KEY_ORDER_SIG = "sig"
    private const val KEY_ORDER_IDS = "ids"

    fun publishOrder(context: Context, channels: List<Channel>) {
        if (Build.VERSION.SDK_INT < 26 || channels.isEmpty()) return
        val app = context.applicationContext
        if (!TvProfile.of(app).isTv) return
        val list = channels.take(ORDER_COUNT).toList()
        Thread {
            runCatching { publishOrderNow(app, list) }
                .onFailure { Log.w(TAG, "Watch Next sırası yazılmadı: ${it.javaClass.simpleName}: ${it.message}") }
        }.apply { isDaemon = true; name = "iptv-watchnext-order"; priority = Thread.MIN_PRIORITY }.start()
    }

    @Synchronized
    private fun publishOrderNow(app: Context, list: List<Channel>) {
        val resolver = app.contentResolver
        val prefs = app.getSharedPreferences(PREFS_ORDER, Context.MODE_PRIVATE)
        val sig = list.joinToString("\n") { "${it.number}|${it.group}|${it.name}|${it.url}|${it.logo.orEmpty()}" }.hashCode().toString() + ":" + list.size
        if (prefs.getString(KEY_ORDER_SIG, null) == sig) return
        // Köhnə sıra kartları silinir, playlist sırası ilə yenidən yazılır.
        prefs.getString(KEY_ORDER_IDS, "")!!.split(',').mapNotNull { it.toLongOrNull() }.forEach { id ->
            runCatching { resolver.delete(TvContractCompat.buildWatchNextProgramUri(id), null, null) }
        }
        val banner = Uri.parse("android.resource://${app.packageName}/drawable/tv_banner")
        // Ən yeni vaxt cərgənin əvvəlində görünür: 1-ci kanal ən yeni vaxtla yazılır.
        val base = System.currentTimeMillis()
        val ids = ArrayList<Long>()
        list.forEachIndexed { i, ch ->
            val open = Intent(app, MainActivity::class.java).apply {
                action = ACTION_PLAY
                putExtra(EXTRA_URL, ch.url)
                putExtra(EXTRA_NAME, ch.name)
                putExtra(EXTRA_GROUP, ch.group)
            }
            val logo = ch.logo?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val program = WatchNextProgram.Builder()
                .setType(TvContractCompat.PreviewPrograms.TYPE_CLIP)
                .setWatchNextType(TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE)
                .setLastEngagementTimeUtcMillis(base - i * 1000L)
                .setTitle("${ch.number} · ${ch.name}")
                .setDescription(ch.group)
                .setPosterArtUri(logo?.let { Uri.parse(it) } ?: banner)
                .setPosterArtAspectRatio(
                    if (logo != null) TvContractCompat.PreviewPrograms.ASPECT_RATIO_1_1
                    else TvContractCompat.PreviewPrograms.ASPECT_RATIO_16_9
                )
                .setInternalProviderId("order|${ch.group}|${ch.name}")
                .setIntentUri(Uri.parse(open.toUri(Intent.URI_INTENT_SCHEME)))
                .build()
            runCatching { resolver.insert(TvContractCompat.WatchNextPrograms.CONTENT_URI, program.toContentValues()) }
                .getOrNull()?.let { ids.add(ContentUris.parseId(it)) }
        }
        prefs.edit().putString(KEY_ORDER_IDS, ids.joinToString(",")).putString(KEY_ORDER_SIG, sig).apply()
        Log.i(TAG, "Watch Next sırası yeniləndi: ${ids.size} kart")
    }

    /** Eyni kanal (ad + qrup) həmişə eyni kart olur; link dəyişsə də təkrarlanmır. */
    private fun keyOf(ch: Channel) = "${ch.group}|${ch.name}"

    @Synchronized
    private fun publishNow(app: Context, ch: Channel, playGroup: String?) {
        val resolver = app.contentResolver
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        // Saxlanılan kartlar: köhnədən yeniyə, hər sətir "açar<TAB>proqramId".
        val items = LinkedHashMap<String, Long>()
        prefs.getString(KEY_ITEMS, "")!!.lineSequence().forEach { line ->
            val p = line.split('\t')
            if (p.size == 2) p[1].toLongOrNull()?.let { items[p[0]] = it }
        }

        val key = keyOf(ch)
        val open = Intent(app, MainActivity::class.java).apply {
            action = ACTION_PLAY
            putExtra(EXTRA_URL, ch.url)
            putExtra(EXTRA_NAME, ch.name)
            putExtra(EXTRA_GROUP, playGroup ?: "")
        }
        val logo = ch.logo?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        val poster = logo?.let { Uri.parse(it) } ?: Uri.parse("android.resource://${app.packageName}/drawable/tv_banner")
        val program = WatchNextProgram.Builder()
            .setType(TvContractCompat.PreviewPrograms.TYPE_CLIP)
            .setWatchNextType(TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE)
            .setLastEngagementTimeUtcMillis(System.currentTimeMillis())
            .setTitle(ch.name)
            .setDescription(ch.group)
            .setPosterArtUri(poster)
            .setPosterArtAspectRatio(
                if (logo != null) TvContractCompat.PreviewPrograms.ASPECT_RATIO_1_1
                else TvContractCompat.PreviewPrograms.ASPECT_RATIO_16_9
            )
            .setInternalProviderId(key)
            .setIntentUri(Uri.parse(open.toUri(Intent.URI_INTENT_SCHEME)))
            .build()
        val values = program.toContentValues()

        var id = items[key]
        var updated = false
        if (id != null) {
            updated = resolver.update(TvContractCompat.buildWatchNextProgramUri(id), values, null, null) > 0
        }
        if (!updated) {
            // Yeni kart (və ya istifadəçi köhnəsini cərgədən silib).
            val uri = resolver.insert(TvContractCompat.WatchNextPrograms.CONTENT_URI, values) ?: return
            id = ContentUris.parseId(uri)
        }
        items.remove(key)
        items[key] = id!!

        // Ən çox MAX_ITEMS kart: ən köhnələri silinir.
        while (items.size > MAX_ITEMS) {
            val oldest = items.entries.first()
            runCatching { resolver.delete(TvContractCompat.buildWatchNextProgramUri(oldest.value), null, null) }
            items.remove(oldest.key)
        }
        prefs.edit().putString(KEY_ITEMS, items.entries.joinToString("\n") { "${it.key}\t${it.value}" }).apply()
        Log.i(TAG, "${if (updated) "Yeniləndi" else "Əlavə edildi"}: ${ch.name} (kart sayı ${items.size})")
    }
}
