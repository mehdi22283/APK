package az.mehdi.iptvplayer

import android.content.Context
import java.security.MessageDigest

/**
 * Bufer səviyyələri (kanal başına). 0 = normal (sürətli açılış), 1 = orta, 2 = böyük.
 * Kanal 2 dəqiqədə 3 dəfə buferlənərsə səviyyə bir pillə qalxır; 20 dəqiqə buferlənmədən işləyərsə bir pillə düşür.
 */
object BufferProfile {
    const val MAX_LEVEL = 2
    /** Yayımın başlaması üçün lazım olan bufer (ms). */
    fun startMs(level: Int): Int = when (level) { 0 -> 1_000; 1 -> 2_000; else -> 3_000 }
    /** Buferlənmədən sonra davam etmək üçün lazım olan bufer (ms). */
    fun rebufferMs(level: Int): Int = when (level) { 0 -> 2_500; 1 -> 6_000; else -> 12_000 }
}

/**
 * Kanalın bufer səviyyəsini yadda saxlayır (kanal linki → 0/1/2). Yalnız UI thread-i.
 * Açar linkin qısa MD5-idir; ehtiyat (yoda.az tokenli) linklər saxlanmır.
 */
class BufferMemory(context: Context) {
    private companion object {
        const val PREFS = "buffer_memory_v1"
        const val MAX_ENTRIES = 4_000
    }

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val cache = HashMap<String, Int>()

    init {
        runCatching {
            for ((k, v) in prefs.all) if (v is Int) cache[k] = v
            if (cache.size > MAX_ENTRIES) { cache.clear(); prefs.edit().clear().apply() }
        }
    }

    private fun key(url: String): String {
        val d = MessageDigest.getInstance("MD5").digest(url.trim().toByteArray())
        val sb = StringBuilder(16)
        for (i in 0 until 8) sb.append(String.format("%02x", d[i]))
        return sb.toString()
    }

    fun level(url: String): Int = (cache[key(url)] ?: 0).coerceIn(0, BufferProfile.MAX_LEVEL)

    fun set(url: String, level: Int) {
        val k = key(url)
        val l = level.coerceIn(0, BufferProfile.MAX_LEVEL)
        if (l == 0) {
            if (cache.remove(k) != null) runCatching { prefs.edit().remove(k).apply() }
            return
        }
        if (cache[k] == l) return
        cache[k] = l
        runCatching { prefs.edit().putInt(k, l).apply() }
    }
}
