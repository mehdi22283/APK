package az.mehdi.iptvplayer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi

/**
 * Dolby / DTS passthrough: AC3, E-AC3 (Dolby Digital Plus), DTS və DTS-HD səsi dekod edilmədən (bitstream) TV-yə / səs sisteminə ötürülür.
 *
 * Media3-də passthrough MediaCodec səs yolunun (NORMAL rejim) daxilindədir: cihaz bu formatı "birbaşa" oynada bilirsə
 * (`AudioTrack` ENCODING_AC3 / E_AC3 / DTS ...), ExoPlayer dekoder əvəzinə passthrough seçir; bilmirsə FFmpeg dekoderi PCM-ə çevirir.
 * Bu sinif iki iş görür: (1) cihazın nəyi birbaşa oynada bildiyini sistemdən oxuyur (log + məlumat üçün),
 * (2) hazırkı AudioTrack-in kodlaşdırmasına görə passthrough-un həqiqətən işlədiyini müəyyən edir ([isPassthroughEncoding]).
 */
@androidx.annotation.OptIn(UnstableApi::class)
object AudioPassthrough {
    private const val TAG = "IPTV-PASSTHROUGH"

    class Caps(val ac3: Boolean, val eac3: Boolean, val dts: Boolean, val dtsHd: Boolean, val trueHd: Boolean) {
        val any: Boolean get() = ac3 || eac3 || dts || dtsHd || trueHd
        fun describe(): String =
            listOfNotNull(
                "AC3".takeIf { ac3 }, "EAC3".takeIf { eac3 }, "DTS".takeIf { dts },
                "DTS-HD".takeIf { dtsHd }, "TrueHD".takeIf { trueHd }
            ).ifEmpty { listOf("yoxdur") }.joinToString(" ")
    }

    @Volatile private var cached: Caps? = null
    @Volatile private var cachedAt = 0L

    /** Cihazın birbaşa (passthrough) oynada bildiyi formatlar. HDMI/ARC dəyişə bilər: 30 s keşlənir. */
    fun caps(context: Context): Caps {
        val now = System.currentTimeMillis()
        cached?.let { if (now - cachedAt < 30_000L) return it }
        val c = detect(context.applicationContext)
        if (cached == null || cached?.describe() != c.describe()) Log.i(TAG, "Birbaşa oynatma dəstəyi: ${c.describe()}")
        cached = c
        cachedAt = now
        return c
    }

    private fun detect(c: Context): Caps {
        if (Build.VERSION.SDK_INT >= 29) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                .build()
            fun direct(enc: Int, mask: Int): Boolean = runCatching {
                val f = AudioFormat.Builder().setEncoding(enc).setSampleRate(48_000).setChannelMask(mask).build()
                AudioTrack.isDirectPlaybackSupported(f, attrs)
            }.getOrDefault(false)
            return Caps(
                ac3 = direct(AudioFormat.ENCODING_AC3, AudioFormat.CHANNEL_OUT_5POINT1),
                eac3 = direct(AudioFormat.ENCODING_E_AC3, AudioFormat.CHANNEL_OUT_5POINT1),
                dts = direct(AudioFormat.ENCODING_DTS, AudioFormat.CHANNEL_OUT_5POINT1),
                dtsHd = direct(AudioFormat.ENCODING_DTS_HD, AudioFormat.CHANNEL_OUT_7POINT1_SURROUND),
                trueHd = direct(AudioFormat.ENCODING_DOLBY_TRUEHD, AudioFormat.CHANNEL_OUT_7POINT1_SURROUND)
            )
        }
        // API 24–28: HDMI çıxış cihazlarının bildirdiyi kodlaşdırmalar.
        val enc = runCatching {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .filter { it.type == AudioDeviceInfo.TYPE_HDMI || it.type == AudioDeviceInfo.TYPE_HDMI_ARC }
                .flatMap { it.encodings.toList() }
                .toSet()
        }.getOrDefault(emptySet())
        return Caps(
            ac3 = AudioFormat.ENCODING_AC3 in enc,
            eac3 = AudioFormat.ENCODING_E_AC3 in enc,
            dts = AudioFormat.ENCODING_DTS in enc,
            dtsHd = AudioFormat.ENCODING_DTS_HD in enc,
            trueHd = AudioFormat.ENCODING_DOLBY_TRUEHD in enc
        )
    }

    /** AudioTrack kodlaşdırması PCM deyilsə, səs dekod edilmədən ötürülür (bitstream). */
    fun isPassthroughEncoding(encoding: Int): Boolean = when (encoding) {
        C.ENCODING_AC3, C.ENCODING_E_AC3, C.ENCODING_E_AC3_JOC, C.ENCODING_AC4,
        C.ENCODING_DTS, C.ENCODING_DTS_HD, C.ENCODING_DTS_UHD_P2, C.ENCODING_DOLBY_TRUEHD -> true
        else -> false
    }

    /** Qısa etiket (məs. "AC3", "EAC3", "DTS"): məlumat sətrində göstərilir. */
    fun label(encoding: Int): String = when (encoding) {
        C.ENCODING_AC3 -> "AC3"
        C.ENCODING_E_AC3, C.ENCODING_E_AC3_JOC -> "EAC3"
        C.ENCODING_AC4 -> "AC4"
        C.ENCODING_DTS -> "DTS"
        C.ENCODING_DTS_HD, C.ENCODING_DTS_UHD_P2 -> "DTS-HD"
        C.ENCODING_DOLBY_TRUEHD -> "TrueHD"
        else -> ""
    }

}
