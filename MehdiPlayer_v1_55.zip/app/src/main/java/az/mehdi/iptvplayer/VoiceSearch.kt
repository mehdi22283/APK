package az.mehdi.iptvplayer

import java.text.Normalizer

/**
 * Səs axtarışı (Assistant və ya tətbiqdaxili mikrofon): gələn mətnə ən uyğun kanalı tapır.
 * Mətn sadələşdirilir (ə/ı/ö/ü/ş/ç/ğ → e/i/o/u/s/c/g, kiril → latın), "aç / oynat / göstər / kanalı" kimi əmr sözləri atılır.
 * Səs tanıma səhv eşidəndə ("Həzər TV", "Khazar tv", "Хәзәр ТВ") fonetik müqayisə və 1-2 hərflik fərq də qəbul edilir.
 */
object VoiceSearch {
    private val COMMAND_WORDS = setOf(
        "ac", "acin", "oynat", "oynadin", "goster", "gosterin", "ver", "qos", "qosun", "izle", "bax",
        "kanal", "kanali", "kanalini", "kanalina", "et", "zehmet", "olmasa", "zehmet olmasa",
        "play", "open", "watch", "show", "channel", "tune", "to", "the", "in", "on", "mehdi", "player", "playerde", "playerda"
    )

    // Kiril (Azərbaycan / rus) → latın
    private val CYR = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "j", 'з' to "z",
        'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
        'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "x", 'ц' to "c", 'ч' to "c", 'ш' to "s", 'щ' to "s",
        'ы' to "i", 'э' to "e", 'ю' to "u", 'я' to "a", 'ъ' to "", 'ь' to "",
        'ә' to "e", 'ғ' to "g", 'ү' to "u", 'ө' to "o", 'һ' to "h", 'ҹ' to "c", 'қ' to "q", 'ң' to "n", 'ҝ' to "g"
    )

    fun fold(s: String): String {
        var t = s.lowercase()
        if (t.any { it in CYR }) t = buildString { t.forEach { append(CYR[it] ?: it.toString()) } }
        t = t.replace('ə', 'e').replace('ı', 'i')
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        return t.trim()
    }

    /** Əmr sözləri atılmış, sadələşdirilmiş sorğu. Hamısı əmr sözüdürsə ilkin sadələşdirilmiş mətn qaytarılır. */
    fun clean(raw: String): String {
        val folded = fold(raw).replace(Regex("\\b(ti ?vi|teve|tiv)\\b"), "tv")
        val kept = folded.split(' ').filter { it.isNotEmpty() && it !in COMMAND_WORDS }
        return if (kept.isEmpty()) folded else kept.joinToString(" ")
    }

    /** Fonetik açar: x/kh→h, q→g, w→v, təkrarlanan hərflər tək, boşluqsuz ("Xəzər TV" ≈ "Həzər TV" ≈ "Hazar TV"). */
    private fun phon(s: String): String =
        s.replace("kh", "h").replace('x', 'h').replace('q', 'g').replace('w', 'v')
            .replace('a', 'e')              // "Hazar" ≈ "Hezer"
            .replace(Regex("(.)\\1+"), "$1").replace(" ", "")

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private val QUALITY = Regex("\\b(tv|hd|fhd|uhd|sd|4k)\\b")

    /** Ən yaxşı uyğun kanal; tapılmazsa null. */
    fun best(channels: List<Channel>, raw: String): Channel? {
        val q = clean(raw)
        if (q.isEmpty()) return null
        val qTokens = q.split(' ')
        val pq = phon(q)
        val pqCore = phon(q.replace(QUALITY, " ").trim())
        var bestCh: Channel? = null
        var bestTier = Int.MAX_VALUE
        var bestLen = Int.MAX_VALUE
        var bestNum = Int.MAX_VALUE
        for (c in channels) {
            val n = fold(c.name)
            if (n.isEmpty()) continue
            val nTokens = n.split(' ')
            var tier = when {
                n == q -> 0
                n.startsWith("$q ") -> 1
                n.length >= 3 && q.startsWith("$n ") -> 2
                qTokens.all { t -> nTokens.any { it.startsWith(t) } } -> 3
                n.contains(q) -> 4
                else -> -1
            }
            if (tier < 0 && pq.length >= 3) {
                // Fonetik / yazılışı yaxın uyğunluq (səs tanıma səhvləri üçün).
                val pn = phon(n)
                val pnCore = phon(n.replace(QUALITY, " ").trim())
                tier = when {
                    pn == pq || (pnCore.isNotEmpty() && pnCore == pqCore) -> 5
                    pn.startsWith(pq) || (pqCore.length >= 3 && pnCore.startsWith(pqCore)) -> 6
                    pq.length >= 4 && pn.contains(pq) -> 7
                    else -> {
                        val d = minOf(lev(pn, pq), lev(pnCore, pqCore), lev(pn.take(pq.length), pq))
                        val limit = if (pq.length >= 8) 2 else 1
                        if (pq.length >= 4 && d <= limit) 8 + d else -1
                    }
                }
            }
            if (tier < 0) continue
            // Eyni səviyyədə daha qısa ad (məs. "Xəzər TV" > "Xəzər TV HD"), sonra kiçik nömrə.
            val better = tier < bestTier ||
                (tier == bestTier && (n.length < bestLen || (n.length == bestLen && c.number < bestNum)))
            if (better) { bestCh = c; bestTier = tier; bestLen = n.length; bestNum = c.number }
        }
        return bestCh
    }
}
