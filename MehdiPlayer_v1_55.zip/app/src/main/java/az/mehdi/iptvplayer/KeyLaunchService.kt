package az.mehdi.iptvplayer

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Əlçatımlılıq xidməti: pultun 4001 kodlu düyməsi basılanda tətbiq açılır (tətbiq fonda/bağlı olsa da). */
class KeyLaunchService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != TRIGGER && event.scanCode != TRIGGER) return super.onKeyEvent(event)
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            runCatching {
                startActivity(Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                })
            }
        }
        return true // düymə başqa tətbiqə keçməsin
    }

    companion object {
        const val TRIGGER = 4001
    }
}
