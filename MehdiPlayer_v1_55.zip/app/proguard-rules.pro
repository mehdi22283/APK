# R8 / kod kiçiltmə qaydaları (IPTV Player). Məqsəd: APK ölçüsü və sürət; oynatma davranışı dəyişməməlidir.

# Stack izləri oxunaqlı qalsın (xəta/crash log-ları üçün sətir nömrələri).
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod,*Annotation*
-renamesourcefileattribute SourceFile

# Native (JNI) metodları olan bütün siniflər: FFmpeg (NextLib) və Media3 dekoderləri.
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }
-keep class io.github.anilbeesetti.nextlib.** { *; }
-keep class androidx.media3.decoder.** { *; }

-dontwarn androidx.media3.**

# OkHttp (isteğe bağlı TLS provayderləri quraşdırılmayıb).
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**

# Kotlin / korutinlər.
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.debug.**
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# Gizli WebView (yoda.az ehtiyat linki) JS körpüsü istifadə edilirsə, işarələnmiş metodlar qalır.
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }

# Android TV Watch Next provayderi (tvprovider) sütun adları ilə işləyir.
-keep class androidx.tvprovider.media.tv.** { *; }
