package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceView
import androidx.media3.common.util.UnstableApi
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** Mühərriklərin (Media3 / mpv) geri çağırışları. */
interface PlayerCallback {
    fun onLoading()
    /** Yüklənmə/keçid mesajı və həmin cəhd üçün təxmini taymer. */
    fun onStatus(message: String, countdownMs: Long = 0L) {}
    fun onPlaying()
    fun onBuffering(active: Boolean)
    fun onFailed(message: String)
    /** Media3 codec/formatı dekodlaya bilmir: PlayerManager dərhal mpv-yə keçir (MainActivity-yə çatmır). */
    fun onCodecUnsupported(message: String) {}
    /**
     * mpv yayımı aça bilmədi. true qaytarılırsa ehtiyat link prosesi (yoda.az) başladılıb,
     * pleyer xəta göstərmir; isBackup = oynadılan link artıq yoda.az-dan alınmış linkdir.
     */
    fun onStreamFailed(isBackup: Boolean): Boolean = false
}

/**
 * Kanal linkinin serverinə ilkin sorğu (pleyerlərdən əvvəl).
 * false = server xəta qaytardı (HTTP 4xx/5xx) və ya qoşulmadı (DNS/refused/SSL) → kanal işləmir;
 * true = server normal cavab verdi; null = nəticəsiz (vaxt aşımı və ya yanlış link) → pleyerlər yoxlayır.
 */
private object Preflight {
    private val client: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val b = OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .callTimeout(5, TimeUnit.SECONDS)
            .protocols(listOf(Protocol.HTTP_1_1))
            .followRedirects(true)
            .followSslRedirects(true)
            .hostnameVerifier { _, _ -> true }
        runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            b.sslSocketFactory(ctx.socketFactory, trustAll)
        }
        b.build()
    }

    fun check(url: String, ua: String?, ref: String?): Boolean? {
        return try {
            val rb = okhttp3.Request.Builder().url(url)
                .header("User-Agent", ua?.takeIf { it.isNotBlank() } ?: "VLC/3.0.20 LibVLC/3.0.20")
            ref?.takeIf { it.isNotBlank() }?.let { rb.header("Referer", it) }
            // Yalnız başlıqlar oxunur, yayımın gövdəsi endirilmir (use bağlantını bağlayır).
            client.newCall(rb.build()).execute().use { r -> r.code < 400 }
        } catch (e: java.net.SocketTimeoutException) {
            null
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: java.io.IOException) {
            false
        } catch (e: Throwable) {
            // Ayrıca thread-də tutulmayan istənilən xəta bütün tətbiqi çökdürür: nəticəsiz sayılır, pleyerlər yoxlayır.
            null
        }
    }
}

/**
 * Pleyer meneceri: ƏVVƏL Media3 (yalnız http/https), codec/format dəstəklənmirsə DƏRHAL mpv.
 *
 * Yeni kanal: Media3 × 1 cəhd (5 s) → hər hansı uğursuzluqda mpv × 3 cəhd (hər biri 5 s).
 * Codec dəstəklənmir (video/səs treki dekodlanmır, dekoder açılmır, format tanınmır) → gözləmədən mpv.
 * rtsp/rtmp/udp/srt və s. → birbaşa mpv. İşləyən kanal qırılsa/donsa avtomatik yenidən qoşulur (2 cəhd).
 * Hamısı uğursuz olarsa ehtiyat link (yoda.az) və ya "Kanal İşləmir".
 */
@androidx.annotation.OptIn(UnstableApi::class)
class PlayerManager(
    context: Context,
    private val view: SurfaceView,
    private val cb: PlayerCallback
) {
    private enum class Eng { EXO, MPV }

    private companion object {
        // Bir cəhdin açılış vaxt aşımı və cəhd sayı. Yeni kanal: Media3 1 + mpv 3; işləmiş kanalın bərpası: mpv 2.
        const val EXO_TIMEOUT_MS = 5_000L
        const val MPV_TIMEOUT_MS = 5_000L
        const val NEW_ATTEMPTS = 3
        const val RECOVER_ATTEMPTS = 2
        const val PREFLIGHT_MS = 5_000L
        // Avtomatik bərpa: bufer 5 s dolmursa və ya görüntü/vaxt 5 s donursa kanal yenidən qoşulur.
        const val STALL_BUFFERING_MS = 5_000L
        const val STALL_FREEZE_MS = 5_000L
        // Pleyer "oynayır" deyir, amma vaxt göstəricisi heç gəlmirsə (qara ekran/boş yayım).
        const val NO_TIME_MS = 10_000L
        const val WATCHDOG_MS = 1_000L
        const val RECONNECT_DELAY_MS = 0L
        // Əvvəl işləmiş kanalın bərpası bu müddətdən uzun çəksə yüklənmə göstəricisi çıxır; qısa bərpa görünmür.
        const val SILENT_RECOVERY_MS = 3_500L
        const val RETRY_ALL_DELAY_MS = 2_000L
        const val ICON_MEDIA3 = "\uD83D\uDC99" // 💙
        const val ICON_MPV = "\uD83D\uDC9C"    // 💜
    }

    private val ui = Handler(Looper.getMainLooper())
    private var url: String? = null
    private var ua: String? = null
    private var ref: String? = null
    // true: oynadılan link yoda.az ehtiyat linkidir (tokenlidir)
    private var usingBackup = false
    private var resume = false
    private var released = false
    private var playedOk = false
    private var everPlayed = false
    private var reconnecting = false
    private var userPaused = false
    private var bufferingSince = 0L
    private var lastPos = -1L
    private var lastPosAt = 0L
    // Cari mühərrik; cari cəhd nömrəsi (yalnız mpv üçün sayılır) / icazə verilən cəhd sayı.
    private var cur = Eng.MPV
    private var attempt = 0
    private var maxAttempts = NEW_ATTEMPTS
    // İlkin server sorğusunun nömrəsi: kanal dəyişəndə/dayandırılanda köhnə nəticə ignor edilir.
    private var preflightGen = 0

    private fun pos(): Long = if (cur == Eng.EXO) exo.position() else mpv.position()

    private val watchdogRun: Runnable = object : Runnable {
        override fun run() {
            if (released || url == null || !playedOk) return
            val now = SystemClock.elapsedRealtime()
            var stalled = false
            if (!userPaused) {
                if (bufferingSince != 0L && now - bufferingSince >= STALL_BUFFERING_MS) {
                    stalled = true
                } else {
                    val p = pos()
                    if (p > 0) {
                        if (p != lastPos) { lastPos = p; lastPosAt = now }
                        else if (now - lastPosAt >= STALL_FREEZE_MS) stalled = true
                    } else if (now - lastPosAt > NO_TIME_MS) {
                        // "Oynayır" dedi, amma vaxt heç irəliləmir: yenidən qoşulur.
                        stalled = true
                    }
                }
            }
            if (stalled) { reconnect("Yayım donub"); return }
            ui.postDelayed(this, WATCHDOG_MS)
        }
    }
    private val slowRecoveryRun: Runnable = Runnable { if (!released && url != null && reconnecting) cb.onLoading() }
    private val restartRun: Runnable = Runnable {
        if (released || url == null) return@Runnable
        reconnecting = false
        startEngine(retry = true)
    }
    private val retryAllRun: Runnable = Runnable {
        if (released || url == null) return@Runnable
        attempt = 0
        maxAttempts = NEW_ATTEMPTS
        reconnecting = false
        begin()
    }

    /** Hər mühərrik üçün ayrıca geri çağırış: o an aktiv olmayan mühərrikin gecikmiş hadisələri ignor edilir. */
    private fun makeCb(tag: Eng): PlayerCallback = object : PlayerCallback {
        override fun onLoading() {}
        override fun onPlaying() {
            if (released || url == null || cur != tag) return
            playedOk = true
            everPlayed = true
            reconnecting = false
            bufferingSince = 0L
            lastPos = -1L
            lastPosAt = SystemClock.elapsedRealtime()
            ui.removeCallbacks(watchdogRun)
            ui.postDelayed(watchdogRun, WATCHDOG_MS)
            cb.onPlaying()
        }
        override fun onBuffering(active: Boolean) {
            if (released || url == null || cur != tag) return
            if (active) { if (bufferingSince == 0L) bufferingSince = SystemClock.elapsedRealtime() }
            else bufferingSince = 0L
            cb.onBuffering(active)
        }
        override fun onFailed(message: String) {
            if (released || url == null || reconnecting || cur != tag) return
            // Yayım əvvəl işləyibsə (sonra qırılıbsa) yenidən qoşulur; ilk açılışda isə növbəti cəhd / mpv.
            if (playedOk) reconnect(message) else fallback(message)
        }
        override fun onCodecUnsupported(message: String) {
            if (released || url == null || reconnecting || cur != tag || tag != Eng.EXO) return
            // Codec dəstəklənmir: heç bir cəhd/gözləmə yoxdur, dərhal mpv.
            switchToMpv(message, codec = true)
        }
    }

    private val mpv: MpvEngine = MpvEngine(context, view, makeCb(Eng.MPV))
    private val exo: Media3Engine = Media3Engine(context, view, makeCb(Eng.EXO))

    init {
        // Köhnə (Media3/VLC dövrünün) pleyer yaddaşı artıq lazım deyil.
        runCatching { context.applicationContext.getSharedPreferences("player_memory_v3", Context.MODE_PRIVATE).edit().clear().apply() }
    }

    /** Media3 yalnız http/https açır; qalan sxemlər (rtsp, rtmp, udp, srt ...) birbaşa mpv-yə verilir. */
    private fun exoEligible(u: String): Boolean {
        val scheme = u.substringBefore("://", "").lowercase()
        return scheme == "http" || scheme == "https"
    }

    private fun startEngine(retry: Boolean = false) {
        if (cur == Eng.EXO) startExo(retry) else startMpv(retry)
    }

    private fun startExo(retry: Boolean = false) {
        val u = url ?: return
        val isRetry = retry || reconnecting || attempt > 0
        if (!(retry && everPlayed)) cb.onStatus(
            if (isRetry) "Təkrar cəhd edilir (Media3 Player)" else "Yüklənir (Media3 Player)",
            EXO_TIMEOUT_MS
        )
        playedOk = false
        // Eyni video səthini yalnız bir mühərrik tuta bilər: əvvəl mpv ayrılır.
        mpv.stop()
        mpv.releaseSurface()
        exo.play(u, ua, ref, EXO_TIMEOUT_MS)
    }

    private fun startMpv(retry: Boolean = false, message: String? = null) {
        val u = url ?: return
        val isRetry = retry || reconnecting || attempt > 0
        // Əvvəl işləmiş kanalın təkrar cəhdində yükləmə paneli dərhal çıxmır: son kadr ekranda qalır, bərpa fonda gedir.
        if (!(retry && everPlayed)) cb.onStatus(
            message ?: if (isRetry) "Təkrar cəhd edilir (mpv Player)" else "Yüklənir (mpv Player)",
            MPV_TIMEOUT_MS
        )
        playedOk = false
        // Media3 dekoderi və səthi tam azad edilir (mpv hwdec/səth götürəcək).
        exo.releaseSurface()
        mpv.play(u, ua, ref, MPV_TIMEOUT_MS)
    }

    /** Media3-dən mpv-yə keçid: cəhd sayğacı sıfırlanır, mpv-nin tam cəhd sayı qalır. */
    private fun switchToMpv(reason: String, codec: Boolean) {
        if (released || url == null) return
        android.util.Log.w("IPTV-PLAYER", "Media3 → mpv (${if (codec) "codec" else "xəta"}): $reason")
        cur = Eng.MPV
        attempt = 0
        playedOk = false
        bufferingSince = 0L
        ui.removeCallbacks(watchdogRun)
        startMpv(
            retry = true,
            message = if (codec) "Codec dəstəklənmir — mpv Player" else "Media3 açmadı — mpv Player"
        )
    }

    fun play(newUrl: String, newUa: String? = null, newRef: String? = null, backup: Boolean = false) {
        if (released) return
        url = newUrl; ua = newUa; ref = newRef
        usingBackup = backup
        resume = false
        attempt = 0
        maxAttempts = NEW_ATTEMPTS
        playedOk = false
        everPlayed = false
        reconnecting = false
        userPaused = false
        bufferingSince = 0L
        cancelRecovery()
        stopEngines()
        cb.onLoading()
        begin()
    }

    private fun stopEngines() {
        exo.stop()
        mpv.stop()
    }

    /**
     * Açılış ardıcıllığı: əvvəl serverə qısa sorğu, sonra Media3 (1 cəhd), uğursuz/codec olarsa mpv (3 cəhd).
     * Hamısı uğursuz olarsa ehtiyat link (yoda.az) və ya "Kanal İşləmir".
     */
    private fun begin() {
        val u = url ?: return
        cur = if (exoEligible(u)) Eng.EXO else Eng.MPV
        val scheme = u.substringBefore("://", "").lowercase()
        // Əvvəl kanalın serverinə sorğu: xəta cavabı (404/403/5xx, qoşulmur) alınırsa kanal işləmir, pleyerlər yoxlanmır.
        // Ehtiyat (yoda.az tokenli) linkdə sorğu göndərilmir.
        if (!usingBackup && (scheme == "http" || scheme == "https")) {
            val g = ++preflightGen
            val pu = u; val pua = ua; val pref = ref
            cb.onStatus("Server yoxlanılır", PREFLIGHT_MS)
            Thread {
                val r = Preflight.check(pu, pua, pref)
                ui.post {
                    if (released || g != preflightGen || url != pu) return@post
                    if (r == false) {
                        android.util.Log.w("IPTV-PLAYER", "Server xəta qaytardı/qoşulmadı → kanal işləmir: $pu")
                        failAll()
                    } else startEngine()
                }
            }.start()
            return
        }
        startEngine()
    }

    private fun fallback(message: String) {
        // Media3 açmadı (codec xətası olmayan səbəblə): mpv ikinci rəy kimi yoxlanır.
        if (cur == Eng.EXO) { switchToMpv(message, codec = false); return }
        android.util.Log.w("IPTV-PLAYER", "Cəhd ${attempt + 1}/$maxAttempts uğursuz: $message")
        attempt++
        if (attempt >= maxAttempts) { failAll(); return }
        startMpv(retry = true)
    }

    private fun failAll() {
        stopEngines()
        // Əsas link işləmir: ehtiyat link (yoda.az) prosesi başladılırsa xəta göstərilmir.
        if (!released && url != null && cb.onStreamFailed(usingBackup)) return
        if (everPlayed) {
            // Kanal əvvəl işləyib: server müvəqqəti düşübsə, avtomatik təkrar yoxlanılır.
            cb.onLoading()
            cb.onStatus("Kanal cavab vermir — yenidən yoxlanılır", RETRY_ALL_DELAY_MS)
            ui.removeCallbacks(retryAllRun)
            ui.postDelayed(retryAllRun, RETRY_ALL_DELAY_MS)
        } else {
            cb.onFailed("Kanal İşləmir")
        }
    }

    private fun cancelRecovery() {
        preflightGen++
        ui.removeCallbacks(watchdogRun)
        ui.removeCallbacks(restartRun)
        ui.removeCallbacks(retryAllRun)
        ui.removeCallbacks(slowRecoveryRun)
    }

    /** Yayım işləyərkən qırılıb/donub: kanalı avtomatik yenidən qoşur (eyni mühərriklə; o da açmasa mpv). */
    private fun reconnect(reason: String) {
        if (released || url == null || reconnecting) return
        android.util.Log.w("IPTV-PLAYER", "Yenidən qoşulma: $reason")
        if (!everPlayed) cb.onStatus("Təkrar cəhd edilir", MPV_TIMEOUT_MS)
        reconnecting = true
        playedOk = false
        bufferingSince = 0L
        attempt = 0
        maxAttempts = RECOVER_ATTEMPTS
        ui.removeCallbacks(watchdogRun)
        // Əvvəl oynamış kanalın bərpası sakit gedir: son kadr ekranda qalır, yüklənmə yalnız uzun çəkəndə görünür.
        ui.removeCallbacks(slowRecoveryRun)
        if (everPlayed) ui.postDelayed(slowRecoveryRun, SILENT_RECOVERY_MS) else cb.onLoading()
        // Heç nə gözlənmir: təkrar cəhd dərhal (eyni döngədə) başlayır.
        ui.removeCallbacks(restartRun)
        if (RECONNECT_DELAY_MS <= 0L) ui.post(restartRun) else ui.postDelayed(restartRun, RECONNECT_DELAY_MS)
    }

    fun attach() {
        if (released) return
        val u = url
        if (resume && u != null) play(u, ua, ref, usingBackup)
    }

    /** Yayımı tam dayandırır (yoda.az linki gözlənərkən köhnə kanal səsi/şəkli qalmasın). */
    fun halt() {
        if (released) return
        cancelRecovery()
        stopEngines()
        url = null
        resume = false
        playedOk = false
        everPlayed = false
        reconnecting = false
    }

    fun stopForBackground() {
        if (released) return
        resume = url != null
        cancelRecovery()
        exo.stopForBackground()
        mpv.stopForBackground()
    }

    fun isPaused(): Boolean = userPaused

    fun hasUrl(): Boolean = url != null

    fun togglePause() {
        userPaused = !userPaused
        if (userPaused) ui.removeCallbacks(watchdogRun)
        else { lastPosAt = SystemClock.elapsedRealtime(); lastPos = -1L; bufferingSince = 0L; if (playedOk) ui.postDelayed(watchdogRun, WATCHDOG_MS) }
        if (cur == Eng.EXO) exo.togglePause() else mpv.togglePause()
    }

    fun stats(): PlayerStats? {
        val isExo = cur == Eng.EXO
        val s = (if (isExo) exo.stats() else mpv.stats()) ?: return null
        // Pleyer işarəsi: 💙 = Media3, 💜 = mpv
        return PlayerStats(s.width, s.height, s.bufferMs, s.level, s.bps, if (isExo) ICON_MEDIA3 else ICON_MPV, s.bitrate)
    }

    fun release() {
        if (released) return
        released = true
        cancelRecovery()
        exo.release()
        mpv.release()
    }
}
