package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import `is`.xyz.mpv.MPVLib
import java.io.File

/**
 * İkinci (ehtiyat) mühərrik: mpv (libmpv, mpv-android build-i). Media3 codec-i açmayanda dərhal buna keçilir.
 *
 * Qaydalar:
 *  1) mpv prosesdə TƏK nüsxədir (MPVLib singleton). Yaradılması/seçimləri init-də edilir, kanal dəyişəndə yalnız loadfile işlədilir.
 *  2) loadfile / stop / pause əmrləri əsas thread-də yox, tək "mpv-ctl" thread-ində ardıcıl icra olunur
 *     (şəbəkədə ilişən açılış UI-ı dondurmasın). Hər əmr "generation" nömrəsi daşıyır: köhnəlmiş əmrlər atlanır.
 *  3) Video səthi hazır olmadan loadfile verilmir (yoxsa mpv yalnız səslə açılır): səth gələnə qədər başlanğıc gözləyir.
 *  4) mpv hadisələri (mpv event thread-i) UI thread-inə ötürülür; əvvəlki yayımın gecikmiş hadisələri
 *     "started" bayrağı ilə (yeni START_FILE gəlməyibsə) ignor edilir.
 *  5) Əsas thread mpv-dən property OXUMUR: qiymətlər observeProperty ilə keşlənir (stats/position keşdən oxunur).
 */
class MpvEngine(
    context: Context,
    private val view: SurfaceView,
    private val callback: PlayerCallback
) : SurfaceHolder.Callback, MPVLib.EventObserver {

    companion object {
        private const val TAG = "IPTV-MPV"
        private const val DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"
        private const val VO = "gpu"
        // Səth gec gələndə açılış vaxt aşımına əlavə gözləmə.
        private const val SURFACE_WAIT_MS = 4_000L
    }

    private val appContext = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())

    // Native əmrlər yalnız bu thread-də.
    private val workerThread = HandlerThread("mpv-ctl").apply { start() }
    private val worker = Handler(workerThread.looper)

    @Volatile private var generation = 0
    @Volatile private var released = false
    private var ready = false

    // ---- vəziyyət (yalnız UI thread-i) ----
    private var surfaceValid = false      // SurfaceView-in səthi mövcuddur
    private var surfaceReady = false      // səth + ölçü məlumdur
    private var surfaceAttached = false   // səth mpv-yə qoşulub (Media3 işləyərkən qoşulmur!)
    private var surfW = 0
    private var surfH = 0
    private var pendingStart = false
    private var url: String? = null
    private var userAgent: String? = null
    private var referer: String? = null
    private var timeoutMs = 5_000L
    private var started = false        // bu generation üçün START_FILE gəlib
    private var restarted = false      // bu generation üçün PLAYBACK_RESTART gəlib
    private var coreIdle = true
    private var playing = false
    private var pausedByUser = false
    private var buffering = false
    private var lastBufferingAt = 0L
    private var openTimeout: Runnable? = null
    private val speed = SpeedMeter()

    // ---- mpv thread-indən yazılan keş (əsas thread yalnız oxuyur) ----
    @Volatile private var timePosSec = -1L
    @Volatile private var videoW = 0L
    @Volatile private var videoH = 0L
    @Volatile private var cacheSecs = -1.0
    @Volatile private var videoBitrate = -1.0
    @Volatile private var audioBitrate = -1.0

    init {
        ready = try {
            initMpv()
            true
        } catch (t: Throwable) {
            Log.e(TAG, "mpv başladılmadı", t)
            false
        }
        view.holder.addCallback(this)
        // Səth artıq yaradılıbsa (callback əlavə olunmazdan əvvəl) vəziyyət əl ilə qeyd olunur.
        if (view.holder.surface?.isValid == true) {
            surfaceValid = true
            if (view.width > 0 && view.height > 0) { surfW = view.width; surfH = view.height; surfaceReady = true }
        }
    }

    // ---------- mpv quraşdırma ----------
    private fun prepareCaFile(): String? = runCatching {
        val f = File(appContext.filesDir, "cacert.pem")
        if (!f.exists() || f.length() == 0L) {
            appContext.assets.open("cacert.pem").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
        f.path
    }.getOrNull()

    private fun initMpv() {
        val cores = Runtime.getRuntime().availableProcessors()
        val cache = appContext.cacheDir.path
        val ca = prepareCaFile()

        MPVLib.create(appContext)
        fun opt(k: String, v: String) { MPVLib.setOptionString(k, v) }

        opt("gpu-shader-cache-dir", cache)
        opt("icc-cache-dir", cache)
        // Zəif TV box: sürətli profil (bilinear miqyas, ağır GPU effektləri söndürülüb).
        opt("profile", "fast")
        opt("vo", VO)
        opt("gpu-context", "android")
        opt("opengl-es", "yes")
        // Dekoder: əvvəl cihazın MediaCodec-i (birbaşa, sonra copy), açılmasa proqram (FFmpeg) dekoderi.
        opt("hwdec", "mediacodec,mediacodec-copy")
        opt("hwdec-codecs", "h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1")
        opt("vd-lavc-threads", minOf(cores, 4).toString())
        opt("ao", "audiotrack,opensles")
        opt("audio-set-media-role", "movie")
        // Video həmişə ekranı tam doldurur (stretch) — əvvəlki Media3/VLC davranışı ilə eyni.
        opt("keepaspect", "no")
        // Altyazı lazım deyil (CPU/RAM qənaəti).
        opt("sid", "no")
        opt("sub-auto", "no")
        opt("ytdl", "no")
        // 2 GB RAM: kiçik bufer. Canlı yayımda geriyə bufer demək olar ki, yoxdur.
        opt("cache", "yes")
        opt("cache-secs", "20")
        opt("demuxer-readahead-secs", "20")
        opt("demuxer-max-bytes", (24L * 1024 * 1024).toString())
        opt("demuxer-max-back-bytes", (4L * 1024 * 1024).toString())
        opt("cache-pause", "yes")
        opt("cache-pause-wait", "2.5")
        // Şəbəkə: IPTV serverlərində vaxtı keçmiş/özü imzalı sertifikat tez-tez olur → yoxlama söndürülüb (əvvəlki trust-all kimi).
        opt("network-timeout", "8")
        opt("tls-verify", "no")
        if (ca != null) opt("tls-ca-file", ca)
        opt("stream-lavf-o", "reconnect=1,reconnect_streamed=1,reconnect_delay_max=2")
        // libmpv: pleyer boşdur və fayl bitəndə də açıq qalır (kanal dəyişəndə yeni loadfile verilir).
        opt("idle", "yes")
        opt("force-window", "no")

        MPVLib.addObserver(this)
        MPVLib.init()

        MPVLib.observeProperty("core-idle", MPVLib.MpvFormat.FLAG)
        MPVLib.observeProperty("paused-for-cache", MPVLib.MpvFormat.FLAG)
        MPVLib.observeProperty("idle-active", MPVLib.MpvFormat.FLAG)
        MPVLib.observeProperty("time-pos", MPVLib.MpvFormat.INT64)
        MPVLib.observeProperty("video-params/w", MPVLib.MpvFormat.INT64)
        MPVLib.observeProperty("video-params/h", MPVLib.MpvFormat.INT64)
        MPVLib.observeProperty("demuxer-cache-duration", MPVLib.MpvFormat.DOUBLE)
        MPVLib.observeProperty("video-bitrate", MPVLib.MpvFormat.DOUBLE)
        MPVLib.observeProperty("audio-bitrate", MPVLib.MpvFormat.DOUBLE)
    }

    // ---------- mpv hadisələri (mpv event thread-i) ----------
    override fun eventProperty(property: String) {
        // Qiymət yoxdur (property əlçatmaz oldu).
        when (property) {
            "time-pos" -> timePosSec = -1L
            "video-params/w" -> videoW = 0L
            "video-params/h" -> videoH = 0L
            "demuxer-cache-duration" -> cacheSecs = -1.0
            "video-bitrate" -> videoBitrate = -1.0
            "audio-bitrate" -> audioBitrate = -1.0
        }
    }

    override fun eventProperty(property: String, value: Long) {
        when (property) {
            "time-pos" -> timePosSec = value
            "video-params/w" -> videoW = value
            "video-params/h" -> videoH = value
        }
    }

    override fun eventProperty(property: String, value: Double) {
        when (property) {
            "demuxer-cache-duration" -> cacheSecs = value
            "video-bitrate" -> videoBitrate = value
            "audio-bitrate" -> audioBitrate = value
        }
    }

    override fun eventProperty(property: String, value: String) {}

    override fun eventProperty(property: String, value: Boolean) {
        ui.post { onFlag(property, value) }
    }

    override fun event(eventId: Int) {
        ui.post { onMpvEvent(eventId) }
    }

    // ---------- hadisələrin işlənməsi (UI thread-i) ----------
    private fun onMpvEvent(id: Int) {
        if (released) return
        when (id) {
            MPVLib.MpvEvent.START_FILE -> if (url != null) started = true
            MPVLib.MpvEvent.PLAYBACK_RESTART -> if (url != null && started) { restarted = true; maybeMarkPlaying() }
        }
    }

    private fun onFlag(name: String, value: Boolean) {
        if (released) return
        when (name) {
            "core-idle" -> {
                coreIdle = value
                if (!value) maybeMarkPlaying()
            }
            "paused-for-cache" -> {
                if (!playing || url == null) return
                if (value == buffering) return
                buffering = value
                if (value) lastBufferingAt = SystemClock.elapsedRealtime()
                callback.onBuffering(value)
            }
            "idle-active" -> {
                // mpv boşa düşdü: yayım bitdi və ya açıla bilmədi (yalnız bu kanalın START_FILE-ından sonra).
                if (value && url != null && started) {
                    Log.w(TAG, "mpv boşa düşdü (yayım bitdi/açılmadı)")
                    failNow(generation, if (playing) "Yayım bitdi" else "mpv yayımı aça bilmədi")
                }
            }
        }
    }

    private fun maybeMarkPlaying() {
        if (playing || url == null || !started || !restarted || coreIdle) return
        playing = true
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        callback.onPlaying()
    }

    private fun failNow(g: Int, message: String) {
        if (released || g != generation || url == null) return
        playing = false
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        callback.onFailed(message)
    }

    // ---------- Səth ----------
    // Səthi eyni anda yalnız bir mühərrik tuta bilər: mpv səthi YALNIZ özü oynayanda (startNow) qoşur,
    // Media3 işləyəndə isə qoşulmur. Media3-ə qayıdanda releaseSurface() çağırılır.
    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceValid = true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfW = width; surfH = height
        if (surfaceAttached && ready && !released) {
            runCatching { MPVLib.setPropertyString("android-surface-size", "${width}x$height") }
        }
        // Ölçü verildikdən sonra səth hazır sayılır; gözləyən başlanğıc varsa indi icra olunur.
        surfaceReady = true
        if (pendingStart && !released && ready) {
            pendingStart = false
            startNow()
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceValid = false
        surfaceReady = false
        releaseSurface()
    }

    private fun attachSurfaceIfNeeded(): Boolean {
        if (surfaceAttached) return true
        if (!ready || released || !surfaceValid) return false
        return runCatching {
            MPVLib.attachSurface(view.holder.surface)
            MPVLib.setOptionString("force-window", "yes")
            MPVLib.setPropertyString("vo", VO)
            if (surfW > 0 && surfH > 0) MPVLib.setPropertyString("android-surface-size", "${surfW}x$surfH")
            surfaceAttached = true
        }.onFailure { Log.e(TAG, "Video səthi qoşula bilmədi", it) }.isSuccess
    }

    /** Səthi mpv-dən ayırır (Media3 götürməzdən əvvəl; fona keçəndə). Əsas thread-də. */
    fun releaseSurface() {
        if (!surfaceAttached) return
        surfaceAttached = false
        if (released || !ready) return
        runCatching {
            MPVLib.setPropertyString("vo", "null")
            MPVLib.setOptionString("force-window", "no")
            MPVLib.detachSurface()
        }
    }

    // ---------- Worker ----------
    private fun post(g: Int, block: () -> Unit) {
        worker.post {
            if (released || g != generation) return@post
            block()
        }
    }

    // ---------- Oynatma ----------
    /** timeoutMs: bu cəhd üçün açılış vaxt aşımı (müvəffəqiyyət: PLAYBACK_RESTART + core-idle=false). */
    fun play(newUrl: String, ua: String?, ref: String?, timeoutMs: Long) {
        if (released) return
        val g = ++generation
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        url = newUrl
        userAgent = ua
        referer = ref
        this.timeoutMs = timeoutMs
        started = false
        restarted = false
        playing = false
        buffering = false
        pausedByUser = false
        timePosSec = -1L
        videoW = 0L
        videoH = 0L
        cacheSecs = -1.0
        videoBitrate = -1.0
        audioBitrate = -1.0
        speed.reset()
        if (!ready) { failNow(g, "mpv işə düşmədi"); return }
        if (!surfaceReady) {
            // Səth hələ yoxdur: loadfile səth gələndə verilir (yoxsa mpv yalnız səslə açılardı).
            pendingStart = true
            armTimeout(g, timeoutMs + SURFACE_WAIT_MS)
        } else {
            pendingStart = false
            startNow()
        }
    }

    private fun startNow() {
        val u = url ?: return
        val g = generation
        if (!attachSurfaceIfNeeded()) { failNow(g, "mpv video səthi qoşula bilmədi"); return }
        armTimeout(g, timeoutMs)
        val ua = userAgent?.takeIf { it.isNotBlank() } ?: DEFAULT_UA
        val rf = referer?.takeIf { it.isNotBlank() } ?: ""
        post(g) {
            try {
                MPVLib.setPropertyString("user-agent", ua)
                MPVLib.setPropertyString("referrer", rf)
                MPVLib.setPropertyBoolean("pause", false)
                MPVLib.command(arrayOf("loadfile", u, "replace"))
            } catch (t: Throwable) {
                Log.e(TAG, "Yayım açıla bilmədi", t)
                ui.post { failNow(g, "mpv yayımı aça bilmədi") }
            }
        }
    }

    private fun armTimeout(g: Int, ms: Long) {
        openTimeout?.let { ui.removeCallbacks(it) }
        val r = Runnable {
            openTimeout = null
            if (released || g != generation || url == null || playing) return@Runnable
            failNow(g, "mpv ${timeoutMs / 1000} saniyədə açmadı")
        }
        openTimeout = r
        ui.postDelayed(r, ms)
    }

    fun stop() {
        val g = ++generation
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        url = null
        started = false
        restarted = false
        playing = false
        buffering = false
        pendingStart = false
        pausedByUser = false
        if (!ready || released) return
        // Yeni generation: bu əmr köhnəlməsin deyə birbaşa worker-ə (generation yoxlaması ilə) verilir.
        post(g) { runCatching { MPVLib.command(arrayOf("stop")) } }
    }

    fun stopForBackground() = stop()

    fun togglePause() {
        if (released || !ready || !playing) return
        pausedByUser = !pausedByUser
        val pause = pausedByUser
        val g = generation
        post(g) { runCatching { MPVLib.setPropertyBoolean("pause", pause) } }
    }

    /** Oynatma mövqeyi (ms); yayım donanda dəyişmir. Naməlum: -1. */
    fun position(): Long {
        val s = timePosSec
        return if (s < 0) -1L else s * 1000L
    }

    fun stats(): PlayerStats? {
        if (released || !playing) return null
        val now = SystemClock.elapsedRealtime()
        val level = when {
            buffering -> 2
            now - lastBufferingAt < 12_000L -> 1
            else -> 0
        }
        val bps = speed.sample(uidRxBytes(), now)
        val vb = videoBitrate
        val ab = audioBitrate
        val trackBr = if (vb > 0) (vb + maxOf(ab, 0.0)).toLong() else 0L
        // Canlı yayımda trek bitrate-i çox vaxt yoxdur: onda son ~5 s-in orta sürəti götürülür.
        val br = if (trackBr > 0) trackBr else bps
        val cs = cacheSecs
        val bufMs = if (cs >= 0) (cs * 1000).toLong() else -1L
        return PlayerStats(videoW.toInt(), videoH.toInt(), bufMs, level, bps, "", br)
    }

    fun release() {
        if (released) return
        released = true
        generation++
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        url = null
        runCatching { view.holder.removeCallback(this) }
        if (ready) {
            runCatching { MPVLib.removeObserver(this) }
            // Native boşaltma worker-də: əvvəlki əmrlərin arxasında gözləyir, əsas thread bloklanmır.
            worker.post {
                runCatching { MPVLib.command(arrayOf("stop")) }
                runCatching { MPVLib.destroy() }
                workerThread.quitSafely()
            }
        } else {
            workerThread.quitSafely()
        }
    }
}
