package az.mehdi.iptvplayer

import android.net.Uri
import android.os.SystemClock
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.ByteArrayDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Sürətli kanal dəyişmə: qonşu kanalların HLS manifesti (master + ilk variantın media playlisti) əvvəlcədən yüklənir.
 * Kanal dəyişəndə Media3 eyni URL-i istəyəndə cavab şəbəkədən yox, yaddaşdan verilir ([PrefetchDataSource]):
 * DNS + TCP/TLS + 1–2 HTTP gediş-gəlişi (master, sonra media playlist) qənaət olunur.
 *
 * Köhnə (stale) playlist canlı yayımı geridə başlatmasın deyə: master playlist 60 s, media playlist cəmi 5 s saxlanılır.
 * Cavab "#EXTM3U" ilə başlamırsa və ya 256 KB-dan böyükdürsə yaddaşa yazılmır (Media3 özü normal yükləyir).
 */
object ManifestPrefetch {
    private const val TAG = "IPTV-PREFETCH"
    private const val MASTER_TTL_MS = 60_000L
    private const val MEDIA_TTL_MS = 5_000L
    private const val MAX_BYTES = 256 * 1024
    private const val MAX_ENTRIES = 12

    private class Entry(val bytes: ByteArray, val expiresAt: Long)

    private val cache = ConcurrentHashMap<String, Entry>()
    // Eyni URL qısa müddətdə təkrar yüklənmir (kanal sürətlə dəyişəndə şəbəkə boş yerə yüklənməsin).
    private val requestedAt = ConcurrentHashMap<String, Long>()
    private val pool = Executors.newFixedThreadPool(2) { r -> Thread(r, "iptv-prefetch").apply { isDaemon = true } }

    /** Media3 manifest istəyəndə hazır cavab varsa verir (bir dəfəlik). */
    fun take(url: String): ByteArray? {
        val e = cache.remove(url) ?: return null
        return if (SystemClock.elapsedRealtime() <= e.expiresAt) e.bytes else null
    }

    fun prefetch(items: List<Channel>) {
        val now = SystemClock.elapsedRealtime()
        if (requestedAt.size > 100) requestedAt.clear()
        for (ch in items) {
            val u = ch.url
            val low = u.lowercase()
            if (!(low.startsWith("http://") || low.startsWith("https://")) || !low.contains(".m3u8")) continue
            // Tokenli yoda.az kanalları bu yolla açılmır (link əvvəl alınmalıdır).
            if (Backup.yodaFirst(ch)) continue
            if (now - (requestedAt[u] ?: 0L) < MASTER_TTL_MS) continue
            requestedAt[u] = now
            pool.execute { runCatching { fetchChannel(ch) }.onFailure { Log.d(TAG, "${ch.name}: ${it.message}") } }
        }
    }

    private fun fetchChannel(ch: Channel) {
        val master = download(ch.url, ch.ua, ch.referer) ?: return
        put(ch.url, master, MASTER_TTL_MS)
        val text = String(master, Charsets.UTF_8)
        if (!text.contains("#EXT-X-STREAM-INF")) return
        // Master: ilk variant (Media3 adətən onunla başlayır) media playlisti də əvvəlcədən yüklənir.
        val rel = firstVariantUri(text) ?: return
        val variantUrl = runCatching { URI(ch.url).resolve(rel).toString() }.getOrNull() ?: return
        val media = download(variantUrl, ch.ua, ch.referer) ?: return
        put(variantUrl, media, MEDIA_TTL_MS)
    }

    private fun firstVariantUri(master: String): String? {
        var next = false
        for (raw in master.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXT-X-STREAM-INF")) { next = true; continue }
            if (next && line.isNotEmpty() && !line.startsWith("#")) return line
        }
        return null
    }

    private fun put(url: String, bytes: ByteArray, ttl: Long) {
        val now = SystemClock.elapsedRealtime()
        cache.entries.removeAll { it.value.expiresAt < now }
        if (cache.size >= MAX_ENTRIES) cache.keys.firstOrNull()?.let { cache.remove(it) }
        cache[url] = Entry(bytes, now + ttl)
    }

    private fun download(url: String, ua: String?, ref: String?): ByteArray? {
        val rb = Request.Builder().url(url)
            .header("User-Agent", ua?.takeIf { it.isNotBlank() } ?: STREAM_DEFAULT_UA)
        ref?.takeIf { it.isNotBlank() }?.let { rb.header("Referer", it) }
        StreamHttp.client.newCall(rb.build()).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body ?: return null
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            body.byteStream().use { s ->
                while (true) {
                    val n = s.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_BYTES) return null
                }
            }
            val bytes = out.toByteArray()
            // Yalnız həqiqi M3U8 (BOM/boşluqdan sonra #EXTM3U).
            val head = String(bytes, 0, minOf(bytes.size, 16), Charsets.UTF_8).trimStart('\uFEFF', ' ', '\n', '\r', '\t')
            return if (head.startsWith("#EXTM3U")) bytes else null
        }
    }
}

/** Hazır (əvvəlcədən yüklənmiş) manifest varsa onu, yoxdursa şəbəkəni (upstream) oxuyan DataSource. */
@androidx.annotation.OptIn(UnstableApi::class)
class PrefetchDataSourceFactory(private val upstream: DataSource.Factory) : DataSource.Factory {
    override fun createDataSource(): DataSource = PrefetchDataSource(upstream.createDataSource())
}

@androidx.annotation.OptIn(UnstableApi::class)
private class PrefetchDataSource(private val upstream: DataSource) : DataSource {
    private var active: DataSource = upstream
    private val listeners = ArrayList<TransferListener>()

    override fun addTransferListener(transferListener: TransferListener) {
        listeners.add(transferListener)
        upstream.addTransferListener(transferListener)
    }

    override fun open(dataSpec: DataSpec): Long {
        val hit = if (dataSpec.position == 0L && dataSpec.length == C.LENGTH_UNSET.toLong()) {
            ManifestPrefetch.take(dataSpec.uri.toString())
        } else null
        active = if (hit != null) {
            ByteArrayDataSource(hit).also { ds -> listeners.forEach { ds.addTransferListener(it) } }
        } else upstream
        return active.open(dataSpec)
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int = active.read(buffer, offset, length)

    override fun getUri(): Uri? = active.uri

    override fun getResponseHeaders(): Map<String, List<String>> = active.responseHeaders

    override fun close() {
        try { active.close() } finally { active = upstream }
    }
}
