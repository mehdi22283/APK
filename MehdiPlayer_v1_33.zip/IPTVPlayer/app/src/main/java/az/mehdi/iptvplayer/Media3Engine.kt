package az.mehdi.iptvplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.SurfaceView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.metadata.MetadataOutput
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import androidx.media3.exoplayer.video.VideoRendererEventListener
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** Playlist/manifest sorğularında istifadə olunan standart User-Agent (kanalın öz UA-sı yoxdursa). */
internal const val STREAM_DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"

/** Media3 üçün HTTP müştərisi (OkHttp): vaxtı keçmiş/özü imzalı sertifikatlı IPTV serverləri üçün sertifikat yoxlaması söndürülüb. */
internal object StreamHttp {
    val client: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val b = OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .protocols(listOf(Protocol.HTTP_1_1))
            .followRedirects(true)
            .followSslRedirects(true)
            .hostnameVerifier { _, _ -> true }
        runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            b.sslSocketFactory(ctx.socketFactory, trustAll)
        }
        b.build()
    }
}

/**
 * Dekoder rejimi ([DecoderMode]) üzrə renderer-lər:
 *  NORMAL — MediaCodec əvvəl, dəstəkləmirsə FFmpeg; ALL_FFMPEG — səs və video üçün FFmpeg əvvəl;
 *  AUDIO_FFMPEG — səs FFmpeg (proqram) dekoderi ilə, video isə MediaCodec ilə (çık-çık səsin əsas həlli).
 */
@androidx.annotation.OptIn(UnstableApi::class)
private class ModeRenderersFactory(
    private val context: Context,
    private val mode: DecoderMode
) : RenderersFactory {
    private fun make(ffmpegFirst: Boolean): RenderersFactory = NextRenderersFactory(context)
        .setExtensionRendererMode(
            if (ffmpegFirst) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
            else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
        )
        .setEnableDecoderFallback(true)

    override fun createRenderers(
        eventHandler: Handler,
        videoRendererEventListener: VideoRendererEventListener,
        audioRendererEventListener: AudioRendererEventListener,
        textRendererOutput: TextOutput,
        metadataRendererOutput: MetadataOutput
    ): Array<Renderer> {
        fun build(f: RenderersFactory) = f.createRenderers(
            eventHandler, videoRendererEventListener, audioRendererEventListener, textRendererOutput, metadataRendererOutput
        )
        return when (mode) {
            DecoderMode.NORMAL -> build(make(false))
            DecoderMode.ALL_FFMPEG -> build(make(true))
            DecoderMode.AUDIO_FFMPEG -> {
                val base = build(make(false)).filter { it.trackType != C.TRACK_TYPE_AUDIO }
                val audio = build(make(true)).filter { it.trackType == C.TRACK_TYPE_AUDIO }
                (base + audio).toTypedArray()
            }
        }
    }
}

/**
 * Yeganə mühərrik: Media3 (ExoPlayer, OkHttp). http/https (m3u8, mpd, ts, mp4 ...) və Media3-ün özü açan sxemlər.
 *
 * Kanal açılanda yeganə yoxlama OkHttp-dir: HTTP 4xx/5xx və ya qoşulma xətası dərhal xəta verir (yeni cəhd və vaxt aşımı sayğacı yoxdur).
 *
 * Çık-çık səs və donan görüntü özü-özünə həll olunur ([poorQuality]): səs underrun-ları və atılan video kadrlar izlənir,
 * problem olarsa kanal addım-addım yenidən açılır: (1) səs FFmpeg dekoderi ilə, (2) daha böyük bufer, (3) səs+video FFmpeg.
 * Kömək edən rejim kanal üzrə yadda saxlanır ([DecoderMemory]); bufer səviyyəsi PlayerManager-də saxlanır.
 * Bütün çağırışlar yalnız əsas (UI) thread-dədir.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class Media3Engine(
    context: Context,
    private val view: SurfaceView,
    private val callback: PlayerCallback
) {
    companion object {
        private const val TAG = "IPTV-MEDIA3"
        private const val DEFAULT_UA = STREAM_DEFAULT_UA

        // Keyfiyyət nəzarəti ("çık-çık" səs və donan görüntü): oynamağa başladıqdan sonra bu müddət (ms) ölçülmür,
        // çünki açılışda bir-iki underrun/atılmış kadr normaldır.
        private const val QUALITY_GRACE_MS = 4_000L
        // Pəncərə (ms): bu müddətdə hədd aşılarsa kanal problemli sayılır.
        private const val QUALITY_WINDOW_MS = 10_000L
        // Pəncərədə səs underrun sayı (AudioTrack boşalır = çık-çık səs).
        private const val UNDERRUN_LIMIT = 3
        // Pəncərədə atılmış video kadrların cəmi (görüntü donması / titrəməsi).
        private const val DROPPED_FRAMES_LIMIT = 60
        // Bir kanalın açılışında ən çox neçə dəfə özü-özünə düzəliş edilir (sonsuz döngü olmasın).
        private const val MAX_HEALS = 3

        // MPEG-TS (IPTV-də ən çox rast gəlinən): AUD olmayan H.264, non-IDR açar kadrlar, HDMV DTS səsi.
        private const val TS_FLAGS =
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS

        // İcra zamanı dekoder xətaları: FFmpeg-i MediaCodec-dən əvvəl qoymaq kömək edə bilər.
        private fun isDecoderRuntimeError(code: Int): Boolean = when (code) {
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED -> true
            else -> false
        }
    }

    private val appContext = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())
    private val memory = DecoderMemory(context)

    private var player: ExoPlayer? = null
    // Hazırkı player hansı dekoder rejimi / bufer səviyyəsi ilə qurulub; yeni açılış hansı ilə başlayır.
    private var playerMode = DecoderMode.NORMAL
    private var playerLevel = 0
    private var mode = DecoderMode.NORMAL
    private var bufLevel = 0
    // false: ehtiyat (yoda.az tokenli) link — rejim yadda saxlanmır.
    private var persist = true
    private var heals = 0
    private var ua: String? = null
    private var ref: String? = null
    private var released = false
    private var generation = 0
    private var url: String? = null
    private var playing = false
    private var buffering = false
    private var lastBufferingAt = 0L
    private var firstFrame = false
    // Açılmış video dekoderinin adı (TV-də hardware/proqram yolunu göstərmək üçün).
    private var videoDecoder = ""
    private var hasVideoGroup = false
    private var tracksKnown = false
    // Dolby/DTS passthrough: AudioTrack kodlaşdırması PCM deyilsə səs dekod edilmədən TV-yə ötürülür (etiket: AC3, EAC3, DTS ...).
    private var passthroughLabel = ""
    // Keyfiyyət nəzarəti: underrun vaxtları və atılmış kadrlar (vaxt, say).
    private var playingAt = 0L
    private val underrunTimes = ArrayDeque<Long>()
    private val droppedEvents = ArrayDeque<Pair<Long, Int>>()
    private val speed = SpeedMeter()

    /** Açılmazdan əvvəl HTTP 4xx/5xx cavabı alınarsa təkrar cəhd olmadan dərhal xəta (OkHttp yoxlaması). */
    private inner class FastFailPolicy : DefaultLoadErrorHandlingPolicy(1) {
        override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long {
            val e = loadErrorInfo.exception
            if (!playing && e is HttpDataSource.InvalidResponseCodeException && e.responseCode >= 400) return C.TIME_UNSET
            return super.getRetryDelayMsFor(loadErrorInfo)
        }
    }

    private val listener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            if (!isCurrent()) return
            var v = 0; var vOk = false; var a = 0; var aOk = false
            for (g in tracks.groups) {
                when (g.type) {
                    C.TRACK_TYPE_VIDEO -> { v++; if (g.isSupported(false)) vOk = true }
                    C.TRACK_TYPE_AUDIO -> { a++; if (g.isSupported(false)) aOk = true }
                }
            }
            if (v + a == 0) return // treklər hələ məlum deyil
            hasVideoGroup = v > 0
            tracksKnown = true
            if ((v > 0 && !vOk) || (a > 0 && !aOk)) {
                val what = if (v > 0 && !vOk) "video" else "səs"
                failNow("Media3: $what codec-i dəstəklənmir")
                return
            }
            maybeMarkPlaying()
        }

        override fun onRenderedFirstFrame() {
            if (!isCurrent()) return
            firstFrame = true
            maybeMarkPlaying()
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (!isCurrent()) return
            when (state) {
                Player.STATE_BUFFERING -> if (playing && !buffering) {
                    buffering = true
                    lastBufferingAt = SystemClock.elapsedRealtime()
                    callback.onBuffering(true)
                }
                Player.STATE_READY -> {
                    if (buffering) { buffering = false; callback.onBuffering(false) }
                    maybeMarkPlaying()
                }
                Player.STATE_ENDED -> failNow("Yayım bitdi")
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            if (!isCurrent()) return
            Log.w(TAG, "Xəta: ${error.errorCodeName}", error)
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                // HLS: bufer uzun donub, köhnə seqmentlər serverdən silinib: yeganə çıxış canlı yayımın cari yerinə keçməkdir.
                player?.let { it.seekToDefaultPosition(); it.prepare() }
                return
            }
            // Dekoder açılmadı/dekodlama xətası: bir dəfə FFmpeg dekoderləri əvvəl ilə yenidən açılır.
            val u = url
            if (u != null && isDecoderRuntimeError(error.errorCode) && mode != DecoderMode.ALL_FFMPEG && heals < MAX_HEALS) {
                mode = DecoderMode.ALL_FFMPEG
                heals++
                Log.w(TAG, "Media3: ${error.errorCodeName} → FFmpeg dekoderləri əvvəl ilə təkrar cəhd")
                restart(u)
                return
            }
            failNow("Media3: ${error.errorCodeName}")
        }
    }

    private val analytics = object : AnalyticsListener {
        override fun onVideoDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long
        ) {
            videoDecoder = decoderName
            Log.i(TAG, "Video dekoder: $decoderName (proqram=${TvProfile.isSoftwareDecoder(decoderName)})")
        }

        override fun onAudioTrackInitialized(eventTime: AnalyticsListener.EventTime, audioTrackConfig: AudioSink.AudioTrackConfig) {
            if (!isCurrent()) return
            val enc = audioTrackConfig.encoding
            passthroughLabel = if (AudioPassthrough.isPassthroughEncoding(enc)) AudioPassthrough.label(enc) else ""
            Log.i(TAG, "AudioTrack kodlaşdırması=$enc passthrough=${passthroughLabel.ifEmpty { "yox (PCM)" }}")
        }

        override fun onAudioUnderrun(
            eventTime: AnalyticsListener.EventTime,
            bufferSize: Int,
            bufferSizeMs: Long,
            elapsedSinceLastFeedMs: Long
        ) {
            if (!isCurrent() || !playing) return
            val now = SystemClock.elapsedRealtime()
            if (now - playingAt < QUALITY_GRACE_MS) return
            underrunTimes.addLast(now)
            while (underrunTimes.isNotEmpty() && now - underrunTimes.first() > QUALITY_WINDOW_MS) underrunTimes.removeFirst()
            if (underrunTimes.size >= UNDERRUN_LIMIT) poorQuality(true, "səs keyfiyyəti aşağıdır (underrun)")
        }

        override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
            if (!isCurrent() || !playing) return
            val now = SystemClock.elapsedRealtime()
            if (now - playingAt < QUALITY_GRACE_MS) return
            droppedEvents.addLast(now to droppedFrames)
            while (droppedEvents.isNotEmpty() && now - droppedEvents.first().first > QUALITY_WINDOW_MS) droppedEvents.removeFirst()
            if (droppedEvents.sumOf { it.second } >= DROPPED_FRAMES_LIMIT) poorQuality(false, "video keyfiyyəti aşağıdır (atılan kadrlar)")
        }
    }

    /**
     * Səs çık-çık edir və ya görüntü donur: kanal özü-özünə addım-addım düzəldilir.
     *  - səs problemi və rejim NORMAL: səs dekoderi FFmpeg olur (MediaCodec səs dekoderinin xətaları aradan qalxır);
     *  - sonra: kanalın bufer səviyyəsi bir pillə qalxır (PlayerManager yadda saxlayır);
     *  - sonra: səs və video FFmpeg dekoderləri.
     * Hər düzəlişdən sonra kanal yenidən açılır; ən çox [MAX_HEALS] dəfə.
     */
    private fun poorQuality(audioProblem: Boolean, reason: String) {
        underrunTimes.clear()
        droppedEvents.clear()
        val u = url ?: return
        if (released || heals >= MAX_HEALS) return
        val action = when {
            audioProblem && mode == DecoderMode.NORMAL -> { mode = DecoderMode.AUDIO_FFMPEG; "səs FFmpeg dekoderi ilə" }
            bufLevel < BufferProfile.MAX_LEVEL -> { bufLevel++; callback.onBufferLevel(bufLevel); "bufer səviyyəsi $bufLevel" }
            // TV-də video proqram (FFmpeg) dekoderinə keçirilmir: TV-nin hardware şəkil yolu (AI upscaling, HDR, MEMC) itərdi,
            // 4K-nı CPU dekod edə də bilməz. Dekoder tam açılmasa onPlayerError ayrıca ALL_FFMPEG-ə keçir.
            mode != DecoderMode.ALL_FFMPEG && !TvProfile.of(appContext).isTv -> { mode = DecoderMode.ALL_FFMPEG; "səs+video FFmpeg dekoderləri ilə" }
            else -> return
        }
        heals++
        Log.w(TAG, "Media3 $reason → $action təkrar açılır ($heals/$MAX_HEALS)")
        restart(u)
    }

    /** Eyni linki cari rejim/bufer səviyyəsi ilə növbəti döngədə yenidən açır (köhnə player-in gecikmiş hadisələri ignor edilir). */
    private fun restart(u: String) {
        val gen = ++generation
        playing = false
        ui.post { if (!released && url == u && generation == gen) start(u) }
    }

    private fun isCurrent(): Boolean {
        val p = player ?: return false
        return !released && url != null && p.currentMediaItem?.mediaId == generation.toString()
    }

    /** Player-i buraxır (video səthi də azad edilir); rejim dəyişəndə yenisi qurulur. */
    private fun discardPlayer() {
        player?.let { runCatching { it.removeListener(listener); it.removeAnalyticsListener(analytics); it.clearVideoSurfaceView(view); it.release() } }
        player = null
    }

    private fun ensurePlayer(): ExoPlayer {
        if (player != null && (playerMode != mode || playerLevel != bufLevel)) discardPlayer()
        player?.let { return it }
        playerMode = mode
        playerLevel = bufLevel
        // Cihazın birbaşa (passthrough) oynada bildiyi Dolby/DTS formatları loqa yazılır.
        AudioPassthrough.caps(appContext)
        // Bufer həddi cihazın RAM-ına görə: 3 GB-lı TV-də (TCL 65C6K) 48 MB (4K axınlar), digər cihazlarda 24 MB.
        // Başlama/davam həddi kanalın bufer səviyyəsindən asılıdır.
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 20_000, BufferProfile.startMs(bufLevel), BufferProfile.rebufferMs(bufLevel))
            .setTargetBufferBytes(TvProfile.targetBufferBytes(appContext))
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        val p = ExoPlayer.Builder(appContext, ModeRenderersFactory(appContext, mode))
            .setLoadControl(load)
            .build()
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            false
        )
        // TV: yayımın kadr tezliyinə (25/50/60 fps) görə ekran rejimi yalnız fasiləsiz (qara ekransız) keçid mümkündürsə dəyişir;
        // TV-nin sistem ayarındakı "Match content frame rate" bunu idarə edir. 144 Hz panelli TCL-də kadr atlama/judder azalır.
        p.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS)
        p.addListener(listener)
        p.addAnalyticsListener(analytics)
        player = p
        return p
    }

    private fun maybeMarkPlaying() {
        if (playing || url == null) return
        val p = player ?: return
        if (p.playbackState != Player.STATE_READY) return
        // Görüntülü yayım: ilk kadr çəkilib; yalnız səs (radio): video qrupu yoxdur.
        if (!(firstFrame || (tracksKnown && !hasVideoGroup))) return
        playing = true
        playingAt = SystemClock.elapsedRealtime()
        underrunTimes.clear()
        droppedEvents.clear()
        // Kanal bu rejimdə açıldı: növbəti dəfə birbaşa bu rejimlə başlayır.
        if (persist) url?.let { memory.remember(it, mode) }
        callback.onPlaying()
    }

    private fun failNow(message: String) {
        playing = false
        callback.onFailed(message)
    }

    fun play(newUrl: String, ua: String?, ref: String?, level: Int = 0, persist: Boolean = true) {
        if (released) return
        this.bufLevel = level.coerceIn(0, BufferProfile.MAX_LEVEL)
        this.ua = ua
        this.ref = ref
        this.persist = persist
        // Yeni kanal: yadda saxlanmış rejim; təkrar qoşulmada (eyni link) cari rejim saxlanır.
        if (newUrl != url) {
            mode = if (persist) memory.mode(newUrl) else DecoderMode.NORMAL
            heals = 0
        }
        start(newUrl)
    }

    private fun start(newUrl: String) {
        if (released) return
        val g = ++generation
        url = newUrl
        playing = false
        buffering = false
        firstFrame = false
        videoDecoder = ""
        passthroughLabel = ""
        hasVideoGroup = false
        tracksKnown = false
        speed.reset()
        underrunTimes.clear()
        droppedEvents.clear()
        try {
            val p = ensurePlayer()
            // Kadrı kəsmə; SurfaceView sahəsinə uyğun miqyasla.
            p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            p.stop()
            p.clearMediaItems()
            val http = OkHttpDataSource.Factory(StreamHttp.client)
                .setUserAgent(ua?.takeIf { it.isNotBlank() } ?: DEFAULT_UA)
            ref?.takeIf { it.isNotBlank() }?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
            val low = newUrl.lowercase()
            val item = MediaItem.Builder()
                .setUri(newUrl)
                .setMediaId(g.toString())
                // Buferlənmədən sonra canlı yayımın sonuna yetişmək üçün sürətləndirmə YOXDUR: qaldığı yerdən 1x ilə davam edir.
                .setLiveConfiguration(
                    MediaItem.LiveConfiguration.Builder()
                        .setMinPlaybackSpeed(1f)
                        .setMaxPlaybackSpeed(1f)
                        .build()
                )
                .apply {
                    when {
                        low.contains(".m3u8") -> setMimeType(MimeTypes.APPLICATION_M3U8)
                        low.contains(".mpd") -> setMimeType(MimeTypes.APPLICATION_MPD)
                    }
                }
                .build()
            // Qonşu kanalların əvvəlcədən yüklənmiş HLS manifestləri (ManifestPrefetch) varsa şəbəkəyə getmədən verilir.
            val ds = PrefetchDataSourceFactory(DefaultDataSource.Factory(appContext, http))
            val src = if (low.contains(".m3u8")) {
                HlsMediaSource.Factory(ds)
                    .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, false))
                    .setLoadErrorHandlingPolicy(FastFailPolicy())
                    .createMediaSource(item)
            } else {
                DefaultMediaSourceFactory(ds, DefaultExtractorsFactory().setTsExtractorFlags(TS_FLAGS))
                    .setLoadErrorHandlingPolicy(FastFailPolicy())
                    .createMediaSource(item)
            }
            p.setVideoSurfaceView(view)
            p.setMediaSource(src)
            p.prepare()
            p.playWhenReady = true
        } catch (t: Throwable) {
            Log.e(TAG, "Media3 başladılmadı", t)
            ui.post { if (!released && g == generation && url != null) failNow("Media3 işə düşmədi") }
        }
    }

    fun stop() {
        generation++
        url = null
        playing = false
        buffering = false
        player?.let { runCatching { it.stop(); it.clearMediaItems() } }
    }

    fun stopForBackground() = stop()

    fun togglePause() {
        val p = player ?: return
        if (released || !playing) return
        p.playWhenReady = !p.playWhenReady
    }

    /** Oynatma mövqeyi (ms); yayım donanda dəyişmir. Naməlum: -1. */
    fun position(): Long {
        val p = player ?: return -1L
        return if (!playing) -1L else p.currentPosition
    }

    fun stats(): PlayerStats? {
        val p = player ?: return null
        if (released || !playing) return null
        val now = SystemClock.elapsedRealtime()
        val level = when {
            buffering -> 2
            now - lastBufferingAt < 12_000L -> 1
            else -> 0
        }
        val bps = speed.sample(uidRxBytes(), now)
        val vb = p.videoFormat?.bitrate ?: -1
        val ab = p.audioFormat?.bitrate ?: -1
        val trackBr = if (vb > 0) (vb + maxOf(ab, 0)).toLong() else 0L
        val br = if (trackBr > 0) trackBr else bps
        val size = p.videoSize
        val vf = p.videoFormat
        val hdr = when {
            vf?.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION -> "DV"
            vf?.colorInfo?.colorTransfer == C.COLOR_TRANSFER_ST2084 -> "HDR10"
            vf?.colorInfo?.colorTransfer == C.COLOR_TRANSFER_HLG -> "HLG"
            else -> ""
        }
        val path = if (videoDecoder.isNotBlank() && TvProfile.isSoftwareDecoder(videoDecoder)) "SW" else "" // HW yazılmır
        // Dolby/DTS dekod edilmədən ötürülürsə format adı + PT (məs. "AC3 PT").
        val pt = if (passthroughLabel.isNotEmpty()) "$passthroughLabel PT" else ""
        val tag = listOf(path, hdr, pt).filter { it.isNotEmpty() }.joinToString(" ")
        return PlayerStats(size.width, size.height, p.totalBufferedDuration, level, bps, "", br, tag)
    }

    fun release() {
        if (released) return
        released = true
        generation++
        url = null
        player?.let { runCatching { it.removeListener(listener); it.removeAnalyticsListener(analytics); it.release() } }
        player = null
    }
}
